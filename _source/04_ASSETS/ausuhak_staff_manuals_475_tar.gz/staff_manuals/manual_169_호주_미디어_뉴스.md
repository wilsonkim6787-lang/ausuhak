# #169 호주 미디어 / 뉴스 / 영어 뉴스 학습

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 뉴스 어디서 봐요? 한국 뉴스 같이 볼 수 있어요? TV 어떻게 봐요? 영어 공부에 좋은 채널 있어요?"

**직원 멘붕 포인트:**
- 호주 미디어 시스템 모름 (ABC, Free TV)
- 한국 미디어 호주 접근 모름 (Naver, Kakao)
- 영어 학습용 미디어 모름

---

## ❌ 절대 하지 말아야 할 답

> "호주 뉴스는 ABC 보세요!"

→ ABC만 있는 게 아님. 학생 수준에 맞는 미디어 안내 필요.

---

## ✅ 정답

호주는 공영방송 ABC, SBS와 상업 방송 (Seven, Nine, Ten) 모두 무료. 한국 뉴스는 Naver, Kakao, KBS World 등 쉽게 접근 가능. 영어 학습에는 ABC, BBC, SBS Easy News 추천. 무료 시청 방법 알려드릴게요.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 무료 TV 채널
**공영방송 (Public):**
- **ABC** (Australian Broadcasting Corporation)
  - ABC1: 메인 채널, 뉴스
  - ABC News: 24시간 뉴스
  - ABC Kids / ABC ME: 어린이
  - ABC iView: 무료 온라인 (회원가입)
- **SBS** (Special Broadcasting Service)
  - SBS One: 메인, 다문화
  - SBS World News: 국제 뉴스
  - SBS Food: 음식
  - SBS On Demand: 무료 온라인

**상업방송 (Commercial):**
- **Seven Network** (7, 7Two, 7Mate, 7Plus)
- **Nine Network** (9, 9Gem, 9Go, 9Now)
- **Ten Network** (10, 10 Bold, 10 Peach, 10 Play)

→ 무료 안테나 또는 무료 앱 (iView, On Demand, 7Plus, 9Now, 10Play)

### 2. 호주 신문 / 뉴스 사이트
**무료 (Free):**
- **ABC News:** abc.net.au/news (가장 신뢰)
- **SBS News:** sbs.com.au/news (다문화)
- **The Guardian Australia:** theguardian.com/au
- **The Conversation:** theconversation.com (학술)

**유료 (Paywall):**
- **The Sydney Morning Herald:** smh.com.au
- **The Age (Melbourne):** theage.com.au
- **The Australian:** theaustralian.com.au (국가 신문, 보수)
- **Australian Financial Review:** afr.com (경제)

**무료 신문 (도시):**
- **Daily Mail Australia, news.com.au:** 황색 언론, 무료
- **mX (도시 무료 신문):** 폐간

**라디오:**
- **ABC Radio National:** 시사
- **Triple J:** 청년 음악/뉴스
- **2GB (Sydney), 3AW (Melbourne):** 토크 라디오

### 3. 한국 뉴스 호주에서 보기
**무료 (Free):**
- **Naver, Daum, 카카오:** 호주에서 모두 접속 가능
- **KBS World, MBC News, SBS News:** 유튜브 무료
- **YTN, JTBC, MBN:** 유튜브 채널
- **연합뉴스, 한겨레, 조선일보:** 웹사이트 무료

**유료 (Paid):**
- **Wavve, Tving, KBS World+:** 한국 IP 우회 필요 (VPN)
- **Coupang Play:** 한국 콘텐츠

**한인 호주 미디어:**
- **호주나라:** hojunara.com (한인 뉴스/생활정보)
- **TOP DIGITAL:** topdigital.com.au
- **호주동아:** dongahnews.com.au

### 4. 영어 학습용 미디어
**초급 (Beginner):**
- **SBS Easy News:** sbs.com.au/news/easy-english (쉬운 영어)
- **ABC Kids News:** 어린이용 뉴스
- **News in Slow English** (앱)

**중급 (Intermediate):**
- **ABC News (TV):** 정확한 발음
- **The Project (Channel 10):** 가벼운 시사
- **6 Minute English (BBC):** 영어 학습 팟캐스트

**고급 (Advanced):**
- **Q+A (ABC):** 시사 토론
- **4 Corners (ABC):** 심층 보도
- **Insight (SBS):** 사회 토론
- **Foreign Correspondent (ABC):** 국제 보도

**팟캐스트:**
- **ABC News Daily:** 매일 10분 뉴스
- **The Daily (NYT):** 미국 뉴스 (호주에서 무료)
- **The Australian Politics Podcast:** 정치

### 5. 스트리밍 서비스 (호주)
**유료 (Paid):**
- **Netflix:** $13~$26/월
- **Disney+:** $14/월
- **Prime Video:** $10/월
- **Stan (호주 자체):** $10~$22/월
- **Apple TV+:** $13/월
- **Binge (Foxtel):** $14~$22/월
- **Paramount+:** $10/월

**무료 (Free, BVOD):**
- **ABC iView, SBS On Demand**
- **7Plus, 9Now, 10Play** (광고 포함)
- **Tubi, Pluto TV** (무료 영화)

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. 호주 무료 미디어 안내
- TV: 안테나 또는 무료 앱
- 뉴스: ABC, SBS (무료)
- 영어 학습: SBS Easy News, ABC

### Step 2. 한국 뉴스 접근
- Naver, Kakao 자유 접속
- KBS World, MBC 유튜브 무료
- 한인 호주 미디어 (호주나라)

### Step 3. 영어 학습용 미디어 추천
- 초급: SBS Easy News
- 중급: ABC News
- 고급: Q+A, 4 Corners

### Step 4. 스트리밍 (학생 예산)
- 무료: iView, On Demand, 7Plus, 9Now
- 유료: Netflix $13/월 (가성비)
- 학생 할인: Apple TV+ Student

### Step 5. 한국 콘텐츠 (드라마/영화)
- Netflix Korea 드라마
- Wavve/Tving = VPN 필요
- 유튜브 KBS World

---

## 💡 직원이 학생한테 말할 멘트

> "호주 미디어 무료 자료 많아요! 한국 뉴스도 쉽게 보실 수 있고요.
>
> **호주 무료 TV (앱 무료):**
> - ABC iView (메인)
> - SBS On Demand
> - 7Plus, 9Now, 10Play
>
> **호주 뉴스 (무료 사이트):**
> - ABC News: abc.net.au/news (가장 신뢰)
> - SBS News (다문화)
> - The Guardian Australia
>
> **한국 뉴스 (호주에서 무료):**
> - Naver, Kakao, Daum (그대로 접속)
> - KBS World, MBC, SBS (유튜브 무료)
> - YTN, JTBC, MBN 유튜브 채널
> - 한인 호주 미디어: 호주나라(hojunara.com), TOP DIGITAL
>
> **영어 학습 추천:**
> - 초급: SBS Easy News (쉬운 영어)
> - 중급: ABC News (정확한 발음)
> - 고급: Q+A, 4 Corners (심층 보도)
> - 팟캐스트: 'ABC News Daily' (매일 10분)
>
> **유료 스트리밍:**
> - Netflix $13~$26/월 (가성비)
> - Stan (호주 자체) $10/월
> - Disney+, Prime Video, Apple TV+
>
> **한국 콘텐츠:**
> - Netflix Korea 드라마 (호주 Netflix에 일부)
> - Wavve/Tving = VPN 필요
> - 유튜브 무료
>
> 어느 도시 가시나요? 영어 수준은요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. ABC만 있다고 생각
- ABC 외에도 SBS, Seven, Nine, Ten 무료
- 다양하게 시청 가능

### 함정 2. 한국 사이트 차단
- ❌ 차단 X
- Naver/Kakao 자유 접속

### 함정 3. 한국 스트리밍 (Wavve/Tving)
- 호주 IP 차단됨
- VPN 필요 (월 $5~$15)
- 또는 한국 가족 계정 사용

### 함정 4. 영어 학습 = 무조건 BBC
- BBC도 좋지만 호주 학생 = 호주 영어 우선
- ABC, SBS 호주 발음 익숙해지기

### 함정 5. 무료 = 광고 X
- 무료 BVOD는 광고 多 (15~30초)
- 광고 없는 = 유료 (iView 일부 무광고)

### 함정 6. 한국 신문 호주 발행
- 호주나라, TOP DIGITAL (한인 발행)
- 한국 본사 신문 (조선일보, 한겨레) = 한국 사이트
- 두 가지 차이 인지

### 함정 7. 학생 할인
- Spotify Student $5/월 (1년)
- Apple TV+ Student
- Amazon Prime Student 6개월 무료

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **영어 수준?** (IELTS, TOEIC) → 미디어 추천
2. **한국 콘텐츠 자주 보시나요?** → VPN 필요 여부
3. **TV 시청 시간?** → 무료 vs 유료
4. **학습 목표?** → 시사, 일상, 비즈니스

---

## 🔍 직원이 직접 확인 가능한 사이트

- **ABC iView:** iview.abc.net.au
- **SBS On Demand:** sbs.com.au/ondemand
- **The Guardian Australia:** theguardian.com/au
- **호주나라:** hojunara.com
- **TOP DIGITAL:** topdigital.com.au
- **SBS Easy News:** sbs.com.au/news/easy-english

---

## 🚨 직원 영역 vs 윌슨 영역

| 직원 가능 | 윌슨 영역 |
|-----------|-----------|
| 호주 미디어 일반 | 학생 1:1 영어 코칭 |
| 한국 뉴스 접근 | - |
| 영어 학습 미디어 | - |
| 스트리밍 서비스 | - |

---

## ✅ 완벽 응대 체크리스트

- [ ] 호주 무료 TV (ABC, SBS, Seven 등)
- [ ] 호주 뉴스 사이트
- [ ] 한국 뉴스 호주 접근 (Naver 등)
- [ ] 한인 호주 미디어 (호주나라)
- [ ] 영어 학습 (SBS Easy News, ABC)
- [ ] 팟캐스트 추천
- [ ] 스트리밍 (Netflix 등)
- [ ] VPN 필요 (한국 Wavve)
- [ ] 학생 할인
- [ ] 영어 수준 확인

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 미디어/학습
