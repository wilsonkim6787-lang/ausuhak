# #274 호주 학생 정신과 진료

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 와서 우울증이 심해졌어요. 정신과 가야 할 것 같은데 어디로 가야 하나요?"

**직원 멘붕 포인트:**
- 호주 정신과 = Psychiatrist (의사)
- GP → Mental Health Plan → Psychologist (상담)
- Lifeline 13 11 14 = 24시간 무료
- OSHC / Medicare 일부 환급

---

## ❌ 절대 하지 말아야 할 답

> "한국 가서 정신과 보세요."

→ ❌ **호주 정신과 시스템 = 활용 가능**.

---

## ✅ 정답

호주 정신건강: ① **GP 1차** = Mental Health Care Plan 작성 ② **Psychologist** = 상담 (10세션 보조 / Medicare) ③ **Psychiatrist** = 의사 + 약 처방 (전문의) ④ **Lifeline 13 11 14** = 24시간 위기 ⑤ **Beyond Blue 1300 22 4636** = 우울/불안 전문 ⑥ **OSHC** = 부분 환급 ⑦ **학교 Counsellor** = 무료 (1차).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 위기 라인 (즉시)**
Lifeline = 13 11 14 (24시간 / 무료) / Beyond Blue = 1300 22 4636 / Suicide Call Back = 1300 659 467 / Kids Helpline = 1800 55 1800

**2. Mental Health Care Plan**
GP가 작성 / Medicare 보조 / Psychologist 10세션 + Psychiatrist 5세션 / PR / 시민권 적용 / 학생 = OSHC 별도

**3. Psychologist (상담)**
면허 상담사 / 1세션 $200~$300 / Medicare = 약 $89 환급 / 학생 OSHC = 부분 / Bulk Billing 일부 무료

**4. Psychiatrist (의사)**
정신과 의사 / 약 처방 / GP Referral 필수 / 1세션 $300~$500 / Medicare = 약 $200 환급

**5. 학교 Counselling Service**
모든 대학 + 일부 학교 무료 / Student Wellbeing Service / 5~10세션 / 영어 / 한국어 가능 학교 일부

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 위기 시 = Lifeline 13 11 14 (24시간)
**2단계**: GP 방문 → Mental Health Care Plan
**3단계**: Psychologist 또는 Psychiatrist 의뢰
**4단계**: 학교 Counselling Service 무료 활용
**5단계**: 윌슨 1:1 상담 (한국어)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 정신과 시스템 활용 충분히 가능해요. 위기 상황 (자살 충동 등)은 즉시 Lifeline 13 11 14 (24시간 무료) 전화하세요. 일반 우울/불안은 GP 가서 Mental Health Care Plan 받으면 Psychologist 10세션 + Psychiatrist 5세션 보조받을 수 있어요. 학생은 OSHC가 일부 환급하고, 학교 Counselling Service는 5~10세션 무료입니다. 한국어 상담은 일부 한인 Psychologist 가능해요. 윌슨님이 1:1로 상담 + 한인 정신과 매칭 + 케어 계획 드려요. 카카오 (studywilson)으로 상황 알려주세요. **위기 상황은 지금 즉시 Lifeline 13 11 14 전화하세요.**"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **정신과 = 한국만 ❌**
   → 호주도 활용 가능

2. **Lifeline = 유료 ❌**
   → 24시간 무료

3. **GP = 정신과 X ❌**
   → Mental Health Care Plan + 의뢰

4. **Psychologist = Psychiatrist 동일 ❌**
   → Psychologist = 상담 / Psychiatrist = 의사 + 약

5. **학생 = Mental Health 보조 ❌**
   → Medicare = PR / 시민권 / 학생 = OSHC

6. **학교 Counselling = 비용 ❌**
   → 대부분 무료

7. **정신과 약 = 호주 약 X ❌**
   → GP / Psychiatrist 처방 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 상태 (위기 / 일반 우울)
2. 한국어 상담 필요 여부
3. OSHC 가입 + 환급
4. 학교 Counselling 활용 가능 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Lifeline: 13 11 14 (24시간)
- Beyond Blue: 1300 22 4636
- Headspace: https://headspace.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 한인 Psychologist 매칭
- 위기 상담 1:1
- GP / 학교 Counselling 가이드

**MARA / 변호사 영역**
- 정신과 약 부작용 + 의료 분쟁
- 정신병원 입원 + 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 위기 = Lifeline 13 11 14 (24시간)
- [ ] GP → Mental Health Care Plan
- [ ] Psychologist (상담) vs Psychiatrist (의사+약)
- [ ] Medicare = PR/시민권 / OSHC = 학생
- [ ] 학교 Counselling = 무료
- [ ] Beyond Blue / Headspace 자원
- [ ] 윌슨 1:1 = 한인 매칭
- [ ] 윌슨 카카오 자연 유도
