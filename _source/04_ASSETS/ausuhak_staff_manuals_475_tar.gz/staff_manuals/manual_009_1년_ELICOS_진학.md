# 📚 직원 응대 매뉴얼 #009

**케이스: 22세 / 1년 어학연수 + 대학 진학 / 5천만 예산**

---

## 🎬 상황 시뮬레이션

> 22살이고요. 1년 어학연수 후에 호주 대학 가고 싶어요. 어떤 식으로 진행해야 하나요? 1년 5천만 예산이에요.

**👉 정답**: **ELICOS 1년 (General + IELTS + EAP) → Direct Entry 또는 IELTS 시험 → 학사/Pathway**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 1년 어학연수 = ELICOS 30~52주

- 학생비자(subclass 500): 12주 이상부터 가능
- 1년 = 약 40-52주 (학기 휴식 포함)
- General English (GE) → IELTS 준비 → EAP 순서로 레벨업
- **EAP는 학생 선택 사항** (필수 아님)

### 2️⃣ Direct Entry 시스템 (EAP 코스 졸업 시 가능)

**EAP** = English for Academic Purposes = 학술 영어 코스

- EAP 졸업 시 일반 코스 입학 IELTS 시험 면제 (Direct Entry) 가능
- 단, **간호 등 의료직은 면제 안 됨** (별도 IELTS 7.0 시험 必)
- 어학원-대학 파트너십 = 자동 진학 가능
- 일반 IELTS 시험 응시도 가능 (학생 선택)

### 3️⃣ EAP → Direct Entry 시스템 학교 예시

| 어학원 | 진학 가능 대학 |
|---|---|
| ELS Universal English | UTS / 일부 대학 |
| Navitas English | Navitas 패스웨이 대학 |
| Embassy English (운영 중) | 다양한 학교 |
| ILSC | UTS Insearch / SIBT 등 |
| IH Sydney (폐교 전) | 영구 폐교 / 회피 |

### 4️⃣ ELICOS 학비 (1년 기준)

| 도시 | 주당 | 1년 (40주) |
|---|---|---|
| 시드니 | $400~$500 | $16,000~$20,000 |
| 멜번 | $380~$480 | $15,200~$19,200 |
| 브리즈번 | $350~$450 | $14,000~$18,000 |
| Adelaide | $320~$420 | $12,800~$16,800 |

### 5️⃣ 1년 후 진학 옵션

| 영어 도달 수준 | 진학 옵션 |
|---|---|
| IELTS 5.5 | Diploma → Bachelor 2학년 |
| IELTS 6.0 | 일반 대학 Bachelor / Foundation 단축 |
| IELTS 6.5 | Go8 (일부 학과) |
| IELTS 7.0+ | 의료직 / Master 가능 |

---

## 🎯 정답 경로

### 옵션 A. 어학연수 1년 → Diploma Pathway → Bachelor

```
ELICOS 1년 (General → EAP) - $15K~$20K
        ↓ Direct Entry (IELTS 면제)
Diploma 1년 ($28K~$38K)
        ↓ 1년 학점 인정
Bachelor 2학년 직진 (2년) ($48K~$60K)
        ↓
졸업 + 485
```

**총 4년 호주 / 학비 약 $90K~$120K**

---

## 💡 직원이 학생한테 말할 멘트

> "22세 1년 어학연수 + 대학 진학, 좋은 계획이에요.
> 
> 핵심은 **EAP(학술 영어) 코스 + Direct Entry 시스템** 활용입니다.
> 
> 1. **ELICOS 1년** (General → IELTS → EAP) = $15K~$20K
> 2. **EAP 졸업 시 IELTS 면제** = 학교 직접 진학 (단 간호 등 의료직 제외)
> 3. **Diploma → Bachelor 2학년 편입** = 1년 단축
> 
> 1년 5천만 예산이면 어학연수 + 학사 1학년 학비까지 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 현재 영어 수준 (IELTS / 토익)  
> ② 희망 전공  
> ③ Go8 vs 일반 대학"

---

## ⚠️ 함정

1. **"어학연수 끝나면 무조건 IELTS 면제"** → ❌ EAP 코스만 가능, GE는 X
2. **"간호도 EAP로 면제"** → ❌ 간호는 별도 IELTS 7.0
3. **"폐교 어학원 회피"** → IH Sydney, EC English 등 18곳 폐교 (회피 명단)
4. **"한국인 多 어학원도 OK"** → 영어 환경 약하면 EAP 통과 어려움

---

## 📞 카카오 응대 시 필수

1. 현재 영어 수준
2. 희망 전공
3. 1년 후 진학 학교 (Go8 / 일반 / TAFE)
4. 도시 선호 (영어 환경 vs 도시)

---

## 🔍 직원 확인 사이트

- ELICOS Australia: englishaustralia.com.au
- 학교별 EAP Direct Entry 파트너 확인
- 폐교 18곳 회피 명단 (DB 참조)
