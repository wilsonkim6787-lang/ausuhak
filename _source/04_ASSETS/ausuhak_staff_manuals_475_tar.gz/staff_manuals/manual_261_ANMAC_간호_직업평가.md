# #261 ANMAC 간호 직업평가

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 간호 학사 졸업했는데 PR 위해 ANMAC 평가 어떻게 받나요?"

**직원 멘붕 포인트:**
- ANMAC = Australian Nursing & Midwifery Accreditation Council
- RN (Registered Nurse) = ANZSCO 254418
- AHPRA 등록 ≠ ANMAC 평가
- 호주 졸업자 = 자동 인정 (Pathway A)

---

## ❌ 절대 하지 말아야 할 답

> "AHPRA 등록만 받으면 PR 신청 가능합니다."

→ ❌ **AHPRA = 면허 / ANMAC = PR 직업평가 별개**.

---

## ✅ 정답

ANMAC 간호 평가: ① **Australian Nursing & Midwifery Accreditation Council** = 간호 PR 직업평가 ② **Pathway A** = 호주 ANMAC 인증 코스 졸업 = 자동 ③ **Pathway B** = 한국 간호사 + AHPRA 등록 ④ **수수료 약 $590 AUD** ⑤ **심사 8~12주** ⑥ **AHPRA 등록 별개 필수** ⑦ **ANZSCO 254418 RN**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ANMAC vs AHPRA 차이**
AHPRA = 호주 간호사 면허 (등록) / ANMAC = PR 직업평가 (이민용) / 둘 다 필수 / 별개 신청

**2. Pathway A (호주 졸업)**
ANMAC 인증 호주 Bachelor of Nursing 졸업 / 자동 인정 / AHPRA 등록 증명서 + 졸업증

**3. Pathway B (해외 간호사)**
한국 간호 학사 + 한국 RN 면허 + AHPRA 등록 + IELTS 7 / 추가 학습 가능 (Bridging Program)

**4. 간호 IELTS 절대 7.0**
AHPRA + ANMAC 모두 IELTS 7.0 (각 영역 7.0) / 면제 불가 (간호는 ELICOS Direct Entry 안 됨) / 학위 무관

**5. Bridging Program**
한국 간호사 → 호주 간호사 전환 / IRON (Initial Registration for Overseas Nurses) Program / 약 3개월~12개월 / AHPRA 결정

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: AHPRA 등록 신청 (ahpra.gov.au)
**2단계**: ANMAC 사이트 등록 (anmac.org.au)
**3단계**: Skills Assessment 신청 + 수수료 ($590)
**4단계**: 심사 8~12주 → 결과 → EOI 입력
**5단계**: PR 본 신청 (189 / 190 / 491)

---

## 💡 직원이 학생한테 말할 멘트

> "간호 PR은 AHPRA (면허) + ANMAC (직업평가) 둘 다 필수예요. 호주 간호 학사 졸업자는 Pathway A로 자동 인정되고, AHPRA 등록 + ANMAC 평가만 추가 신청하면 됩니다. 간호는 IELTS 7.0 (각 영역 7) 절대 의무이고 면제 불가입니다. 한국 간호사는 Pathway B인데 AHPRA Bridging Program 거쳐야 할 수도 있어요. 윌슨님이 1:1로 AHPRA + ANMAC 시점 + IELTS 전략 + Bridging 가이드 드려요. 카카오 (studywilson)으로 학력 + 면허 + 영어 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **AHPRA = ANMAC 동일 ❌**
   → AHPRA = 면허 / ANMAC = PR / 별개

2. **간호 IELTS 6 OK ❌**
   → IELTS 7 절대 의무 / 면제 불가

3. **호주 졸업 = AHPRA 자동 ❌**
   → 별도 신청 + 수수료

4. **EN = RN PR ❌**
   → EN (간호조무사) = MLTSSL 없음 / RN만 PR

5. **ANMAC = 1번 영구 ❌**
   → 유효 2년 / 만료 재신청

6. **Bridging Program = 모든 한국 간호사 ❌**
   → AHPRA 결정 / 사람별 차이

7. **ANMAC 미인증 = AHPRA OK ❌**
   → ANMAC 미인증 학교 = AHPRA 거부 = 면허 불가

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 학력 + 면허 (한국 RN / 호주 BN)
2. AHPRA 등록 여부
3. IELTS 7 가능 여부
4. ANMAC 인증 코스 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ANMAC: https://www.anmac.org.au
- AHPRA: https://www.ahpra.gov.au
- NMBA: https://www.nursingmidwiferyboard.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- AHPRA + ANMAC 시점 1:1
- Bridging Program 전략
- EN → RN 편입 경로

**MARA / 변호사 영역**
- AHPRA 등록 거절 + 항소
- PR 거절 + ART 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] AHPRA + ANMAC 둘 다 필수
- [ ] IELTS 7 (각 영역) 절대 의무
- [ ] Pathway A / B 명확
- [ ] EN ≠ RN PR
- [ ] Bridging Program 가능성
- [ ] ANMAC 미인증 = 면허 불가
- [ ] 윌슨 1:1 = 시점 + 전략
- [ ] 윌슨 카카오 자연 유도
