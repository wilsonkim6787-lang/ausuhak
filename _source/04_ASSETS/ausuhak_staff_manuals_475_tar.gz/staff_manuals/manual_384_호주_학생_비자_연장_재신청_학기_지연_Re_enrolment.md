# #384 호주_학생_비자_연장_재신청_학기_지연_Re_enrolment

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제 학생비자가 6개월 후 만료인데 코스가 1년 더 남았어요. 비자 연장 어떻게 해요?"

**직원 멘붕 포인트:**
- Subclass 500 신청료 $2,000 (2025.07부터) + Health Check + OSHC 갱신

---

## ❌ 절대 하지 말아야 할 답

> "학생비자는 자동 연장됩니다."

→ ❌ Subclass 500은 연장 개념 X. 새 비자 재신청만 가능. 현 비자 만료 전 신청 = Bridging Visa A 자동 부여 → 결정 대기 합법 체류. 만료 후 신청 = Bridging Visa C (알바 X).

---

## ✅ 정답

**학생비자 재신청(연장) 가이드** (2026):

**Subclass 500 비자 연장이란?**:
- 호주는 학생비자 "연장" 개념 X
- 새 비자 재신청 = 사실상 연장
- 현 비자 만료 + 새 비자 시작 = 연속 거주

**언제 재신청해야 하는가?**:
- 코스 추가 등록 (Bachelor → Master)
- 코스 연장 (학기 지연/Fail 재수강)
- 다른 학교 추가 코스
- 영어시험 다시 → 본 코스 진입

**재신청 시점**:
- 현 비자 만료 60일 전 신청 권장
- 너무 일찍 (3개월+ 전) = 거부 가능
- 만료 임박 (1주일+) = Bridging Visa C 위험

**재신청 절차**:
1. 새 학교/코스 등록 → New COE 발급
2. ImmiAccount 로그인 (immi.homeaffairs.gov.au)
3. Subclass 500 새 신청서 작성
4. 서류 업로드 + 비용 결제 ($2,000, 2025.07~)
5. Health Check + Biometrics (필요 시)
6. 결정 대기 (4주 ~ 6개월)

**Bridging Visa A (자동 발급)**:
- 현 비자 만료 전 새 비자 신청 시 자동
- 결정 대기 중 합법 체류
- 알바 가능 (학생 주 48시간)
- 한국 출국 시 무효 (재입국 X)

**Bridging Visa B (출국 허용)**:
- BVA 보유자가 출국 필요 시 별도 신청
- 비용 $200
- 호주 재입국 가능

**Bridging Visa C** (만료 후 신청):
- 현 비자 만료 후 신청 시 부여
- 알바 자동 X (별도 신청)
- 출국 = 비자 무효 (재입국 X)
- 비추 → 만료 전 신청 필수

**서류 (재신청)**:
- 여권 사본
- 새 COE 원본
- GTE Statement (한국 귀국 의사 명확)
- 영어 점수 (코스 요건 충족)
- 재정증명 ($29,710 + 학비 + 항공권)
- OSHC 가입증 (코스 기간 커버)
- Health Check (4년 이상 호주 거주 시)
- Police Check (한국 + 호주, 일부 경우)

**비용**:
- 비자 신청 $2,000 (2025.07~)
- Health Check $300~$500
- Biometrics $35
- OSHC 1년 ~$700
- 총 $1,800~$2,500

**거절 사유 (주의)**:
- GTE 부족 (한국 귀국 의사 불명)
- AQF 하향 (Bachelor → Diploma)
- Course Progress 불량 (Fail 다수)
- 재정증명 부족
- Course Hopping (학교 자주 변경)

**Course Hopping 위험**:
- 어학원 → 디플로마 → 다른 디플로마 → 또 다른 학교 = 의심
- 1~2회 변경 = OK / 3회+ = 거절 위험
- GTE Statement에 사유 명확

**한국 학생 표준 패턴**:
- ELICOS 6개월 + Diploma 1.5년 = 비자 2년 (1차)
- Diploma 후 Bachelor 추가 = 비자 재신청 (2차) = 3년
- Bachelor 후 Master = 재신청 (3차) = 2년
- Master 후 485 = 재신청 (별개 비자)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. DOHA Subclass 500**
homeaffairs.gov.au/visas/500

**2. Bridging Visas**
BVA/BVB/BVC

**3. ImmiAccount**
immi.homeaffairs.gov.au

**4. GTE Genuine Temporary Entrant**
DOHA Direction 90

**5. BUPA OSHC**
bupa.com.au - 학생비자 보험

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 현 비자 만료일 확인 (VEVO 사이트)
**2단계**: 2. 60일 전 새 학교/코스 등록 → New COE
**3단계**: 3. ImmiAccount에서 Subclass 500 새 신청
**4단계**: 4. GTE + 재정증명 + OSHC 갱신 제출
**5단계**: 5. Bridging Visa A 자동 부여 → 결정 대기

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 학생비자 연장 답변드립니다.

호주 학생비자는 "연장" 개념이 없고 새 비자 재신청을 통해 사실상 연장하는 구조입니다. 현 비자 만료 60일 전 신청을 권장합니다.

절차는 ① 새 학교/코스 등록 → New COE 발급, ② ImmiAccount에서 Subclass 500 새 신청, ③ GTE Statement(한국 귀국 의사 명확), 재정증명($29,710 + 학비 + 항공권), OSHC 갱신 제출입니다. 비용은 비자 $2,000 (2025.07~) + Health Check $300~$500 + OSHC $700 = 총 $1,800~$2,500 정도입니다.

현 비자 만료 전 신청하시면 Bridging Visa A가 자동 부여돼서 결정 대기 중에도 합법 체류 + 알바 가능합니다. 만료 후 신청하면 Bridging Visa C가 부여되는데 알바가 자동 안 되니 만료 전 신청이 필수입니다.

처리 시간은 4주~6개월입니다. 코스 변경(Bachelor → Diploma 같은 AQF 하향)은 GTE 위반으로 거절되니 동급 또는 상위만 신청 가능합니다.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **자동 연장 인식**
   → Subclass 500 연장 X. 재신청만.

2. **만료 후 신청 권유**
   → Bridging C → 알바 X. 만료 전 필수.

3. **AQF 하향 권유**
   → GTE 위반. 거절.

4. **Course Hopping 권유**
   → 3회+ 변경 = 의심. 거절 위험.

5. **OSHC 자동 갱신 인식**
   → OSHC 별도 신청. 미가입 = 비자 위반.

6. **Health Check 무시**
   → 4년 이상 호주 거주 시 의무.

7. **BVB 자동 인식**
   → BVA → BVB 별도 신청 ($200, 출국 시).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현 비자 만료일?
2. 새 코스 결정 + COE?
3. 재정증명 준비?
4. GTE 한국 귀국 사유 명확?

---

## 🔍 직원이 직접 확인 가능한 사이트

- immi.homeaffairs.gov.au (비자 신청)
- VEVO 비자 확인 사이트
- bupa.com.au (OSHC)
- 각 학교 International Office

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 재신청 일정 + 새 학교/코스 매칭 + GTE 작성

**MARA / 변호사 영역**
- 재신청 거절 + ART 항소 = MARA Agent.

---

## ✅ 완벽 응대 체크리스트

- [ ] 60일 전 신청 권장
- [ ] Bridging Visa A 자동
- [ ] GTE Statement 다시 작성
- [ ] AQF 동급/상위만
- [ ] OSHC 갱신 의무
- [ ] 카카오 상담 신청 유도
