# #165 호주 캠핑 / 하이킹 / 야외 활동

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "친구들이 캠핑 가자고 하는데 호주 캠핑 어떻게 해요? 텐트 빌릴 수 있나요? 위험한 동물 없어요? 어디로 가요?"

**직원 멘붕 포인트:**
- 호주 국립공원 시스템 모름
- 캠핑 장비 대여 모름
- 안전 사항 (위험 동물, 일사병) 모름

---

## ❌ 절대 하지 말아야 할 답

> "호주 어디든 위험해요. 캠핑 가지 마세요!"

→ 과도한 공포 X. 현실적 안전 가이드 필요.

---

## ✅ 정답

호주 캠핑/하이킹은 안전하고 쉽게 시작할 수 있어요. 국립공원 (National Park)에 캠핑장이 잘 갖춰져 있고, 텐트는 Anaconda/BCF 등에서 대여/구매 가능. 안전 수칙 (자외선, 야생동물, 길 잃음 방지) 알아두면 즐길 수 있어요.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 국립공원 (National Parks)
**시드니 (NSW) 인근:**
- **Royal National Park** (시드니 남쪽, 1시간) - 호주 최초 국립공원
- **Blue Mountains National Park** (시드니 서쪽, 1.5시간) - 유네스코
- **Ku-ring-gai Chase National Park** (시드니 북쪽, 30분)
- **Kosciuszko National Park** (스노위 마운틴, 5시간) - 호주 최고봉

**멜번 (VIC) 인근:**
- **Wilsons Promontory** (멜번 남쪽, 3시간) - 캠핑 명소
- **Grampians National Park** (서쪽, 3시간) - 등산
- **Great Ocean Road** (해안, 1.5~3시간) - 12 Apostles

**브리즈번 (QLD) 인근:**
- **Lamington National Park** (1.5시간) - 우림
- **Springbrook National Park** (1.5시간) - 폭포
- **Fraser Island** (3.5시간) - 세계 최대 모래섬

**애들레이드 (SA) 인근:**
- **Flinders Ranges** (5시간) - 사막

**퍼스 (WA) 인근:**
- **Karijini National Park** (북쪽, 비행기) - 협곡

### 2. 캠핑장 예약 시스템
- **NSW:** nationalparks.nsw.gov.au
- **VIC:** parks.vic.gov.au
- **QLD:** parks.des.qld.gov.au
- **SA:** parks.sa.gov.au
- **WA:** parks.dpaw.wa.gov.au
- **TAS:** parks.tas.gov.au

**예약:**
- 사이트 1박 $10~$50 (평균 $20~$30)
- 학생 할인 일부
- 인기 캠핑장 (Wilsons Prom 등) 6개월 전 예약

### 3. 캠핑 장비 (대여/구매)
**대여 (Rent):**
- **Wicked Campers / Britz / Apollo** (캠퍼밴 대여, 일 $80~$200)
- **Outdoor Hire Shop** (텐트, 침낭 일 $20~$50)
- **Snowys Outdoors** (구매 위주)

**구매:**
- **Anaconda** (캠핑 전문, 가성비)
- **BCF (Boating Camping Fishing)** (가성비)
- **Kathmandu, Mountain Designs** (고급)
- **Aldi** 시즌별 캠핑용품 (저렴)

**필수 장비:**
- 텐트 ($50~$300)
- 침낭 (Sleeping Bag) ($30~$200)
- 매트리스 (Sleeping Mat) ($20~$100)
- 헤드라이트 ($15~$50)
- 가스 스토브 ($30~$150)
- 쿨러 박스 (Esky) ($30~$200)

### 4. 안전 수칙
**자외선 (호주 = 한국 5~10배):**
- SPF50+ 선크림 (Cancer Council Sunscreen)
- 모자 (와이드 브림)
- 선글라스 (UV 100% 차단)
- 긴 옷 (Rashie)

**물:**
- 1인 1일 2~4리터
- 식수 표시된 곳에서만
- 강물/호수물 마시지 X (정수기 필수)

**길 잃음 방지:**
- 마킹된 트랙 (Marked Trail)에서 벗어나지 X
- 휴대폰 신호 X 지역 多 → PLB (Personal Locator Beacon) 대여 추천
- Hiking Buddy 동행
- 출발 전 가족/친구에게 알림

**야생동물:**
- **거미:** 1979년 이후 사망 0 (의료체계 발달)
- **뱀:** 거의 안 보임, 부츠 + 긴 바지 필수
- **상어:** 해변 표지판 따름
- **악어 (북부):** 다윈/QLD 북부 표지판 절대 무시 X
- **딩고 (Fraser Island):** 음식 보관 철저

**구급:**
- 응급: **000**
- 산악 구조 (PLB): 24시간 자동 구조
- First Aid Kit 휴대 (밴드, 소독약, 진통제)

### 5. 캠핑 시즌
- **봄 (9~11월):** 최적 (꽃, 시원함)
- **여름 (12~2월):** 더움 (산불 위험, 일부 폐쇄)
- **가을 (3~5월):** 최적 (시원, 단풍)
- **겨울 (6~8월):** 추움 (남부 눈, 북부 적합)

**산불 (Bushfire):**
- 12~3월 위험
- ABC Emergency 앱
- "Total Fire Ban" 날 화기 사용 X

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. 첫 캠핑 = 가까운 국립공원
- 시드니: Royal National Park, Ku-ring-gai
- 멜번: Wilsons Prom, Great Ocean Road
- 브리즈번: Lamington, Springbrook

### Step 2. 장비 대여 우선 (구매 X)
- Outdoor Hire Shop 텐트/침낭 일 $20~$50
- 캠퍼밴 = Britz/Apollo 일 $80~$200

### Step 3. 인터넷 예약
- 국립공원 웹사이트
- 6개월 전 인기 사이트
- 사이트당 $20~$30

### Step 4. 안전 수칙 숙지
- 자외선 (SPF50+, 모자)
- 물 1인 2~4L
- 마킹된 트랙
- Hiking Buddy 동행

### Step 5. 첫 캠핑 = 친구와
- 혼자 X (특히 첫 시도)
- 학교 동아리 (Bushwalking Club) 추천
- Meetup 그룹 활용

---

## 💡 직원이 학생한테 말할 멘트

> "호주 캠핑/하이킹 정말 좋아요! 안전하게 즐기는 법 알려드릴게요.
>
> **추천 국립공원:**
> - 시드니: Royal National Park (1시간), Blue Mountains (1.5시간)
> - 멜번: Wilsons Prom (3시간), Great Ocean Road
> - 브리즈번: Lamington, Fraser Island
>
> **예약:**
> - 국립공원 웹사이트 (NSW: nationalparks.nsw.gov.au 등)
> - 사이트 $20~$30/박
> - 인기 캠핑장 6개월 전 예약
>
> **장비 (첫 캠핑은 대여 추천):**
> - Outdoor Hire Shop: 텐트/침낭 일 $20~$50
> - Anaconda/BCF: 가성비 구매
> - 캠퍼밴: Britz/Apollo 일 $80~$200
>
> **안전 수칙:**
> - 자외선 (SPF50+, 모자, 선글라스) - 호주 한국 5~10배
> - 물 1인 2~4리터 (필수)
> - 마킹된 트랙에서 벗어나지 X
> - 휴대폰 신호 X 지역 多 → 친구와 동행
> - 산불 시즌 (12~3월) 'Total Fire Ban' 날 화기 X
> - 응급: 000
>
> **위험 동물 (과도한 공포 X):**
> - 거미: 1979년 이후 사망 0
> - 뱀: 거의 안 보임 (부츠 + 긴 바지)
> - 도시 캠핑장 = 안전
>
> **첫 캠핑은 친구나 학교 동아리(Bushwalking Club)와 함께 가세요!**
>
> 어느 도시 학생이세요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. 자외선 가볍게
- 호주 자외선 한국 5~10배
- 30분 노출도 화상 위험
- SPF50+ 30분마다 재바름

### 함정 2. 물 부족
- 마트 도시 50km 떨어진 캠핑장 多
- 1인 2~4리터 = 4인 가족 12리터+
- 강물/호수 마시지 X (Giardia 감염)

### 함정 3. 산불 시즌 무시
- 12~3월 산불 위험 高
- "Total Fire Ban" 위반 = $5,500 벌금
- ABC Emergency 앱 필수

### 함정 4. 야생동물 과도한 공포
- 거미/뱀 사망 매우 드뭄
- 도시 캠핑장 = 안전
- 표지판 따르면 OK

### 함정 5. 휴대폰 신호
- 국립공원 신호 X 지역 多
- PLB (Personal Locator Beacon) 대여 추천
- Garmin inReach 등 위성 통신

### 함정 6. 캠퍼밴 함정
- Wicked Campers 등 가격 싸지만 사고/고장 위험
- 24/7 로드사이드 어시스턴스 확인
- Bond ($1,000~$5,000) 예치

### 함정 7. 캠핑 매너
- "Leave No Trace" 원칙 (쓰레기 X, 모닥불 X)
- 화재 금지 시즌 = 가스 스토브만
- 야생동물 먹이 주지 X

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **어느 도시? 첫 캠핑?** → 가까운 국립공원 추천
2. **친구와 갈 건가요? 혼자?** → 동행 강력 추천
3. **계절은?** → 산불/추위 안전
4. **장비 있나요?** → 대여 vs 구매

---

## 🔍 직원이 직접 확인 가능한 사이트

- **국립공원 NSW:** nationalparks.nsw.gov.au
- **Parks Victoria:** parks.vic.gov.au
- **QPWS (QLD):** parks.des.qld.gov.au
- **WikiCamps Australia 앱:** 캠핑장 정보
- **Anaconda:** anacondastores.com
- **BCF:** bcf.com.au
- **ABC Emergency:** abc.net.au/emergency
- **Cancer Council Sunscreen:** cancer.org.au

---

## 🚨 직원 영역 vs 윌슨 영역

| 직원 가능 | 윌슨 영역 |
|-----------|-----------|
| 국립공원 일반 안내 | 학생 1:1 여행 코칭 |
| 캠핑 장비 정보 | - |
| 안전 수칙 | - |
| 도시별 추천 | - |

---

## ✅ 완벽 응대 체크리스트

- [ ] 도시별 추천 국립공원
- [ ] 예약 사이트 안내
- [ ] 장비 대여 vs 구매 (Anaconda, BCF)
- [ ] 자외선 안전 (SPF50+)
- [ ] 물 1인 2~4L 강조
- [ ] 마킹된 트랙 안전
- [ ] 산불 시즌 주의 (12~3월)
- [ ] 야생동물 현실 (과도한 공포 X)
- [ ] 친구/동아리 동행 추천
- [ ] 응급 000 안내

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 여행/야외활동
