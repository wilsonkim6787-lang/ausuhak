# #445 호주_학생_졸업식_Graduation_Ceremony_가족_초청_초청장_비자

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "다음달 졸업식인데 한국 부모님 모셔오고 싶어요. 학교에서 초청장 받을 수 있나요? 졸업식 입장권은 가족 몇 명까지 가능한가요? 부모님 비자 어떻게 받나요? 사진 촬영은 어디서 하나요?"

**직원 멘붕 포인트:**
- Graduation Invitation Letter (학교 발급)
- Visitor 600 vs ETA
- Guest Ticket 보통 2-4매
- 졸업 가운/캡 대여
- 졸업 사진 스튜디오

---

## ❌ 절대 하지 말아야 할 답

> "가족 비자는 알아서 받으셔야 해요"

→ ❌ ❌ 학교 초청장 + 비자 일반 안내 = 직원 가능. 친절도 부족.

---

## ✅ 정답

졸업식 가족 초청: ① 학교 Graduation Office에 'Invitation Letter for Family' 요청 (대부분 무료 / 영문 / Visitor 600 신청 시 권장), ② 한국 부모 비자 - ETA 601 (만 74세 이하 / $20 / 90일) 또는 Visitor 600 (60세+ / $200 offshore Tourist), ③ Guest Ticket - 학교마다 2-4매 표준 (사전 예약 필수), ④ 졸업 가운/캡 대여 - $80~$150 (학교 또는 Academic Apparel 업체), ⑤ 졸업 사진 - 학교 공식 사진사 (가족 사진 $200~$500) 또는 외부 스튜디오, ⑥ 졸업식 후 Family Lunch/Dinner 권장 (한인 식당 또는 호주 레스토랑), ⑦ 부모 입국 시 졸업식 사유 입국 카드 'Visit Family' 솔직 OK, ⑧ 항공권 5월/12월 졸업 시즌 = 인천-시드니 $1,500~$2,500 (성수기).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Invitation Letter**
학교 무료 / Visitor 600 신청 시 권장

**2. Guest Ticket**
2-4매 / 사전 예약

**3. 졸업 가운/캡**
$80~$150 대여

**4. 졸업 사진**
공식 $200+ / 외부 가능

**5. 입국 사유**
Visit Family 솔직 OK

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 학교 Graduation Office 초청장 요청
**2단계**: 2단계: 부모 ETA 또는 Visitor 600 결정
**3단계**: 3단계: Guest Ticket 사전 예약
**4단계**: 4단계: 졸업 가운/캡 대여 + 사진 예약
**5단계**: 5단계: Family Lunch/Dinner 예약

---

## 💡 직원이 학생한테 말할 멘트

> "졸업 축하드립니다! 학교 Graduation Office에 Invitation Letter 요청하세요 (무료). 부모님 ETA 601($20) 또는 Visitor 600 ($200 offshore / $500 onshore) 신청하세요. Guest Ticket 사전 예약 필수입니다. 졸업식 사유 입국 신고 솔직 OK입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **초청장 학교 발급 X**
   → Graduation Office 무료

2. **Guest Ticket 무제한**
   → 2-4매 표준

3. **졸업 가운 무료**
   → $80~$150 대여

4. **ETA 60세+ 가능**
   → 60세+ Visitor 600 권장

5. **입국 졸업식 사유 거부**
   → Visit Family 솔직 OK

6. **졸업식 후 자동 비자 변경**
   → 별도 비자

7. **Graduation 학기 끝 자동**
   → 예약/등록 필요

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 졸업식 정확한 날짜
2. 부모 만 나이
3. Guest Ticket 사전 예약 여부
4. 사진/식사 일정

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Graduation Office', '각 학교')
- ('ETA 신청', 'eta.immi.homeaffairs.gov.au')
- ('Visitor 600', 'immi.homeaffairs.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 일반 안내, 학교 절차

**MARA / 변호사 영역**
- 비자 거부 사례 시 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 학교 Invitation Letter 안내함
- [ ] ETA vs Visitor 600 분기 안내함
- [ ] Guest Ticket 사전 예약 강조함
- [ ] 졸업 가운 대여 안내함
- [ ] 졸업식 사유 입국 OK 안내함
- [ ] 졸업 축하 표현함
