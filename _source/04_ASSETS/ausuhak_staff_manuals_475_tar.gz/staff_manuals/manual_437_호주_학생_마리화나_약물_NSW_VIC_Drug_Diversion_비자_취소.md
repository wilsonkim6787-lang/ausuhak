# #437 호주_학생_마리화나_약물_NSW_VIC_Drug_Diversion_비자_취소

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "친구가 마리화나 권해서 한 번 했어요. NSW에서 합법화 됐다고 들었는데 진짜인가요? 적발되면 비자 취소되나요? 한국 들어갈 때 머리카락 검사 한대요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- NSW Cannabis 비범죄화 (2024) 정확히
- Drug Diversion Program
- Section 10 NSW (Conviction X)
- Visa Cancellation Section 116
- 한국 마약류 검사 입국

---

## ❌ 절대 하지 말아야 할 답

> "NSW는 합법이에요"

→ ❌ ❌ 비범죄화 X 합법화 X. Cannabis Cautioning Scheme (15g 이하 / 1회 경고만) 일부 해당. 적발 시 형사 처벌 가능.

---

## ✅ 정답

NSW 마리화나 정확한 법: ① NSW Cannabis Cautioning Scheme - 15g 이하 사용자 / 첫 적발 시 경고 (Caution) / 두 번째부터 형사 기소, ② VIC = Cannabis 비범죄화 (소량 / 의료용 일부) - NSW와 다름, ③ 의료 대마 (Medical Cannabis) - GP 처방만 합법, ④ 적발 시 Drug Diversion Program 참여 권유 = Conviction X (대부분 학생 1회), ⑤ Section 10 (NSW) - 유죄 인정하나 Conviction 기록 X (재량), ⑥ 비자 영향 - Migration Act Section 116 'Character Test' 1년 이상 형 / 12개월 이하 형 = 비자 유지 가능 / Cannabis Cautioning은 비자 영향 거의 없음, ⑦ 한국 입국 머리카락 검사 = 마약 의심자만 / 일반 입국자 X (소문), ⑧ 한국 마약류 처벌 = 마리화나 사용 처벌 (한국법) = 한국 입국 후 적발 시 처벌 (드뭄).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. NSW Cannabis Cautioning**
15g / 1회 경고 / 2회+ 기소

**2. Drug Diversion Program**
Conviction X / 학생 1회

**3. Section 10 NSW**
유죄 인정 / Conviction X

**4. Migration Act 116**
1년 이상 형 = 비자 취소

**5. 한국 마약법**
사용/소지 처벌 / 호주 행위도 한국 처벌

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 1회 사용 / 적발 X = 우선 중단 권유
**2단계**: 2단계: 적발 시 형사 변호사 (LawAccess 1300 888 529)
**3단계**: 3단계: Drug Diversion Program 신청 우선
**4단계**: 4단계: Section 10 협상
**5단계**: 5단계: 한국 입국 시 자진 신고 X (소문 X)

---

## 💡 직원이 학생한테 말할 멘트

> "NSW는 비범죄화 X 합법화 X 입니다. Cannabis Cautioning Scheme(15g 이하 1회 경고)만 있습니다. 적발 시 형사 변호사 (LawAccess 1300 888 529 무료) 즉시 연락하세요. 비자 영향은 Conviction 여부 / 형량에 따라 다릅니다. 한국 입국 머리카락 검사는 일반 X 의심자만입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **NSW 합법화**
   → 비범죄화/합법화 X

2. **VIC NSW 동일**
   → 다른 법 적용

3. **의료 대마 자유 구매**
   → GP 처방만

4. **Cannabis Cautioning 자동 비자 취소**
   → 거의 영향 X

5. **Drug Diversion Conviction**
   → Conviction X

6. **한국 입국 머리카락 검사 자동**
   → 의심자만

7. **Section 10 무죄**
   → 유죄 인정 / 기록 X

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 1회 사용 vs 반복
2. 적발 여부
3. 현재 비자 상태
4. 한국 입국 일정

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('NSW Police Cannabis', 'police.nsw.gov.au')
- ('LawAccess NSW', '1300 888 529')
- ('Migration Character Test', 'immi.homeaffairs.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 법 일반 안내 / 변호사 의뢰 권유

**MARA / 변호사 영역**
- Migration Character Test / 형사 변호사 동반

---

## ✅ 완벽 응대 체크리스트

- [ ] NSW 비합법 강조함
- [ ] Cannabis Cautioning 정확히 안내함
- [ ] Drug Diversion 안내함
- [ ] 변호사 의뢰 권유함
- [ ] 비자 영향 = 형량에 따라 안내함
- [ ] 한국법 적용 가능 안내함
