# #248 호주 영어 발음 (Aussie English)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 IELTS 7.5인데 호주 와서 사람들 말 못 알아 듣겠어요. 미국 영어랑 너무 달라요. 적응할 수 있을까요?"

**직원 멘붕 포인트:**
- Aussie English = 영국식 + 호주 슬랭 + 빠른 속도
- "G'day mate" / "How ya going" 표준 인사
- 적응 = 3~6개월 (90% 학생 경험)

---

## ❌ 절대 하지 말아야 할 답

> "호주 영어가 너무 어려워요. 미국으로 가세요."

→ ❌ **3~6개월 적응** (90% 학생). IELTS 점수 무관 = 정상 경험.

---

## ✅ 정답

호주 영어 (Aussie English): ① **영국식 기반** (스펠링 colour / centre / behaviour) ② **호주 슬랭**: G'day, mate, no worries, fair dinkum, brekkie ③ **단어 줄임**: arvo (afternoon), servo (gas station), Macca's (McDonald's), uni (university) ④ **빠른 속도** + Rising Intonation ("?" 같은 끝맺음) ⑤ **적응 기간 3~6개월** (IELTS 점수 무관 / 정상) ⑥ **개선 방법**: ABC News / Triple J 라디오 / 호주 친구 / 셰어하우스. ⑦ **윌슨 영역 X** (개인 적응 / 영어 학원 영역).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Aussie English 특징**
- **영국식 기반**: colour / centre / theatre / labour
- **단모음**: "today" → "today" (미국 = "Tooday" / 호주 = "To-die" 비슷)
- **R 발음 약함**: "car" → "ka" (영국식)
- **빠른 속도** + 모음 길게 늘림

**2. 일반 호주 슬랭 (학생 필수)**
- **G'day**: Hello (Good day 줄임)
- **mate**: 친구 / 호칭 (성별 무관)
- **no worries**: 괜찮아 / 천만에
- **fair dinkum**: 진짜 / 정말
- **she'll be right**: 괜찮을 거야
- **arvo**: 오후 (afternoon)

**3. 단어 줄임 (호주 특수)**
- **brekkie**: 아침 (breakfast)
- **servo**: 주유소 (service station)
- **Macca's**: 맥도날드
- **uni**: 대학 (university)
- **bottle-o**: 주류 판매점
- **ute**: 픽업트럭 (utility vehicle)
- **sunnies**: 선글라스
- **footy**: 호주 풋볼 (AFL)

**4. 인사 / 일상**
- "How ya going?" = "잘 지내?" (Hi 대신)
- "Cheers!" = Thanks / Bye / 건배 (다용도)
- "Reckon" = "I think" (자주 사용)
- "Heaps" = "Many / Lots" (a lot 대신)

**5. 적응 방법**
- **ABC News** (호주 표준 영어)
- **Triple J** 라디오 (호주 음악 + DJ 호주 발음)
- **호주 친구 / 셰어하우스** (Immersion)
- **Netflix 호주 시리즈**: Bluey (어린이) / Heartbreak High
- **3~6개월 적응** (정상)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 적응 = 정상 / 3~6개월 위로
**2단계**: ABC News + Triple J 라디오
**3단계**: 호주 친구 만들기 (셰어하우스 / 학교 동아리)
**4단계**: 영화 / Netflix 호주 시리즈
**5단계**: 학교 Conversation Club / 영어 회화 모임
**6단계**: 호주 슬랭 학습 (재미 + 친근감)

---

## 💡 직원이 학생한테 말할 멘트

> "윌슨님께 이렇게 전달드릴게요:
> 
> '호주 영어 (Aussie English)는 영국식 기반 + 호주 슬랭 + 빠른 속도 + 단어 줄임이 많아서 IELTS 7.5+ 학생도 처음 3~6개월은 적응이 필요해요 (정상이에요). G\'day (Hello), mate (친구), no worries (괜찮아), arvo (오후), brekkie (아침), Macca\'s (맥도날드) 등 자주 들으실 거예요. 적응 방법은 ABC News (표준 호주 영어) + Triple J 라디오 + Netflix 호주 시리즈 (Bluey / Heartbreak High) + 호주 친구 만들기예요. 셰어하우스 / 학교 동아리 추천이에요. 시간 지나면 자연스럽게 적응돼요.'"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7개

1. **IELTS 점수 = 즉시 적응**: ❌ 3~6개월 정상
2. **미국 영어와 동일**: ❌ 영국식 + 호주 특수
3. **모든 호주인 슬랭 사용**: ⚠️ 도시 / 시골 차이
4. **G'day = 옛날 표현**: ❌ 일상 사용
5. **"mate" = 남자만**: ❌ 성별 무관
6. **호주 영어 학습 X**: ❌ 적응 필수
7. **윌슨 처리**: ❌ 개인 적응 영역

---

## 📞 카카오 응대 시 필수 3가지 확인

1. **체류 기간**: 도착 후 몇 개월
2. **현재 어려움**: 듣기 / 말하기 / 슬랭
3. **노출 환경**: 한인 환경 / 호주 환경

---

## 🔍 직원이 직접 확인 가능한 사이트

- **ABC News**: https://www.abc.net.au/news
- **Triple J 라디오**: https://www.abc.net.au/triplej
- **Aussie Slang 위키**: https://en.wikipedia.org/wiki/Australian_English_vocabulary
- **호주 영어 강의 (YouTube)**: Aussie English with Pete

---

## 🚨 직원 영역 vs 영어 학원 / 개인 적응 영역

| 영역 | 직원 가능 | 외부 영역 |
|------|----------|--------|
| 적응 = 정상 위로 | ✅ | - |
| 슬랭 일반 안내 | ✅ | - |
| 자료 추천 | ✅ | - |
| 1대1 발음 코칭 | ❌ | ✅ 영어 학원 / 코치 |
| 회화 연습 | ❌ | ✅ Conversation Club |

---

## ✅ 완벽 응대 체크리스트

- [ ] 적응 3~6개월 = 정상 위로
- [ ] IELTS 점수 무관 강조
- [ ] G'day / mate / no worries 등 일반 슬랭 안내
- [ ] ABC News / Triple J 추천
- [ ] 셰어하우스 / 친구 = 빠른 적응
- [ ] Netflix 호주 시리즈 추천
- [ ] 시간 지나면 자연 적응 안내
