# #287 호주_약대_입학_경로_PR

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 약사가 되고 싶은데 호주 약대 가면 PR 가능한가요? 학비 얼마예요?"

**직원 멘붕 포인트:**
- Bachelor of Pharmacy 4년 vs Master of Pharmacy 2년
- PSA (Pharmaceutical Society of Australia) 면허 절차
- 약사 = MLTSSL (PR 가능) 직업
- Internship 1년 (호주 약국) 의무
- 한국 약대 출신 호주 면허 인증

---

## ❌ 절대 하지 말아야 할 답

> ""약대 졸업 = 즉시 PR""

→ ❌ Internship 1년 + PSA 시험 + 영어 7.0 + Skill Assessment 필요.

---

## ✅ 정답

"호주 약사는 Bachelor of Pharmacy 4년 또는 Master of Pharmacy 2년 (한국 약대 졸업자) + Internship 1년 + PSA 시험 + IELTS 7.0 (각 영역 7.0) + APC Skill Assessment → 485 → 189/190 PR 경로입니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Bachelor vs Master of Pharmacy**
Bachelor of Pharmacy = 고졸 직접 4년. Sydney/Monash/QUT/Curtin 등. ATAR 80~90. Master of Pharmacy = 학사 졸업 (한국 약대 또는 자연계) 후 2년. UTS/Newcastle/Charles Sturt 등. 둘 다 PSA 인증. 학비 $40,000~$50,000/년.

**2. PSA 시험 + Internship**
졸업 후 Internship 1년 (호주 약국, 보수 $50,000~$60,000). Pharmacy Practice Exam (PSA) 응시. PSA 시험 통과 = 약사 면허 (Pharmacist Registration). AHPRA 등록 의무. 한국 약대 졸업자도 동일 절차 (Master 2년 단축).

**3. PR 경로 (MLTSSL)**
약사 = MLTSSL Skilled Occupation List. 189 (Independent) 또는 190 (State Sponsored). EOI 점수 65+ (실제 80+). Skill Assessment by APC (Australian Pharmacy Council) $1,500. IELTS 7.0 (각 영역 7.0).

**4. APC Skill Assessment**
Australian Pharmacy Council. 한국 약대 졸업자 = Provisional Skills Assessment 신청. 호주 약대 졸업자 = 자동. 평가 기간 8~12주. KAPS Examination (Knowledge Assessment of Pharmaceutical Sciences) 응시. 합격 후 Internship.

**5. 19년 경력 = 약대 추천**
한국 학생 약대 = 의대보다 합격 가능성 높음. ATAR 80~90 = 한국 자연계 우수 학생 OK. PR 경로 안정적. 학비 + 5년 = 약 $300,000. PR 후 약사 연봉 $80,000~$120,000. ROI 좋음.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 자연계 또는 약대 학생 = 약대 진학 결심
**2단계**: Bachelor (고졸) 또는 Master (학사) 결정
**3단계**: ATAR 80~90 + IELTS 7.0 + 호주 약대 입학
**4단계**: 졸업 후 Internship 1년 + PSA 시험
**5단계**: APC Skill Assessment + 485 → 189/190 PR

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 약대는 의대보다 합격 가능성 높고 PR 경로 안정적이에요. Bachelor (고졸 4년) 또는 Master (한국 약대/자연계 학사 후 2년) 결정하세요. 학비 $40,000~$50,000/년이고 졸업 후 Internship 1년 (보수 받음) + PSA 시험 → APC Skill Assessment → 485 → PR 경로예요. IELTS 7.0 (각 영역 7.0) 필수. 한국 학년/내신/영어 알려주시면 학교 매칭해드릴게요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"약대 졸업 = 즉시 PR"**
   → Internship 1년 + PSA + APC Skill Assessment 필수.

2. **"한국 약사 면허로 호주 약사"**
   → APC Skill Assessment + Master + KAPS 시험.

3. **"IELTS 6.5로 가능"**
   → PSA + AHPRA 등록 = 7.0 (각 영역 7.0).

4. **"Internship 보수 X"**
   → $50,000~$60,000/년 보수.

5. **"PSA 시험 한국에서"**
   → 호주에서만. 시드니/멜번.

6. **"학비 장학금"**
   → 국제학생 거의 없음. 자비 $300,000.

7. **"약대 졸업 = 한국 약사 면허"**
   → 한국 약사 면허 별도 (한국 약사 시험).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 자연계/약대 학년 + 내신
2. 영어 IELTS 점수 (7.0 필요)
3. 예산 ($300,000+ 5년)
4. PR 목표 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Pharmacy Council Australia (APC): https://www.pharmacycouncil.org.au
- PSA: https://www.psa.org.au
- AHPRA Pharmacy Board: https://www.pharmacyboard.gov.au
- 각 약대 사이트 (Sydney/Monash 등)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 약대 학교 매칭 + 입학 신청
- Bachelor vs Master 결정 도움
- 한국 자연계 학생 추천
- 비자 신청 대행 (학생비자)
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- APC = Skill Assessment
- PSA = 약사 시험
- AHPRA = 면허 등록
- MARA Lawyer = PR 비자 (485/189/190)
- Internship 약국 = 별도 구직

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 학년/내신 확인했다
- [ ] 영어 IELTS 확인했다
- [ ] Bachelor vs Master 결정 도움 줬다
- [ ] 예산 확인했다 ($300,000+)
- [ ] PR 경로 (485 → 189/190) 안내했다
- [ ] Internship 1년 + PSA 시험 안내했다
- [ ] APC Skill Assessment 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
