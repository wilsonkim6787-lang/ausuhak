# 📚 직원 응대 매뉴얼 #015

**케이스: 21세 / 고졸 / TAFE 직업 코스 / 5천만 예산 / PR 관심**

---

## 🎬 상황 시뮬레이션

> 21살 고졸이고요 학사보다 빨리 일하고 싶어요. 요리나 미용, 유아교육 같은 거 생각 중이에요. 호주 영주권도 받고 싶고. 5천만 예산이에요.

**👉 정답**: **TAFE Cert IV/Diploma + 직업 PR 직군 매칭**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ TAFE 직업 코스 = 빠르게 PR 직군 진입

| 직업 | 코스 | 기간 | ANZSCO 코드 | PR 가능 |
|---|---|---|---|---|
| Chef (요리사) | Cert III + Cert IV + Diploma | 2~3년 | 351311 | ✅ MLTSSL |
| Childcare (유아교육) | Diploma of Early Childhood | 1.5년 | 241111 | ✅ MLTSSL |
| Hairdresser | Cert III in Hairdressing | 2년 | 391111 | ✅ STSOL |
| Beauty Therapist | Cert IV + Diploma | 1.5년 | 451815 | ⚠️ 일부 |
| Massage Therapist | Diploma of Remedial Massage | 1년 | 411611 | ⚠️ |
| Patisserie | Cert III in Patisserie | 1.5년 | 351112 | ✅ STSOL |
| Florist | Cert III in Floristry | 1년 | 639911 | ⚠️ |

### 2️⃣ Cookery (요리) PR 경로 - 가장 인기

```
ELICOS (필요시)
        ↓
Cert III in Commercial Cookery (1년) - $15K~$20K
        ↓
Cert IV in Commercial Cookery (6개월) - $7K~$10K
        ↓
Diploma of Hospitality Management (1년) - $15K~$20K
        ↓
졸업 + 485 + Skills Assessment (TRA)
        ↓
Chef 351311 PR
```

**총 2.5~3년 / 학비 약 $40K~$60K**

### 3️⃣ Childcare (유아교육) PR 경로

```
ELICOS (필요시)
        ↓
Diploma of Early Childhood Education and Care (1.5년) - $25K~$32K
        ↓
졸업 + 485 + ACECQA Skills Assessment
        ↓
Early Childhood Educator 241111 PR
```

**총 2년 / 학비 약 $25K~$32K**

### 4️⃣ TAFE 학교 선택 + 491 비자 +15점 (Regional 지역)

| 도시 | TAFE 학비 | PR 가산점 |
|---|---|---|
| 시드니 (TAFE NSW) | $24K~$30K | Non-regional (491 비적용) |
| 멜번 (TAFE VIC) | $24K~$30K | Non-regional (491 비적용) |
| **브리즈번 CBD (TAFE QLD)** | $20K~$26K | **Non-regional (491 비적용)** |
| Gold Coast / Sunshine Coast (TAFE QLD) | $20K~$26K | 491 +15점 (Regional) |
| Adelaide (TAFE SA) | $18K~$24K | 491 +15점 (Regional) |
| 퍼스 (TIWA) | $18K~$24K | 491 +15점 (Regional) |
| 호바트 (TasTAFE) | $16K~$22K | 491 +15점 (Regional) |
| 캔버라 (CIT) | $20K~$28K | 491 +15점 (Regional) |

### 5️⃣ 5천만 예산 = $35K~$36K

- TAFE 직업 코스 1년 = $20K~$30K
- 1년 학비 + 생활비 가능
- 알바 풀가동 시 자급 가능

---

## 🎯 정답 경로 (3가지 비교)

### 옵션 A. Cookery (요리사 PR)

```
ELICOS 6개월 → Cert III + IV Cookery 1.5년 → Diploma Hospitality 1년
        ↓
TRA Skills Assessment → Chef 351311 → PR
```

**총 3년 / 학비 약 $50K~$60K (Brisbane CBD = Non-regional, Gold Coast/Sunshine Coast 등 Regional 학교 선택 시 491 +15점 적용)**

### 옵션 B. Childcare (유아교육)

```
ELICOS 6개월 → Diploma Early Childhood 1.5년
        ↓
ACECQA Assessment → 241111 → PR
```

**총 2년 / 학비 약 $30K~$40K (Adelaide 등 Regional 도시 선택 시 491 +15점 적용)**

### 옵션 C. Hairdressing/Beauty

```
ELICOS → Cert III/IV (1.5~2년)
        ↓
직업 등록 → STSOL → 491 Regional → PR
```

**총 2.5년 / 학비 약 $25K~$35K**

---

## 💡 직원이 학생한테 말할 멘트

> "21세 고졸이시면 TAFE 직업 코스로 빠르게 PR 직군 진입 가능합니다.
> 
> 가장 인기 있는 3가지 비교해드리면:
> 
> **요리사 (Chef)** - 학비 $50K~$60K / 3년 / MLTSSL 직업군  
> **유아교육사** - 학비 $30K~$40K / 2년 / 가장 빠른 PR  
> **헤어/뷰티** - 학비 $25K~$35K / 2.5년 / 491 Regional PR
> 
> Regional 지역 (Adelaide/Perth/Hobart/Canberra/Gold Coast 등)에서 학업·거주·근무 시 491 비자 +15점 가산점 적용 가능. **Brisbane CBD는 Non-regional이라 491 적용 X** (Gold Coast/Sunshine Coast 등 QLD Regional 지역 이주 필요).
> 
> 5천만 예산이면 1년 학비 + 생활비 + 알바 조합으로 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 어떤 직업에 흥미 (요리/육아/뷰티)  
> ② 도시 선호 (Regional 도시 가능?)  
> ③ 영어 수준"

---

## ⚠️ 함정

1. **"TAFE는 학사보다 못하다"** → ❌ TAFE 직업군은 MLTSSL 직업군 多
2. **"Cookery 다 PR 가능"** → Cert III만 안 됨 / Cert IV + Diploma 必
3. **"미용은 PR 안 됨"** → Hairdresser는 STSOL / 491 Regional 가능
4. **"유아교육은 시드니가 좋다"** → ❌ Regional 지역이 PR 빠름 (491 +15점)

---

## 📞 카카오 응대 시 필수

1. 직업 흥미 (요리/육아/뷰티/Trade)
2. 도시 선호
3. 영어 수준
4. PR 우선순위 (직업 vs 빠르게)

---

## 🔍 직원 확인 사이트

- TAFE NSW / VIC / QLD / SA / WA / TAS 사이트
- Skilled Occupation List: immi.homeaffairs.gov.au
- TRA (Trades Recognition Australia): tradesrecognitionaustralia.gov.au
- ACECQA (유아교육): acecqa.gov.au
