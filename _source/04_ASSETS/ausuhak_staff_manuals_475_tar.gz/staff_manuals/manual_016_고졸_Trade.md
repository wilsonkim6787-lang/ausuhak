# 📚 직원 응대 매뉴얼 #016

**케이스: 24세 / 고졸 / Trade (전기/배관/목공) / 5천만 예산 / PR 목표**

---

## 🎬 상황 시뮬레이션

> 24살이고 한국 고졸이에요. 호주에서 기술직으로 영주권 받고 싶어요. 전기나 배관, 목공 같은 거요. 5천만 정도 예산이에요.

**👉 정답**: **Trade Cert III + IV → 491 Regional 또는 Direct PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Trade 직업군 = PR 매우 강력

| 직업 | ANZSCO 코드 | PR 리스트 | 연봉 (호주) |
|---|---|---|---|
| Electrician | 341111 | MLTSSL | $80K~$120K |
| Plumber | 334111 | MLTSSL | $75K~$110K |
| Carpenter | 331212 | MLTSSL | $70K~$100K |
| Welder (Metal Fabricator) | 322311 | MLTSSL | $70K~$95K |
| Diesel Mechanic | 321212 | MLTSSL | $75K~$100K |
| Automotive Mechanic | 321211 | MLTSSL | $65K~$90K |
| Bricklayer | 331111 | STSOL | $65K~$85K |

호주 Trade = 한국과 위상 다름. **고소득 + MLTSSL 직업군**.

### 2️⃣ Trade 자격 취득 경로

```
ELICOS (필요시 6~12개월)
        ↓
Cert III in [직업] (2~3년) - $30K~$45K
        ↓
Cert IV in [직업] (6개월~1년)
        ↓
TRA Skills Assessment + Apprenticeship
        ↓
Trade 자격 + 485 또는 491
        ↓
PR 신청
```

### 3️⃣ Trade 코스 IELTS

- Cert III/IV: IELTS 5.5~6.0 (각 영역 5.0~5.5)
- 일반적으로 Trade는 영어 조건 낮음

### 4️⃣ Apprenticeship 시스템

- Trade 자격 = 학교 + 현장 실습 결합
- 학교 Cert III + 호주 회사 견습 4년
- 견습 기간 동안 시급 받음 = 알바 풀가동
- 견습 마치면 자격증 + 즉시 취업 가능

### 5️⃣ Trade 전체 경로 비용/시간

| 단계 | 기간 | 학비/수입 |
|---|---|---|
| ELICOS 6~12개월 | 1년 | -$10K~$15K |
| Cert III 2년 + 견습 | 2~3년 | -$30K~$45K + 견습 시급 +$30K~$50K |
| 485 졸업비자 | 1.5~2년 | 시급 풀타임 |
| PR 신청 | 6개월~1년 | - |

**총 5~6년 / 순 학비 약 $40K~$60K (실수입 다 합치면 +)**

---

## 🎯 정답 경로

### Trade Cert III + 견습 + PR

```
ELICOS 6개월 (필요시)
        ↓
Cert III in Electrical/Plumbing/Carpentry (2~3년)
        ↓ Apprenticeship (호주 회사 견습)
Cert IV (6개월)
        ↓
TRA Skills Assessment
        ↓
485 졸업비자 (Post-Vocational, 18개월)
        ↓
ANZSCO 코드 매칭 + PR (189/190/491)
```

**총 5~6년 / 학비 약 $40K~$60K**

---

## 💡 직원이 학생한테 말할 멘트

> "24세 고졸 + Trade 영주권, 호주에서 가장 강력한 PR 경로 중 하나입니다.
> 
> 1. **호주 Trade 직군 = 고소득** (전기 $80K~$120K, 배관 $75K~$110K, 목공 $70K~$100K)
> 2. **MLTSSL 직업군** = 신청 빠름
> 3. **Apprenticeship 시스템** = 학교 + 호주 회사 견습 = 견습 기간 시급 받음 (생활비 자급)
> 4. **영어 조건 낮음** = IELTS 5.5~6.0
> 
> 5천만 예산이면 ELICOS + Cert III 1년차 학비 커버 가능, 견습 시작하면 시급으로 자급 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 직업 선호 (전기/배관/목공/용접/정비)  
> ② 영어 수준  
> ③ 도시 선호 (Regional 지역 거주·근무 시 491 비자 +15점)"

---

## ⚠️ 함정

1. **"Trade는 노동직"** → ❌ 호주에서 고소득 + 사회 지위 高
2. **"Trade는 한국 자격증 인정"** → ❌ 호주 Cert III 필수
3. **"Apprenticeship 자동 받는다"** → ❌ 호주 회사 직접 구해야 (윌슨 매칭 가능)
4. **"Cert III만으로 PR"** → Cert III + Cert IV + TRA Assessment 必須

---

## 📞 카카오 응대 시 필수

1. 직업 선호
2. 영어 수준
3. 도시 (Regional 우선)
4. 신체 조건 (Trade는 체력 必)

---

## 🔍 직원 확인 사이트

- TRA Skills Assessment: tradesrecognitionaustralia.gov.au
- Skilled Occupation List MLTSSL: immi.homeaffairs.gov.au
- TAFE NSW Trade 코스
- Apprenticeship 정보: australianapprenticeships.gov.au
