# 📚 직원 응대 매뉴얼 #089

**케이스: 부모님이 학생 자녀 보러 호주 방문 / "관광비자 어떻게? 얼마나 머무를 수 있어요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 저 멜번에서 공부 중인데 부모님이 다음 달에 저 보러 오시려고 해요. 관광비자 신청 어떻게 해요? 며칠 머무를 수 있어요? 만약 부모님이 더 오래 계시고 싶으시면 연장 가능해요?

**👉 직원이 멘붕하는 순간**
- "관광비자 종류가 뭐가 있지?"
- "신청 어디서?"
- "체류 기간?"
- "연장 가능?"

**❌ 절대 하지 말아야 할 답**
- "무비자로 가능" → **틀림. 한국인 호주 무비자 X**
- "최대 3개월" → **부정확. 비자 종류별 다름**
- "현지에서 연장 가능" → **부정확. 조건부**

**✅ 직원이 알아야 할 정답**
한국 여권 = **호주 무비자 X (반드시 비자 신청)**. 관광비자 = **Visitor Visa (Subclass 600)**. 일반 관광 = **3개월/6개월/12개월** 옵션. **부모 방문 = Sponsored Family Stream** 옵션도 있음. 신청은 **온라인 (ImmiAccount)** 또는 **eVisitor (Subclass 651)**. 한국 여권 = eVisitor 자격 X (eVisitor = 유럽 일부 국가만). **부모님 = Visitor Visa 600 신청 필수**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 한국인 호주 관광 비자 옵션 - eTA vs Visitor Visa

**답**: 한국 여권 보유자 = **2가지 옵션**.

**옵션 1: ETA (Subclass 601) - Electronic Travel Authority**
- 한국 여권 = ETA 자격 **있음** (한국은 ETA 협정국)
- 신청비: $20 AUD (2026년 기준)
- 체류: **최대 3개월/방문**
- 유효기간: 1년 (다회 입국 가능)
- 신청: **모바일 앱 "Australian ETA"** 또는 여행사
- 처리: 즉시~24시간

**옵션 2: Visitor Visa (Subclass 600)**
- 한국 여권 = 신청 가능
- 신청비: **Tourist Stream offshore $200 / onshore $500 / Sponsored Family $415 / Frequent Traveller $1,120 AUD** (2026 기준)
- 체류: **3개월/6개월/12개월**
- 유효기간: 12개월~36개월
- 신청: 온라인 ImmiAccount
- 처리: 1~3개월

**핵심 권장**:
- **부모 단기 방문 (~3개월)**: ETA 601 (저렴, 빠름)
- **부모 장기 방문 (3~12개월)**: Visitor Visa 600
- **65세 이상 부모 + 자녀 영주권자**: Sponsored Parent Visa 다른 영역

### 2️⃣ ETA (Subclass 601) 상세 - 가장 일반적

**답**: 한국인 호주 단기 관광 = **ETA가 표준**.

**ETA 신청 절차**:
1. **Australian ETA 앱** 다운로드 (iOS/Android, 호주 정부 공식)
2. 여권 사진 촬영 + 칩 스캔
3. 셀카 사진
4. 개인정보 입력
5. $20 AUD 결제 (신용카드)
6. 즉시~24시간 승인

**주의**:
- 여행사 대행 시 = **$50~80 추가 수수료**
- 직접 앱 신청 = $20만
- 가짜 사이트 다수 (구글 광고) → 공식 앱만 사용

**ETA 조건**:
- 1회 방문당 최대 3개월
- 1년 내 다회 입국 가능
- 호주 내 학업·취업 X
- 호주 내 비자 변경 X (귀국 후 재신청)

**ETA 거부 사유**:
- 과거 비자 거부 이력
- 호주 내 가족 이민 신청 진행 중
- 건강 문제 (결핵 등)
- 범죄 기록

### 3️⃣ Visitor Visa (Subclass 600) - 장기·반복 방문

**답**: 3개월 초과 또는 반복 방문 = Visitor Visa 600.

**Visitor Visa 600 스트림**:

| 스트림 | 신청비 (2026) | 체류 | 적합 대상 |
|---|---|---|---|
| **Tourist Stream (offshore)** | $200 | 3/6/12개월 | 일반 관광 |
| **Tourist Stream (onshore)** | $500 | 3/6/12개월 | 호주 내 연장 |
| **Sponsored Family Stream** | $415 | 3/6/12개월 | 호주 거주 가족 초청 |
| **Business Visitor Stream** | $200 | 3개월 | 비즈니스 방문 |
| **Frequent Traveller Stream** | $1,120 | 3개월/방문, 10년 유효 | 잦은 방문 |

**부모 방문 가장 일반**: **Tourist Stream 6개월 또는 12개월**.

**필요 서류**:
- 여권 사본
- 사진
- **재정 증빙** (한국 통장 잔고 $5,000~10,000 AUD 권장)
- **귀국 의사 증빙** (한국 직장 재직증명, 주택 소유 등)
- **자녀 학생비자 사본** + **CoE**
- 호주 체류 계획서
- 자녀 초청장 (Letter of Invitation, 형식 자유)

**Letter of Invitation 포함 사항**:
- 자녀 이름 + 학교 + CoE 번호
- 부모 이름 + 관계
- 방문 기간
- 자녀 호주 주소
- 자녀 서명

### 4️⃣ Sponsored Family Stream - 한국 학생들이 잘 모르는 옵션

**답**: 호주 거주 자녀가 부모를 **공식 초청** = Sponsored Family Stream.

**Sponsored Family Stream 특징**:
- 자녀 = 학생비자 OK (영주권 아니어도 가능)
- 자녀가 **공식 스폰서** 등록
- **체류 12개월** 가능
- 거절률 낮음 (자녀가 공식 보증)
- **보증금 (Bond)** 일부 케이스 요구 ($5,000~15,000 AUD)

**적합 케이스**:
- 부모가 첫 호주 방문
- 한국 직장 X (퇴직, 주부)
- 재정 증빙 어려움
- 단순 Tourist Stream 거절 위험

**처리 기간**: 2~6개월 (Tourist Stream보다 김)

**핵심**: 부모가 한국 직장 + 재정 충분 = **Tourist Stream**. 부모가 퇴직·주부·재정 약함 = **Sponsored Family Stream**.

### 5️⃣ 호주 내 비자 연장 - 가능 vs 불가

**답**: 비자 종류별 다름. **ETA = 연장 X**, **Visitor Visa 600 = 일부 가능**.

**ETA (601) 연장**:
- **호주 내 연장 X**
- 출국 후 재신청 (1년 내 다회 입국 가능)
- 또는 출국 전 Visitor Visa 600 신청

**Visitor Visa 600 연장**:
- **호주 내에서 연장 가능** (Subclass 600 → 600)
- 신청비 추가: $500 (onshore Tourist Stream 기준)
- **No Further Stay 8503 조건** 부착 시 연장 X
- 12개월 초과 체류 = 거의 불가능 (영주권 의도 의심)

**No Further Stay (8503) 조건**:
- Visitor Visa 600에 자주 부착
- "이 비자 만료 후 추가 비자 신청 불가" 의미
- 8503 부착 시 = **출국 후 재신청만 가능**
- 8503 부착 여부 = 비자 발급서 (Grant Notification) 확인

---

## 🎯 이 학생에게 안내할 정답 경로

### 1단계: 부모 방문 기간 결정
- 1~3개월 → ETA (Subclass 601)
- 3~12개월 → Visitor Visa 600 Tourist Stream
- 부모 재정 약함 → Visitor Visa 600 Sponsored Family Stream

### 2단계: 비자 신청 (출국 1~3개월 전)
- ETA: Australian ETA 앱
- Visitor Visa 600: ImmiAccount

### 3단계: 자녀 준비 사항
- Letter of Invitation 작성
- 학생비자 사본 + CoE
- 호주 체류지 정보

### 4단계: 부모 준비 사항
- 한국 통장 잔고 증명
- 한국 직장 재직증명 또는 사업자등록증
- 한국 주택 소유증빙 (있으면)
- 여행 일정표

### 5단계: 호주 내 비자 변경
- ETA → Visitor Visa 600 연장 = 출국 후 재신청
- Visitor Visa 600 → Visitor Visa 600 = 8503 조건 없으면 연장 가능

---

## 💡 직원이 학생한테 말할 멘트

```
안녕하세요 ○○님.
부모님 멜번 방문 환영해요.

한국 여권은 호주 무비자 X예요. 비자 신청 필수예요.

부모님 방문 기간에 따라 2가지 옵션이에요:

📌 1~3개월 머무시면 = ETA (Subclass 601)
   - $20 AUD, 즉시~24시간 승인
   - "Australian ETA" 앱에서 직접 신청
   - 여행사 X (수수료 추가)
   - 1년 내 다회 방문 가능

📌 3개월 이상 머무시면 = Visitor Visa 600
   - $200 AUD (offshore Tourist Stream), 1~3개월 처리
   - 6개월 또는 12개월 체류 가능
   - ImmiAccount 온라인 신청

부모님 한국 직장 + 재정 충분하면 → Tourist Stream
부모님 퇴직·주부·재정 약함 → Sponsored Family Stream
   (○○님이 공식 스폰서, 거절률 낮음)

자녀 ○○님이 준비할 서류:
1. 학생비자 사본
2. CoE
3. Letter of Invitation (간단 양식 보내드릴게요)
4. 호주 주소 정보

부모님이 준비할 서류:
1. 여권
2. 한국 통장 잔고 증명 ($5,000~10,000 AUD)
3. 한국 직장 재직증명
4. 여행 일정표

연장 관련:
- ETA = 호주 내 연장 X, 출국 후 재신청
- Visitor Visa 600 = 8503 조건 없으면 연장 가능

복잡한 케이스(거절 이력, 재정 약함, 12개월 이상)는
윌슨님 1:1 상담 가능해요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7가지

### 함정 1: "한국인 호주 무비자"
- **사실**: 한국 여권 = ETA 또는 Visitor Visa 필수
- 무비자 X (한국은 무비자 협정국 X)

### 함정 2: ETA = eVisitor 혼동
- **사실**: ETA (Subclass 601) = 한국 가능 / eVisitor (Subclass 651) = 유럽 일부만
- 한국인 = ETA만

### 함정 3: 여행사 ETA 신청 단정
- **사실**: 직접 앱 신청 $20 / 여행사 $50~80
- 학생에게 직접 신청 권유

### 함정 4: "현지에서 연장" 단정
- **사실**: ETA = 연장 X, Visitor 600 = 8503 부착 여부 확인
- 8503 = "No Further Stay"

### 함정 5: 자녀 학생비자 = 부모 자동 비자 오해
- **사실**: 자녀 학생비자 = 부모 비자에 영향 X
- 부모는 별도 신청

### 함정 6: 재정 증빙 무시
- **사실**: 한국 통장 잔고 $5,000~10,000 AUD 권장
- 부족 시 Sponsored Family Stream

### 함정 7: 12개월 이상 체류 단정
- **사실**: 12개월 이상 = 영주권 의도 의심, 거의 불가
- 장기 방문 = Parent Visa 별도 영역

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 부모 방문 기간
- 1~3개월 / 3~6개월 / 6~12개월

### 2. 부모 한국 신분
- 직장인 / 자영업자 / 퇴직 / 주부

### 3. 부모 호주 비자 이력
- 과거 호주 방문 여부 / 거절 이력

### 4. 자녀 호주 비자 상태
- 학생비자 / 485 / 영주권 신청 중

---

## 🔍 직원이 직접 확인 가능한 사이트

- **ETA (Subclass 601)**: https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/electronic-travel-authority-601
- **Visitor Visa (Subclass 600)**: https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/visitor-600
- **Australian ETA 앱**: iOS App Store / Google Play
- **ImmiAccount**: https://online.immi.gov.au
- **Visa 조건 8503**: https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions
- **VEVO (비자 확인)**: https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online

---

## 🚨 직원 영역 vs 윌슨 영역 vs 변호사 영역

### 직원이 할 수 있는 일
- 비자 종류 일반 안내
- 신청 방법 안내
- 서류 리스트 안내
- Letter of Invitation 양식 제공

### 윌슨 1:1 영역
- 12개월 이상 장기 체류 계획
- 거절 이력 있는 부모 케이스
- Sponsored Family Stream 결정 가이드

### MARA 변호사 영역 (직원·윌슨 X)
- 비자 거절 후 항소
- Parent Visa (영주권) 신청
- 복잡한 가족 이민 케이스

---

## ✅ 완벽 응대 체크리스트

- [ ] 부모 방문 기간 확인
- [ ] ETA (1~3개월) vs Visitor 600 (3개월 이상) 안내
- [ ] 한국인 무비자 X 명확히
- [ ] Australian ETA 앱 직접 신청 권유
- [ ] 여행사 수수료 주의 안내
- [ ] Letter of Invitation 양식 제공
- [ ] 재정 증빙 ($5,000~10,000 AUD) 안내
- [ ] Sponsored Family Stream 옵션 (재정 약함 시)
- [ ] 8503 조건 (No Further Stay) 설명
- [ ] 12개월 초과 = Parent Visa 별도 영역
- [ ] 거절 이력 시 윌슨 상담 연결
- [ ] 정부 공식 사이트만 사용 권장

---

## 📌 윌슨 19년 경력 기반 정리

> **부모 호주 방문은 학생 1년차에 가장 많이 들어오는 문의.**
>
> 핵심 3가지:
> 1. **한국 여권 = 무비자 X** (한국은 ETA 협정국)
> 2. **단기 = ETA $20 / 장기 = Visitor 600 $200 (offshore Tourist)**
> 3. **자녀가 스폰서 = Sponsored Family Stream** (재정 약한 부모 안전)
>
> 직원 함정:
> - "Australian ETA" 가짜 사이트 다수 (구글 검색 광고)
> - 여행사 수수료 = 학생 돈 낭비
> - 8503 조건 = 호주 내 연장 X
>
> 부모 비자는 직원 영역. 부모 영주권(Parent Visa)은 별도 영역, 윌슨 1:1.
