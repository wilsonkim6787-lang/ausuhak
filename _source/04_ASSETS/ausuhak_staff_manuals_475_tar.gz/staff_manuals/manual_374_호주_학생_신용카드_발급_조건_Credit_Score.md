# #374 호주_학생_신용카드_발급_조건_Credit_Score

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주에서 신용카드 만들 수 있어요? 학생비자라 안 된다는 말도 있고. 한국 신용카드 그대로 써도 돼요?"

**직원 멘붕 포인트:**
- 학생비자 신용카드 발급 거부 빈번
- Credit Score 0 (호주 신용 이력 없음)
- Secured Credit Card 옵션
- 한국 신용카드 해외 사용 수수료 (3% + ATM 인출 $5)
- Debit Card vs Credit Card 차이

---

## ❌ 절대 하지 말아야 할 답

> "학생비자라도 4대 은행 가면 신용카드 만들어줍니다."

→ ❌ 대부분 거부. 호주 신용 이력(Credit File) 없음 + 학생비자 = 단기 거주 + 정규 소득 없음 → CommBank/Westpac/ANZ/NAB 모두 거부 표준. Secured Card($1,000 보증금 예치) 또는 OneCard만 가능.

---

## ✅ 정답

**학생비자 신용카드 발급 현실** (2026):

**일반 신용카드 (Unsecured)**:
- 4대 은행 (CommBank, Westpac, ANZ, NAB): 거부 표준
- 사유: Credit File 없음 + 정규 소득 증빙 X + 학생비자 단기
- 예외: 시민/PR 보증인 + 본인 정규직 풀타임 = 가능

**Secured Credit Card** (보증금 예치형):
- 보증금: $500~$1,000 예치 → 동일 한도 카드 발급
- ANZ Secured Visa, Westpac Secured: 신청 가능
- 1년 사용 + 연체 X = Unsecured 전환 가능
- Credit Score 빌드업 목적

**Debit Card** (학생 표준):
- 4대 은행 모두 자동 발급 (계좌 개설 시)
- Visa/Mastercard 로고 = 신용카드처럼 사용 가능
- 잔액만큼만 인출 (대출 X)
- 해외 사용 수수료 X (Wise Debit 추천)

**한국 신용카드 호주 사용**:
- 결제 수수료: 1~3% (해외 가맹점 수수료)
- ATM 인출 수수료: $5~$10/건 + 환율 1.75%
- 추천 카드: 해외 결제 무수수료 (KB 위시카드, 신한 Mr.Life)
- 단점: 분실 시 재발급 한국 배송 (1~2주)

**OneCard / Up Bank** (디지털 은행):
- 핸드폰 앱 발급 (5분)
- Debit + Credit 기능
- 학생비자 가입 가능
- 해외 결제 무수수료
- 추천: Up Bank, ING Direct

**Credit Score 빌드업 전략** (PR 후 활용):
- 학생비자 → 485 비자 → PR 신청 시 모든 신용 이력 누적
- 휴대폰 24개월 약정 = Credit File 시작
- 전기/가스 자동이체 = 신용 이력 누적
- equifax.com.au에서 Credit File 무료 조회

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Equifax Australia**
equifax.com.au - Credit Score 조회 무료

**2. ANZ Secured Card**
anz.com.au - 보증금형 신용카드

**3. Up Bank**
up.com.au - 디지털 은행 학생 가입

**4. ING Direct**
ing.com.au - 무수수료 Debit

**5. ASIC MoneySmart**
moneysmart.gov.au - 카드 비교

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 호주 도착 즉시 4대 은행 Debit Card 발급 (계좌 개설)
**2단계**: 2. 한국 신용카드 = 응급/온라인 결제용으로만 보관
**3단계**: 3. 신용카드 필요 시 = ANZ/Westpac Secured Card ($500 보증금)
**4단계**: 4. 휴대폰 24개월 약정 = Credit File 시작
**5단계**: 5. 1년 후 Equifax 조회 → Credit Score 확인 → Unsecured 신청

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주 신용카드 발급 답변드립니다.

학생비자로는 호주 신용카드(Unsecured) 발급이 사실상 거부됩니다. 호주 신용 이력(Credit File)이 없고 정규 소득 증빙이 어려워서 4대 은행(CommBank, Westpac, ANZ, NAB) 모두 거부합니다.

대안은 두 가지입니다. 첫째, 4대 은행 Debit Card를 사용하시면 Visa/Mastercard 로고가 있어서 신용카드처럼 결제 가능합니다(잔액 한도). 둘째, 신용카드가 꼭 필요하면 ANZ Secured Card에 $500~$1,000 보증금을 예치하고 동일 한도 카드를 발급받는 방법이 있습니다.

한국 신용카드는 해외 결제 수수료 1~3% + ATM 인출 $5/건이 발생하므로 응급용으로만 쓰시는 게 좋습니다. KB 위시카드나 신한 Mr.Life처럼 해외 무수수료 카드 1장은 비상용으로 가져가세요.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생비자 신용카드 발급 권유**
   → 거부 표준. 신용 점수 하락 + 시간 낭비.

2. **Credit Score = 한국 신용등급 인식**
   → 별개 시스템. 호주 = Equifax/Illion/Experian.

3. **Debit = Credit 인식**
   → Debit = 잔액만, Credit = 대출. 호텔 Hold 시 Debit 거부 빈번.

4. **OneCard 한도 무시**
   → $5,000~$10,000 한도. 학비 결제 X.

5. **한국 신용카드 ATM 인출 권유**
   → $5~$10/건 + 1.75% 스프레드. Wise 카드 권장.

6. **PayPal 신용카드 등록**
   → 한국 카드 PayPal 등록 OK, 호주 카드 X (없음).

7. **Credit Score 평생 0 인식**
   → 휴대폰 약정 + 전기 자동이체 = 6개월 후 Score 빌드업.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Debit Card vs Credit Card 차이 이해?
2. 한국 해외 무수수료 카드 보유?
3. $1,000 보증금 예치 여력 있음?
4. 장기 거주(485+PR) 계획 있음?

---

## 🔍 직원이 직접 확인 가능한 사이트

- equifax.com.au (점수 조회)
- anz.com.au (Secured Card)
- up.com.au (디지털 은행)
- moneysmart.gov.au (카드 비교)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 신용카드 vs Debit 차이 안내 + 한국 카드 활용

**MARA / 변호사 영역**
- 카드 부정 사용/도용 = 경찰(Police Report) + 은행. 신용 점수 분쟁 = 변호사 X.

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생비자 신용카드 거부 안내
- [ ] Debit Card 우선 권장
- [ ] Secured Card 옵션 안내
- [ ] 한국 카드 응급용 보관
- [ ] Credit File 빌드업 전략
- [ ] 카카오 상담 신청 유도
