# 📚 직원 응대 매뉴얼 #013

**케이스: 19세 / 검정고시 / 영어 5.5 / Adelaide / 간호 PR / 4천만 예산**

---

## 🎬 상황 시뮬레이션

> 19살이고 검정고시 봤어요. IELTS 5.5 정도 됩니다. 간호사 되고 영주권 받고 싶은데 시드니는 비싸서 Adelaide 알아보고 있어요. 1년 4천만 정도예요.

**👉 정답**: **TAFE SA 간호 디플로마 + Adelaide University 학사 편입 + 491 +15점 (Regional 지역)**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Adelaide = 491 비자 +15점 (Regional 지역)

- 시드니/멜번 = Non-regional (491 비적용)
- Adelaide/Perth (Regional) = **491 +15점**, Brisbane CBD는 Non-regional
- 호바트/다윈 (Regional) = 491 +15점

같은 간호사여도 **Adelaide 졸업 = 영주권 1-2년 빠름**.

### 2️⃣ TAFE SA = SA 정부 운영 직업 교육

- **TAFE SA** = SA 정부 직속 운영
- 간호 디플로마(HLT54121) ANMAC 인증
- 학비 약 $36,960 (Tuition) + $1,500 (Incidental) = 총 약 $38,460
- IELTS 7.0 (각 영역 7.0) - 간호 표준
- Year 12 또는 동등 학력 (검정고시 인정 가능)

### 3️⃣ Adelaide University = SA Go8 (Group of Eight)

- 2026년 부터 Adelaide University = University of Adelaide + UniSA 통합
- TAFE SA 디플로마 졸업자 우선 입학
- Bachelor of Nursing 1년 학점 인정 (3년 → 2년)
- 학비 약 $44K~$48K/년

### 4️⃣ 검정고시 + Adelaide 간호 경로

| 단계 | 학비 | 기간 |
|---|---|---|
| ELICOS 30~52주 | $13K~$18K (Adelaide 저렴) | 약 1년 |
| TAFE SA 간호 디플로마 | $38,460 | 1.5년 |
| Adelaide Uni Bachelor 2년 (편입) | $44K~$48K x 2 = $88K~$96K | 2년 |
| **총** | **약 $140K~$162K** | **약 5년** |

### 5️⃣ Adelaide 한국 학생 환경

- 한국인 비율 3-8% (호주 6개 주 중 가장 낮음)
- 영어 환경 우수
- 생활비 시드니 대비 약 30% 저렴

---

## 🎯 정답 경로

### TAFE SA + Adelaide University 패스웨이

```
ELICOS 30~52주 (IELTS 7.0 도달)
        ↓
TAFE SA 간호 디플로마 1.5년 ($38,460)
        ↓ (1년 학점 자동 인정)
Adelaide University Bachelor 2년 ($88K~$96K)
        ↓
RN 자격 + 485 졸업비자 + 491 +15점 (Regional)
        ↓
영주권 (시드니 대비 1-2년 빠름)
```

**총 약 5년 / 학비 약 $140K~$162K**

---

## 💡 직원이 학생한테 말할 멘트

> "Adelaide 선택 매우 좋습니다. 시드니보다 영주권에 더 유리합니다.
> 
> 1. **Adelaide = 491 비자 +15점 (Regional 지역)** (시드니 Non-regional, 491 비적용)
> 2. **TAFE SA 간호 디플로마 $38,460** + Adelaide University 학사 편입 = 1년 학점 인정
> 3. **한국 학생 비율 3-8%** = 호주 최저 = 영어 환경 우수
> 4. **생활비 시드니 대비 30% 저렴**
> 
> 검정고시 + IELTS 5.5도 TAFE SA 인정 학교가 있어 진학 가능하고, 1년 4천만 예산이면 ELICOS + 디플로마 1년차 학비 커버됩니다.
> 
> 카톡으로 알려주세요:
> ① 정확한 IELTS 점수 (각 영역)  
> ② 출국 희망 시기  
> ③ 부모 동반 vs 단독"

---

## ⚠️ 함정

1. **"Adelaide는 시드니보다 수준 낮다"** → ❌ Adelaide University Go8
2. **"TAFE SA = 사립처럼 위험"** → ❌ SA 정부 직속 / ANMAC 인증
3. **"검정고시 = TAFE SA 거절"** → ✅ 검정고시 인정 학교 多 / 사전 확인
4. **"ELICOS 끝나면 IELTS 면제"** → 간호는 X / 7.0 시험 별도

---

## 📞 카카오 응대 시 필수

1. 정확한 IELTS 점수
2. Adelaide vs 다른 도시 비교 원하는지
3. 출국 시기
4. 부모 동반 vs 단독

---

## 🔍 직원 확인 사이트

- TAFE SA: tafesa.edu.au/international
- Adelaide University: adelaide.edu.au
- StudyAdelaide: studyadelaide.com
- ANMAC 인증: anmac.org.au
