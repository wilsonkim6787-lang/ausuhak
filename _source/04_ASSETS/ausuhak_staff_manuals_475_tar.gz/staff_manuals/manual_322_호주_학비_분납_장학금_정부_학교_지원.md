# #322 호주_학비_분납_장학금_정부_학교_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "학비가 부담돼서 분납 가능한지 + 장학금 받을 수 있는지 알고 싶어요."

**직원 멘붕 포인트:**
- 호주 학교 = 학기별 분납 (2학기 = 6개월) 일반
- 월별 분납 = 학교별, 일부 가능
- 장학금 = 외국인도 가능 (성적/직군별)
- 정부 장학금 (Australia Awards) = 외국인 PR/Master 일부
- 직원이 정확한 정보 안내 = 학생 안심

---

## ❌ 절대 하지 말아야 할 답

> "장학금은 외국인 학생은 못 받아요."

→ ❌ 외국인 = 정부 장학금 (Australia Awards) 일부 + 학교 자체 장학금 (Merit-Based) 가능. 직원이 학교/학과별 장학금 안내 필요.

---

## ✅ 정답

**학비 분납 (Payment Plan):**

**일반 분납:**
- 학기별 분납 = 호주 학교 표준 (1학기 = 6개월)
- 한 학기 학비 = 학기 시작 1~2주 전 납부
- Bachelor 4년 = 8학기 분납

**월별 분납 (선택):**
- 일부 학교 = 월별 가능 (학교 정책)
- 추가 수수료 ($100~$300/회)
- 신용 카드 = 추가 1.5~2.5% 수수료

**FEE-HELP / HECS-HELP (호주 시민권자만):**
- 학비 무이자 정부 대출
- 졸업 후 소득 $54,435+ 시작 = 자동 상환
- 외국인 학생비자 = 자격 X
- PR도 X (NZ 시민권자 일부 예외)

**Tuition Protection Service (TPS):**
- 학교 부도 시 학비 환불 보호
- 정부 운영, 모든 학교 의무 등록
- 학생 = 자동 보호

**장학금 종류:**

**1. Australia Awards Scholarships (정부):**
- 외국인 정부 지원, Master/PhD 일부
- 100% 학비 + 항공권 + 생활비
- 한국 = 일부 자격 X (개발도상국 우선)

**2. Destination Australia (정부):**
- 외국인 + 호주 학생 모두
- 지역 (Regional) 학교만
- $15,000~$20,000/년
- Bachelor / Master 가능

**3. 학교 Merit-Based 장학금:**

**G8 학교:**
- USyd International Scholarship: 25%~50% 학비
- UNSW International Scientia: 50%~100%
- UQ International Scholarship: 25%~50%
- Monash International Merit: 25%~50%
- ANU Tuition Scholarship: 25%~50%

**자격:**
- 한국 고교 성적 (수능/IB/A-Level)
- IELTS 6.5+ (일반) / 7.0+ (간호)
- 자동 평가 (별도 신청 X) 또는 별도 신청

**4. 학과별 장학금:**
- Engineering / IT / Business 인기
- Master Research = 100% + 생활비 (PhD 일반)
- 의료 = 외국인 자격 X (호주 시민권자 우선)

**5. 한국 정부 장학금:**
- KOSAF (한국장학재단) = 외국 유학 일부
- 한국 외무부 = 일부 (외교관/국비 유학)
- 회사 후원 (삼성/LG 등) = 일부

**장학금 신청 절차:**
1. 학교 합격
2. 장학금 신청 (자동 평가 또는 별도)
3. 결과 통보 (보통 합격 후 4~12주)
4. 학비 차감 (자동 적용)

**장학금 + 학비 분납 조합:**
- 장학금 50% + 학기별 분납 = 가장 일반
- 일부 = 장학금 100% (PhD/Top Tier)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 학기별 분납 (Semester Payment)**
1학기 = 6개월 단위 학비 납부. 호주 학교 표준. 월별 = 일부.

**2. FEE-HELP / HECS-HELP**
정부 무이자 학비 대출. 호주 시민권자만 (PR 외국인 학생비자 X).

**3. Tuition Protection Service**
학교 부도 시 학비 환불 보호. 정부 운영. 자동 보호.

**4. Merit-Based Scholarship**
학교 자체 장학금. 외국인 가능. 자동 평가 또는 별도 신청.

**5. Destination Australia**
정부 지역 (Regional) 장학금. 외국인 가능. $15K~$20K/년.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **학교 합격 + 학비 확인** - Bachelor $30K~$50K/년 일반
**2단계**: **장학금 신청** - 자동 평가 / 별도 신청
**3단계**: **결과 통보** - 합격 후 4~12주, 학비 차감
**4단계**: **학비 분납 신청** - 학기별 / 월별 (학교 정책)
**5단계**: **Tuition Protection 자동 적용** - 학교 부도 시 환불

---

## 💡 직원이 학생한테 말할 멘트

> "호주 학교 학비는 학기별 분납 (1학기 = 6개월)이 표준이고, 일부 학교는 월별 분납도 가능합니다 (수수료 $100~$300). 외국인 학생도 학교 Merit-Based 장학금 (USyd 25%~50%, UNSW Scientia 50%~100%) 신청 가능하고, 지역 학교는 Destination Australia 정부 장학금 ($15K~$20K)도 있습니다. 단, FEE-HELP/HECS-HELP는 호주 시민권자만 가능합니다. 학교 + 학과 + 성적 알려주시면 자세히 안내드립니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **외국인 = 장학금 못 받음**
   → 학교 Merit-Based + Destination Australia = 외국인 가능.

2. **FEE-HELP = 외국인 가능**
   → FEE-HELP/HECS-HELP = 호주 시민권자만. PR 외국인 학생비자 X.

3. **월별 분납 = 모든 학교**
   → 학기별 표준. 월별 = 일부 학교 (수수료 추가).

4. **장학금 = 신청 의무**
   → 일부 = 자동 평가 (성적 기반). 일부 = 별도 신청.

5. **Australia Awards = 한국인 자격**
   → Australia Awards = 개발도상국 우선. 한국 = 자격 일부 X.

6. **학비 분납 = 무료**
   → 신용카드 = 1.5~2.5% 수수료. 월별 = $100~$300/회 추가 가능.

7. **학교 부도 = 학비 손실**
   → TPS (Tuition Protection) = 자동 환불 보호.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 학교 + 학과 + 학년
2. 한국 고교 성적 (장학금 자격)
3. IELTS 점수 (장학금 영어 조건)
4. 분납 / 장학금 / 양쪽 의지

---

## 🔍 직원이 직접 확인 가능한 사이트

- Australia Awards: www.australiaawards.gov.au
- Destination Australia: www.education.gov.au/destination-australia
- USyd Scholarships: www.sydney.edu.au/scholarships
- UNSW Scientia: www.unsw.edu.au/scholarships
- Tuition Protection Service: www.tps.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 분납 / 장학금 일반 정보
- 학교별 Merit-Based 장학금 안내
- TPS 자동 보호 안내

**MARA / 변호사 영역**
- 장학금 분쟁 = 학교 + 변호사
- FEE-HELP 자격 분쟁 = 회계사
- 비자 + 장학금 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] 학교/학과/성적 확인
- [ ] 외국인 가능 장학금 안내
- [ ] FEE-HELP = 시민권자만 명시
- [ ] 분납 학기별 표준 안내
- [ ] TPS 자동 보호 강조
- [ ] 주관적 추천 X (객관적 정보만)
