# #455 호주_학생_신용카드_도용_Phishing_Scam_은행_신고_IDCARE

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제 호주 카드(Commonwealth Bank Debit Card)에서 모르는 결제 5건이 떴어요. 총 $2,300인데 어떤 사이트인지도 모르겠어요. 한국에서 산 적도 없고요. 어제 SMS로 'Australia Post 배송 실패' 링크 클릭한 게 마음에 걸려요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Phishing SMS = 호주 흔한 사기 수법 (Australia Post/myGov 사칭)
- 은행 24시간 신고 라인 즉시
- 카드 즉시 정지 + 재발급
- IDCARE = 호주 정부 ID 도용 무료 지원
- Scamwatch (ACCC) 신고
- 환불 가능성 높음 (피해자 입증 시)

---

## ❌ 절대 하지 말아야 할 답

> "이미 결제됐으니 어쩔 수 없어요"

→ ❌ 호주 은행 사기 방어 강력 / 24시간 내 신고 시 환불 가능성 높음 / 즉시 액션 필수

---

## ✅ 정답

(1) 은행 24시간 라인 즉시 (카드 정지 + Dispute) (2) Australia Post 사칭 SMS = Phishing - 신고 (3) IDCARE 1800 595 160 (4) Scamwatch 신고 (5) 환불 신청 (4~6주)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 은행 24시간 사기 신고 라인**
Commonwealth Bank: 13 22 21 / Westpac: 1300 651 089 / NAB: 13 22 65 / ANZ: 13 33 50 / 24시간 / 즉시 카드 정지 + Dispute 절차.

**2. Phishing SMS 일반 패턴**
Australia Post 'Failed Delivery' / myGov 'Tax Refund' / Bank 'Unusual Activity' / 링크 클릭 시 가짜 사이트 → 카드 정보 입력 → 도용. SMS 링크 클릭 X 원칙.

**3. IDCARE (호주 정부 ID 도용 지원)**
idcare.org / 1800 595 160 / 무료 / 신원 도용 케이스 매니저 배정 / 은행/정부 기관 통합 대응 / 한국어 통역 가능.

**4. Scamwatch (ACCC)**
scamwatch.gov.au / 호주 사기 신고 통합 시스템 / 무료 / 패턴 분석 + 공공 경고 / 통계 발표.

**5. Charge Dispute (환불 절차)**
Visa/Mastercard Chargeback 규정 / 카드 도용 = 즉시 환불 가능성 높음 / 4~6주 처리 / 입증 책임 = 카드사 (피해자 X 일반).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 은행 24시간 라인 즉시 (카드 정지 + Dispute)
**2단계**: 2차: 본인 명의 다른 카드/계좌 확인 - 추가 도용 점검
**3단계**: 3차: IDCARE 1800 595 160 - 케이스 매니저 배정
**4단계**: 4차: Scamwatch 신고 (scamwatch.gov.au)
**5단계**: 5차: 새 카드 재발급 + 비밀번호 변경 + Phishing SMS 차단

---

## 💡 직원이 학생한테 말할 멘트

> "호주 흔한 사기 수법이에요. 즉시 액션하면 환불 가능성 높습니다.

**지금 즉시 (15분 내):**

1. **은행 24시간 라인** (카드사별):
   - Commonwealth Bank: **13 22 21**
   - Westpac: 1300 651 089
   - NAB: 13 22 65
   - ANZ: 13 33 50

2. 카드 즉시 정지 + Dispute (사기 신고) → 새 카드 재발급

3. **본인 명의 다른 카드/계좌 확인** - 추가 도용 점검

**오늘:**
4. **IDCARE 1800 595 160** (무료) - 신원 도용 케이스 매니저 배정. 한국어 통역 가능.
5. **Scamwatch 신고**: scamwatch.gov.au

**환불:**
Visa/Mastercard Chargeback 규정상 4~6주 내 환불 가능성 높습니다. 카드 도용 입증 책임은 카드사에 있어요(피해자 X).

**Phishing SMS 패턴 (조심):**
- "Australia Post 배송 실패" → 진짜 X
- "myGov Tax Refund" → 진짜 X  
- "Bank Unusual Activity" → 직접 은행 앱으로 확인 (SMS 링크 X)

**원칙:**
**SMS/이메일 링크 절대 클릭 X**. 의심되면 직접 공식 사이트/앱 접속.

학교/지역 알려주시면 한국어 가능 IDCARE 안내드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **이미 결제 = 환불 불가능**
   → 24시간 내 신고 + Chargeback = 환불 가능성 높음 / Visa/Mastercard 규정

2. **호주 은행은 안전해서 도용 X**
   → Phishing 흔함 / 은행 잘못 X / 사용자 도용 사기

3. **학생/외국인이라 환불 안 해준다**
   → 비자/국적 무관 / 카드 명의자 권리 동일

4. **경찰 신고가 최우선**
   → 은행 신고 최우선 (즉시 정지) / 경찰은 큰 사건 시 / IDCARE/Scamwatch가 통합 대응

5. **Australia Post SMS는 진짜다**
   → Australia Post는 SMS로 배송 실패 링크 X / 100% Phishing

6. **새 카드 발급비 본인 부담**
   → 사기 피해 시 일반적 무료 / 카드사 정책별

7. **IDCARE는 호주인만**
   → 거주자/학생 모두 무료 / 한국어 통역 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 결제 발생 시간 (24시간 내 신고용)
2. 총 도용 금액 + 건수
3. 본인 다른 카드/계좌 도용 확인 여부
4. Phishing SMS 발신 번호 (Scamwatch 증거)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Commonwealth Bank 13 22 21
- idcare.org / 1800 595 160 (한국어 통역)
- scamwatch.gov.au
- auspost.com.au/parcels-mail/track (진짜 추적)
- TIS National 131 450 (한국어 통역 신고)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 은행 24시간 라인 안내
- IDCARE 일반 안내
- Scamwatch 신고 절차
- Phishing 패턴 일반 정보

**MARA / 변호사 영역**
- 큰 금액 도용 시 형사 절차
- 비자 영향 (재정 부족 시)
- 사기 가해자 측 변호 (학생이 가해자 의심 시)

---

## ✅ 완벽 응대 체크리스트

- [ ] 은행 24시간 라인 즉시 강조
- [ ] 카드 정지 + Dispute 절차 안내
- [ ] IDCARE 무료 안내
- [ ] Scamwatch 신고 안내
- [ ] 환불 가능성 높음 안심
- [ ] SMS 링크 클릭 금지 원칙 강조
- [ ] 한국어 통역 안내
- [ ] Phishing 패턴 교육
