# #338 호주_학생_인턴십_무급_유급_PR_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주 회사 인턴십 들어가려는데 무급도 가능한가요? 비자에 영향 있나요? 인턴 후에 PR 길도 있나요?"

**직원 멘붕 포인트:**
- 무급 인턴십 = 합법?
- 학생비자 + 인턴십 시간 제한?
- 인턴 후 482 비자 가능?
- PR 경로?

---

## ❌ 절대 하지 말아야 할 답

> "무급 인턴은 안 돼요."

→ ❌ Fair Work Act + Vocational Placement + Internship 구분 모름. 잘못하면 학생 노동 착취 또는 기회 박탈.

---

## ✅ 정답

**호주 인턴십 = ① Vocational Placement (학교 정규 과정) ② Paid Internship (유급) ③ Unpaid Internship (무급, 제한적) 세 종류.**

**핵심 사실:**
- **Vocational Placement**: 학교 커리큘럼의 일부 = 무급 합법. ESOS Act + Fair Work Act 면제. 비자 제한 없음.
- **Paid Internship**: 일반 직장과 동일. 최저임금($24.95/시간 (2025.07~)) 적용. 학생비자 주 48시간 제한.
- **Unpaid Internship (학교 외)**: Fair Work Ombudsman 조사 대상. 단순 노동 = 무급 불법. '실질적 학습 기회' = 합법 가능 (회색 지대).
- **인턴 후 482 SID 비자 (구 TSS, 2024.12.07부터 SID로 명칭 변경)**: 학사 학위 + 직업군 매칭(CSOL, 2024.12.03부터 482 비자용 통합 리스트) + 회사 스폰서 + 영어 IELTS 5.0~6.0 = 482 가능.
- **PR 경로**: 482 SID 비자 → 186 ENS PR (2년 근무 후, TRT 경로) 또는 189 독립 기술이민 (485 + 직업 평가 + EOI 점수 70+).

**경로:**
인턴십 자격 평가 → 학교 Vocational Placement vs 일반 인턴 결정 → 회사 면접 → 인턴 시작 → 졸업 + 485 → 482 스폰서 → 186 PR

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Vocational Placement**
학교 커리큘럼 정규 인턴 = Fair Work Act 면제 (무급 합법). ESOS Act는 주 48시간 학습 시간 인정. 비자 시간 제한 없음.

**2. Paid Internship**
일반 직장과 동일. 최저임금 $24.95/시간 (2025.07~). 슈퍼 12% (2025.07~). 학생비자 = 주 48시간 (격주 평균).

**3. Unpaid Internship 합법성**
Fair Work Ombudsman: '실질적 학습 기회 + 본인 이익' = 합법. '단순 노동 + 회사 이익' = 불법. 회색 지대.

**4. 482 SID 비자 (구 TSS, 2024.12.07~ 명칭 변경)**
직군 매칭(CSOL Core Skills Occupation List, 456 직군) + 회사 SBS 스폰서십 + 영어 IELTS 5.0~6.0 + **1년 경력** (이전 2년 → 1년 단축) + Salary $76,515+ (Core) 또는 $141,210+ (Specialist). 모든 stream 4년 + PR 경로 제공.

**5. 186 ENS PR**
482 SID 후 **2년 근무** (이전 3년 → 2년, 2024.12.07부터 단축) + 회사 nomination = 186 ENS TRT 경로. 또는 Direct Entry (3년 경력 + Skills Assessment + CSOL). 영어 IELTS 6.0(각 영역) + 직업 평가. 45세 미만.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 현재 학과 Vocational Placement 정규 과정 여부 확인
**2단계**: Vocational Placement 무급 합법, 일반 인턴 = 유급/회색 지대 평가
**3단계**: 회사 면접 + 인턴 시작 + 학생비자 주 48시간 준수
**4단계**: 졸업 후 485 비자 (Bachelor 2년) + 회사 스폰서십 협상
**5단계**: 482 SID (구 TSS) → 2년 근무 → 186 ENS PR (TRT 경로, 2024.12.07부터 3년→2년 단축)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 인턴십은 학교 정규 과정 vs 일반 회사 인턴이 완전히 다릅니다. 무급 인턴은 합법성 회색 지대라 잘못하면 노동 착취 + 비자 위반.

본인 학과 + 인턴 회사 + 무급/유급 + PR 목표 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **무급 인턴 = 불법**
   → ❌ Vocational Placement(학교 정규 과정) = 무급 합법. 일반 회사 인턴은 회색 지대.

2. **Vocational Placement = 비자 시간 제한**
   → ❌ 학교 커리큘럼 = 비자 시간 제한 면제.

3. **Paid Internship = 무제한 노동**
   → ❌ 학생비자 주 48시간 (격주 평균) 제한.

4. **인턴 = 자동 482**
   → ❌ 482는 회사 스폰서 + 직업군 매칭 + 영어 + 경력 모두 충족 필요.

5. **482 = 즉시 PR**
   → ❌ 482 SID는 임시 비자. 2년 근무 후 186 ENS PR 신청 가능 (2024.12.07부터 3년→2년 단축).

6. **무급 인턴 = 학습 명목이면 OK**
   → ❌ Fair Work 조사 시 '실질적 학습 vs 단순 노동' 판단. 회색 지대.

7. **학교 추천 인턴 = 100% 합법**
   → ❌ 학교 추천도 일반 회사 인턴이면 Fair Work Act 적용. Vocational Placement만 면제.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 학과 + Vocational Placement 정규 과정 여부
2. 인턴 회사 + 직무 + 무급/유급 + 시간
3. 학생비자 주 48시간 노동 준수 가능
4. 졸업 후 485 + PR 직업군 매칭 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Fair Work Ombudsman Internship (fairwork.gov.au/find-help-for/young-workers-and-students/unpaid-work)
- DHA 482 SID (구 TSS) Visa (immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/temporary-skill-shortage-482)
- DHA 186 ENS Visa (immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/employer-nomination-scheme-186)
- MLTSSL/STSOL/ROL Skilled Occupation Lists (immi.homeaffairs.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Vocational Placement vs 일반 인턴 평가
- 유급/무급 인턴 합법성 가이드
- 인턴 후 485 → 482 → 186 PR 경로 설계

**MARA / 변호사 영역**
- 482 SID 비자 (구 TSS) 신청 + 회사 스폰서 분쟁 (MARA)
- 186 ENS PR 신청 + 직업 평가 (MARA)
- 무급 인턴 노동 착취 신고 = Fair Work Ombudsman + 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] Vocational Placement vs 일반 인턴 구분
- [ ] 무급 인턴 합법성 평가 (Fair Work Ombudsman)
- [ ] 학생비자 주 48시간 준수 + 슈퍼 12% (2025.07~) 확인
- [ ] 회사 스폰서 가능성 + 직업군 MLTSSL/STSOL 매칭
- [ ] 졸업 후 485 비자 + 직업 평가 + 영어 준비
- [ ] 482 SID (구 TSS) → 2년 근무 → 186 ENS PR 로드맵
- [ ] 인턴 계약서 + 노동 시간 + 임금 기록 보관
