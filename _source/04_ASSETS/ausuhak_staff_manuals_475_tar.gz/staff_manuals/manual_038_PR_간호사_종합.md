# 📚 직원 응대 매뉴얼 #038

**케이스: 간호사 직군 종합 / PR 매칭 가이드**

---

## 🎬 상황 시뮬레이션

> 호주 간호사 영주권 가능한 거 다 알려주세요. 한국 간호 학사도 있고 무관도 있고 다양한 케이스가 있을 텐데요.

**👉 정답**: **5가지 케이스별 경로 분기**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 간호사 직군 = 호주 MLTSSL 직업군 (모든 시기 강세)

| 직업 | ANZSCO | PR 리스트 | 영어 | 면허 |
|---|---|---|---|---|
| Registered Nurse (RN) | 254499 | MLTSSL | IELTS 7.0 | AHPRA |
| Enrolled Nurse (EN) | 411411 | STSOL | IELTS 7.0 | AHPRA |
| Midwife (조산사) | 254111 | MLTSSL | IELTS 7.0 | AHPRA |
| Aged Care Nurse | 423111 (Aide) | STSOL | - | - |

⚠️ **EN은 영주권 안 됨** (RN으로 전환 必)

### 2️⃣ 케이스별 경로 분기

**케이스 1. 한국 비간호 학사 (예: 영문학) → 간호사**
→ Master of Nursing Pre-registration 2년

**케이스 2. 한국 간호 학사 + 면허 + 경력**
→ OBA 시험 또는 Bridging Course

**케이스 3. 한국 검정고시 / 정규고졸**
→ TAFE Diploma → Bachelor 편입 (UTS 등) 또는 직접 Bachelor

**케이스 4. 호주 학사 졸업자 (간호 외 학과)**
→ Master Pre-reg 2년

**케이스 5. 한국 4년제 + 호주 정착 후 간호사 전환**
→ Master Pre-reg 2년 또는 Bachelor 편입

### 3️⃣ ANMAC + AHPRA 시스템

```
학교 → ANMAC 인증 → 졸업 → AHPRA 등록 → RN 면허
                ↑
            IELTS 7.0 (각 영역 7.0)
```

**핵심**: 학교가 **ANMAC 인증** 안 되어 있으면 졸업해도 면허 X.

### 4️⃣ 간호 IELTS 7.0 절대 원칙

- 모든 간호 코스 (Diploma / Bachelor / Master) IELTS 7.0
- 각 영역 7.0 (Listening / Reading / Writing / Speaking)
- ELICOS Direct Entry로 면제 안 됨 (다른 코스는 가능)
- OET B grade 동등 인정

### 5️⃣ 간호사 영주권 + Regional 지역 강세 (491 +15점)

| 도시 | Cat | RN 학사 학비 | PR 가산점 |
|---|---|---|---|
| Sydney | 1 | $44K~$54K | 0 |
| Melbourne | 1 | $42K~$50K | 0 |
| Brisbane | 2 | $36K~$44K | +15 |
| Adelaide | 2 | $34K~$42K | +15 |
| Perth | 2 | $36K~$44K | +15 |
| Hobart | 3 | $34K~$40K | +20 |

---

## 🎯 정답 경로 (케이스별)

### 케이스 2. 한국 간호사 + 5년 경력

→ **OBA 시험** (NCLEX-RN + OSCE) = 9-12개월 / $5K
→ **Bridging Course** = 1-1.5년 / $30K~$45K

### 케이스 1, 4. 비간호 학사 → 호주 간호사

→ **Master of Nursing Pre-registration 2년** = $60K~$110K

### 케이스 3. 한국 고졸/검정고시 → 간호사

→ **TAFE Diploma 1.5년 + Bachelor 2년 편입** = $90K~$130K (저예산)
→ **Bachelor 3년 직접** = $130K~$170K (안전)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 간호사 PR은 시기 상관없이 매우 강세 직업입니다. 본인 케이스에 따라 경로가 다른데:
> 
> 1. **한국 간호사 면허 있음** = OBA 시험 (9-12개월) 또는 Bridging (1-1.5년)
> 2. **한국 비간호 학사** = Master Pre-reg 2년
> 3. **한국 고졸/검정고시** = TAFE Diploma + Bachelor 편입 = 4-5년
> 
> 모든 경우 **IELTS 7.0 (각 영역 7.0)** 必, **ANMAC 인증 학교** 必입니다.
> 
> Regional 지역 (Adelaide/Perth/Hobart 등)에서 학업·거주 시 491 +15점 + Australian Study +5점 추가 적용 (Brisbane CBD는 Non-regional)입니다.
> 
> 카톡으로 알려주세요:
> ① 본인 학력 (한국 간호 학사 / 비간호 학사 / 고졸 / 검정고시)  
> ② IELTS 점수  
> ③ 도시 우선  
> ④ 가족 동반 여부"

---

## ⚠️ 함정

1. **"EN으로 영주권"** → ❌ RN만 가능
2. **"간호 IELTS 6.5 OK"** → ❌ 7.0 절대
3. **"사립 컬리지 다 OK"** → ANMAC 인증 학교만
4. **"ELICOS 끝나면 IELTS 면제"** → 간호는 X

---

## 📞 카카오 응대 시 필수

1. 본인 학력 (간호 vs 비간호)
2. IELTS 점수
3. 도시 우선
4. 가족 동반

---

## 🔍 직원 확인 사이트

- ANMAC: anmac.org.au
- AHPRA: ahpra.gov.au
- NMBA: nursingmidwiferyboard.gov.au
- OBA: ahpra.gov.au
