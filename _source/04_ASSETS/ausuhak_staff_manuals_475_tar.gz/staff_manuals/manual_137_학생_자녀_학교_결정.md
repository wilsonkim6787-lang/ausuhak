# 매뉴얼 #137: 학생 자녀 학교 결정 (Public vs Private vs Catholic)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "쌤 저 시드니 Master 코스 오는데 6살 아이 데려가요. 호주 학교 어디 보내요? Public이 무료라는데 학생 자녀도 무료예요? Private vs Catholic 차이가 뭐예요?"

**직원 멘붕 포인트:**
- 학생 자녀 = NSW/VIC = 학비 의무 (Full Fee)
- 일부 주(SA) = 면제
- Catholic 학교 vs Private 차이
- 입학 신청 시기 (6~12개월 전)

---

## ❌ 절대 하지 말아야 할 답
> "Public은 다 무료예요" (틀림 - 학생 자녀는 학비)
> "한국에서 미리 등록하면 돼요" (틀림 - 호주 도착 후)
> "다 비슷해요" (틀림)

## ✅ 정답
> "학생 자녀의 호주 학교 학비: NSW/VIC Public = 연 $7,500~$15,000, Private = $20,000~$50,000+, Catholic = $5,000~$15,000. SA는 영주권 신청 학생 자녀 무료. 입학 신청 6~12개월 전 시작 권장. Master/PhD 학생은 일부 면제 케이스. 자세한 절차는 윌슨 카카오 상담 시 케이스별 안내드려요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 학교 시스템
- **Public (정부 학교)**: 학비 저렴/면제 (호주인)
- **Catholic (천주교 학교)**: 중간 학비
- **Private (사립)**: 고학비, Independent 사립 多
- **Independent (독립 사립)**: 가장 고학비

### 2. 학생 자녀 학비 (주별)
- **NSW**: 의무 (Public Primary $7,500/년)
- **VIC**: 의무 (Public Primary $9,500/년)
- **QLD**: 의무 (Public Primary $11,200/년)
- **SA**: 영주권 신청 학생 자녀 면제 (조건부)
- **WA**: 의무 ($7,000~$10,000/년)
- **TAS**: 의무 (저렴 $5,000~$8,000/년)

### 3. Master/PhD 학생 특혜
- Master/PhD = 일부 주 자녀 학비 면제
- VIC: PhD 학생 자녀 일부 면제
- SA: 영주권 신청 학생 면제
- 학교별 상이

### 4. 학년 구분 (호주)
- **Pre-school (만 4세)**: 선택
- **Kindergarten (만 5세)**: NSW Year K, VIC Prep
- **Primary School (Year 1~6)**: 만 6~12세
- **Secondary (Year 7~12)**: 만 13~18세
- **HSC/VCE**: 12학년 졸업시험

### 5. 입학 신청 절차
- 6~12개월 전 (인기 학교 1~2년)
- 학교 직접 신청 또는 정부 포털
- 입학 시험 (일부 사립)
- 면접 (일부 학교)

---

## 🎯 이 학생에게 안내할 정답 경로

### 1단계: 거주 도시 확정
- 도시별 학비 차이
- 학교 분포 차이

### 2단계: 학교 종류 결정
- 예산: Public vs Catholic vs Private
- 종교: Catholic 가능
- 영어 수준: ESL 지원 학교

### 3단계: 학교 검색
- My School (myschool.edu.au)
- 정부 포털
- 한인 카페 추천

### 4단계: 신청
- 6~12개월 전 시작
- CoE (학생 본인) 필수
- Birth Certificate, 예방접종 기록

### 5단계: 학비 납부
- 학기별 분납 가능
- 카드/은행 이체
- 영수증 보관

---

## 💡 직원이 학생한테 말할 멘트

```
학생 자녀 호주 학교 옵션은 3가지예요.

1. Public (정부 학교)
   - 학비 저렴 (호주인 무료)
   - 학생 자녀 = 학비 의무
   - NSW/VIC: $7,500~$11,200/년
   - SA: 영주권 신청 학생 자녀 면제 (조건부)
   - ESL 지원

2. Catholic (천주교 학교)
   - 학비 중간 ($5,000~$15,000)
   - 학업 분위기 우수
   - 종교 활동 일부

3. Private (사립)
   - 학비 고가 ($20,000~$50,000+)
   - 사립 (Sydney Grammar, Scotch College 등)
   - 입학 시험·면접

4. 학년 구분
   - Kindergarten: 만 5세
   - Primary: Year 1~6 (만 6~12)
   - Secondary: Year 7~12 (만 13~18)

5. 신청 시기
   - 6~12개월 전 권장
   - 인기 학교 1~2년 전
   - 영주권 신청 중이면 SA 무료 검토

자세한 안내는 윌슨한테 카카오 (studywilson) 주세요.
도시별·학교별 추천 + 학비 케이스 분석해드려요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: Public 무료 함정
- 호주인/영주권자만 무료
- 학생 자녀 = 학비 의무
- SA는 영주권 신청 시 예외

### 함정 2: 한국 학년과 호주 학년 매칭
- 한국 초등 1학년 ≈ 호주 Year 2
- 한국 만 나이 + 1
- 학교 입학 시 평가

### 함정 3: 영어 못하는 자녀
- ESL (English as Second Language) 프로그램
- Public 학교 대부분 제공
- IEC (Intensive English Centre) 별도

### 함정 4: 사립학교 입학 시험
- Sydney Grammar 등 사립 = 시험·면접
- AEAS (Australian Education Assessment Services)
- 영어·수학·General Ability

### 함정 5: 종교 활동 강제 X
- Catholic 학교 = 종교 활동 일부 (선택)
- 비신자 가능
- 입학 시 종교 명시

### 함정 6: 학교 변경 절차
- 학년 중 가능 (위치 이전)
- 새 학교 자리 확보 필수
- 정부 학교 = 거주 구역 우선

### 함정 7: 자녀 비자 = 학생 자녀 비자
- 학생 비자 동반 가족 = 자녀 학생 비자
- 학교 등록 = 자녀 비자 갱신 조건
- 학교 출석 미달 = 비자 취소 위험

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **자녀 나이** (학년 결정)
2. **거주 도시** (주별 학비 차이)
3. **본인 비자** (Master/PhD vs Bachelor)
4. **예산** (Public/Catholic/Private)

---

## 🔍 직원이 직접 확인 가능한 사이트

- **My School**: myschool.edu.au
- **NSW Public Schools**: education.nsw.gov.au
- **VIC Schools**: education.vic.gov.au
- **QLD International Students**: eqi.com.au
- **AEAS**: aeas.com.au

---

## 🚨 직원 영역 vs 전문가 영역

| 항목 | 직원 처리 | 전문가 |
|------|---------|-----|
| 학교 종류 안내 | ✅ | |
| 학비 범위 안내 | ✅ | |
| 신청 시기 안내 | ✅ | |
| 학교별 입학 자문 | ❌ | ✅ 학교 직접 |
| AEAS 시험 준비 | ❌ | ✅ 학원 |
| 비자 매칭 | ❌ | ✅ MARA |

---

## ✅ 완벽 응대 체크리스트

- [ ] Public/Catholic/Private 차이 안내
- [ ] 학생 자녀 학비 의무 강조 (NSW/VIC)
- [ ] SA 영주권 신청 면제 케이스 안내
- [ ] 한국 학년 ↔ 호주 학년 매칭
- [ ] ESL 프로그램 안내
- [ ] 6~12개월 전 신청 권장
- [ ] 윌슨 카카오 상담 유도
