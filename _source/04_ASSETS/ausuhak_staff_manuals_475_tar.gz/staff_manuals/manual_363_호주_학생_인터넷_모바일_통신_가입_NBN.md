# #363 호주_학생_인터넷_모바일_통신_가입_NBN

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니 도착했는데 인터넷이랑 핸드폰 어떻게 가입해요? 통신사 추천해주세요. 학생비자도 가입 가능하죠?"

**직원 멘붕 포인트:**
- 통신사 (Telstra/Optus/Vodafone/Aldi/Belong) 비교
- Postpaid vs Prepaid 차이
- NBN (가정 인터넷) 종류 (Fibre/Cable/Wireless) 모름
- ABN/한국 여권 vs Medicare 가입 가능 여부
- 약정 (Contract) vs No Contract 선택

---

## ❌ 절대 하지 말아야 할 답

> "Telstra가 제일 좋아요. Postpaid 약정 가입하세요."

→ ❌ 학생 = 가성비 + No Contract 추천. Telstra = 비싸고 약정 길음. Aldi/Belong/Boost = 학생 가성비 추천. 약정 = 출국 시 위약금.

---

## ✅ 정답

**모바일 통신사 비교 (2025)**:

**메이저 4사**:
- Telstra: 커버리지 1위, 비싸ə (월 $50~$100)
- Optus: 가성비 2위 (월 $35~$80)
- Vodafone: 도시권 가성비 (월 $30~$70)
- TPG: 시드니/멜번 한정

**MVNO (재판매 통신사)**:
- Belong (Telstra 망): 월 $25~$50 (추천)
- Boost (Telstra 망): 월 $25~$60 (Prepaid)
- Aldi Mobile (Telstra 망): 월 $15~$40 (가성비)
- Coles Mobile (Optus 망): 월 $20~$45
- Catch Connect (Optus 망): 월 $15~$35 (최저)

**가입 서류**:
- 한국 여권 + 호주 주소 + 이메일
- ABN/Medicare 불필요
- Postpaid = 한국 신용카드 + 호주 ABA 계좌

**NBN 종류** (속도/가격):
- FTTP (Fibre to the Premises): 최고 속도, 도시권
- FTTC (Fibre to the Curb): 광섬유 + 동축 마지막 구간
- HFC (Hybrid Fibre Coax): 케이블 인터넷
- FTTN (Fibre to the Node): 동축, 느림
- Wireless: 외곽 지역

**NBN 가격** (월):
- 25Mbps: $50~$60
- 50Mbps: $65~$80
- 100Mbps: $80~$95
- Aussie Broadband, Belong, TPG, Optus

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Postpaid vs Prepaid**
Postpaid = 월 후불 + 약정 (12~24개월) 또는 No Contract. Prepaid = 선불 충전. 학생 = Prepaid/No Contract 추천.

**2. MVNO**
Mobile Virtual Network Operator = 메이저 망 재판매. Belong (Telstra), Catch (Optus). 가성비 + 동일 커버리지.

**3. NBN (National Broadband Network)**
호주 국가 광대역망. 모든 가정 NBN 의무 (전화선 폐지). 통신사 = NBN 임차 + 판매.

**4. ABA 계좌**
Australian Bank Account. Postpaid 자동이체 의무. Westpac/CBA/NAB/ANZ 4대 은행.

**5. Roaming**
한국 통신사 로밍 = 비싸 ($10/MB+). 호주 도착 즉시 호주 SIM 추천. 한국 번호 유지 = 한국 알뜰폰 6개월 정지.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 공항 도착: Optus/Vodafone Prepaid SIM ($30 7일)
**2단계**: 1주일 내: ABA 계좌 개설 + 영구 SIM 가입
**3단계**: Belong/Boost/Aldi Postpaid (월 $25~$40, No Contract)
**4단계**: 거주지 NBN 가입 (Aussie Broadband 추천)
**5단계**: 한국 번호 유지: 한국 알뜰폰 정지 (3개월 무료)

---

## 💡 직원이 학생한테 말할 멘트

> "학생은 Aldi/Belong/Boost/Catch 등 MVNO 통신사가 가성비 좋아요. 월 $25~$40 + No Contract로 출국 시 위약금 없습니다. NBN 인터넷은 50Mbps $65~$80 정도고 Aussie Broadband 추천해요. 한국 여권 + 호주 주소만 있으면 가입 가능합니다. 자세한 추천은 윌슨 1:1 상담 가능해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Telstra 무조건 1위**
   → 커버리지만. 가격 = 1.5~2배.

2. **Postpaid 약정 = 가성비**
   → 약정 = 출국 시 위약금. 학생 = No Contract.

3. **ABN 필수**
   → 한국 여권만. ABN 불필요.

4. **NBN = 별도 회선**
   → 기존 ADSL/전화선 = NBN 자동 전환. 별도 공사 X.

5. **MVNO = 커버리지 X**
   → 메이저 망 재판매. 동일 커버리지.

6. **로밍 = 호주 도착 후 OK**
   → 로밍 = 비싸. 즉시 호주 SIM 추천.

7. **한국 번호 = 호주에서 자동 유지**
   → 한국 알뜰폰 정지 신청 필요. 미정지 = 월 요금 청구.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 도착 후 경과 기간 (공항 SIM vs 영구 SIM)
2. 거주지 (시내/외곽) → NBN 종류
3. ABA 계좌 개설 여부 (Postpaid 가입 가능)
4. 한국 번호 유지 계획 (가족 연락용)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Belong: belong.com.au
- Aldi Mobile: aldimobile.com.au
- Boost: boost.com.au
- Aussie Broadband: aussiebroadband.com.au
- Whistleout (가격 비교): whistleout.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학생 가성비 통신사 추천
- 도착 직후 임시 SIM + 영구 SIM 안내
- 한국 번호 유지 절차

**MARA / 변호사 영역**
- 통신 분쟁 시 TIO (Telecommunications Industry Ombudsman)
- 약정 위약금 분쟁

---

## ✅ 완벽 응대 체크리스트

- [ ] MVNO 가성비 추천 (Belong/Aldi/Boost)
- [ ] No Contract 강조 (출국 위약금 X)
- [ ] 한국 여권만으로 가입 가능 안심
- [ ] NBN 50Mbps 추천
- [ ] Aussie Broadband 추천
- [ ] 한국 번호 정지 안내
- [ ] 윌슨 1:1 상담 자연 유도
