# #439 호주_학생_게임_중독_온라인_Gaming_Disorder_WHO_OSHC_상담

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 외롭고 우울해서 LoL을 매일 8시간씩 해요. 학업도 못 따라가고 친구도 안 만나요. 한국 부모님이 게임 끊으라고 화내시는데 못 끊겠어요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Gaming Disorder (WHO ICD-11)
- GP Mental Health Care Plan
- Gambling Disorder vs Gaming Disorder
- Headspace 청년 정신건강
- Game Quitters 자조 단체

---

## ❌ 절대 하지 말아야 할 답

> "게임 끊는 게 답이에요"

→ ❌ ❌ Gaming Disorder = WHO 공식 질환 (2019). 의지력 평가 X. 의료적 접근 필요.

---

## ✅ 정답

Gaming Disorder 접근: ① WHO ICD-11 공식 질환 (2019~) - 의학적 진단 가능, ② 진단 기준 - 12개월+ 게임 통제 불가 + 일상 기능 손상, ③ GP - Mental Health Care Plan (10세션 OSHC 부분 커버), ④ Headspace (headspace.org.au) - 12-25세 청년 정신건강 무료 / 한국어 일부, ⑤ Game Quitters (gamequitters.com) - 자조 모임 / 영어 / 무료, ⑥ Lifeline 13 11 14 (한국어), ⑦ 우울/외로움 = 게임 의존 근본 원인 (대부분) → 사회 활동 + 운동 처방, ⑧ 학교 Counselling Service - 무료 (대부분 학교) / 한국어 일부, ⑨ 한국 부모 통보 = 본인 결정 / 의료 사생활.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Gaming Disorder ICD-11**
WHO 공식 질환 / 2019

**2. Mental Health Care Plan**
GP 작성 / OSHC 10세션

**3. Headspace**
12-25세 무료 / 호주 전국

**4. Game Quitters**
자조 모임 / 무료

**5. 학교 Counselling**
무료 / 대부분 캠퍼스

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: GP 예약 + Gaming Disorder 진단 의뢰
**2단계**: 2단계: Mental Health Care Plan 신청
**3단계**: 3단계: Headspace 또는 학교 Counselling 등록
**4단계**: 4단계: 우울/외로움 근본 원인 치료
**5단계**: 5단계: 사회 활동 + 운동 + 한국어 모임 권장

---

## 💡 직원이 학생한테 말할 멘트

> "Gaming Disorder는 WHO 공식 질환입니다. GP에서 Mental Health Care Plan 받으면 OSHC 10세션 커버됩니다. 12-25세면 Headspace 무료입니다. 학교 Counselling도 무료입니다. 의지력 문제 X 의학적 접근입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **게임 = 의지력**
   → WHO 공식 질환

2. **Gambling vs Gaming 동일**
   → 다른 진단 / 다른 치료

3. **OSHC Mental Health X**
   → Care Plan 일부 커버

4. **Headspace 영어만**
   → 한국어 일부 가능

5. **학교 Counselling 유료**
   → 대부분 무료

6. **게임 못 끊으면 비자 X**
   → 비자 영향 X

7. **한국 부모 자동 통보**
   → 의료 사생활

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 일일 게임 시간
2. 학업 성적 변화
3. 우울/외로움 수준
4. OSHC 가입사

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Headspace', 'headspace.org.au')
- ('Game Quitters', 'gamequitters.com')
- ('Lifeline 한국어', '13 11 14')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 자료 안내, 학교 Counselling 의뢰

**MARA / 변호사 영역**
- 비자 영향 X / 무관

---

## ✅ 완벽 응대 체크리스트

- [ ] WHO 공식 질환 강조함
- [ ] Mental Health Care Plan 안내함
- [ ] Headspace 12-25세 안내함
- [ ] 학교 Counselling 무료 안내함
- [ ] 근본 원인 우울/외로움 언급함
- [ ] 한국 부모 자동 통보 X 명시함
