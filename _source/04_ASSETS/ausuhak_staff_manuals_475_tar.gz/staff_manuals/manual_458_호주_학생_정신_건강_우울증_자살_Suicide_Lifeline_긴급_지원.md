# #458 호주_학생_정신_건강_우울증_자살_Suicide_Lifeline_긴급_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 외롭고 부모님 압박도 심해서 너무 힘들어요. 가끔 죽고 싶다는 생각이 들어요. 부모님께 말 못하겠고 한국 친구들에게도 부담 주기 싫어요. 도와주세요."

**직원 멘붕 포인트:**
- 자살 위험 표현 = 즉시 위기 대응
- Lifeline 13 11 14 = 24시간 무료
- 직원이 정신과 상담 X 절대 - 즉시 전문가 연결
- OSHC 정신과 일부 커버
- Mental Health Care Plan = OSHC 환급 강화
- 한국 부모 통보 의무 X (성인)

---

## ❌ 절대 하지 말아야 할 답

> "너무 힘드시겠어요. 차차 좋아질 거예요"

→ ❌ 위로 화법 = 위기 대응 X / 자살 위험 = 즉시 전문가 연결 / 단순 위로는 위험

---

## ✅ 정답

(1) Lifeline 13 11 14 즉시 (24시간 무료) (2) GP Mental Health Care Plan (3) Headspace (25세 이하 무료) (4) 학교 Counsellor (5) 한국어 통역 TIS 131 450

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Lifeline (호주 자살 예방)**
13 11 14 / 24시간 무료 전화 / lifeline.org.au 텍스트/채팅 / 익명 / 한국어 통역 자동 연결 가능.

**2. GP Mental Health Care Plan**
GP 방문 → 정신 건강 평가 → MHCP 작성 → Psychologist 10회/년 + Psychiatrist Referral / OSHC 일부 커버 / 학생 권장.

**3. Headspace (12~25세 무료)**
headspace.org.au / 호주 정부 운영 / 12~25세 무료 / Counsellor + Psychiatrist + Group / 한국어 통역 가능.

**4. 학교 Counsellor**
대학/TAFE 무료 Counselling 운영 (International Student Office) / 익명 / 비자 영향 X / 학업 영향 분리.

**5. Beyond Blue / Suicide Call Back**
Beyond Blue 1300 22 4636 / Suicide Call Back Service 1300 659 467 / 24시간 무료.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 즉시 Lifeline 13 11 14 (24시간) - 첫 통화
**2단계**: 2차: 24~48시간 내 GP 방문 → Mental Health Care Plan
**3단계**: 3차: Psychologist 10회/년 (OSHC 일부 커버)
**4단계**: 4차: 학교 Counsellor 병행 (무료)
**5단계**: 5차: 한국어 가능 Counsellor 연결 (장기)

---

## 💡 직원이 학생한테 말할 멘트

> "솔직히 말씀해주셔서 정말 다행이에요. 도움받으실 수 있어요. 본인 잘못 아니고 외로움+압박은 누구나 무너집니다.

**지금 즉시 할 수 있는 일:**

📞 **Lifeline 13 11 14**
- 24시간 무료
- 익명 가능
- 한국어 통역 자동 연결 가능 ("Korean please" 하시면 됩니다)
- 통화 어려우면: lifeline.org.au 텍스트/채팅

**24~48시간 내:**
1. **GP 방문** → "I'd like a Mental Health Care Plan" 한 마디만
2. GP가 Psychologist 10회/년 추천 (OSHC 일부 커버)
3. **학교 Counsellor**도 병행 (무료, 익명, 비자 영향 X)

**25세 이하면:**
**Headspace** (headspace.org.au) - 호주 정부 운영, 무료, 한국어 통역.

**기타 24시간 무료:**
- Beyond Blue 1300 22 4636
- Suicide Call Back 1300 659 467

**부모님께:**
지금 말씀 안 하셔도 됩니다. 본인 페이스로. 직원/Counsellor가 부모님께 통보 의무 없어요.

**비자 영향:**
정신 건강 치료 = 비자 영향 X. 학교 LOA 신청 시 오히려 보호 사유.

지금 너무 힘들면 Lifeline 13 11 14 통화 한 번만 해보세요. 통화 후에도 도움 더 필요하시면 학교/지역 알려주세요. 한국어 가능 GP/Counsellor 안내드릴게요.

**기억하세요: 본인 가치는 성적/부모 기대로 결정되지 않습니다.**"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **정신과 진료 = 비자 영향**
   → 치료 자체 비자 영향 X / 학생비자 Health Waiver X but 정신 치료 단독으로 거부 사유 X

2. **부모에게 통보된다**
   → 성인 = 부모 통보 의무 X / 본인 동의 없이 의료 정보 공유 안 됨

3. **Lifeline은 호주인만**
   → 거주자/학생 모두 / 한국어 통역 가능

4. **학교 Counsellor는 학교에 보고**
   → 익명 / 학교 행정에 학업 영향 분리 / 비자 영향 X

5. **OSHC가 정신과 안 커버**
   → GP Mental Health Care Plan 통한 Psychologist 일부 커버 / 보험사별 차이

6. **죽고 싶다는 생각 = 절대 말하면 안 된다**
   → 전문가에게 솔직히 말해야 정확한 도움 가능 / 숨기면 위험 증가

7. **한국 가야만 치료된다**
   → 호주에서 충분한 치료 가능 / 한국 귀국 = 학업 + 비자 + 비용 큼

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 위험 정도 (계획 있는지 - 즉시 위기 대응 vs 일반 우울)
2. 본인 나이 (25세 이하 = Headspace)
3. OSHC 가입 여부
4. 한국어 통역 필요 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Lifeline 13 11 14 (24시간)
- Beyond Blue 1300 22 4636
- Suicide Call Back 1300 659 467
- headspace.org.au (12~25세 무료)
- TIS National 131 450 (한국어 통역)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Lifeline/Beyond Blue 안내 (즉시 전화)
- GP Mental Health Care Plan 일반 정보
- Headspace 안내
- 학교 Counsellor 안내
- 한국어 가능 GP/Counsellor 추천

**MARA / 변호사 영역**
- 정신 치료 비자 영향 평가
- LOA 신청 시 비자 보호
- Compassionate Circumstances 비자 신청

---

## ✅ 완벽 응대 체크리스트

- [ ] 위기 신호 즉시 인식
- [ ] Lifeline 13 11 14 즉시 안내
- [ ] 위로보다 행동 단계 안내
- [ ] GP MHCP 24~48시간 내 강조
- [ ] 학교 Counsellor 무료 + 익명 안내
- [ ] 한국어 통역 적극 안내
- [ ] 부모 통보 의무 X 안심
- [ ] 비자 영향 없음 안심
- [ ] 본인 가치 = 성적 X 메시지
