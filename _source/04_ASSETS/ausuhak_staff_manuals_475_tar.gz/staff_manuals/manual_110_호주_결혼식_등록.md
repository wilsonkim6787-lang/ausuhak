# 📚 직원 응대 매뉴얼 #110

**케이스: 29세 / 시드니 학생 + 호주 시민권자 약혼 / "호주에서 결혼하려고 하는데 절차가 어떻게 돼요? 비자에도 영향 있나요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니 살고 있고 학생인데 호주 시민권자랑 결혼하기로 했어요. 호주에서 결혼하려고 하는데 절차 어떻게 해요? Notice of Intended Marriage? 한국에 신고해야 해요? 비자도 바뀌나요?

**👉 직원이 멘붕하는 순간**
- "호주 결혼 절차?"
- "Notice of Intended Marriage?"
- "Celebrant?"
- "한국 신고 = 어떻게?"
- "Partner Visa로 변경?"

**❌ 절대 하지 말아야 할 답**
- "결혼 = 영주권 자동" → **거짓. Partner Visa 별도**
- "Civil Wedding 무료" → **거짓**
- "한국 신고 안 해도 돼" → **거짓. 의무**

**✅ 직원이 알아야 할 정답**
호주 결혼 = **법적 절차 + 양국 신고**:

1. **Notice of Intended Marriage (NOIM)** = 1개월 전 신청
2. **Celebrant** = 결혼 집전인 (의무)
3. **Marriage Certificate** = 호주 정부 발급
4. **한국 영사관 신고** = 의무 (3개월 이내)
5. **Partner Visa** = 별도 신청 (자동 X)
6. **Prospective Marriage Visa (300)** = 결혼 전 신청
7. **결혼식 vs 등록** = 다름

직원 = **시스템 안내**. 윌슨 = **MARA 영역 (비자) + 결혼 행사 X**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Notice of Intended Marriage (NOIM)

**답**: 호주 결혼 = **NOIM 1개월~18개월 전 의무**.

**NOIM 정의**:
- 결혼 의사 통보
- 정부 양식 (Form 13)
- Celebrant에게 제출
- 1개월 ~ 18개월 사이

**서류 (NOIM)**:
- 신분증 (여권)
- 출생 증명 (영문) - 가족관계증명서 + NAATI 번역
- 이혼 증명 (재혼 시) - 영문
- 사망 증명 (배우자 사망 시) - 영문
- 비자 증명
- 한국 미혼 증명서 (영문) - 일부 Celebrant 요구

**제출 대상**:
- Celebrant (결혼 집전인)
- Registry Office (등기소)

**비용**:
- NOIM 신청: 무료 (Celebrant 선택 시 X)
- Celebrant Fee: $300~1,000
- Marriage Certificate: $60~85

**한국인 추가 서류**:
- 한국 가족관계증명서 (3개월 이내) + 영문 번역 (NAATI)
- 한국 미혼 증명서 (필요 시)
- 한국 영사관에서 무료 발급

**출처**: ag.gov.au/families-and-marriage/marriage

---

### 2️⃣ Celebrant (결혼 집전인) 시스템

**답**: 호주 결혼 = **Celebrant 의무**. 자유롭게 선택.

**Celebrant 종류**:

**Civil Celebrant (시민 집전인)**:
- 종교 X
- 자유로운 진행
- 90% 이상 호주 결혼
- $400~1,000 비용

**Religious Celebrant (종교)**:
- 신부, 목사, 스님 등
- 종교 의식 포함
- 비용 다양

**Government Celebrant (Registry)**:
- 등기소 직원
- Civil Wedding (간단)
- $400~600
- 등기소에서 진행

**Celebrant 역할**:
- NOIM 접수 + 서류 검토
- 결혼식 진행
- 법적 선언 (의무 문구)
- Marriage Certificate 발급
- 정부 등록

**찾는 법**:
- Australian Marriage Celebrants Inc (AMCI)
- Find a Celebrant: ag.gov.au
- 한국어 가능 Celebrant 검색
- 후기 (Easy Weddings, Google)

**Celebrant 의무 문구**:
> "I am duly authorised by law to solemnise marriages according to law..."
> = 법적 효력 있는 문구 (생략 X)

**출처**: ag.gov.au/families-and-marriage/marriage/find-a-celebrant

---

### 3️⃣ 결혼식 vs 등록 vs 사실혼

**답**: 호주 결혼 = **3가지 형태** 가능.

**1. Wedding Ceremony (결혼식 + 등록)**:
- Celebrant 진행
- 가족/친구 초청
- 결혼식 = 의식
- + 정부 등록 (자동)
- 가장 일반

**2. Registry Wedding (등기소 결혼)**:
- 등기소에서 간단 진행
- 5~30분
- 2명 증인
- $400~600
- 시간 짧음 / 저렴
- 외국인 학생 인기

**3. De Facto Relationship (사실혼)**:
- 결혼 X
- 12개월+ 동거
- 또는 자녀 함께
- 또는 등록 (Relationship Register)
- Partner Visa 가능

**Registry Office (각 주)**:
- NSW: NSW Registry of Births, Deaths and Marriages
- VIC: BDM Victoria
- QLD: BDM Queensland
- SA: ConsumerSA
- WA: BDM WA

**시드니 등기소**:
- BDM NSW, 35 Regent St, Chippendale
- 예약 필수
- 평일 + 토요일

**증인**:
- 2명 (18세 이상)
- 호주 시민/PR 의무 X
- 학생/관광객 OK

**드레스코드**:
- 자유 (등기소 = Smart Casual)
- 결혼식 = 자유

**출처**: nsw.gov.au/birth-death-marriage

---

### 4️⃣ 한국 영사관 신고 (의무)

**답**: 호주 결혼 = **한국 신고 의무**. 3개월 이내.

**왜 필수**:
- 한국 가족관계 등록부 등재
- 한국 = 결혼 인정
- 한국 거주증명/주민등록 영향
- 자녀 한국 국적 등록 시 필수

**신고처**:
- 시드니 총영사관 (시드니/NSW)
- 멜번 총영사관 (멜번/VIC/SA/TAS)
- 브리즈번 총영사관 (브리즈번/QLD/NT)
- 캔버라 대사관 (ACT)

**서류**:
- 호주 Marriage Certificate (정부 발급)
- 한국 영문 번역 (NAATI)
- 가족관계증명서 (한국)
- 여권 사본 (양 측)
- 신고서 (영사관 양식)

**비용**:
- $0~50

**기간**:
- 3개월 이내 신고 (의무)
- 늦으면 과태료 (없을 수도)

**한국 출입국**:
- 신고 후 한국 가족관계증명서 = 결혼 표시
- 한국 부모 = 가족관계증명서로 확인

**한국에서 결혼식 (선택)**:
- 호주 결혼 = 법적 효력 (한국에서도)
- 한국 결혼식 = 가족 행사
- 추가 법적 절차 X

**한국 가족관계 등재**:
- 신고 후 1~3개월
- 한국 모든 신분 서류 = 결혼 표시

**출처**: aus-syd.mofa.go.kr (시드니 영사관)

---

### 5️⃣ Partner Visa / Prospective Marriage Visa

**답**: 결혼 = **비자 자동 변경 X**. Partner Visa 별도 신청.

**Partner Visa 옵션**:

**Subclass 820 / 801 (Onshore)**:
- 호주 내 신청
- 결혼 후 또는 De Facto
- 820 = 임시 (2년)
- 801 = 영주권

**Subclass 309 / 100 (Offshore)**:
- 호주 외 신청
- 결혼 후 또는 De Facto
- 309 = 임시
- 100 = 영주권

**Subclass 300 (Prospective Marriage Visa)**:
- 약혼 비자 (피앙세 비자)
- 결혼 전 신청
- 9개월 이내 호주 입국 + 결혼 의무
- 결혼 후 = 820/801 신청

**비용**:
- $9,365 AUD (820 또는 309) - 2026 기준
- 자녀 추가: $4,680 each
- 의료/경찰 증명: $500~1,000

**서류**:
- 결혼 증명 (Marriage Certificate)
- 또는 De Facto 증명 (12개월+)
- 관계 증명 (사진, 메시지, 공동 계좌, 임대 계약)
- 양측 신원
- 의료/경찰 증명
- 호주 시민/PR 후원자

**처리 기간**:
- 12~24개월 (820)
- 18~30개월 (309)

**Bridging Visa**:
- 신청 후 Bridging Visa A/B/C 자동
- 호주 내 거주 가능
- 일 가능 (조건)

**MARA 등록 (이민 변호사) 의무**:
- 윌슨 = MARA X
- 학생 = MARA 등록 변호사 안내
- 잘못된 신청 = 거절

**출처**: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/partner-onshore

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 약혼 → 계획 수립 (지금)
- 결혼 날짜 정함
- Celebrant 검색 (1~3개월 전)
- 한국어 가능 또는 영어 가능
- 한국 가족관계증명서 준비

### Step 2: NOIM 신청 (1개월 전)
- Celebrant 또는 등기소
- 양식 + 서류 제출
- 검토 (5~10일)

### Step 3: 결혼식 또는 등기소
- 결혼식 = 가족/친구 초청
- 등기소 = 간단 진행
- 2명 증인
- 30분 ~ 2시간

### Step 4: Marriage Certificate 수령
- 결혼식 후 즉시 (Celebrant 발급)
- 정부 공식 = $60~85
- 5~10일 우편

### Step 5: 한국 영사관 신고 (3개월 이내)
- Marriage Certificate + 영문 번역
- 시드니 영사관 방문 또는 우편
- 신고서 작성
- 한국 가족관계 등재

### Step 6: Partner Visa 신청
- MARA 등록 변호사 (의무 권장)
- 820/801 (Onshore)
- $9,365 AUD
- Bridging Visa 자동

### Step 7: 학생비자 → Bridging Visa A
- 학생비자 만료 시 자동
- Partner Visa 처리 중 (12~24개월)
- 일 가능 (조건)

---

## 💡 직원이 학생한테 말할 멘트

```
호주 시민권자와 결혼 축하드립니다!
호주 결혼 = 한국과 절차가 매우 달라요.

[호주 결혼 = 3단계]

1. NOIM (Notice of Intended Marriage)
   - 결혼 1개월~18개월 전 신청
   - Celebrant에 양식 제출
   - 한국 가족관계증명서 + 영문 번역 (NAATI) 필요

2. 결혼식 (Wedding Ceremony)
   - Celebrant 진행 (의무)
   - Civil Celebrant = 90% 이상 (종교 X)
   - 등기소 (Registry) = 간단/저렴 옵션
   - 2명 증인
   - 비용: $400~1,500 (Celebrant Fee)

3. Marriage Certificate (결혼 증명서)
   - 정부 발급
   - $60~85
   - 결혼 직후 또는 우편 5~10일

[한국 영사관 신고 (의무)]
- 결혼 3개월 이내
- 시드니 영사관 (시드니, NSW)
- Marriage Certificate + NAATI 영문 번역
- 한국 가족관계 등재
- 한국에서도 결혼 인정

[비자 변경 = 자동 X]
- 학생비자 → Partner Visa (별도 신청 의무)
- Subclass 820/801 (Onshore) = $9,365 AUD
- 처리 기간: 12~24개월
- 신청 후 Bridging Visa 자동 (학생비자 만료 시)
- Bridging Visa = 일 가능 (조건)

[한국 학생이 자주 하는 패턴]

옵션 1: 등기소 결혼 (간단)
- 5~30분 진행
- $400~600
- 2명 증인
- 학생 = 가장 인기

옵션 2: Civil Wedding (가족/친구)
- Celebrant + 장소 + 식사
- $5,000~30,000
- 한국 가족 호주 방문 시 일반

옵션 3: 한국 + 호주 둘 다
- 호주 = 법적 결혼 (등기소)
- 한국 = 가족 결혼식 (별도)
- 한국 결혼식 = 법적 절차 X (이미 호주에서 결혼)

[준비 서류]

본인 (한국인):
- 여권
- 학생비자 증명
- 한국 가족관계증명서 (3개월 이내) + NAATI 번역
- 한국 미혼 증명서 (일부 Celebrant 요구) + 번역

배우자 (호주 시민):
- 호주 여권 또는 출생 증명
- 시민권 증명

[Partner Visa 신청 = MARA 변호사]
- 윌슨 = 이민 변호사 X
- MARA 등록 변호사 (의무 권장)
- 비용: 변호사비 $3,000~8,000 + 정부비 $9,365
- 시드니/멜번 한국어 변호사 다수

[결혼 후 비자 단계]
1. Partner Visa 820 신청 (호주 내)
2. Bridging Visa A 자동 (학생비자 만료 시)
3. 일 가능 (조건)
4. 12~24개월 후 영주권 (820 → 801 자동)
5. 4년 후 시민권 신청 가능

[현실적 비용 (호주 결혼)]
- 등기소 결혼: $1,000~2,000
- 일반 결혼식: $10,000~30,000
- 큰 결혼식: $30,000~80,000
- + Partner Visa: $9,365 + 변호사 $3,000~8,000
- 총 첫 비용: $20,000~50,000

축하드리고, 결혼 + 비자 = 신중히 준비하세요.
MARA 변호사 추천은 윌슨이 카카오로 안내드려요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "결혼 = 영주권 자동"
- **거짓**. Partner Visa 별도 신청 + 12~24개월 처리
- 결혼만 하면 영주권 X

### 함정 2: "한국 결혼식 = 호주 인정"
- **부분 사실**. 한국 등록 = 호주 인정 가능
- 다만 호주 결혼이 법적으로 더 강함
- 호주에서 살 거면 호주 결혼 권장

### 함정 3: "Civil Wedding = 한국식 안 됨"
- **거짓**. Civil = 자유 진행
- 한국 의식 포함 가능
- Celebrant와 협의

### 함정 4: "NOIM 안 해도 돼"
- **거짓**. 의무
- 1개월 전 의무
- 미신청 = 결혼 무효

### 함정 5: "Partner Visa 신청 = 윌슨"
- **거짓**. MARA 등록 의무
- 윌슨 X (이민 변호사 X)
- 변호사 안내만

### 함정 6: "한국 영사관 신고 안 해도 돼"
- **거짓**. 의무
- 3개월 이내
- 한국 신분 서류 영향

### 함정 7: "De Facto = 결혼 동일"
- **부분 사실**. 법적 효력 비슷
- 다만 De Facto = 12개월+ 증명
- Partner Visa = 둘 다 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 약혼자 정보
- 호주 시민 vs PR vs 임시 비자
- 결혼 가능 여부 (양측 자유 신분)

### 2. 결혼 일정
- 1개월~18개월 사이
- 등기소 vs 결혼식

### 3. 한국 가족
- 호주 방문 가능 여부
- 가족관계증명서 발급

### 4. 비자 변경 의도
- Partner Visa 즉시
- 학생비자 유지 (학업 마무리)
- 귀국 의도

---

## 🔍 직원이 직접 확인 가능한 사이트

- Attorney-General's Department: ag.gov.au/families-and-marriage/marriage
- Find a Celebrant: ag.gov.au/families-and-marriage/marriage/find-a-celebrant
- NSW BDM: nsw.gov.au/birth-death-marriage
- VIC BDM: bdm.vic.gov.au
- QLD BDM: qld.gov.au/law/births-deaths-marriages-and-divorces
- 시드니 영사관: aus-syd.mofa.go.kr
- 멜번 영사관: aus-melbourne.mofa.go.kr
- 브리즈번 영사관: aus-brisbane.mofa.go.kr
- Department of Home Affairs: immi.homeaffairs.gov.au
- MARA: mara.gov.au

---

## 🚨 직원 영역 vs MARA / Wedding Planning 영역

### 직원이 할 수 있는 것
- ✅ 호주 결혼 절차 설명
- ✅ NOIM 시스템 안내
- ✅ Celebrant 시스템 설명
- ✅ 한국 영사관 신고 안내
- ✅ Partner Visa 개요 설명

### 직원이 할 수 없는 것
- ❌ Partner Visa 신청 (MARA 의무)
- ❌ 변호사 자문
- ❌ Wedding Planning
- ❌ Celebrant 추천 강요
- ❌ 결혼 적법성 판단

---

## ✅ 완벽 응대 체크리스트

- [ ] 약혼자 비자 신분 확인
- [ ] 결혼 일정 확인
- [ ] 한국 가족 호주 방문 여부
- [ ] 비자 변경 의도 확인
- [ ] NOIM 1개월 전 의무 설명
- [ ] Celebrant 의무 설명
- [ ] 등기소 결혼 옵션 안내 (저렴)
- [ ] 한국 가족관계증명서 + NAATI 강조
- [ ] 한국 미혼 증명서 안내
- [ ] Marriage Certificate 발급 설명
- [ ] 한국 영사관 신고 의무 강조 (3개월)
- [ ] 결혼 ≠ 영주권 자동 강조
- [ ] Partner Visa 별도 신청 설명
- [ ] MARA 변호사 의무 권장
- [ ] Bridging Visa 자동 안내
- [ ] 처리 기간 12~24개월 안내
- [ ] 비용 합계 ($20,000~50,000) 안내
- [ ] Wedding Planning = 안 함
- [ ] Partner Visa 신청 대행 = 안 함

---

**작성**: ausuhak.com 직원 교육팀
**감수**: Wilson Kim (QEAC E240)
**기준**: 2026년 5월
**다음 업데이트**: Partner Visa 정책 변경 시
