# #211 코스 변경 (학과 전환 / 6개월 룰)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 와서 회계 공부 중인데 IT로 바꾸고 싶어요. 학교도 바꾸고 싶고요. 비자 다시 받아야 하나요?"

**직원 멘붕 포인트:**
- 6개월 룰 (Standard 7 of National Code)
- 같은 학교 vs 다른 학교
- 같은 레벨 vs 낮은 레벨
- Release Letter

---

## ❌ 절대 하지 말아야 할 답

> "코스 변경 자유로워요. 그냥 다른 학교 가세요!"

→ ❌ **6개월 룰 = 첫 코스 시작 6개월 이내 = 학교 변경 X (Release Letter 필수)**.

---

## ✅ 정답

호주 코스 변경: ① **6개월 룰 (Standard 7 of National Code)** = 첫 코스 시작 6개월 이내 = 학교 변경 시 Release Letter 필수 ② **6개월 후** = 자유 변경 ③ **같은 학교 코스 전환** = 6개월 룰 적용 X (학교 내부 절차) ④ **레벨 다른 코스** (Bachelor → Master) = 비자 새로 신청 ⑤ **같은 레벨** (Bachelor → Bachelor) = 기존 비자 유지 (학교 변경 신고). PRISMS 통보. 윌슨 검토.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 6개월 룰 (Standard 7 of National Code)
- 첫 주 (Principal Course) 시작 6개월 이내 = 학교 변경 시 Release Letter 필수
- 학교 거부 가능
- ELICOS / Foundation = 첫 주 코스 X (Bachelor 시작이 첫 주)

### 2. Release Letter
- 현재 학교가 발급
- "다른 학교로 옮겨도 이의 없음" 확인서
- 거부 사유: 학비 미납 / 출석 불량
- 거부 시 = ART 항소 가능

### 3. 같은 학교 코스 전환
- 학교 내부 신청
- 6개월 룰 X
- 비자 = CoE 변경 시 학교 → DHA 통보

### 4. 레벨 변경
- 같은 레벨 (Bachelor → Bachelor): 기존 비자 OK
- 낮은 레벨 (Bachelor → Diploma): 비자 영향 가능 (DHA 통보)
- 높은 레벨 (Bachelor → Master): 비자 새로 신청

### 5. 코스 변경 후 비자 영향
- 코스 길이 길어짐 → 비자 연장
- 코스 길이 짧아짐 → 비자 단축
- 학비 변동 → 재정증명 영향 가능

---

## 🎯 정답 경로

### Step 1: 첫 코스 시작 시점 확인
- 6개월 이내? → Release Letter 필수
- 6개월 후? → 자유

### Step 2: 변경 종류
- 같은 학교 다른 코스 → 학교 내부
- 다른 학교 → Release Letter + 새 CoE
- 다른 레벨 → 비자 영향 검토

### Step 3: Release Letter 신청
- 현재 학교에 신청
- 학비 완납 / 출석 양호 시 발급
- 거부 시 ART 항소

### Step 4: 새 학교 CoE
- 새 학교 지원 → CoE 발급
- DHA 통보 (학교 자동)

### Step 5: 비자 검토
- 코스 길이 / 학비 변경 시 비자 영향
- 윌슨 무료 검토

---

## 💡 직원 멘트

> "안녕하세요! 코스 변경 안내드릴게요.
>
> ✅ 첫 코스 시작 6개월 이내? → Release Letter 필수
> ✅ 6개월 이후 → 자유 변경
> ✅ 같은 학교 다른 코스 → 학교 내부 절차
> ✅ 다른 학교 → Release Letter + 새 CoE
>
> 코스 변경 = 비자에 영향 있을 수 있어서 윌슨님 검토 필수예요!
>
> 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 7개

1. ❌ "코스 자유 변경" → ✅ 6개월 룰 적용
2. ❌ "Release Letter 자동 발급" → ✅ 학교 거부 가능
3. ❌ "같은 학교 코스 전환 = 6개월 룰 적용" → ✅ 같은 학교 = 룰 X
4. ❌ "비자 영향 X" → ✅ 코스 변경 = 비자 영향 가능
5. ❌ "Release 거부 = 못 옮김" → ✅ ART 항소 가능
6. ❌ "간호 → IT 자유 전환" → ✅ 간호 = 별도 IELTS 7.0 / ANMAC 검토
7. ❌ "Pathway → 본 코스 = 6개월 룰" → ✅ Pathway → 본 코스 = 패키지면 OK

---

## 📞 필수 4가지 확인

1. ✅ 첫 코스 시작 시점 (6개월 룰)
2. ✅ 변경 종류 (학교 / 레벨)
3. ✅ Release Letter 가능 여부
4. ✅ 윌슨 비자 영향 검토

---

## 🔍 직원 사이트

- **PRISMS**: https://prisms.education.gov.au
- **DHA 학생비자 변경**: https://immi.homeaffairs.gov.au
- **National Code 2018**: https://internationaleducation.gov.au

---

## 🚨 직원 vs 윌슨

**직원**: 6개월 룰 안내 / Release Letter 절차
**윌슨**: 코스 매칭 / 비자 영향 검토 / Release 거부 시 ART

---

## ✅ 체크리스트

- [ ] 첫 코스 시작 시점 / 6개월 룰 적용 여부
- [ ] 변경 종류 (학교 / 레벨)
- [ ] Release Letter 가능 여부
- [ ] 비자 영향 윌슨 검토
- [ ] 카카오톡 1:1 상담 연결
