# #471 호주_학생_과제_표절_Plagiarism_Turnitin_Academic_Misconduct_퇴학

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "에세이 제출했는데 학교에서 Academic Misconduct 의심 메일 왔어요. Turnitin Similarity 45% 나왔대요. 친구 거 참고만 했는데 퇴학될까요?"

**직원 멘붕 포인트:**
- Plagiarism = 표절. Turnitin = 호주 모든 대학 의무 사용 표절 검사 시스템
- Similarity 점수 45%면 Heavy Plagiarism 영역 (보통 20% 미만 안전)
- Academic Misconduct 의심 메일 = 정식 조사 시작 신호. 학생은 응답 의무 있음
- 최악의 경우: Course에서 Fail → 학생비자 취소 → 강제 출국 가능성
- 직원이 '괜찮을 거예요' 위로하면 안 됨. 학교 응답 기한 놓치면 자동 유죄

---

## ❌ 절대 하지 말아야 할 답

> "에이 별일 아니에요 학교가 봐줄 거예요 그냥 무시하셔도 돼요"

→ ❌ Academic Misconduct는 학생비자 직결 사안. 응답 기한(보통 5~10일) 놓치면 In Absentia 자동 처분. 한국식 '봐주기' 문화 X. 호주 대학은 ESOS Act 의무 보고

---

## ✅ 정답

가장 중요한 건 학교에서 보낸 메일의 응답 기한 확인입니다. 보통 5~10영업일 안에 답변해야 해요. 기한 놓치면 변명 기회 없이 자동 처분됩니다. 학교 Academic Integrity Officer와 미팅 신청하시고, Student Advocacy Service(무료)에 동행 요청하세요. 동시에 윌슨샘과 비자 영향 상담 잡아야 합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Turnitin Similarity 점수 기준**
0~10%: 안전 (인용 문헌 매칭 수준)
10~20%: 주의 (Self-citation 포함 가능)
20~40%: 의심 (조사 대상)
40% 이상: Heavy Plagiarism 추정
Quote 인용 부호 사용해도 출처 표기 누락 시 표절로 카운트

**2. Academic Misconduct 종류 (호주 대학 공통)**
1. Plagiarism: 출처 없는 복사
2. Collusion: 공동 작업 금지된 과제 같이 쓴 것
3. Contract Cheating: 대필/돈 주고 산 과제 (가장 중죄, 즉시 퇴학)
4. AI Generation: ChatGPT 등 AI 사용 (2024부터 검사 강화)
5. Self-Plagiarism: 본인이 다른 과목 낸 과제 재사용
→ 친구 거 참고는 #2 Collusion 가능성 높음

**3. 처벌 수위 (호주 대학 표준)**
Tier 1 (경고): 점수 0점 + 재제출 (1차 위반)
Tier 2 (감점): Course Fail Grade
Tier 3 (정학): 1~2 학기 정학
Tier 4 (퇴학): Exclusion. 성적표에 영구 기록
Contract Cheating은 1차 위반도 바로 Tier 4

**4. 학생비자 영향 (CRITICAL)**
Course Fail = Unsatisfactory Course Progress
→ 학교가 PRISMS 통해 Section 19 Report
→ Department of Home Affairs 통보
→ Section 116 비자 취소 검토
→ Notice of Intention to Consider Cancellation (NOICC) 28일 응답
→ 응답 안 하면 자동 비자 취소

**5. Student Advocacy Service (무료, 가장 중요)**
호주 모든 대학 학생회(Student Union) 산하에 있음
USyd: SRC Caseworkers / UNSW: Arc / UTS: Students' Association
Monash: MSA Advocacy / UQ: UQ Union
역할: Hearing 동행 + 학교 절차 자문 + 진술서 작성 도움
100% 무료 + 학교에서 독립적 = 학생 편

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 메일 받은 즉시 응답 기한 확인 → 캘린더 알람 설정
**2단계**: 학교 Student Advocacy Service 연락 → Hearing 동행 신청
**3단계**: Turnitin 보고서 PDF 다운로드 + 본인 초안/노트 보존 (의도성 부인 자료)
**4단계**: Academic Integrity Officer Hearing 참석 → Tier 1 경고 협상
**5단계**: 결과에 따라 윌슨샘 카카오 1:1 상담 → 비자 Section 19/116 대응 결정

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요 학생님. Plagiarism 의심 메일은 매우 중요한 사안이에요. 응답 기한이 며칠 남았는지 먼저 확인 부탁드립니다. 그리고 학교 Student Advocacy Service(학생회 무료 자문)에 바로 연락해서 Hearing 동행 요청하세요. 비자 영향 부분은 윌슨샘과 1:1 상담 잡아드릴게요. 카카오 ID studywilson 입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'친구 거 참고만 했어요' = Collusion 자백**
   → 친구 과제를 참고했다는 표현은 학교에 Collusion으로 해석됨. 진술 시 단어 선택 신중. 'Reference made publicly available materials'로 수정

2. **ChatGPT 사용 부인 = 더 큰 처벌**
   → Turnitin AI Detector 정확도 높음. 거짓말 들통나면 Tier 1 → Tier 4 상승. 사용했으면 솔직히 인정 + 잘못 인지

3. **'한국에서는 친구 거 베끼는 거 흔해요' 변명 X**
   → 호주 대학은 문화 변명 안 받음. 한국식 사고방식 통하지 않음. 학교 정책 무지가 변명 안 됨

4. **Hearing 안 가면 자동 유죄**
   → 출석 안 하면 In Absentia 처분. 변명 기회 박탈. 무조건 출석 필수

5. **부모님 호출 X**
   → 호주 대학은 18세 이상 학생만 직접 응대. 부모 동행 무의미. Student Advocacy가 정답

6. **학교 봐주기 기대 X**
   → 호주 대학은 ESOS Act에 의해 Department에 의무 보고. 학교가 봐줄 수 있는 영역 아님

7. **Section 19 Report 통보 자동**
   → 학교가 학생에게 Section 19 Report 가는 사실 별도 통보 안 함. PRISMS 통해 자동 보고

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 메일 응답 기한 며칠 남았어요? (5일 이상 / 5일 미만)
2. Turnitin Similarity 점수 몇 퍼센트예요? (20% 미만 / 20~40% / 40% 이상)
3. ChatGPT 같은 AI 사용했어요? (했다 / 안 했다)
4. Student Advocacy Service 연락했어요? (했다 / 안 했다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- USyd Academic Integrity: sydney.edu.au/students/academic-integrity
- UNSW Conduct: student.unsw.edu.au/conduct
- Monash Integrity: monash.edu/students/admin/policies/academic-integrity
- Department NOICC: immi.homeaffairs.gov.au (Section 116)
- TEQSA Higher Ed Standards: teqsa.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 응답 기한 안내
- Student Advocacy Service 연결
- Turnitin 보고서 해석
- Tier 협상 전략 코칭

**MARA / 변호사 영역**
- Section 116 NOICC 응답서 작성 (MARA)
- 비자 취소 이의 신청 ART (Lawyer)
- 재학 중 비자 변경 옵션 (MARA)
- Federal Court Judicial Review (Lawyer)

---

## ✅ 완벽 응대 체크리스트

- [ ] 응답 기한 캘린더 알람 설정 완료
- [ ] Student Advocacy Service 연락 완료
- [ ] Turnitin PDF + 본인 초안/노트 보존 완료
- [ ] Hearing 출석 일정 확정
- [ ] 윌슨샘 비자 영향 1:1 상담 예약
