# #490 호주_학교_학생_사망_자살_다른_학생_PTSD_심리_지원_Counselling

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제 학교 친구가 갑자기 자살했어요. 충격이 너무 커서 학업도 못 하겠어요. 학교에서 뭐 도와주나요?"

**직원 멘붕 포인트:**
- 친구 사망 = PTSD 위험 + 본인 자살 위험 신호 가능
- Lifeline 13 11 14 / Beyond Blue 1300 22 4636
- Suicide Call Back 1300 659 467
- 학교 Counselling Service 무료 + Mental Health Care Plan
- 직원이 '시간 지나면 잊혀져요' 위로 X

---

## ❌ 절대 하지 말아야 할 답

> "시간 지나면 잊혀져요 너무 많이 생각하지 마세요"

→ ❌ 외상 사건은 시간만으로 해결 X. PTSD/우울 진행 위험. 전문가 연결 필수

---

## ✅ 정답

친구 잃으셨다니 정말 가슴 아픕니다. 지금 학업도 어려우신 정도면 외상 후 스트레스 신호일 수 있어요. 학교 Counselling Service 무료 상담 예약하시고, Beyond Blue 1300 22 4636 한국어 통역(13 14 50) 통한 24시간 상담도 가능합니다. GP에서 Mental Health Care Plan 받으면 심리치료 10회 거의 무료예요. 학업은 학교에 Special Consideration 신청하면 시험 연기/대체 평가 가능합니다. 본인 위험 신호 느끼면 즉시 000 또는 Lifeline 13 11 14 연락하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. PTSD 신호 (사건 1개월 이상)**
Flashback (사건 반복 떠올림)
악몽
회피 (장소/사람)
과민 (놀람/분노)
우울/무기력
자살 사고
학업/기능 저하
1주 이상 지속 시 GP 필수

**2. 학교 Counselling (무료)**
USyd: Student Counselling Service
UNSW: Psychology and Wellness
UTS: Counselling
Monash: Counselling and Psychological Service
예약 1~3주 대기 (긴급은 24시간)
외국인 학생도 무료

**3. Mental Health Care Plan (GP)**
GP 방문 → MHCP 작성
심리치료 10회 + 추가 10회 (연 20회)
OSHC 일부 환급 + Bulk-Bill 시 무료
Psychologist/Social Worker/Mental Health Nurse

**4. 긴급 자원**
000 즉시 (생명 위협)
Lifeline 13 11 14 (24시간)
Beyond Blue 1300 22 4636 (24시간)
Suicide Call Back 1300 659 467
한국어 통역 13 14 50
Headspace 12~25세 무료

**5. Special Consideration**
학교 학업 연기/대체 평가
Counselling Letter 또는 GP Letter 첨부
사망 사건은 Compassionate 인정
시험 연기, 과제 연장, Withdraw Without Penalty
Census Date 이후도 가능 (Compassionate)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 학교 Counselling Service 즉시 예약
**2단계**: GP 방문 + Mental Health Care Plan 발급
**3단계**: Beyond Blue 또는 Lifeline 24시간 상담
**4단계**: 학교 Special Consideration 신청 (학업)
**5단계**: 위험 신호 시 000 또는 Lifeline

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 친구 잃으셨다니 정말 가슴 아픕니다. 학교 Counselling Service 무료 상담 예약하시고, Beyond Blue 1300 22 4636에서 24시간 한국어 통역(13 14 50) 상담 받으세요. GP에서 Mental Health Care Plan 받으면 심리치료 10회 거의 무료입니다. 학업은 Special Consideration 신청하면 시험 연기 가능해요. 본인 위험 신호 느끼면 즉시 Lifeline 13 11 14 연락하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'시간 지나면' 위로 X**
   → 전문가 연결 필수

2. **학교 상담 유료 X**
   → 무료 + 외국인 OK

3. **MHCP 거부 X**
   → OSHC 일부 환급 + Bulk-Bill

4. **한국 부모 X**
   → 한국 부모 알리는 게 부담이면 학교/Beyond Blue

5. **Special Consideration 자동 X**
   → 신청 + Counselling/GP Letter

6. **위험 신호 무시 X**
   → 본인 자살 사고 즉시 000

7. **종교 강요 X**
   → 본인 가치관 존중

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사건 후 며칠? (1주 이내/1주~1개월/1개월+)
2. 본인 자살 사고 있어요? (있다/없다)
3. GP 또는 학교 상담 받았어요? (받음/안 받음)
4. 한국 가족 인지? (인지/미인지)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Lifeline: 13 11 14 / lifeline.org.au
- Beyond Blue: 1300 22 4636 / beyondblue.org.au
- Suicide Call Back: 1300 659 467
- Headspace: headspace.org.au
- TIS Korean: 13 14 50

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학교 Counselling 안내
- Beyond Blue 한국어 통역 안내
- Special Consideration 1차 안내
- GP 연결

**MARA / 변호사 영역**
- Special Consideration 분쟁 (학교 또는 Lawyer)
- 비자 Compassionate 연장 (MARA)
- 한국 가족 알림 (영사관)
- 사망 친구 가족 한국 송환 (Funeral Director)

---

## ✅ 완벽 응대 체크리스트

- [ ] 학교 Counselling 예약
- [ ] GP MHCP 발급
- [ ] Beyond Blue 상담
- [ ] Special Consideration 신청
- [ ] 위험 신호 시 즉시 000
