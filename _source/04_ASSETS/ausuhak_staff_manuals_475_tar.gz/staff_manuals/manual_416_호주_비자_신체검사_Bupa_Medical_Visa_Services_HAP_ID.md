# #416 호주_비자_신체검사_Bupa_Medical_Visa_Services_HAP_ID

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "학생비자 처음 받을 때 신체검사 했는데, 485 비자 신청할 때도 다시 해야 하나요? 어디서 받나요? 한국에서 받는 거랑 호주에서 받는 거 차이 있나요? B형 간염 보균자인데 비자 떨어질까봐 걱정돼요."

**직원 멘붕 포인트:**
- 비자별 신체검사 재시행 여부
- Bupa Medical 위치 모름
- 한국/호주 검사 비용 차이
- B형 간염/HIV 등 비자 영향
- Health Waiver 조건

---

## ❌ 절대 하지 말아야 할 답

> "B형 간염 있으면 비자 못 받아요"

→ ❌ ❌ 거짓. B형 간염 단독으론 거의 영향 없음. 단, 활성 결핵, HIV (특정 조건), 복합 의료비 $86K(2024 기준) 초과 예상 시만 거부.

---

## ✅ 정답

HAP ID(Health Examination Reference) 발급 후 Bupa Medical Visa Services(BMVS) 또는 한국 지정 병원에서 검사. 비자 신청마다 별도. 학생→485 = 새 신체검사 (단, 12개월 내 검사면 면제 가능). 비용: 호주 $370~$500 / 한국 KRW 30만~50만. B형 간염은 거의 영향 X. 활성 결핵/HIV/복합 만성질환만 우려. 거부 우려 시 Health Waiver(Subclass별 가능) 또는 MARA 변호사.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. HAP ID + Examination 종류**
비자 신청 시 ImmiAccount에서 HAP ID 발급. Examination 501(General Medical, 보통 6개월+ 비자), 502(Chest X-ray), 707(HIV Test 만 15세+ 일부 비자). 707은 PR/485/일부 학생비자 의무. 학생비자 12개월+ = 501+502 (필요 시 707). 485 = 501+502+707 의무. PR (189/190/186/482) = 모두 의무.

**2. Bupa Medical Visa Services (BMVS)**
호주 정부 지정 의료기관. bupamvs.com.au. 호주 25개 도시. Sydney CBD, Parramatta, Bankstown, Melbourne CBD, Box Hill, Brisbane, Adelaide, Perth, Hobart, Canberra, Darwin 등. 예약 필수 (1~3주 대기). 비용: 501 $400, 502 $100~$150, 707 $200. 결과 직접 ImmiAccount 업로드 (5~14일).

**3. 한국 지정 병원 + 비용 차이**
한국 지정 병원: 강남 세브란스, 서울아산, 한양대 구리병원, 부산백병원, 대구 영남대 등 immi.homeaffairs.gov.au에서 검색. 비용: KRW 30만~50만 (501+502), KRW 60만~80만 (501+502+707). 호주 대비 30% 저렴. 단, 한국에서 검사 후 영문 결과지 + Apostille 불필요 (지정 병원이 직접 ImmiAccount 업로드).

**4. B형/C형 간염 비자 영향 (거의 없음)**
Migration Health Requirements: 비자 거부 사유 = 1) Public Health Risk (활성 결핵, 일부 면역억제 환자) 2) Significant Healthcare Cost ($86K/생애 평균) 3) 호주 의료시스템 부담. B형/C형 간염 보균자 (만성 캐리어): 비자 영향 거의 없음 (간경변/간암 진행 중인 경우만 우려). 활성 결핵: 치료 후 음성 확인 = 통과. HIV: PEP/ART 치료 비용 $86K 초과 가능 → 거부 가능 (Skilled 비자에서 더 엄격).

**5. Health Waiver (특정 비자만)**
Health Waiver = 의료 요건 면제 신청. 가능 비자: 485(부분), 482(부분), 186(가능), 189/190(부분), 부모비자(가능). 학생비자 = Health Waiver 없음 (의료 거부 시 비자 거부). Waiver 조건: 의료비가 호주 사회에 'Undue Cost' 안 끼친다 입증 (예: 본인 + 가족이 비용 부담 약속). MARA 변호사 + 의료 변호사 협업 필수.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 비자 신청 시 ImmiAccount에서 HAP ID 자동 발급
**2단계**: 2단계: BMVS(호주) 또는 한국 지정병원 예약 - 1~3주 대기
**3단계**: 3단계: 검사 (501/502/707) - 본인 여권 + HAP ID 지참
**4단계**: 4단계: 5~14일 후 결과 ImmiAccount 자동 업로드
**5단계**: 5단계: 의료 우려 시(B형 간염/활성 질환) MARA 변호사 + Health Waiver 신청 (가능 비자만)

---

## 💡 직원이 학생한테 말할 멘트

> "비자 신체검사 정리해드릴게요.

485 비자 신청 시 새로 검사 받으셔야 해요. 보통 학생비자 첫 검사 후 12개월 내면 면제 가능하지만, 그 이후면 재검사예요.

검사 항목:
- 501: General Medical (혈압, 시력, 청력, 신체 검진)
- 502: 흉부 X-ray (결핵 검사)
- 707: HIV (만 15세+ 일부 비자 의무, 485 의무)

호주: BMVS (bupamvs.com.au) - $400~$700
한국: 강남 세브란스 등 지정 병원 - KRW 60만~80만 (호주 대비 30% 저렴)

B형 간염은 거의 영향 없습니다. 호주 비자 거부 의료 사유는:
1) 활성 결핵 (치료 받으면 통과)
2) 의료비 $86K/생애 초과 우려 질환
3) 일부 면역억제 환자

B형 간염 캐리어(만성)는 거의 영향 없고, 간경변/간암 진행 중일 때만 우려예요.

걱정되시면 윌슨 카톡(studywilson)으로 의료 기록 (한국어 OK) 보내주시면 1차 평가 후 MARA 변호사 + Health Waiver 가능성 안내드려요. 솔직히 B형 간염 단독은 90%+ 통과해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **B형 간염 보균자 비자 못 받는다고 안내**
   → ❌ 거짓. B형 간염 단독은 거의 영향 없음. 활성 결핵/HIV(특정)/복합 질환만.

2. **학생비자 신체검사 한 번이면 평생 OK라고 안내**
   → ❌ 거짓. 비자 신청마다 새로 (12개월 내 면제 가능).

3. **한국에서 검사 받으면 호주 인정 안 된다고 안내**
   → ❌ 거짓. immi.homeaffairs.gov.au 지정 병원이면 인정.

4. **Bupa Medical에서 본인이 결과 받아 제출한다고 안내**
   → ❌ 거짓. BMVS가 직접 ImmiAccount 업로드. 본인 못 봄.

5. **학생비자에 Health Waiver 가능하다고 안내**
   → ❌ 거짓. 학생비자는 Health Waiver 없음. 의료 거부 시 비자 거부.

6. **HIV 양성이면 무조건 비자 거부라고 안내**
   → ❌ 부정확. ART 치료 + 비용 부담 능력 입증 시 일부 비자 통과 가능 (Skilled 어려움, 학생/관광 가능 多).

7. **707 검사 모든 비자 의무라고 안내**
   → ❌ 부정확. 만 15세+ + 일부 비자(485, PR 등)만 의무. 단기 비자 면제.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 신청할 비자 종류 (학생/485/PR)
2. 이전 검사 시점 (12개월 내 면제 가능)
3. 건강 상태 (B형 간염/HIV/결핵 이력)
4. 검사 장소 선호 (호주 BMVS / 한국 지정병원)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Bupa Medical Visa Services: bupamvs.com.au
- 한국 지정 병원 검색: immi.homeaffairs.gov.au (검색: panel physician)
- Migration Health Requirements: immi.homeaffairs.gov.au (검색: health requirements)
- Health Waiver 정보: immi.homeaffairs.gov.au (검색: health waiver)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 일정 + 신체검사 일정 코디네이션
- 한국 vs 호주 검사 비용/시간 비교 컨설팅
- 장기 비자 (485/PR) 의료 사전 평가

**MARA / 변호사 영역**
- Health Waiver 신청 - MARA 변호사 (필수, 학생비자 X)
- 의료 거부 항소 - ART (Administrative Review Tribunal (2024.10.14 AAT 대체))
- 복잡한 의료 케이스 (HIV/암 등) - MARA + Medical Lawyer

---

## ✅ 완벽 응대 체크리스트

- [ ] 신체검사 비자별 새로 받음 안내
- [ ] 501/502/707 차이 설명
- [ ] BMVS + 한국 지정병원 옵션 안내
- [ ] 비용 차이 (호주 $400~$700 vs 한국 KRW 60~80만)
- [ ] B형 간염은 거의 영향 없음 (걱정 덜기)
- [ ] Health Waiver는 학생비자 X 명확히
- [ ] HIV/결핵 등 우려 시 MARA 변호사 안내
- [ ] 윌슨 카톡 1차 의료 평가 유도
