# #427 호주_학생_룸메이트_갈등_셰어_분쟁_보증금_NCAT

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "셰어하우스 사는데 한인 룸메이트가 자꾸 부엌 안 치우고 음식 훔쳐먹고 친구들 매일 데려와서 시끄러워요. 마스터 룸 잡은 사람이라 저보고 나가라는데 보증금 $1,500 안 돌려준대요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Sublease 합법성 (마스터 룸 권한)
- Bond (보증금) 회수 절차
- NCAT 신청 자격
- Subletting 분쟁 관할
- 한인 셰어 서면 계약 부재

---

## ❌ 절대 하지 말아야 할 답

> "셰어 분쟁은 그냥 나가시는 게 마음 편해요"

→ ❌ ❌ Bond은 법적 권리. NCAT 무료 ($55) 신청 가능. 포기 권유 금지.

---

## ✅ 정답

셰어 분쟁 해결: ① Lease Agreement 확인 (Co-tenant vs Sub-tenant 구분), ② Co-tenant = 본인도 임대인 직접 계약 / Sub-tenant = 마스터 룸 통한 재임대, ③ Bond은 RTBA(VIC)/Rental Bonds Online(NSW) 등록 의무 (미등록 = 불법), ④ 미등록 Bond = Local Court 또는 NCAT 신청 가능, ⑤ NCAT 신청 $55 / 6주 처리 / 한국어 통역 무료, ⑥ Sublease 자체가 마스터 룸 임대인의 House Owner 동의 없으면 불법 (마스터 룸 사람이 위반), ⑦ 한인 셰어 서면 계약 X = 입증 어려움 (카톡/송금 내역 증거), ⑧ Tenants Union 무료 상담 (NSW 8117 3700).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Co-tenant vs Sub-tenant**
임대인 직접 계약 vs 재임대

**2. Bond 등록 의무**
RTBA(VIC) / Rental Bonds Online(NSW)

**3. NCAT**
$55 / 6주 / 한국어 통역

**4. Tenants Union**
주별 무료 / NSW 8117 3700

**5. Subletting 동의**
House Owner 서면 동의 필수

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 계약서 (있으면) 또는 카톡/송금 증거 수집
**2단계**: 2단계: Bond 등록 여부 확인 (RTBA/RBO 조회)
**3단계**: 3단계: Tenants Union 무료 상담
**4단계**: 4단계: NCAT 신청 ($55)
**5단계**: 5단계: 새 셰어 찾기 (Gumtree/Flatmates.com.au)

---

## 💡 직원이 학생한테 말할 멘트

> "Bond은 법적 권리입니다. 카톡/송금 내역 증거 모으시고 Tenants Union NSW 8117 3700 무료 상담 받으세요. NCAT $55로 신청 가능합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한인 셰어 법적 보호 X**
   → 잘못된 정보 / 법 적용 동일

2. **서면 계약 X = 권리 X**
   → 구두 계약도 인정

3. **Bond 자동 반환**
   → 21일 내 미반환 시 NCAT

4. **Sublease 합법**
   → House Owner 동의 필수

5. **경찰 신고로 해결**
   → 민사는 경찰 X / NCAT

6. **한국 영사관 분쟁 해결**
   → 호주 민사는 호주만

7. **Master Room이 House Owner**
   → 전혀 다름

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Co-tenant vs Sub-tenant 구분
2. 서면 계약 또는 송금 증거 유무
3. Bond 등록 여부
4. 현재 거주 여부 (이사 전/후)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Tenants Union NSW', 'tenants.org.au')
- ('Rental Bonds Online', 'rbo.fairtrading.nsw.gov.au')
- ('NCAT', 'ncat.nsw.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 셰어 분쟁 일반론, NCAT 안내

**MARA / 변호사 영역**
- 대규모 분쟁 시 Civil Lawyer / LawAccess 1300 888 529

---

## ✅ 완벽 응대 체크리스트

- [ ] Bond 등록 확인 강조함
- [ ] Tenants Union 무료 안내함
- [ ] NCAT $55 안내함
- [ ] 증거 수집 강조함
- [ ] Co-tenant/Sub-tenant 구분함
- [ ] 구두 계약 인정 안내함
