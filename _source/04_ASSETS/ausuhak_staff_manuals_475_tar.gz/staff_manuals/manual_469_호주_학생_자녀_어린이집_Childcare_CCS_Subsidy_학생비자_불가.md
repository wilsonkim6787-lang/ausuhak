# #469 호주_학생_자녀_어린이집_Childcare_CCS_Subsidy_학생비자_불가

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "동반 비자로 와이프와 아들(2살) 같이 호주 살아요. 와이프 아르바이트 시작하려는데 아들 어린이집 보내야 해요. 호주 어린이집 비싸다고 들었는데 정부 보조(CCS) 받을 수 있나요? 학생비자도 가능한가요? 비용 얼마나 들어요?"

**직원 멘붕 포인트:**
- Childcare Subsidy(CCS) = 영주권/시민권만 (학생비자 X)
- Long Day Care 비용 $100~$180/일 / 주 5일 = $500~$900/주
- Family Day Care = $80~$130/일 (저렴)
- NSW/VIC/QLD 4세 무료 Pre-school = 학생비자 일부 OK
- 어린이집 Waiting List 6~12개월 (도시)
- 한인 베이비시터 = 무허가 위험

---

## ❌ 절대 하지 말아야 할 답

> "학생비자도 정부 보조 받을 수 있어요"

→ ❌ Childcare Subsidy = 영주권/시민권/임시 비자 일부만 / 학생비자 = 자격 X / 100% 본인부담 / 정확한 안내 필수

---

## ✅ 정답

(1) CCS = 영주권/시민권만 - 학생비자 자격 X (2) 학생비자 자녀 = 100% 본인부담 (3) Long Day Care $500~$900/주 (4) Family Day Care $400~$650/주 (5) NSW/VIC/QLD Pre-school 4세 무료(일부 학생비자 OK) (6) 윌슨 직접 상담 - 가족 동반 자금 계획

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Childcare Subsidy(CCS) 자격**
Services Australia 운영 / servicesaustralia.gov.au / 영주권(186/189/190/491 등) / 시민권 / Special Category(NZ) / 일부 임시 비자(Bridging) / 학생비자 500 = 자격 X / 동반 비자 자녀 = 자격 X.

**2. 어린이집 종류 + 비용**
Long Day Care(LDC): $100~$180/일 / 풀타임 6시-18시 / 영아~5세 / Family Day Care(FDC): $80~$130/일 / 가정 보육 / 4명 이내 / Outside School Hours Care(OSHC): $30~$60/일 / 학교 후 / Pre-school: 3~5세 / NSW Mobile Pre-school 일부 무료.

**3. 주별 4세 무료 Pre-school**
NSW Universal Access: 4세 600시간/년 무료(Mobile Pre-school만) / VIC Three-Year-Old + Four-Year-Old Kinder: 무료(영주권/시민권 우선) / QLD Kindergarten: 4세 600시간 / 학생비자 자녀 = 일부 자치주 가능(공립 Pre-school).

**4. Family Day Care 한국인 등록**
Family Day Care Educator = 정부 등록 / NQF(National Quality Framework) 인증 / 한국인 Educator 일부 존재 / 한국어 보육 가능 / Wilson 한인 커뮤니티 X 권장(Wilson 6대 실패).

**5. Waiting List 6~12개월**
도시(시드니/멜번 CBD) Long Day Care = 6~12개월 대기 / 임신 시점 등록 권장 / 부모 직장 근처 우선 / 학교 부속(University 어린이집) = 학생 우선 OK.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 어린이집 종류 결정 - LDC vs FDC vs Pre-school
**2단계**: 2차: 학생비자 자녀 = CCS X 확인 - 100% 본인부담 사실
**3단계**: 3차: 어린이집 Waiting List 신청 - 즉시(임신 시 1년 전부터)
**4단계**: 4차: 비용 계산 - Long Day Care $500~$900/주 = 월 $2,000~$3,600
**5단계**: 5차: 한국 vs 호주 보육 비교 - 윌슨 직접 상담

---

## 💡 직원이 학생한테 말할 멘트

> "Childcare Subsidy(CCS)는 영주권/시민권 자격이라 학생비자는 100% 본인부담입니다. Long Day Care(시드니/멜번) $500~$900/주 = 월 $2,000~$3,600 정도입니다. Family Day Care는 $400~$650/주로 저렴합니다. 도시는 Waiting List 6~12개월이라 즉시 신청 권장합니다. 4세는 NSW/VIC/QLD Pre-school 일부 무료(공립)이니 4세 시기에 활용하시고요. 와이프 아르바이트 수입 vs 어린이집 비용 비교 필요해서 윌슨 직접 상담 권장합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **CCS 학생비자 X**
   → Services Australia = 영주권/시민권만 / 학생비자 자녀 = 자격 X / 100% 본인부담.

2. **Pre-school 무료 학생비자 일부**
   → NSW Mobile Pre-school = 학생비자 자녀 OK / VIC Kinder = 영주권 우선 / 자치주 정책 다름.

3. **Waiting List 도시 길음**
   → 시드니/멜번 6~12개월 / 지방(Regional) 1~3개월 / 임신 시 등록 권장.

4. **어린이집 비용 와이프 알바 효율**
   → $25/시간 알바 × 주 24시간(학생비자 동반) = $600/주 / Long Day Care $500~$900/주 = 적자 가능 / Wilson 종합.

5. **한인 베이비시터 무허가**
   → 한인 커뮤니티 베이비시터 = 무허가 위험 / 사고 시 보험 X / NQF 인증 Family Day Care 권장.

6. **학교 부속 어린이집**
   → University of Sydney 어린이집 / UNSW 어린이집 / Monash 어린이집 / 학생/직원 우선 / 일반 LDC보다 약간 저렴 / Waiting List 짧음.

7. **Allergies / Special Needs**
   → 어린이집 등록 시 알레르기/특수 요구 명시 / EpiPen 등록 / 한국 의사 의견서 영문 번역.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. (
2. 1
3. )
4.  
5. 자
6. 녀
7.  
8. 나
9. 이
10. /
11. 특
12. 수
13.  
14. 요
15. 구
16. ?
17.  
18. (
19. 2
20. )
21.  
22. 와
23. 이
24. 프
25.  
26. 알
27. 바
28.  
29. 시
30. 간
31. /
32. 시
33. 급
34. ?
35.  
36. (
37. 3
38. )
39.  
40. W
41. a
42. i
43. t
44. i
45. n
46. g
47.  
48. L
49. i
50. s
51. t
52.  
53. 신
54. 청
55.  
56. 가
57. 능
58.  
59. 시
60. 기
61. ?
62.  
63. (
64. 4
65. )
66.  
67. 한
68. 인
69.  
70. 베
71. 이
72. 비
73. 시
74. 터
75.  
76. v
77. s
78.  
79. 어
80. 린
81. 이
82. 집
83.  
84. 비
85. 교
86. ?

---

## 🔍 직원이 직접 확인 가능한 사이트

- Services Australia(servicesaustralia.gov.au), Mychild(mychild.gov.au), ACECQA(acecqa.gov.au), NSW Pre-school(education.nsw.gov.au), VIC Kinder(vic.gov.au/kindergarten)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- CCS 학생비자 X / Long Day Care 비용 / Family Day Care / Pre-school 4세 무료 / Waiting List / 한인 베이비시터 X

**MARA / 변호사 영역**
- 동반 비자 거절 → 이민 변호사 / 어린이집 사고 → 변호사 / 한국 가족 영주권 → 이민 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] □
- [ ]  
- [ ] C
- [ ] C
- [ ] S
- [ ]  
- [ ] 학
- [ ] 생
- [ ] 비
- [ ] 자
- [ ]  
- [ ] X
- [ ]  
- [ ] 안
- [ ] 내
- [ ]  
- [ ] □
- [ ]  
- [ ] L
- [ ] D
- [ ] C
- [ ]  
- [ ] $
- [ ] 5
- [ ] 0
- [ ] 0
- [ ] ~
- [ ] $
- [ ] 9
- [ ] 0
- [ ] 0
- [ ] /
- [ ] 주
- [ ]  
- [ ] □
- [ ]  
- [ ] F
- [ ] D
- [ ] C
- [ ]  
- [ ] $
- [ ] 4
- [ ] 0
- [ ] 0
- [ ] ~
- [ ] $
- [ ] 6
- [ ] 5
- [ ] 0
- [ ] /
- [ ] 주
- [ ]  
- [ ] □
- [ ]  
- [ ] P
- [ ] r
- [ ] e
- [ ] -
- [ ] s
- [ ] c
- [ ] h
- [ ] o
- [ ] o
- [ ] l
- [ ]  
- [ ] 4
- [ ] 세
- [ ]  
- [ ] 무
- [ ] 료
- [ ]  
- [ ] 일
- [ ] 부
- [ ]  
- [ ] □
- [ ]  
- [ ] W
- [ ] a
- [ ] i
- [ ] t
- [ ] i
- [ ] n
- [ ] g
- [ ]  
- [ ] L
- [ ] i
- [ ] s
- [ ] t
- [ ]  
- [ ] 6
- [ ] ~
- [ ] 1
- [ ] 2
- [ ] 개
- [ ] 월
- [ ]  
- [ ] □
- [ ]  
- [ ] 한
- [ ] 인
- [ ]  
- [ ] 베
- [ ] 이
- [ ] 비
- [ ] 시
- [ ] 터
- [ ]  
- [ ] X
- [ ]  
- [ ] □
- [ ]  
- [ ] W
- [ ] i
- [ ] l
- [ ] s
- [ ] o
- [ ] n
- [ ]  
- [ ] 직
- [ ] 접
- [ ]  
- [ ] 상
- [ ] 담
