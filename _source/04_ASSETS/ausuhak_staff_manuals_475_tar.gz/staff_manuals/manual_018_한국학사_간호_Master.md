# 📚 직원 응대 매뉴얼 #018

**케이스: 28세 / 한국 4년제 (비간호 학사) / 호주 간호사 전환 / 1억 예산**

---

## 🎬 상황 시뮬레이션

> 한국에서 영문학 전공으로 학사 졸업했어요. 28세이고 호주에서 간호사 되고 영주권 받고 싶습니다. IELTS 7.0 가지고 있어요. 1년 1억 가능합니다.

**👉 정답**: **Master of Nursing (Pre-registration) 2년**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Master of Nursing Pre-registration = 학사 보유자용 간호사 전환

- 다른 분야 학사 보유자 대상
- 2년 학업 + 임상 실습 800~1,000시간
- 졸업 시 RN(Registered Nurse) 자격
- IELTS 7.0 (각 영역 7.0) 절대 조건

### 2️⃣ Master Pre-reg 운영 학교

| 학교 | 도시 | 학비 (연간) | 분류 |
|---|---|---|---|
| USyd Master Nursing | 시드니 | $54K~$57K | Non-regional |
| UTS Master Nursing | 시드니 | $42K~$46K | Non-regional |
| Monash Master Nursing | 멜번 | $48K~$52K | Non-regional |
| ACU Master Nursing | 시드니/멜번/브리즈번 | $34K | Non-regional or Regional |
| Federation Master Nursing | Ballarat | $30K | Regional (491+15) |
| USC Master Nursing | Sunshine Coast | $32K | Regional (491+15) |
| ECU Master | Perth | $36K | Regional (491+15) |
| UTAS Master | Hobart | $40K | Regional (491+15) |

### 3️⃣ 한국 학사 + 비간호 → Master Pre-reg 적합

- 한국 4년제 학사 (어떤 전공이든)
- IELTS 7.0
- GPA 일정 수준 (학교마다)
- 보통 면접 또는 학업 의지 에세이

### 4️⃣ 28세 + Master 2년 = 30세 졸업 = 485 가능

- 485 Post-Higher Education = 35세 미만
- Master 졸업 시 30세 → 485 2년 → 32세 시작
- PR 시도 가능

### 5️⃣ 1억 예산 = $70K = 시드니 어려움 / 다른 도시 가능

- USyd $54K-$57K = 1년 빠듯
- UTS $42K = 가능
- ACU $34K = 충분
- Federation $30K = 매우 여유 + 491 +15점 (Regional)

---

## 🎯 정답 경로 (3가지 비교)

### 옵션 A. UTS Master 2년 (시드니)

```
한국 학사 + IELTS 7.0
        ↓
UTS Master of Nursing 2년 ($84K~$92K)
        ↓
RN + 485 졸업비자 + 호주 병원 취업
        ↓
PR (Non-regional (491 비적용) + 직업 +60)
```

### 옵션 B. ACU Master 2년 (시드니/멜번/브리즈번/캔버라)

```
한국 학사 + IELTS 7.0
        ↓
ACU Master 2년 ($68K)
        ↓
ACU 캔버라 캠퍼스 = Regional (491 +15점)
ACU 브리즈번/시드니/멜번 캠퍼스 = Non-regional
        ↓
PR (Regional 캠퍼스 선택 시 491 적용 가능)
```

### 옵션 C. Federation Master 2년 (Regional, 491 +15점)

```
한국 학사 + IELTS 7.0
        ↓
Federation Master 2년 ($60K)
        ↓
Ballarat = Regional 491+15
        ↓
PR 가장 빠름
```

---

## 💡 직원이 학생한테 말할 멘트

> "한국 학사 + IELTS 7.0 = Master of Nursing Pre-registration 가능하시고, 가장 빠른 간호사 전환 경로입니다.
> 
> 시드니 외에도 옵션 多:
> 
> **시드니 - UTS** ($42K~$46K/년) = 1년 8천만 가능
> **시드니/멜번/브리즈번 - ACU** ($34K/년) = 비교적 학비 효율 (단, Non-regional 도시는 491 +15점 적용 X)
> **ACU 캔버라 캠퍼스** = Regional (491 +15점) 적용 가능
> **Federation Ballarat (Regional)** ($30K/년) = 491 +15점 + 485 Second PHEW Extension +2년
> 
> 28세시면 졸업 30세 → 485 2년 → 32세 PR 시도 가능합니다. **Regional 도시 검토**가 PR에 유리합니다.
> 
> 1억 예산이면 어느 학교든 가능하고, 시드니 외 도시 가시면 학비 + 생활비 + 여행까지 가능합니다.
> 
> 카톡으로 알려주세요:
> ① IELTS 정확한 점수 (각 영역 7.0?)  
> ② 도시 우선순위  
> ③ 졸업 후 한국 vs 호주 거주"

---

## ⚠️ 함정

1. **"한국 영문학 → 호주 간호 불가"** → ❌ 학사 있으면 어떤 전공이든 OK
2. **"Master Pre-reg = 1년"** → ❌ 2년 / 임상 실습 多
3. **"IELTS 6.5도 OK"** → ❌ 7.0 절대 / 각 영역 7.0
4. **"시드니가 취업 多"** → 사실이나 PR 가산점 0 / Regional 지역이 491 통한 PR 빠름
5. **"Master research 더 좋다"** → research는 485 3년이지만 임상 실습 X = RN 자격 X

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수 (각 영역)
2. 한국 학사 GPA
3. 도시 우선
4. 졸업 후 한국 vs 호주

---

## 🔍 직원 확인 사이트

- UTS Nursing: uts.edu.au/study/nursing
- ACU: acu.edu.au
- Federation: federation.edu.au
- ANMAC: anmac.org.au
