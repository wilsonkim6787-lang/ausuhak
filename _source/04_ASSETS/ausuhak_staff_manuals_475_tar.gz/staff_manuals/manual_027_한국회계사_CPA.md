# 📚 직원 응대 매뉴얼 #027

**케이스: 32세 / 한국 회계사 (KICPA) + 5년 경력 / 호주 회계사 / CPA Australia**

---

## 🎬 상황 시뮬레이션

> 한국 KICPA(공인회계사) 자격 + 5년 경력이에요. 호주 가서 회계사로 일하고 영주권 받고 싶어요. 32세이고 IELTS 7.0 있어요.

**👉 정답**: **CPA Australia 자격 전환 + Skills Assessment + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ KICPA → CPA Australia 자격 전환

- 한국 KICPA = 한국 공인회계사
- CPA Australia = 호주 공인회계사
- **Mutual Recognition Agreement (MRA)** 체결: 일부 면제 가능
- 한국 KICPA + CPA Australia 시험 일부 응시

### 2️⃣ CPA 자격 단계

```
1단계 Foundation (6과목) = Master Acc 졸업자 면제
2단계 Professional (6과목 + 1 elective) = KICPA 일부 면제 가능
3단계 Practical Experience (3년) = 한국 경력 인정 가능
```

### 3️⃣ KICPA 인정 받는 부분

- Foundation 6과목: KICPA + Master Accounting 면제
- Professional 일부 과목 면제
- Practical Experience 3년: 한국 경력 인정

**결과**: 한국 KICPA + 5년 경력자 = CPA 일부 시험만 응시하면 자격 가능

### 4️⃣ 호주 회계 직업 PR

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Accountant General | 221111 | MLTSSL |
| Management Accountant | 221112 | MLTSSL |
| Taxation Accountant | 221113 | MLTSSL |
| External Auditor | 221213 | MLTSSL |

### 5️⃣ 한국 KICPA 활용 호주 PR 경로

```
한국 KICPA + 5년 경력 + IELTS 7.0
        ↓
호주 입국 (학생비자 또는 워홀)
        ↓
CPA Australia 가입 + 시험 일부 응시 (1년)
        ↓
호주 회계 회사 취업 + Skills Assessment
        ↓
EOI + PR (189/190/491)
```

**총 2-3년 / 비용 약 $5K (CPA 시험) + 호주 체류**

---

## 🎯 정답 경로 (2가지 비교)

### 옵션 A. Direct PR (Master 없이)

```
한국 KICPA + 5년 경력 + IELTS 7.0
        ↓
호주 입국 (워홀 또는 단기 학생비자)
        ↓
CPA 시험 응시 + 회계 회사 취업
        ↓
Skills Assessment (CPA Australia)
        ↓
PR 직접 신청
```

**총 1.5-2년 / 비용 적음 / 빠름**

### 옵션 B. Master + CPA + PR (안전)

```
한국 KICPA + IELTS 7.0
        ↓
Master of Accounting 1년 (KICPA = 1년 단축)
        ↓
CPA 시험 + 485 + 호주 취업
        ↓
PR 신청
```

**총 2.5-3년 / 학비 $40K~$50K / 안정적**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 KICPA + 5년 경력 + IELTS 7.0 = 호주 회계사 전환 매우 빠른 경로 가능합니다.
> 
> 1. **CPA Australia 가입** = KICPA 자격 + Master Acc 일부 면제
> 2. **시험 일부만 응시** = Foundation 6과목 면제 + Professional 일부 면제
> 3. **Practical Experience 3년 = 한국 경력 인정**
> 4. **PR 직업**: Accountant 221111 (MLTSSL) 직업군
> 
> **옵션 A. Direct PR** = Master 없이 시험만 응시 (1.5-2년)
> **옵션 B. Master + CPA** = 안정적 + 호주 적응 (2.5-3년)
> 
> Big 4 (PwC, EY, Deloitte, KPMG) 한국 사무실 경력이면 호주 사무실 이직도 가능합니다.
> 
> 카톡으로 알려주세요:
> ① IELTS 정확한 점수  
> ② KICPA + 한국 경력 분야 (Big 4 / 일반 회사 / 회계법인)  
> ③ Master 추가 의향"

---

## ⚠️ 함정

1. **"KICPA = 호주 자동 회계사"** → CPA Australia 가입 + 시험 必
2. **"한국 경력 다 인정"** → Skills Assessment 평가 必
3. **"Master 必須"** → 한국 경력 + 학위 인정으로 Direct 가능
4. **"Big 4 = 자동 PR"** → 회사 + 직업 매칭 必

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수
2. KICPA + 경력 분야
3. Master 추가 의향
4. 도시 우선

---

## 🔍 직원 확인 사이트

- CPA Australia: cpaaustralia.com.au
- KICPA / CPA Australia MRA: cpaaustralia.com.au
- Skills Assessment: cpaaustralia.com.au
