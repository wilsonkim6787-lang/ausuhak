# #501 호주_셰어_동거인_폭력_위협_경찰_AVO_긴급_숙소_변경_Lease

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "셰어하우스 동거인이 술 마시고 폭력 휘두르고 욕설해요. 무서워서 잠을 못 자요. 경찰 부르면 어떻게 돼요? 어디 가야 해요?"

**직원 멘붕 포인트:**
- 동거인 폭력 = Domestic Violence (호주 정의 광범위)
- 긴급 시 000 즉시 → AVO (Apprehended Violence Order) 가능
- 셰어하우스라도 함께 거주 = Domestic Violence 적용
- 긴급 숙소: NSW Link2home 1800 152 152 (24시간 무료)
- Lease 계약 강제 종료 가능 (Domestic Violence 사유)

---

## ❌ 절대 하지 말아야 할 답

> "셰어메이트랑 다툼은 그냥 참거나 이사하세요"

→ ❌ 폭력은 즉시 안전 문제. 참기 X. 경찰 + AVO + 긴급 숙소 + 변호사

---

## ✅ 정답

동거인 폭력은 즉시 안전 확보가 우선이에요. 위협 느끼시면 즉시 000 부르시고, 안전한 곳으로 이동하세요. AVO(Apprehended Violence Order) 신청하면 가해자 접근 금지 명령 가능합니다. 긴급 숙소는 NSW Link2home 1800 152 152(24시간 무료)나 1800 RESPECT(1800 737 732, 한국어 통역 가능)에 연락하세요. 셰어 Lease는 Domestic Violence 사유로 강제 종료 가능해요(Bond 보호). 법률 자문은 LawAccess NSW 1300 888 529 무료입니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Domestic Violence 정의 (호주)**
Crimes (Domestic and Personal Violence) Act 2007 NSW:
관계 (모든 거주자 포함):
- 배우자/파트너
- 가족 구성원
- 함께 거주하는 자 (셰어메이트)
- 데이트 관계

행위:
- 신체 폭력
- 위협 (말/행동)
- 스토킹
- 정신적 학대
- 재정 통제
→ 셰어메이트 폭력 적용

**2. AVO (Apprehended Violence Order)**
AVO 종류:
- ADVO (Apprehended Domestic Violence Order)
- APVO (Apprehended Personal Violence Order)
셰어메이트 → ADVO
법원 명령:
- 가해자 접근 금지
- 거주지/직장 출입 금지
- 연락 금지
- 위반 시 즉시 체포 + 형사 처벌
신청: 경찰 통해 또는 본인 직접 (Local Court)

**3. 긴급 숙소 (Emergency Accommodation)**
NSW Link2home: 1800 152 152 (24시간 무료)
1800 RESPECT: 1800 737 732 (24시간 한국어 통역)
VIC Safe Steps: 1800 015 188
QLD DV Connect: 1800 811 811
WA Crisis Care: 1800 199 008
긴급 숙소: 호스텔/Refuge 무료 1~6주
이후 임대 지원 + Centrelink 일부 (PR 한정)

**4. Lease 강제 종료 (Domestic Violence)**
Residential Tenancies Act 2010 NSW:
Section 105B: Domestic Violence 임차인 권리
강제 종료 사유:
1. AVO 발급
2. Provisional AVO
3. Police DV 보고서
4. Medical Report
절차:
- 집주인에게 서면 통보 + 증빙
- 즉시 종료 (28일 무관)
- Bond 100% 환급
- 가해자만 책임 (피해자 X)

**5. 법률 + 심리 자원 (호주 무료)**
법률:
- LawAccess NSW: 1300 888 529 (무료 자문)
- Women's Legal Service NSW: 1800 801 501
- Legal Aid 각 주

심리:
- 1800 RESPECT: 1800 737 732 (한국어 통역)
- Beyond Blue: 1300 22 4636
- Lifeline: 13 11 14
TIS National Korean: 13 14 50
외국인 학생도 모두 무료

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 위협 시 즉시 000 + 안전한 곳 이동
**2단계**: 1800 RESPECT 1800 737 732 (한국어 통역) 상담
**3단계**: AVO 신청 (경찰 통해 또는 Local Court)
**4단계**: Lease 종료 + Bond 환급 (집주인 통보 + 증빙)
**5단계**: 긴급 숙소 + 새 거주지 + 법률/심리 자문

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 동거인 폭력은 즉시 안전이 우선이에요. 위협 느끼면 즉시 000 부르시고 안전한 곳으로 이동하세요. AVO 신청하면 가해자 접근 금지 명령 가능합니다. 긴급 숙소는 1800 RESPECT 1800 737 732 (한국어 통역) 또는 NSW Link2home 1800 152 152에 연락하세요. Lease는 Domestic Violence 사유로 강제 종료 가능 + Bond 100% 환급됩니다. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'다툼' 가벼움 X**
   → 신체 위협은 즉시 폭력 사건

2. **셰어메이트 Domestic Violence X**
   → 함께 거주 = DV 적용

3. **AVO 자동 X**
   → 신청 + 법원 결정

4. **Lease 28일 통보 의무 X**
   → DV 사유 즉시 종료

5. **Bond 일부 환급 X**
   → DV 피해자 100% 환급

6. **외국인 자원 못 받음 X**
   → 전부 외국인 학생도 무료

7. **증빙 없음 X**
   → Police 보고서 + Medical 1개라도 충분

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 위협 정도? (말 위협/신체 폭력/위협 진행 중)
2. 현재 안전해요? (안전/안전 X)
3. 경찰 신고했어요? (했다/안 했다)
4. AVO 신청 의향? (있다/없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- 1800 RESPECT: 1800 737 732 / 1800respect.org.au
- NSW Link2home: 1800 152 152
- LawAccess NSW: 1300 888 529
- AVO 정보: lawaccess.nsw.gov.au
- TIS Korean: 13 14 50

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 긴급 안전 우선 안내
- 1800 RESPECT/Link2home 연결
- AVO 절차 1차 안내
- Lease 종료 1차 안내

**MARA / 변호사 영역**
- AVO 신청 (Lawyer)
- Lease 종료 분쟁 (NCAT)
- Civil Lawsuit 손해배상 (Civil Lawyer)
- 비자 영향 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 즉시 안전 확보 + 000
- [ ] 1800 RESPECT/Link2home 연락
- [ ] AVO 신청
- [ ] Lease 종료 + Bond 환급
- [ ] 법률 + 심리 자원 활용
