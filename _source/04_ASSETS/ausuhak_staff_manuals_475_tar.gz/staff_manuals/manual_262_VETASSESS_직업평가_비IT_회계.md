# #262 VETASSESS 직업평가 비IT/회계

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 마케팅 전공인데 PR 직업평가 어디서 받나요?"

**직원 멘붕 포인트:**
- VETASSESS = Vocational Education and Training Assessment Services
- IT/회계/엔지니어/간호 외 직업 평가
- 마케팅 / HR / Trades / 매니저 평가
- Track A / B / C / D 종류

---

## ❌ 절대 하지 말아야 할 답

> "마케팅 전공이면 PR 직업이 없습니다."

→ ❌ **VETASSESS Marketing Specialist 225113 PR 가능**.

---

## ✅ 정답

VETASSESS 평가: ① **Vocational Education and Training Assessment Services** = IT/회계/EA/ANMAC 외 직업 평가 ② **Track A** = 학력 + 경력 정확 일치 ③ **Track B/C/D** = 부분 일치 + 추가 경력 ④ **수수료 약 $1,055** (Stage 1 + 2) ⑤ **심사 12~16주** ⑥ **유효 3년**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. VETASSESS 평가 직업**
Marketing Specialist (225113) / HR Adviser (223111) / 매니저 / Trades (Cook, Hairdresser) / 기타 240+ 직업

**2. Track 종류**
A = 학력 + 경력 + 직업 100% 일치 / B = 학력 일치 + 경력 1년 / C = 학력 부분 + 경력 3년 / D = 학력 부족 + 경력 5년

**3. Trades 평가**
Cook (Chef) / Hairdresser / Mechanic 등 Trades 별도 양식 / TRA (Trades Recognition Service) 호주 시험 (PSA) 의무

**4. Stage 1 + 2**
Stage 1 = 학력 평가 ($725) / Stage 2 = 경력 평가 ($330) / 합 $1,055 / 동시 신청 가능

**5. Job Ready Program (Trades)**
Trades 직업 = JRP 4단계 (TRA + 호주 경력 1900시간 + 직장 평가 + 최종) / 1년 정도

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 직업 코드 확인 (ANZSCO 4자리)
**2단계**: VETASSESS 사이트 등록 (vetassess.com.au)
**3단계**: Track A/B/C/D 자가 진단
**4단계**: Stage 1 + 2 신청 + 수수료 ($1,055)
**5단계**: 심사 12~16주 → 결과 → EOI 입력

---

## 💡 직원이 학생한테 말할 멘트

> "VETASSESS는 IT/회계/엔지니어/간호 외 직업 평가 기관이에요. 마케팅, HR, 매니저, Trades 등 240+ 직업을 평가합니다. Track A (100% 일치) ~ Track D (5년 경력 보완)까지 4단계로 나뉘고, 학력 + 경력 일치도 따라 결정돼요. 수수료 $1,055이고 심사 12~16주 걸립니다. Trades (Cook, 미용 등)는 추가로 Job Ready Program 1년 거쳐야 해요. 윌슨님이 1:1로 직업 코드 + Track 매칭 + Stage 시점 가이드 드려요. 카카오 (studywilson)으로 직업 + 학력 + 경력 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **VETASSESS = IT 평가 ❌**
   → IT = ACS / VETASSESS = 그 외

2. **Track A = 자동 ❌**
   → 신청 + 서류 + 심사

3. **Trades = VETASSESS 1번 ❌**
   → VETASSESS + TRA + JRP = 1년 이상

4. **학력 부족 = 평가 불가 ❌**
   → Track D 가능 (5년 경력 보완)

5. **Stage 1만 = PR 신청 ❌**
   → Stage 1 + 2 모두 통과 필수

6. **VETASSESS = 영구 ❌**
   → 유효 3년 / 만료 재신청

7. **VETASSESS = IELTS 무관 ❌**
   → PR EOI = IELTS 6+ 별도

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 직업 + ANZSCO 4자리 코드
2. 한국 학력 + 경력 정확
3. Trades 여부 (JRP 적용)
4. Track A/B/C/D 자가 진단

---

## 🔍 직원이 직접 확인 가능한 사이트

- VETASSESS: https://www.vetassess.com.au
- ANZSCO: https://www.abs.gov.au/anzsco
- TRA (Trades): https://www.tradesrecognitionaustralia.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 직업 코드 + Track 매칭 1:1
- Stage 1 + 2 시점 전략
- Trades + JRP 가이드

**MARA / 변호사 영역**
- VETASSESS 거절 + Review
- Trades JRP 분쟁

---

## ✅ 완벽 응대 체크리스트

- [ ] VETASSESS = 비IT/회계 직업 평가
- [ ] Track A/B/C/D 명확
- [ ] Stage 1 + 2 동시 신청
- [ ] Trades = JRP 추가
- [ ] 240+ 직업 평가
- [ ] 수수료 $1,055 + 심사 12~16주
- [ ] 윌슨 1:1 = Track + 직업 코드
- [ ] 윌슨 카카오 자연 유도
