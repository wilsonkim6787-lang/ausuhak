# #164 호주 도서관 / 온라인 학습

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 도서관 무료로 쓸 수 있나요? 어떤 도서관이 좋아요? 학생 카드 만들어야 해요? 한국 책도 있어요?"

**직원 멘붕 포인트:**
- 호주 도서관 시스템 모름 (학교 도서관 vs 공공 도서관)
- 도서관 카드 발급 절차 모름
- 한국 도서/온라인 자료 모름

---

## ❌ 절대 하지 말아야 할 답

> "그냥 가서 책 빌리시면 돼요!"

→ 도서관 카드 필요. 학교/공공 도서관 차이 모르면 학생 헛걸음.

---

## ✅ 정답

호주 도서관은 매우 잘 갖춰져 있어요. 학교 도서관 (학생 무료) + 공공 도서관 (지역 거주민 무료) 둘 다 활용 가능. 한국 책도 일부 도서관에 있고, 온라인으로 한국 e-Book도 무료 대여 가능합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 도서관 종류
**A. 학교 도서관 (University/TAFE/School Library):**
- 학생 자동 가입 (학생증 = 도서관 카드)
- 24시간 개방 (시험기간)
- 전공서적, 학술 데이터베이스
- 그룹 스터디룸 무료 예약
- 노트북/태블릿 대여

**B. 공공 도서관 (Public Library):**
- 거주민 무료 가입 (주소 증명 필요)
- 일반 도서, 영화, 음악 대여
- 무료 와이파이, 컴퓨터 사용
- 무료 강좌 (요리, 컴퓨터, 영어)
- 어린이/노인 프로그램

**C. 주립 도서관 (State Library):**
- NSW: State Library of NSW (Sydney)
- VIC: State Library Victoria (Melbourne)
- QLD: State Library of Queensland (Brisbane)
- 무료 입장, 희귀 자료, 호주 역사 자료

**D. 국립 도서관 (National Library of Australia):**
- 캔버라 위치
- Trove 온라인 (수백만 디지털 자료)

### 2. 도서관 카드 발급
**학교 도서관:**
- 학생증 = 자동 카드
- 별도 절차 X

**공공 도서관:**
- 거주지 주소 증명 (Lease, Bill 등)
- 신분증 (여권 + 학생증)
- 무료 발급 (즉시)
- 도시별 시스템 (예: City of Sydney Library, Yarra Libraries)

### 3. 무료 서비스
- **도서 대여:** 보통 4주, 연장 가능
- **온라인 e-Book:** OverDrive, Libby App
- **온라인 잡지:** PressReader (수천 잡지 무료)
- **학술 데이터베이스:** JSTOR, ProQuest (학교 도서관)
- **무료 영화:** Beamafilm, Kanopy (공공 도서관)
- **무료 음악:** Freegal Music
- **언어 학습:** Mango Languages (한국어/영어 등)
- **이력서 도움:** 도서관 직원 무료 상담
- **세금 신고 도움:** 7월 무료 세무 도우미

### 4. 한국 자료
**한국 도서:**
- 시드니 Strathfield Library: 한국 책 별도 섹션
- 멜번 Box Hill Library: 한국 책 多
- 브리즈번 Sunnybank Library: 한국 책 일부
- City Library (Sydney/Melbourne): 한국 책 소량

**한국 온라인:**
- **OverDrive / Libby:** 한국 e-Book 일부
- **교보문고 e-Book:** 호주에서 구매 가능 (한국 신용카드)
- **Yes24, 알라딘** 한국 e-Book
- **밀리의 서재**: 한국 구독제 (월정액)

### 5. 온라인 학습 플랫폼 (도서관 무료 제공)
- **LinkedIn Learning** (Lynda): 호주 공공 도서관 카드로 무료
- **Coursera / edX** (학교 도서관 일부)
- **Mango Languages**: 70+개 언어 (한국어 포함)
- **Universal Class**: 500+ 무료 강좌
- **Niche Academy**: 컴퓨터, 비즈니스 강좌

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. 학교 도서관 즉시 활용
- 학생증 = 도서관 카드 자동
- 24시간 개방 (시험기간)
- 학술 자료 무료

### Step 2. 거주지 공공 도서관 가입
- 주소 증명 + 신분증
- 즉시 무료 발급
- 도시별 시스템 다름

### Step 3. 한국 자료 활용
- 한인 밀집지역 도서관 (Strathfield, Box Hill)
- OverDrive/Libby App 한국 e-Book
- 한국 e-Book 사이트 직접 구매 (교보문고 등)

### Step 4. 무료 온라인 학습
- LinkedIn Learning (도서관 카드로 무료)
- Mango Languages (영어 학습)

### Step 5. 무료 강좌 참여
- 이력서 워크샵
- 영어 회화 강좌 (도서관별)
- 시민권 시험 준비

---

## 💡 직원이 학생한테 말할 멘트

> "호주 도서관은 정말 잘 갖춰져 있어요. 무료로 활용하세요!
>
> **학교 도서관:** 학생증 = 자동 카드. 24시간 개방 (시험기간), 전공서적, 그룹 스터디룸 무료.
>
> **공공 도서관:** 거주지 주소 증명 + 신분증으로 무료 가입.
> - 도서, 영화, 음악 무료 대여
> - 무료 와이파이/컴퓨터
> - 무료 강좌 (이력서, 영어, 시민권 시험)
>
> **한국 책:**
> - 시드니 Strathfield Library / 멜번 Box Hill Library / 브리즈번 Sunnybank Library
> - 한국 e-Book: OverDrive/Libby App, 교보문고
>
> **온라인 학습 무료 (도서관 카드로):**
> - LinkedIn Learning (수천 강좌)
> - Mango Languages (영어 학습)
> - PressReader (잡지)
> - Kanopy/Beamafilm (영화)
>
> 어느 도시로 가시나요? 그 지역 공공 도서관 알려드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. 학교 도서관 vs 공공 도서관 혼동
- 둘 다 무료지만 시스템 다름
- 둘 다 가입 가능 (둘 다 활용)

### 함정 2. 도서관 카드 = 거주지 도서관만
- 한 도시 안에서는 다른 지역 도서관 가입 OK
- 시드니 학생도 City of Sydney Library + Inner West Library + Canada Bay Library 등 동시 가입 가능

### 함정 3. e-Book 앱 모름
- OverDrive (구버전) → Libby (신버전, 더 편리)
- 도서관 카드 번호 입력하면 무료 사용

### 함정 4. 연체료
- 호주 공공 도서관 대부분 연체료 X (2020년대 폐지 추세)
- 단, 분실/파손은 변상 ($30~$100)

### 함정 5. 24시간 개방
- 학교 도서관 = 시험기간 24시간
- 평소 = 8am~10pm 정도
- 공공 도서관 = 9am~5pm (주말 단축)

### 함정 6. 한국 책 양
- Strathfield/Box Hill 외에는 한국 책 적음
- 온라인 e-Book이 더 다양

### 함정 7. 학교 도서관 외부인 사용
- University 도서관은 학생만
- 공공 도서관은 누구나
- 학생/직원/방문객 차이 있음

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **어느 도시로 가시나요?** → 공공 도서관 시스템
2. **학교 정해졌나요?** → 학교 도서관 자동 가입
3. **한국 책 자주 읽으시나요?** → 한국 e-Book 우선 안내
4. **온라인 학습 관심?** → LinkedIn Learning 등 추천

---

## 🔍 직원이 직접 확인 가능한 사이트

- **NSW 도서관:** library.nsw.gov.au
- **City of Sydney Library:** library.cityofsydney.nsw.gov.au
- **Yarra Libraries (멜번):** yarralibraries.vic.gov.au
- **Brisbane City Council Library:** brisbane.qld.gov.au/library
- **Trove (국립 디지털):** trove.nla.gov.au
- **Libby App:** libbyapp.com

---

## 🚨 직원 영역 vs 윌슨 영역

| 직원 가능 | 윌슨 영역 |
|-----------|-----------|
| 호주 도서관 시스템 안내 | 학생 1:1 학습 코칭 |
| 카드 발급 절차 | - |
| 무료 서비스 안내 | - |
| 한국 자료 위치 | - |

---

## ✅ 완벽 응대 체크리스트

- [ ] 학교 도서관 자동 가입 안내
- [ ] 공공 도서관 가입 절차
- [ ] 무료 서비스 (e-Book, 영화, 음악)
- [ ] 한국 책 위치 (Strathfield, Box Hill 등)
- [ ] Libby App 한국 e-Book
- [ ] LinkedIn Learning 무료
- [ ] Mango Languages 등 학습
- [ ] 무료 강좌 (이력서, 영어)
- [ ] 도시별 도서관 시스템
- [ ] 학생 도시 확인

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 학습/생활
