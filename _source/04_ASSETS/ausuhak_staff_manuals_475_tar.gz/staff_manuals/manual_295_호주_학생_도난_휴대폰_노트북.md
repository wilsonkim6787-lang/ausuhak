# #295 호주_학생_도난_휴대폰_노트북

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 카페에서 노트북이랑 아이폰 도난당했어요. 학교 과제 다 들어있고요. 어떡하죠?"

**직원 멘붕 포인트:**
- Find My iPhone/Find My Mac 즉시 활성화
- Police Report 발급 (보험 청구 필수)
- OSHC/유학생 보험 도난 보상 여부
- 비자/거주 증명 노트북에 있을 시 위험
- 데이터 백업 (iCloud/Google Drive) 복구

---

## ❌ 절대 하지 말아야 할 답

> ""호주 도난 = 거의 못 찾음""

→ ❌ Find My Phone + Police Report로 일부 회수. Travel Insurance 보상.

---

## ✅ 정답

"도난 즉시 1단계 Find My iPhone 활성화 + 잠금. 2단계 경찰 Police Report 발급. 3단계 Travel Insurance 또는 학생 가전 보험 청구. 데이터는 iCloud/Google Drive 백업으로 복구 가능합니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Find My iPhone/Mac 즉시**
iCloud.com/find 또는 다른 기기에서 즉시 잠금 + 위치 추적. 분실 모드 (Lost Mode) 활성화 → 발견 시 비번 요구. 데이터 원격 삭제 (Erase) 가능 (마지막 수단). 안드로이드 = Google Find My Device (android.com/find).

**2. 경찰 Police Report**
NSW Police Online Report (https://www.police.nsw.gov.au) 또는 131 444. Police Event Number 발급 (보험 청구 필수). 호주 경찰 = 도난 신고 받지만 회수율 낮음 (15%). CCTV 위치 알려주면 도움.

**3. 보험 청구**
OSHC = 도난 보상 X (의료만). 별도 가입 = Travel Insurance ($150~$300/년 학생 패키지). 호주 가전 보험 = 한국 학생 거의 미가입. 신용카드 자동 보험 (Visa Platinum 등) = 일부 보상. 청구 = Police Report + 영수증 필수.

**4. 데이터 복구**
iCloud 백업 = 마지막 24시간 자동. Google Drive/Dropbox = 자동 동기화. 학교 과제 = OneDrive/Google Drive 복구. 비밀번호 모든 계정 변경 (이메일/은행/SNS). 2단계 인증 활성화.

**5. 개인정보 위험**
노트북 비번 X = 데이터 탈취 위험. 즉시 변경 = 이메일/카톡/은행/Apple ID/Google. 비자 사본/여권 사본 = 영사관 통보 (재발급 신청 필요 시). 한국 영사관 시드니 02-9210-0200.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Find My iPhone/Mac 즉시 잠금 + 위치 추적
**2단계**: 경찰 Police Report 신고 (Online 또는 131 444)
**3단계**: Travel Insurance/신용카드 보험 청구 (영수증 + Police Report)
**4단계**: iCloud/Google Drive 데이터 복구 + 비번 변경
**5단계**: 비자 사본/여권 사본 도난 시 영사관 통보

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 너무 속상하시겠어요. 일단 즉시 Find My iPhone (icloud.com/find) 들어가서 분실 모드 활성화 + 잠금하세요! 다른 친구 폰으로도 가능해요. 그 다음 경찰 Police Report 신고하시고요 (NSW 131 444). 데이터는 iCloud/Google Drive 백업으로 복구 가능해요. 모든 계정 비번 즉시 변경하시고 (이메일/은행/카톡 등). Travel Insurance 가입했으면 영수증 + Police Report로 보상 청구하세요. OSHC는 도난 보상 안 되고요. 비자/여권 사본 들어있었으면 한국 영사관 02-9210-0200 통보하세요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"호주 도난 못 찾음"**
   → Find My + CCTV로 일부 회수.

2. **"OSHC 보상"**
   → OSHC = 의료만. 도난 X.

3. **"비번 안 변경해도 됨"**
   → 이메일/은행/카톡 즉시 변경.

4. **"Police Report 시간 낭비"**
   → 보험 청구 필수.

5. **"신용카드 보험 X"**
   → Visa Platinum 일부 보상.

6. **"학교 과제 영구 손실"**
   → OneDrive/Google Drive 복구.

7. **"여권 사본 = 안전"**
   → 여권 사본 도난 = 신원도용 위험. 영사관 통보.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 도난 일시 + 장소 (CCTV 가능 여부)
2. Find My 활성화 여부
3. Travel Insurance 가입 여부
4. 노트북에 비자/여권 사본 있었는지

---

## 🔍 직원이 직접 확인 가능한 사이트

- iCloud Find My: https://icloud.com/find
- Google Find My: https://android.com/find
- NSW Police Online: https://www.police.nsw.gov.au
- 한국 영사관 시드니: 02-9210-0200

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 절차 안내
- Find My/Police Report 가이드
- 보험 청구 가이드
- 한국 영사관 안내
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- 경찰 = Police Report
- 보험사 = 청구 처리
- 한국 영사관 = 여권 재발급
- Apple/Google = Find My 지원
- 은행 = 신용카드 정지/재발급

---

## ✅ 완벽 응대 체크리스트

- [ ] 도난 정보 청취했다
- [ ] Find My 즉시 활성화 안내했다
- [ ] Police Report 신고 안내했다
- [ ] 데이터 복구 안내했다
- [ ] 비번 변경 안내했다
- [ ] 보험 청구 가능 여부 안내했다
- [ ] 여권/비자 사본 도난 시 영사관 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
