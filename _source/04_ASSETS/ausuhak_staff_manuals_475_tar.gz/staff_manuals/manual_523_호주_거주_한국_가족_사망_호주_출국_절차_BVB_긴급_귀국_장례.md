# #523 호주_거주_한국_가족_사망_호주_출국_절차_BVB_긴급_귀국_장례

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국 어머니 갑자기 돌아가셨어요. 시드니에서 학교 다니는데 한국 장례 가야 해요. BVB 받아야 해요?"

**직원 멘붕 포인트:**
- 긴급 가족 사망 = 학생비자 BVB(Bridging Visa B) 가능
- 호주 출국 + 재입국 비자 보호 (BVB 의무)
- BVB 없이 출국 = 학생비자 자동 종료
- 한국 영사관 24시간 +82-2-3210-0404 + 항공권 긴급
- 직원이 'BVB 안 받아도 됨' 잘못 안내 시 학생 비자 종료

---

## ❌ 절대 하지 말아야 할 답

> "학생비자면 그냥 출국하셔도 돼요"

→ ❌ BVB 없이 출국 시 학생비자 자동 종료. 재입국 거부

---

## ✅ 정답

가족 사망 위로 드립니다. 학생비자(500)는 Multi Entry라서 단기 출국은 가능하지만, 안전을 위해 BVB(Bridging Visa B)를 미리 신청하시는 게 좋아요. BVB는 출국 + 재입국 비자 보호 + 비자 처리 중에도 출국 가능해요. 신청료 $200, 처리 5~10일이지만 긴급(Compassionate)은 24~48시간 처리 가능합니다. 한국 영사관 +82-2-3210-0404 24시간 핫라인으로 한국 도착 후 도움받으세요. 학교에는 Special Consideration(Compassionate Grounds) 신청해서 학업 보호받으시고요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 학생비자 (500) Multi Entry**
Subclass 500 자동 Multi Entry:
- 호주 출국 + 재입국 자유
- 비자 유효 기간 안
- 출입국 시 비자 카드 + 학생증

단, 비자 처리 중 (Renewal/Change) 출국:
- 학생비자 자동 종료
- 재입국 거부
- 새 비자 필요
→ BVB 필수

**2. BVB (Bridging Visa B) - 출국 + 재입국 보호**
Subclass 020 BVB:
- 비자 처리 중 출국 보호
- 신청료 $200
- 처리 5~10일 (Standard)
- 긴급 (Compassionate) 24~48시간
- 유효 3~6개월

필요 사례:
- 학생비자 신청 중
- 학생비자 변경 중 (예: PR 신청 중)
- 학교 변경 중

기존 학생비자 유효 시 BVB 불필요 (Multi Entry)
→ 본인 비자 상태 먼저 확인

**3. 긴급 (Compassionate) BVB**
Compassionate Grounds:
- 가족 사망 (직계)
- 가족 중병 (Critical Illness)
- 결혼식 (직계)
- 기타 인도적 사유

절차:
1. ImmiAccount 신청
2. Death Certificate 또는 의사 진단서 첨부
3. 가족관계증명서 + Apostille
4. 항공권 예약
5. 학교 통보

처리 24~48시간 (Compassionate)

**4. 학교 Special Consideration (학업)**
Compassionate Grounds 인정:
- 가족 사망 (직계)
- Death Certificate 또는 가족관계증명서 첨부

옵션:
1. Defer Exam (시험 연기)
2. Withdraw Without Penalty
3. Course Defer 1학기
4. Assignment Extension

Census Date 이후도 가능 (Compassionate)
출석률 80% 보호
비자 영향 X (학교 절차)

**5. 한국 도착 후**
한국 영사관 24시간 +82-2-3210-0404
한국 가족관계 등록 (사망 신고):
- 사망 후 1개월 안 의무
- 사망진단서 + 가족관계증명서

장례 + 상속:
- 한국 장례식장 (3일)
- 상속세 신고 6개월 / 납부 9개월

호주 복귀:
- 비자 카드 + 학생증
- 학교 등록 유지
- 출석률 회복

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 현재 비자 상태 확인 (유효 + Multi Entry)
**2단계**: 필요 시 BVB Compassionate 신청 (24~48시간)
**3단계**: 한국 영사관 사망 신고 사전 준비
**4단계**: 항공권 긴급 예약 + 학교 Special Consideration
**5단계**: 한국 도착 후 영사관 + 장례 + 호주 복귀

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 가족 사망 위로 드립니다. 학생비자(500)는 Multi Entry라 단기 출국 가능하지만, 안전 위해 BVB Compassionate 24~48시간 처리 권장해요(긴급 사유 인정). 학교 Special Consideration도 신청하시면 시험 연기 가능합니다. 한국 영사관 24시간 +82-2-3210-0404 활용하시고, Death Certificate + 가족관계 + Apostille 챙겨가세요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **BVB 무관 X**
   → 비자 상태별 다름

2. **학생비자 Multi Entry 자동 X**
   → 비자 처리 중은 BVB 필수

3. **Compassionate 무관 X**
   → 24~48시간 처리

4. **학교 Special Consideration X**
   → 출석률 + 학업 보호

5. **Death Certificate Apostille X**
   → 한국 신고 필수

6. **한국 영사관 무관 X**
   → 24시간 핫라인

7. **출석률 자동 X**
   → Special Consideration 신청

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 비자 상태? (유효 + 처리 중 X/처리 중)
2. 사망 며칠 전? (당일/1~3일/3일+)
3. 항공권 예약했어요? (했다/안 했다)
4. 학교 Special Consideration 알려요? (알다/모름)

---

## 🔍 직원이 직접 확인 가능한 사이트

- BVB 020: immi.homeaffairs.gov.au
- 한국 영사관 24시간: +82-2-3210-0404
- VEVO: immi.homeaffairs.gov.au
- Compassionate Grounds: immi.homeaffairs.gov.au
- Apostille: dfat.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- BVB Compassionate 1차 안내
- 한국 영사관 연결
- Special Consideration 안내
- 한국 도착 후 절차

**MARA / 변호사 영역**
- BVB 신청 (MARA - 긴급 시)
- 한국 사망 신고 (영사관)
- Special Consideration (학교)
- 한국 상속 (한국 법무사)

---

## ✅ 완벽 응대 체크리스트

- [ ] 비자 상태 확인
- [ ] BVB Compassionate 신청 (필요 시)
- [ ] Death Certificate + Apostille
- [ ] 학교 Special Consideration
- [ ] 한국 영사관 + 장례 + 호주 복귀
