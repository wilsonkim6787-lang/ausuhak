# #396 호주_학생_동반_자녀_학교_본인_석사_초중고_등록_비용

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 석사 가는데 7살 아이 데려가요. 아이 학교 비용 얼마예요? Public 학교 보내도 OSHC로 커버돼요? 제가 수업 듣는 동안 아이 어떻게 해요? 방과후 학원 비용은요?"

**직원 멘붕 포인트:**
- 주별 동반자녀 학비 차이 모름
- Public vs Private 학비 차이 모름
- OSHC vs OSC 차이 모름 (자녀)
- After School Care 비용 모름
- 비자 학비 면제 주 모름 (ACT)

---

## ❌ 절대 하지 말아야 할 답

> "호주 Public 학교는 무료니까 학비 걱정 안 하셔도 돼요!"

→ ❌ 학생비자 동반자녀 = Public 학교도 학비 부과. 주별로 다름. 시드니/멜번 = $14,000~$20,000/년. ACT만 일부 면제.

---

## ✅ 정답

**동반자녀 학교 비용 (2026.05 기준)**:

1. **Public 학교 학비 (학생비자 동반자녀)**:
   - **NSW**: $6,200~$13,500/년 (학년별 차등)
   - **VIC**: $11,000~$18,650/년
   - **QLD**: $12,070~$15,420/년
   - **SA**: $7,000~$13,500/년
   - **WA**: $4,000~$15,000/년
   - **ACT**: $13,200/년 (단, PhD 부모는 면제)
   - **TAS**: $10,000~$13,000/년
2. **Private 학교 학비**:
   - $20,000~$45,000/년 (시드니/멜번 상위 사립 = $40,000+)
3. **OSC (Overseas Student Health Cover for children)**:
   - 자녀용 별도 가입 ($600~$1,200/년)
4. **방과후 보육 (After School Care)**:
   - $25~$45/일, 월 $400~$700
5. **부모 대학 수업 중 자녀 관리**:
   - 7세 = Year 2 (Primary School)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 주별 동반자녀 학비 시스템**
호주 8개 주/준주 = 학비 정책 다름. 학생비자 동반자녀 = Public 학교 학비 부과 (ACT PhD 부모 일부 면제). VIC/NSW = 가장 비쌈. WA/SA = 중간. 학년별 차등 (Primary < Secondary).

**2. Public vs Private 학교 차이**
Public = 정부 운영, 동반자녀 학비 부과. Private = 사립, $20K~$45K/년. Catholic = 중간 ($8K~$15K). 시드니 상위 사립 (Sydney Grammar, Knox) = $40,000+/년.

**3. OSC 자녀 건강보험**
OSHC = 본인. OSC = 자녀 (12세 미만). Bupa OSC = $600~$1,200/년. 출국 전 가입. 학교 등록 시 OSC 증명서 제출.

**4. 학교 등록 절차**
주별 신청 사이트: NSW Department of Education, VIC Department of Education and Training. CRICOS Registered. Confirmation of Enrolment (CoE) 필요. 비자 신청 시 자녀 CoE 동봉.

**5. After School Care + 방과후**
OSHC (Outside School Hours Care) ≠ OSHC (건강보험). 학교 부속 또는 사설. $25~$45/일. CCS (Child Care Subsidy) = 시민/PR만. 학생비자 동반 = 본인 부담 100%.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 부모 학교 합격 후 = 자녀 학교 검색 (거주지 인근 Public).
**2단계**: 2단계: 자녀 CoE 신청 (NSW Dept of Education 또는 주별).
**3단계**: 3단계: 자녀 OSC 가입 (출국 전).
**4단계**: 4단계: 비자 신청 시 = 부모 + 자녀 모두 포함 (Subclass 500 종속자).
**5단계**: 5단계: 도착 후 = 학교 등록 + After School Care 가입.

---

## 💡 직원이 학생한테 말할 멘트

> "7세면 Year 2(초등 2학년)이에요. Public 학교 학비가 NSW $6,200~$13,500/년, VIC $11,000~$18,650/년이에요. ACT만 PhD 부모면 일부 면제고 다른 주는 다 부과돼요. OSC(자녀 건강보험)도 별도 가입이세요. After School Care는 월 $400~$700이고요. 도시·학교 선택 자세한 건 윌슨님 카톡 상담주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Public 학교 = 무료라고 단정**
   → 호주 시민/PR 자녀만 무료. 학생비자 동반 = 학비 부과. 주별 다름.

2. **Catholic 학교 = Private라고 묶기**
   → Catholic = Public(정부 보조) vs Private 중간. 학비 $8K~$15K. Private보다 저렴.

3. **ACT 학비 면제 = 모든 학생비자라고 단정**
   → ACT 면제 = PhD 부모 자녀만. Master/학부 부모 = 학비 $13,200.

4. **OSHC = 자녀도 커버라고 안내**
   → OSHC = 본인. 자녀 = OSC 별도. 미가입 시 비자 거절.

5. **After School Care = 정부 보조라고 안내**
   → CCS(Child Care Subsidy) = 시민/PR만. 학생비자 = 본인 부담 100%.

6. **부모 PhD = 자녀 무료라고 단정**
   → ACT/SA 일부 + 면제 신청 케이스. NSW/VIC = PhD도 부과.

7. **자녀 CoE 없이 동반비자 신청 가능이라고 오해**
   → 취학 연령 자녀 = CoE 동봉 의무. 미동봉 시 동반비자 거절.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 자녀 나이 + 학년 (Primary/Secondary)
2. 거주 도시 (학비 차이)
3. Public vs Private 선호 + 예산
4. After School Care 필요 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- education.nsw.gov.au/international-students - NSW
- study.vic.gov.au - VIC
- education.qld.gov.au - QLD
- education.act.gov.au - ACT
- myschool.edu.au - 학교 검색

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 거주 도시 선택 (자녀 학비 영향)
- Public vs Private 안내
- OSC 가입 안내

**MARA / 변호사 영역**
- 동반비자 자녀 추가 = 변호사 (학생비자 종속자)
- Subsequent Entrant 신청 = 변호사
- 비자 거절 시 항소 = 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 자녀 학년 + 학비 안내
- [ ] 주별 학비 차이 안내 (NSW/VIC/QLD/ACT)
- [ ] Public vs Private 안내
- [ ] OSC 자녀 건강보험 안내
- [ ] After School Care 비용 안내
- [ ] 동반비자 종속자 신청 변호사 연결
- [ ] 윌슨 카톡 상담 유도
