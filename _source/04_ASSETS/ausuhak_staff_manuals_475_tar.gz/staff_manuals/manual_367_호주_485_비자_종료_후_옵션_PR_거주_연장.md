# #367 호주_485_비자_종료_후_옵션_PR_거주_연장

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "485 비자 2년 짜리 받았는데 1년 남았어요. PR 점수 부족하면 어떻게 해요? 다시 학생비자 받을 수 있어요?"

**직원 멘붕 포인트:**
- 485 종료 후 옵션 모름
- 다시 학생비자 = GTE 위반 위험
- WHV (462) 가능 여부
- 482/186 고용주 후원 비자
- 출국 vs 호주 잔류 결정

---

## ❌ 절대 하지 말아야 할 답

> "485 끝나면 그냥 다시 학생비자 받으세요."

→ ❌ 485 후 학생비자 = GTE 부정 평가 위험 (PR 회피 의도). 거절률 높음. WHV/482/189/190 검토 우선. 본인 점수 + 직군 분석 필수.

---

## ✅ 정답

**485 종료 후 옵션**:

**1. PR 신청 (점수 충족 시)**:
- Subclass 189 (Skilled Independent): 65점+ MLTSSL 직군
- Subclass 190 (State Sponsored): 65점+ STSOL/MLTSSL + 주 후원 (5점 가산)
- Subclass 491 (Regional): 65점+ 외곽 지역 + 5년 후 PR
- 처리: 6~24개월

**2. 482 (Skills in Demand) 비자**:
- 고용주 후원 (Sponsor 인증)
- 2~4년 임시
- 연봉 $76,515 (TSMIT) 이상
- 직군 = TSS occupation list

**3. 186 (Employer Nomination Scheme) - PR 직접**:
- 482 → 186 (3년 후) 또는 직접 186
- 연봉 + 영어 + 기술 평가 의무
- 영주

**4. WHV (462)**:
- 만 30세 이하 한국인
- 학생비자 → 485 → WHV = 가능 (만 30세 이하면)
- 1년 + 88일 농장 = 2년차 + 6개월 농장 = 3년차

**5. 다시 학생 (Subclass 500)**:
- 다른 분야 학사/석사 (예: IT → 간호)
- GTE 사유 정직
- 거절률 높음 (PR 회피 의도)
- Section 109 부정 평가 시 5년 비자 신청 금지

**6. 출국 + 재신청**:
- 한국 귀국 후 다른 비자 재신청
- GTE 리셋 가능
- 비자 격차 발생

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Subclass 189**
Skilled Independent. 65점+ MLTSSL. 후원 X. EOI → Invitation. 비자 신청 처리 12~18개월.

**2. Subclass 482**
Skills in Demand (Skilled Worker). 고용주 후원. 연봉 $76,515 (TSMIT, 2025)+. 2~4년.

**3. Subclass 491**
Skilled Work Regional. 5년 임시 → 191 영주. 외곽 지역 거주 + 근무 의무. 65점+.

**4. WHV (462) 한국인**
Working Holiday. 만 30세 이하 한국인. 1년 + 농장 88일 = 2년차 + 농장 6개월 = 3년차.

**5. GTE 부정 평가**
Section 109. 거짓 진술/PR 회피 의도 = 5년 비자 신청 금지 + Section 48 호주 내 신청 제한.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 현재 점수 계산: 나이 + 학력 + 영어 + 경력 + 후원
**2단계**: 65점 미만: 점수 향상 (NAATI/PY/IELTS/주 후원)
**3단계**: 65점+: EOI 제출 (SkillSelect)
**4단계**: 482 옵션: 고용주 인증 후원 협상
**5단계**: WHV (462) 가능: 만 30세 이하 + 직장 풀타임

---

## 💡 직원이 학생한테 말할 멘트

> "485 종료 후 옵션은 ① 189/190/491 PR (65점+) ② 482 고용주 후원 (연봉 $76,515+) ③ WHV (만 30세 이하) ④ 다른 학사/석사 학생비자 (GTE 부정 위험) ⑤ 출국 후 재신청이에요. 본인 점수 + 직군 + 영어 + 경력 분석 후 결정해야 해서 정확한 시뮬레이션은 윌슨 1:1 상담 필요해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **485 후 학생 자동 OK**
   → GTE 부정 위험 + 거절 다수.

2. **482 = 자동 PR**
   → 482 = 임시. 186 별도 신청 (3년 후).

3. **WHV 만 30세 이상 OK**
   → 만 30세 이하만 (생일 전).

4. **PR 점수 60점 OK**
   → 65점 최소. 60점 = 거의 거절.

5. **491 = 출퇴근 시드니**
   → 외곽 지역 거주 의무. 시드니 미해당.

6. **출국 후 재신청 = 즉시 가능**
   → Section 48 시 호주 내 신청 제한.

7. **485 연장 가능**
   → 485 = 1회. 연장 X (Bachelor 2년 + Master 1년 추가 가능 케이스만).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 PR 점수 (나이 + 학력 + 영어 + 경력)
2. 전공 + ANZSCO 직군 (MLTSSL/STSOL)
3. 나이 (만 30세 이하 = WHV / 25~32 = PR 우선)
4. 고용주 후원 가능 여부 (482/186)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Subclass 189: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/skilled-independent-189
- Subclass 482: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/skills-in-demand
- MLTSSL: immi.homeaffairs.gov.au/visas/working-in-australia/skill-occupation-list
- SkillSelect EOI: immi.homeaffairs.gov.au/skillselect
- PR 점수 계산: immi.homeaffairs.gov.au/visas/working-in-australia/skillselect/points-table

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 점수 시뮬레이션 + 옵션별 비교
- 직군 ANZSCO 분류 검토
- 고용주 후원 가능성 검토

**MARA / 변호사 영역**
- 189/190/491 신청 (MARA 등록 변호사)
- 482/186 신청 + 고용주 협상
- GTE 사유서 작성 (다시 학생비자 시)

---

## ✅ 완벽 응대 체크리스트

- [ ] PR 점수 65점 명확히 안내
- [ ] 옵션 5가지 정확히 나열
- [ ] 482 연봉 $76,515 명시
- [ ] WHV 만 30세 이하 강조
- [ ] Section 109/48 위험 경고
- [ ] 직군 ANZSCO 검토 필수
- [ ] 윌슨 1:1 상담 자연 유도
