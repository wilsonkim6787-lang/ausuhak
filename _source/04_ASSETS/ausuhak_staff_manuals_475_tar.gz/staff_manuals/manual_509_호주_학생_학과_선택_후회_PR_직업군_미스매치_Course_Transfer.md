# #509 호주_학생_학과_선택_후회_PR_직업군_미스매치_Course_Transfer

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "컴퓨터공학으로 왔는데 적성이 안 맞아요. 간호학 가고 싶어요. PR도 더 빠르대요. Transfer 가능해요?"

**직원 멘붕 포인트:**
- Course Transfer 6개월 룰 (Standard 7 of National Code)
- 간호학 IELTS 7.0 (각 영역) 의무 - 컴퓨터공학과 다름
- PR 직업군 변경 시 Skills Assessment 변경
- 기존 학점 일부 인정 (Credit Transfer)
- 직원이 '간호 추천' 강요 X. 본인 결정 + 정보 제공

---

## ❌ 절대 하지 말아야 할 답

> "간호학이 PR 빠르니까 무조건 가세요"

→ ❌ 추천 강요 X. 간호 IELTS 7.0 필수 + 본인 적성 + 학업 부담 안내

---

## ✅ 정답

Course Transfer는 첫 6개월 (Standard 7 of National Code) 안은 학교 + 비자 변경 절차 필요하고, 6개월 후는 자유롭게 가능해요. 간호학은 IELTS 7.0(각 영역 7.0) 필수라 현재 영어 점수 확인 필요합니다. 컴퓨터공학 학점 일부는 Credit Transfer로 인정 가능해요(과학/수학 등). PR은 간호(RN)가 ANZSCO 254418 MLTSSL이라 점수 빠를 수 있지만 학업이 어렵습니다(임상실습, 영어, 윤리 시험). 본인 적성 + 영어 점수 + 재정 다 고려하세요. 윌슨샘과 1:1 상담 권장합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Course Transfer 규정 (Section 8516)**
첫 6개월 (Principal Course):
- 학교 변경 시 Release Letter 필요
- 새 학교 CoE
- 비자 변경 신청 (필요 시)

6개월 후:
- 자유롭게 변경 가능
- 학교 통보만

Course 종류:
- 같은 레벨: Section 8202 미충족 위험
- 더 낮은 레벨: 비자 변경 필요
- 더 높은 레벨: 자동 OK

**2. 간호학 입학 요건 (IELTS 7.0)**
Bachelor of Nursing (RN):
- IELTS 7.0 (각 영역 7.0) 의무
- ELICOS Direct Entry 면제 X (간호만)
- 학업 3년 + 임상실습
- ANMAC 인증 학교 필수

TAFE EN (Diploma of Nursing):
- IELTS 7.0 동일
- 1.5년
- ANMAC 인증
- EN→RN 편입 가능 (Bachelor 2학년)

**3. Credit Transfer (학점 인정)**
기존 학점 일부 인정:
- 과학 (Biology, Chemistry)
- 수학 (Statistics)
- 일반 교양 (English, Communication)
- IT 기초

인정 어려움:
- 컴퓨터공학 전공 과목 (Programming 등)
- 간호 임상 실습 X
- 해부학/생리학 (간호 우선)

최대 인정: 6~12 unit (1학년 일부)

**4. PR 직업군 변경**
컴퓨터공학:
- ANZSCO 261313 Software Engineer
- MLTSSL
- ACS Skills Assessment
- 70~95점 (PR 가능)

간호 (RN):
- ANZSCO 254418 Registered Nurses
- MLTSSL
- ANMAC Skills Assessment
- 70~85점 (PR 가능)
- 489/491 지방 우선
- AHPRA 등록 필수

**5. 재정 + 학업 부담**
간호 학비 (Bachelor 3년):
- $35,000~$45,000/년
- 총 $105,000~$135,000

TAFE EN (Diploma 1.5년):
- $20,000~$25,000/년
- 총 $30,000~$37,500

학업 부담:
- 임상실습 800시간+ (무급)
- 24시간 시프트
- 영어 환자 응대
- 윤리/법 시험
- 한국 학생 중도 포기 비율 일부 있음

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 현재 비자 첫 6개월 여부 확인 (Section 8516)
**2단계**: IELTS 7.0(각 영역 7.0) 점수 확인
**3단계**: 간호 학교 ANMAC 인증 + Credit Transfer 문의
**4단계**: Release Letter + 새 학교 CoE
**5단계**: 비자 변경 (필요 시) MARA 자문

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. Course Transfer는 첫 6개월 (Standard 7 of National Code)에 따라 절차 다르고, 간호학은 IELTS 7.0(각 영역 7.0) 필수예요. 컴퓨터공학 학점은 일부 Credit Transfer 가능합니다. PR은 간호(RN)가 ANZSCO 254418 MLTSSL이라 점수 빠를 수 있지만 학업 부담 큽니다(임상실습, 영어, 윤리). 본인 적성 + 영어 + 재정 종합 검토 필요해요. 자세한 1:1 상담은 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **간호 PR 빠름 → 무조건 X**
   → 본인 적성 + 영어 + 재정

2. **IELTS 6.5 간호 X**
   → 7.0 각 영역 의무

3. **Credit Transfer 다 X**
   → 전공 과목 X. 일부만

4. **EN→RN 자동 X**
   → 별도 편입 절차

5. **ANMAC 무관 X**
   → 미인증 학교 = AHPRA 거부

6. **학업 가벼움 X**
   → 임상 800시간+ 시프트

7. **Standard 7 무관 X**
   → 첫 6개월 절차 다름

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 비자 몇 개월? (6개월 미만/6개월+)
2. IELTS 영어 점수? (6.5/7.0/모름)
3. 재정 여유? ($30K/$60K/$100K+)
4. 간호 임상 부담 OK? (OK/모름)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Standard 7 of National Code: internationaleducation.gov.au
- ANMAC: anmac.org.au
- AHPRA: ahpra.gov.au
- ANZSCO Search: abs.gov.au
- ACS: acs.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Course Transfer 1차 안내
- 간호 IELTS 7.0 의무 안내
- Credit Transfer 1차 안내
- PR 직업군 비교 1차

**MARA / 변호사 영역**
- Course Transfer 비자 (MARA)
- Skills Assessment 변경 (MARA)
- ANMAC 등록 (학교)
- AHPRA 등록 (간호 졸업 후)

---

## ✅ 완벽 응대 체크리스트

- [ ] Standard 7 of National Code 첫 6개월 확인
- [ ] IELTS 7.0 점수 확인
- [ ] 간호 학교 ANMAC 인증 확인
- [ ] Credit Transfer 문의
- [ ] MARA 1:1 상담
