# #289 호주_법대_입학_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 호주 법대 가고 싶어요. 변호사 되려면 어떻게 해야 하나요? PR 받을 수 있나요?"

**직원 멘붕 포인트:**
- Bachelor of Laws (LLB) vs Juris Doctor (JD)
- PLT (Practical Legal Training) 6개월 의무
- 변호사 = STSOL/MLTSSL X (PR 어려움)
- 한국 변호사 자격 호주 인증 절차
- 법대 졸업해도 PR 보장 X (Wilson 정직 안내)

---

## ❌ 절대 하지 말아야 할 답

> ""법대 졸업 = PR""

→ ❌ 변호사 = MLTSSL X. PR 매우 어려움. 정직 안내 필수.

---

## ✅ 정답

"호주 법대는 Bachelor of Laws (LLB, 학사 4년) 또는 Juris Doctor (JD, 석사 3년) 경로입니다. 졸업 후 PLT (Practical Legal Training) 6개월 + Admission to Practice (변호사 등록). 단, 변호사는 Skilled Occupation List에 없어 PR 매우 어렵습니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. LLB vs JD**
Bachelor of Laws (LLB) = 고졸 4년 또는 5년 (Combined Degree). Sydney/Melbourne/UNSW/Monash. ATAR 95+. Juris Doctor (JD) = 학사 졸업 후 3년. UNSW/Sydney/Melbourne/ANU. GPA 5.0+. 둘 다 변호사 자격 동일.

**2. PLT (Practical Legal Training)**
졸업 후 6개월 PLT 의무 (College of Law / Leo Cussen Centre / ANU 등). $9,000~$15,000. Practical 훈련 (계약/소송/영업). PLT 후 Admission to Practice 신청 → Solicitor (변호사) 등록.

**3. 호주 변호사 종류**
Solicitor = 사무 변호사 (서류/계약/거래). Barrister = 법정 변호사 (재판/변론). 둘 다 LLB/JD + PLT + Admission. Barrister = 추가 Bar Reading 1년. 한국 학생 = Solicitor 일반적.

**4. PR 어려움**
변호사 = CSOL/MLTSSL/STSOL X (모든 Skilled Occupation List 제외). PR 경로 = 482 SID (구 TSS, 4년 임시) → 186 (ENS, PR 어려움). 또는 Partner Visa, 사업 비자. 법대 졸업해도 PR 보장 X. Wilson 정직 안내 필수.

**5. 한국 변호사 호주 인증**
한국 변호사 자격 = 호주 자동 인증 X. LLB/JD 다시 + PLT + Admission. 또는 Foreign Legal Practitioner (한국법 자문만 가능, 호주법 X). 한국 법학 학점 일부 인정 가능 (학교별 평가).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 법대 진학 결심 = PR 보장 X 정확히 인지
**2단계**: LLB (학사) 또는 JD (석사) 결정
**3단계**: ATAR 95+ + IELTS 7.0 + 면접 통과
**4단계**: 졸업 후 PLT 6개월 + Admission
**5단계**: PR = 482 → 186 또는 Partner/사업 비자 별도

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 법대는 호주 변호사 자격 받을 수 있지만 PR이 매우 어려워요. 변호사가 Skilled Occupation List에 없어서요. 법대 졸업 + PLT 6개월 + Admission으로 변호사 등록은 가능하지만, PR은 482 비자 (4년 임시) → 186 (PR) 경로로 어려워요. 한국 변호사 자격 있으시면 LLB/JD 학점 일부 인정 가능해요. 법조계 진로 + PR 둘 다 원하시면 다른 직업 (회계/IT/엔지니어) 추천해요. 정직하게 말씀드려요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"법대 졸업 = PR"**
   → 변호사 = MLTSSL X. PR 매우 어려움.

2. **"한국 변호사 = 호주 자동"**
   → LLB/JD 다시 + PLT + Admission.

3. **"PLT 한국에서 가능"**
   → 호주 College of Law 등에서만.

4. **"Solicitor = Barrister 동일"**
   → Solicitor = 사무. Barrister = 법정 (Bar Reading 추가).

5. **"법대 학비 저렴"**
   → $40,000~$50,000/년. 4~5년 = $200,000+.

6. **"외국 변호사 호주에서 일"**
   → Foreign Legal Practitioner = 한국법 자문만.

7. **"법대 졸업 = 즉시 변호사"**
   → PLT 6개월 + Admission 후 변호사.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학년/내신 (ATAR 95+)
2. 영어 IELTS (7.0)
3. 예산 ($300,000+)
4. PR 보장 X 인지 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Law Society NSW: https://www.lawsociety.com.au
- College of Law: https://www.collaw.edu.au
- Leo Cussen Centre VIC
- 각 법대 사이트

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 정보 안내, 정직한 PR 어려움 전달
- 법대 매칭 + 입학 신청
- 한국 변호사 자격 학점 인정 도움
- PR 어려움 시 다른 직업 제안
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- Law Society = Admission to Practice
- PLT Provider = 6개월 훈련
- MARA Lawyer = 482/186 PR (어려움)
- Foreign Legal Practitioner = 별도 신청
- 각 법대 = 입학 평가

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 내신 확인했다
- [ ] 영어 IELTS 확인했다
- [ ] PR 보장 X 정직하게 전달했다
- [ ] LLB vs JD 안내했다
- [ ] PLT 6개월 안내했다
- [ ] 한국 변호사 학점 인정 안내했다
- [ ] PR 어려우면 다른 직업 제안했다
- [ ] 윌슨 직접 카카오 ID 안내했다
