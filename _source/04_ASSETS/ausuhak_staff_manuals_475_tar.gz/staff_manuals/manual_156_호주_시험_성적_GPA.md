# 매뉴얼 #156 - 호주 학교 시험 / 성적 / GPA

## 🎬 상황 시뮬레이션

**카카오 첫 메시지:**
> "호주 대학 GPA 어떻게 계산해요? 시험은 한국이랑 다른가요? Distinction이 뭐예요?"

**직원 멘붕 포인트:**
- 호주 GPA / WAM 한국과 다름
- 학교마다 평가 다름
- HD/D/C/P 등급 시스템

---

## ❌ 절대 하지 말아야 할 답
- "한국이랑 비슷해요" (다름)
- "외워서 시험만 잘 치면 돼요" (Assignment 50%+)
- "GPA 4.5 만점" (호주는 다름)

## ✅ 정답
"호주 대학은 GPA 7점 만점 또는 WAM 100점 만점이에요. 한국 4.5 만점과 달라요. 시험은 Final Exam + Assignment + Participation 합산이에요. Distinction (D) = 75~84점, High Distinction (HD) = 85점+이에요. 자세한 계산법 윌슨 대표가 카톡으로 안내드려요. ID studywilson 이에요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 등급 시스템

| 등급 | 영문 | 점수 | 한국 비교 |
|---|---|---|---|
| HD | High Distinction | 85~100 | A+ |
| D | Distinction | 75~84 | A |
| C | Credit | 65~74 | B |
| P | Pass | 50~64 | C |
| F | Fail | 0~49 | F |
| WD | Withdraw | - | 자진 취소 |

### 2. GPA / WAM 계산

**WAM (Weighted Average Mark)** - 100점 만점:
- 모든 과목 가중 평균
- 예: 총 평균 75점 → WAM 75
- 호주 대학 가장 일반적

**GPA (Grade Point Average)** - 7점 만점:
- HD = 7.0
- D = 6.0
- C = 5.0
- P = 4.0~4.9
- F = 0~3.0

**호주 GPA ≠ 미국 GPA (4.0 만점)**:
- 미국 4.0 = 호주 7.0
- 한국 대학원 진학 시 변환 필요

### 3. 시험 / 평가 비중

**일반 호주 대학**:
- **Final Exam**: 30~50%
- **Mid-term Exam**: 0~20%
- **Assignment**: 30~50% (Essay/Report)
- **Quiz/Participation**: 5~20%
- **Group Project**: 10~30%

→ 한국 (시험 위주)와 다름. Assignment 비중 높음.

### 4. 한국 학생 자주 실수

**시험 위주 공부**:
- 한국식 = 시험 직전 벼락치기
- 호주식 = 매주 Assignment + 학기 후반 시험
- → 매주 꾸준히 해야

**Assignment 표절 (Plagiarism)**:
- Turnitin 검사 (모든 학교)
- 인터넷 복사 즉시 적발
- F학점 + 학교 처분 (Academic Misconduct)

**Participation 점수**:
- 강의 중 발표/질문 점수
- 한국 학생 어려워함
- 영어 부담 + 점수 손해

**Group Project**:
- 팀워크 평가
- 호주/외국인 학생과 팀
- 영어 부담 + 갈등 발생

### 5. 학점 부족 / Fail 처리

**1차 Fail (P 미달)**:
- Resubmit 일부 가능 (학교 정책)
- Re-exam 가능 (학교 정책)
- 등록금 자비 재수강

**누적 Fail**:
- 50% 이상 Fail → Probation (경고)
- 학기 연속 Fail → Exclusion (퇴출)
- 학생비자 영향

**Fail 후 옵션**:
- Special Consideration (의료/가족 사정)
- Tutor 면담
- 코스 변경
- Withdraw without penalty (일정 기한)

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 학생 현재 상태 파악
- 1학기 처음? 학점 위기?
- 시험 부담? Fail 위기?

### Step 2: 등급 시스템 설명
- HD/D/C/P/F
- WAM 계산법

### Step 3: 평가 비중 안내
- Assignment 50%+
- 매주 꾸준히

### Step 4: 학교 무료 지원
- Academic Skills Centre
- Tutor

### Step 5: 윌슨 상담 (위기 시)
- Fail 후 옵션
- 코스 변경

---

## 💡 직원이 학생한테 말할 멘트

```
[등급 시스템 설명]
호주 대학 등급:

▪️ HD (High Distinction) = 85~100 (A+)
▪️ D (Distinction) = 75~84 (A)
▪️ C (Credit) = 65~74 (B)
▪️ P (Pass) = 50~64 (C)
▪️ F (Fail) = 0~49

WAM 100점 만점이고요, GPA는 7점 만점이에요.

평가 = Assignment 50% + Exam 50% 일반.
한국식 시험 위주 공부 X, 매주 Assignment 꾸준히 해야 해요.

자세한 학습 전략 윌슨 대표가 안내드려요.
ID: studywilson
```

```
[Fail 위기]
Fail 위기시 학교 무료 지원 활용하세요.

▪️ Academic Skills Centre = 라이팅 1:1
▪️ Tutor = 학과 도움
▪️ Special Consideration = 의료/가족 사정 신청
▪️ Re-exam / Resubmit = 일부 가능

코스 변경/휴학 옵션도 있어요.
윌슨 대표가 1:1 상담드려요.
ID: studywilson
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "GPA 4.5 만점"
**아님** - 호주 GPA 7점 또는 WAM 100점. 미국 4.0과도 다름.

### 함정 2: "P (Pass) = 좋은 등급"
**아님** - P는 합격선. 평균 학생 C/D 받음.

### 함정 3: "시험 위주"
**아님** - Assignment 50%+. 매주 꾸준히.

### 함정 4: "Turnitin 표절 검사 = 한국에서 안 걸림"
**아님** - 인터넷 + 학교 DB 통합. 즉시 적발.

### 함정 5: "Group Project = 무임승차"
**위험** - 팀원 평가 시스템. 무임승차 적발 시 F.

### 함정 6: "Participation 점수 = 영어 잘하면"
**전부 X** - 질문/발표/참여. 짧아도 OK.

### 함정 7: "Fail = 즉시 퇴출"
**아님** - Special Consideration 신청. Re-exam 기회.

---

## 📞 카카오 응대 시 필수 4가지 확인

```
[직원이 학생에게 물어볼 4가지]

1. 현재 학년 / 학기?

2. 평가 위기?
   (Fail? 평균 미달?)

3. 학교 무료 지원 활용?
   (Academic Skills 이용 여부)

4. 멘탈 상태?
   ★ 위기 신호 체크 ★

→ 위기 시 매뉴얼 #143 적용
→ 일반 시 윌슨 카톡 연결
```

---

## 🔍 직원이 직접 확인 가능한 사이트

- 학교별 Academic Calendar / Grading System
- [Universities Admissions Centre](https://www.uac.edu.au/)
- [Turnitin](https://www.turnitin.com/)
- 학교 Academic Skills Centre

---

## 🚨 직원 영역 vs 윌슨 영역

### 직원 영역
- 등급 시스템 일반 안내
- 평가 비중 안내
- 학교 무료 지원

### 윌슨 영역 (1:1)
- Fail 후 코스 변경
- 휴학/Withdraw 결정
- 영주권 일정 영향

---

## ✅ 완벽 응대 체크리스트

- [ ] HD/D/C/P/F 등급 안내
- [ ] WAM 100점 / GPA 7점 안내
- [ ] 평가 비중 (Assignment 50%+)
- [ ] 한국식 vs 호주식 차이
- [ ] 학교 무료 지원 안내
- [ ] Fail 시 옵션 (Re-exam / Special)
- [ ] 윌슨 카톡 연결 (위기 시)

---

**작성: 2026-05-04 **
**참조: 학교별 Academic Calendar / UAC / Turnitin**
