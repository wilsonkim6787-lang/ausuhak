# 📚 직원 응대 매뉴얼 #022

**케이스: 30세 / 한국 교사 / 호주 교사 자격 + 영주권 / 1억 예산**

---

## 🎬 상황 시뮬레이션

> 한국에서 영어 교사 4년 했어요. 호주 교사 자격 받고 일하면서 영주권 받고 싶습니다. 30세이고 IELTS 7.5 있어요. 1억 예산이에요.

**👉 정답**: **AITSL 직업 평가 + Master of Teaching 또는 Bridging**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 교사 = MLTSSL 직업군 직업

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Early Childhood Teacher | 241111 | MLTSSL |
| Primary School Teacher | 241213 | MLTSSL |
| Secondary School Teacher | 241411 | MLTSSL |
| Special Needs Teacher | 241511 | MLTSSL |

### 2️⃣ AITSL = 호주 교사 등록 + 평가 기관

- **AITSL** (Australian Institute for Teaching and School Leadership)
- 한국 사범대 학위 + 경력 평가
- 결과: Substantially Equivalent / Not Substantially Equivalent
- 후자면 호주 Master of Teaching 또는 Bridging 必

### 3️⃣ 한국 교사 → 호주 교사 경로

| 평가 결과 | 경로 |
|---|---|
| Substantially Equivalent | 호주 교사 등록 직접 (영어 시험만 통과) |
| Not Substantially Equivalent | Master of Teaching (1.5~2년) 必 |

한국 사범대 영어교육 + 4년 경력 = **Substantially Equivalent 가능성 高**

### 4️⃣ Master of Teaching 학교 (Master Pre-reg)

| 학교 | 학비 (연간) | 코스 |
|---|---|---|
| UMelb Master Teaching | $48K | Primary/Secondary |
| Monash Master Teaching | $44K | Primary/Secondary/EC |
| USyd Master Teaching | $50K | 다양 |
| UTS Master Teaching | $42K | 다양 |
| Macquarie Master Teaching | $40K | 다양 |
| ACU Master Teaching | $32K | 다양 |

### 5️⃣ 호주 교사 자격 영어 조건

- **Academic IELTS 7.0** (Reading/Writing) + **8.0** (Speaking/Listening)
- OET, PTE 동가 점수 가능
- 한국 영어 교사도 IELTS R/W 7.0 + S/L 8.0 별도 시험 필수

---

## 🎯 정답 경로 (2가지 비교)

### 옵션 A. AITSL 평가 + Direct 등록 (자동 인정 시)

```
한국 사범대 + 4년 경력 + IELTS R/W 7.0 + S/L 8.0
        ↓
AITSL 평가 (Substantially Equivalent 시)
        ↓
호주 교사 등록 (NESA / VIT 등)
        ↓
호주 학교 취업 + PR
```

**총 1-2년 / 학비 0 / 가장 빠름**

### 옵션 B. Master of Teaching (안전)

```
한국 학사 + IELTS R/W 7.0 + S/L 8.0
        ↓
Master of Teaching 1.5~2년 ($60K~$100K)
        ↓
졸업 + AITSL 등록
        ↓
호주 학교 + 485 + PR
```

**총 3-4년 / 학비 $60K~$100K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 영어 교사 4년 + IELTS R/W 7.0 + S/L 8.0 = 호주 교사 자격 + PR 빠른 경로 가능합니다.
> 
> 1. **AITSL 평가** = 한국 사범대 학위 인정 여부 결정 (Substantially Equivalent 가능성 높음)
> 2. **자동 인정 시 Direct 등록** = Master 불필요 = 가장 빠름
> 3. **인정 안 될 시 Master of Teaching 1.5~2년** = $60K~$100K
> 
> 영어 조건이 까다로워요: **IELTS R/W 7.0 + S/L 8.0 (AITSL)** = 한국 영어 교사여도 별도 시험 필요.
> 
> 1억 예산이면 어느 옵션이든 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 한국 학교 (사범대인지)  
> ② 영어 교사 4년 경력 자격증 (정교사 1급/2급)  
> ③ AITSL 평가 가능 여부 사전 검토 원하는지"

---

## ⚠️ 함정

1. **"한국 영어 교사 = 호주 자동 자격"** → ❌ AITSL 평가 必
2. **"IELTS 7.0이면 OK"** → ❌ R/W 7.0 + S/L 8.0 必須 (AITSL 정확)
3. **"호주 교사 = 한국보다 쉬움"** → 영어 조건 까다로움
4. **"Master 끝내면 자동 등록"** → 별도 등록 절차 + 인터뷰

---

## 📞 카카오 응대 시 필수

1. 한국 학교 (사범대인지)
2. 자격증 종류 (정교사 1급/2급)
3. 경력 연수 + 분야
4. Direct vs Master 검토

---

## 🔍 직원 확인 사이트

- AITSL: aitsl.edu.au
- NESA NSW: educationstandards.nsw.edu.au
- VIT VIC: vit.vic.edu.au
- Master of Teaching 학교들
