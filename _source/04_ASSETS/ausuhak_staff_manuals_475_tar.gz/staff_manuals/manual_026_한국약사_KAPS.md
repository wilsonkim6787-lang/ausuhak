# 📚 직원 응대 매뉴얼 #026

**케이스: 30세 / 한국 약사 + 3년 경력 / 호주 약사 / KAPS 시험**

---

## 🎬 상황 시뮬레이션

> 한국 약사 면허 + 3년 경력입니다. 호주에서 약사로 일하고 싶어요. 30세이고 IELTS 7.0 있어요.

**👉 정답**: **KAPS (Knowledge Assessment of Pharmaceutical Sciences) 시험 + Internship**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ KAPS = 한국 약사의 호주 약사 전환 시험

**KAPS** (Knowledge Assessment of Pharmaceutical Sciences) = APC (Australian Pharmacy Council) 운영.

```
한국 약사 + IELTS 7.0
        ↓
1단계: APC Eligibility (학위 평가) - 약 3개월
        ↓
2단계 KAPS 시험: 약학 이론 시험 (Pearson VUE)
        ↓
3단계 Pharmacy Intern Year: 호주 약국 1년 견습
        ↓
4단계 Pharmacy Board Exam (실기 + 면접)
        ↓
AHPRA 약사 등록
```

### 2️⃣ KAPS 시험

- 컴퓨터 기반 / Pearson VUE 시험장 (한국 응시 가능)
- Paper 1 + Paper 2 = 약 4시간
- 시험비 약 $1,300 (Paper 1) + $1,300 (Paper 2)
- 1년 2번 응시 가능

### 3️⃣ Intern Year = 호주 약국 1년 견습

- KAPS 통과 후 호주 약국 1년 견습 必須
- 호주 약사 직접 매칭 (윌슨 매칭 가능)
- 견습 시급 받음 (약 $25/시간)

### 4️⃣ 영어 조건

- **IELTS 7.0 (각 영역 7.0)** 또는 OET B grade
- 한국 약사 면허 + IELTS 7.0 = 별도 시험 必須

### 5️⃣ 약사 PR

- ANZSCO 251513 (Retail Pharmacist) - MLTSSL
- ANZSCO 251512 (Hospital Pharmacist) - MLTSSL
- 두 직업 다 MLTSSL 직업군

---

## 🎯 정답 경로

### KAPS + Intern + 약사 등록 + PR

```
한국 약사 + IELTS 7.0
        ↓
APC 자격 평가 (3개월)
        ↓
KAPS Paper 1 + Paper 2 시험 (한국 응시)
        ↓
호주 약국 Intern Year 1년 (견습 시급 $25/시간)
        ↓
Pharmacy Board Exam
        ↓
AHPRA 약사 등록 + PR
```

**총 2-3년 / 비용 약 $5,000 (시험비) + 호주 체류**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 약사 + 3년 경력 + IELTS 7.0 = 호주 약사 전환 가능합니다. 의사보다는 빠릅니다.
> 
> 1. **KAPS 시험** = APC 평가 + 약학 시험 (한국 응시 가능)
> 2. **Intern Year 1년** = 호주 약국 견습 + 시급 받음
> 3. **약사 PR**: ANZSCO 251513/251512 = MLTSSL 직업군
> 4. **총 기간**: 약 2-3년
> 
> KAPS 시험은 1년 2번 응시 가능하고, 한국에서도 응시 가능해서 현지 거주 부담은 적습니다.
> 
> 카톡으로 알려주세요:
> ① IELTS 정확한 점수  
> ② 한국 약사 경력 + 분야 (병원/약국/제약)  
> ③ 호주 어느 도시 견습 희망"

---

## ⚠️ 함정

1. **"한국 약사 자격 = 자동 인정"** → ❌ KAPS 시험 必
2. **"Intern 자동 매칭"** → ❌ 직접 약국 구해야
3. **"IELTS 6.5 OK"** → ❌ 7.0 必須
4. **"Intern 무급"** → ✅ 시급 약 $25 받음

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수
2. 한국 약사 경력 + 분야
3. KAPS 응시 시기
4. Intern 도시 우선

---

## 🔍 직원 확인 사이트

- APC (Australian Pharmacy Council): pharmacycouncil.org.au
- KAPS 시험: pharmacycouncil.org.au/services/qualified-overseas-pharmacist
- AHPRA: ahpra.gov.au
