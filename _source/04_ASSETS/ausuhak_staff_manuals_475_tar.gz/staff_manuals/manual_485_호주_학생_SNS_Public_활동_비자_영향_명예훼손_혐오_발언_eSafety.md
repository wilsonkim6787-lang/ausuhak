# #485 호주_학생_SNS_Public_활동_비자_영향_명예훼손_혐오_발언_eSafety

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "유튜브 채널 운영하면서 호주 생활 영상 올리고 있어요. 한국 정치 비판 영상도 올리는데 학생비자 영향 있나요? 댓글로 욕 들어왔는데 어떻게 해요?"

**직원 멘붕 포인트:**
- SNS = 호주 법 적용 (Online Safety Act, Defamation Act)
- 한국 정치 비판도 호주 영토 내에서는 호주 법 적용
- 혐오 발언/명예훼손 SNS = Character Test 영향 가능
- 사이버 괴롭힘 피해자 신고: eSafety Commissioner
- 직원이 'SNS는 자유' 잘못 안내하면 학생 위험

---

## ❌ 절대 하지 말아야 할 답

> "SNS는 자유라서 비자 영향 없어요 자유롭게 올리세요"

→ ❌ Online Safety Act + Defamation Act 적용. 비자 Character Test 영향 가능. 잘못 안내 시 큰 위험

---

## ✅ 정답

유튜브 채널 자체는 학생비자 위반 아니에요. 단, 콘텐츠가 명예훼손/혐오 발언/선동 포함이면 호주 법 위반될 수 있고, 비자 Character Test에도 영향 줄 수 있어요. 한국 정치 비판도 호주 영토에서 발신되면 호주 법 적용됩니다. 댓글 욕설은 Cyberbullying에 해당해서 eSafety Commissioner(esafety.gov.au)에 신고 가능해요. 콘텐츠 내용이 폭력/혐오 선동 수준이면 윌슨샘과 1:1 상담 잡으시는 게 좋습니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Online Safety Act 2021 (호주 SNS 법)**
주요 위반 항목:
1. Cyberbullying (Adult/Youth) - 신고 후 24시간 삭제 명령
2. Image-based Abuse (성적 사진 동의 X 공유)
3. Cyber Abuse (지속적 괴롭힘)
4. Illegal/Restricted Content (자살/극단주의)
5. Volumetric Attack (대량 비방)

처벌: 벌금 $111,000 + 콘텐츠 삭제 명령
외국인도 동일 적용 (한국 SNS 운영자도 호주 거주 시)

**2. Defamation Act (명예훼손법)**
각 주별 Defamation Act (Uniform Defamation Law):
명예훼손 요건:
1. 사실/의견을 제3자에게 전달
2. 특정 개인 식별 가능
3. 평판 손상 가능성
4. 진실/공익/의견 항변 X

Damages: $432,500까지 (NSW 2026)
유튜브 영상 명예훼손 = Civil Lawsuit 대상
한국 정치인 비방도 호주 영토 발신 시 적용

**3. Character Test 비자 영향 (Section 501)**
Substantial Criminal Record:
- 12개월+ 형 선고

Past or Present Conduct:
- 폭력/극단주의 SNS 게시 = 위험 행동 평가 가능

Risk to Australian Community:
- 혐오 발언 선동 = 비자 거절/취소 사유

→ 단순 정치 비판 X, 폭력/혐오 선동 위험

**4. Cyberbullying 신고 절차 (eSafety)**
esafety.gov.au 또는 1800 880 176
절차:
1. 플랫폼(YouTube/Instagram/Facebook) 자체 신고
2. 48시간 내 삭제 안 되면 eSafety 신고
3. eSafety가 플랫폼에 24시간 삭제 명령
4. 미준수 시 벌금 $111,000
외국인 학생도 신고 가능. 무료

**5. 호주 안전한 SNS 운영 가이드**
1. 정치 비판 시 사실 기반 + 의견 명시 ("내 의견은")
2. 특정 개인 명예훼손 X (사실+공익이면 OK)
3. 폭력/혐오 선동 X
4. 자살/자해 콘텐츠 X (Restricted)
5. 어린이 보호 (만 18세 미만 출연 시 동의)
6. Privacy Act: 본인 동의 없이 타인 사진/영상 X
7. Copyright: 음악/영상 무단 사용 X

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 본인 SNS 콘텐츠 자가 검토 (혐오/명예훼손 점검)
**2단계**: 댓글 욕설 발생 시: 플랫폼 신고 → 48시간 → eSafety 신고
**3단계**: 스크린샷 + URL 보관 (증거)
**4단계**: 심각한 경우 변호사 자문 (Defamation Lawyer)
**5단계**: 비자 Character Test 영향 의심 시 윌슨샘 1:1 상담

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요 학생님. 유튜브 채널 자체는 학생비자 위반 아니에요. 단 콘텐츠가 명예훼손/혐오 발언이면 호주 법 위반 + 비자 Character Test 영향 가능합니다. 댓글 욕설은 esafety.gov.au에 신고하실 수 있어요. 한국 정치 비판도 호주 발신이면 호주 법 적용이라 자가 검토 하시는 게 좋습니다. 비자 영향 자세한 부분은 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **SNS는 자유 X**
   → Online Safety Act + Defamation Act 적용. 비자 영향 가능

2. **'한국 일' 호주 무관 X**
   → 호주 영토 내 발신은 호주 법 적용. 한국 정치 비판도 마찬가지

3. **익명 운영 안전 X**
   → IP 추적 가능. 플랫폼이 법원 명령 시 정보 공개

4. **'표현의 자유' 만능 X**
   → Implied Freedom 일부 보장. 명예훼손/혐오는 예외

5. **Cyberbullying 무시 X**
   → eSafety 무료 신고. 적극 활용 권장

6. **YouTube 수익화 학생비자 위반 X**
   → 원칙상 위반 아니지만 본업 수준 풀타임 시 의문 가능

7. **폭력 영상 단순 공유 X**
   → Restricted Content. 단순 공유도 처벌 대상

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 유튜브 채널 콘텐츠 주제? (생활 / 정치 / 교육 / 엔터)
2. 구독자 수? (1만 미만 / 1만~10만 / 10만+)
3. 수익화 됐어요? (예 / 아니오)
4. 댓글 욕설 빈도? (가끔 / 자주 / 매일)

---

## 🔍 직원이 직접 확인 가능한 사이트

- eSafety Commissioner: esafety.gov.au / 1800 880 176
- Defamation Act NSW: legislation.nsw.gov.au
- Section 501 Character Test: immi.homeaffairs.gov.au
- YouTube Creator Guidelines: support.google.com/youtube
- Privacy Act 1988: privacy.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- SNS 콘텐츠 자가 검토 가이드
- Character Test 1차 안내
- eSafety 신고 절차 안내
- 댓글 욕설 대응 1차 안내

**MARA / 변호사 영역**
- Defamation 명예훼손 변호 (Civil Lawyer)
- Character Test 비자 거절 변호 (MARA)
- Online Safety Act 위반 변호 (Civil Lawyer)
- 수익화 비자 영향 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] SNS 콘텐츠 자가 검토 완료
- [ ] 악플 신고 시 스크린샷 + URL 보관
- [ ] eSafety 신고 절차 숙지
- [ ] 수익화 시 비자 영향 확인
- [ ] 심각 케이스 시 윌슨샘 1:1 상담
