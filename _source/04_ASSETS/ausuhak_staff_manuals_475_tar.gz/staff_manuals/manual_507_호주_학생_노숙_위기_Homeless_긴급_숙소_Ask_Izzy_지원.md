# #507 호주_학생_노숙_위기_Homeless_긴급_숙소_Ask_Izzy_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "셰어 갑자기 쫓겨나서 갈 데가 없어요. 돈도 거의 없어요. 호텔도 못 가는데 어디 가야 해요?"

**직원 멘붕 포인트:**
- 노숙 위기 = 즉시 긴급 숙소 + 사회복지 자원 활용
- Ask Izzy: 호주 노숙자 자원 검색 (askizzy.org.au)
- Salvation Army / Mission Australia / St Vincent de Paul 24시간 지원
- 외국인 학생도 일부 자원 이용 가능 (긴급 숙소/푸드뱅크)
- 직원이 '한국 돌아가세요' 단순 X. 호주 자원 먼저 안내

---

## ❌ 절대 하지 말아야 할 답

> "돈 없으면 한국 돌아가세요"

→ ❌ 긴급 자원 다양. 노숙은 안전 위협 + 학업 위협. 자원 안내 우선

---

## ✅ 정답

긴급 상황이에요. 즉시 (1) Ask Izzy(askizzy.org.au) - 호주 노숙자 무료 검색 사이트, (2) Salvation Army 1300 371 288 - 24시간 위기 지원, (3) Homelessness NSW 1800 152 152 - 24시간 무료, (4) Mission Australia 02 9219 2000 활용하세요. 외국인 학생도 긴급 숙소 1~2주 가능합니다. 푸드뱅크(Foodbank, Second Bite)도 무료 음식 제공해요. 학교 Student Wellbeing/Counselling Service도 1차 도움 가능합니다. 안전 확보 후 새 셰어/임대 알아보세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Ask Izzy (호주 노숙자 자원)**
사이트: askizzy.org.au
기능:
- 위치 기반 무료 자원 검색
- 긴급 숙소 / 음식 / 의료 / 법률
- 외국인 학생 일부 가능
- 24시간 무료
- 한국어 미지원 but 단순 UI
- 모바일 + 웹 둘 다

**2. 긴급 숙소 (24시간 무료)**
Homelessness NSW: 1800 152 152
Salvation Army: 1300 371 288
Mission Australia: 02 9219 2000
St Vincent de Paul: 13 18 12
Wesley Mission: 1800 021 821

VIC: Salvation Army 1800 825 955
QLD: 1800 474 753
WA: 1800 065 892

긴급 숙소 1~2주 무료
이후 Refuge/Hostel

**3. 푸드뱅크 (무료 음식)**
Foodbank: foodbank.org.au
Second Bite: secondbite.org
OzHarvest: ozharvest.org
FareShare: fareshare.net.au

학교 Pantry (일부 대학):
- USyd Foodhub
- UNSW Arc Food Pantry
- UTS Students' Association
외국인 학생도 일부 가능
신분 확인 X (대부분)

**4. 학교 자원 (Student Wellbeing)**
USyd Student Centre: 1800 SYD UNI
UNSW Student Wellbeing: unsw.edu.au
UTS Counselling: uts.edu.au
Monash Counselling: monash.edu
ANU Counselling: anu.edu.au

지원:
- 긴급 자금 (Emergency Grant) $200~$500
- Student Crisis Loan
- Counselling 무료
- Welfare Officer 1대1 상담

**5. 새 거주지 찾기 (긴급)**
긴급 단기 옵션:
- Hostel: $30~$60/일 (Backpacker)
- Airbnb 단기: $50~$150/일
- 학교 Residential College (가용 시)
- Couchsurfing.com (소셜 네트워크)

장기 검색:
- Flatmates.com.au
- Gumtree (Sharehouse)
- 한인 카톡방 (검증 후)
- Domain/Realestate.com.au

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Ask Izzy 또는 Homelessness NSW 1800 152 152 즉시 연락
**2단계**: 긴급 숙소 1~2주 확보
**3단계**: 푸드뱅크/학교 Pantry 무료 음식
**4단계**: 학교 Welfare Officer + Emergency Grant 신청
**5단계**: 장기 셰어 알아보기 (Flatmates/한인 카톡)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 긴급 상황이에요. 즉시 (1) Ask Izzy askizzy.org.au 자원 검색, (2) Homelessness NSW 1800 152 152 24시간 긴급 숙소, (3) Salvation Army 1300 371 288 활용하세요. 외국인 학생도 긴급 숙소 1~2주 가능합니다. 푸드뱅크 Foodbank/Second Bite에서 무료 음식 받으세요. 학교 Student Wellbeing에서 Emergency Grant $200~$500 가능해요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'한국 돌아가세요' X**
   → 호주 자원 먼저

2. **외국인 자원 X**
   → Ask Izzy/Salvation Army 일부 가능

3. **학교 도움 무관 X**
   → Welfare Officer + Emergency Grant

4. **푸드뱅크 신분 확인 X**
   → 대부분 무신분

5. **Hostel 장기 X**
   → 단기 1~2주만

6. **Couchsurfing 위험 X**
   → 검증된 호스트만

7. **긴급 숙소 무료 X**
   → 기본 무료. 일부 음식비 $5~$15

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 어느 도시? (시드니/멜번/브리즈번/기타)
2. 현재 안전해요? (안전/안전 X)
3. 갈 곳 있어요? (오늘 밤/없음)
4. 현금 얼마? ($50 미만/$50~$200/$200+)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Ask Izzy: askizzy.org.au
- Salvation Army: 1300 371 288
- Homelessness NSW: 1800 152 152
- Foodbank: foodbank.org.au
- Mission Australia: missionaustralia.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Ask Izzy 1차 안내
- 긴급 숙소 연결
- 학교 Welfare Officer 안내
- 푸드뱅크 안내

**MARA / 변호사 영역**
- 긴급 숙소 (Salvation Army 등)
- 학교 Emergency Grant (Student Wellbeing)
- 임대 분쟁 (NCAT)
- 비자 영향 (MARA - 보통 무관)

---

## ✅ 완벽 응대 체크리스트

- [ ] Ask Izzy 자원 검색
- [ ] 긴급 숙소 확보
- [ ] 푸드뱅크
- [ ] 학교 Welfare Officer
- [ ] 장기 셰어 검색
