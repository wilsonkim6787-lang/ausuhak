# #429 호주_학생_IELTS_시험_응시_Reschedule_Cancel_Refund

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "IELTS 신청해놨는데 시험 1주일 전에 코로나 걸렸어요. Reschedule 가능한가요? 환불 받을 수 있나요? 그리고 IELTS Indicator vs IELTS Online vs IELTS UKVI 차이가 뭔가요? 호주 비자에 어떤 거 인정되나요?"

**직원 멘붕 포인트:**
- Reschedule 정책 (5주 이전 vs 5주 이내)
- IELTS UKVI vs General vs Academic
- IELTS Online 호주 비자 인정
- 환불 vs 부분 환불
- Test Date 변경 수수료

---

## ❌ 절대 하지 말아야 할 답

> "IELTS는 환불 안 돼요"

→ ❌ ❌ 5주 이전 50% / 의료 사유는 95% 환불 (의사 진단서). Reschedule 가능.

---

## ✅ 정답

IELTS 정책 (IDP/British Council 동일): ① 5주 이전 - $100 수수료 + Reschedule, ② 5주 이내 - 환불 X / Reschedule X, ③ 의료/사망 사유 - 의사 진단서 제출 시 75~95% 환불 또는 무료 Reschedule (5주 내라도), ④ IELTS Indicator (코로나 임시) - 폐지 (2023.12), ⑤ IELTS Online (재택) = 호주 비자 인정 X (2024 기준 일부만), ⑥ IELTS UKVI = 영국 비자 전용 (호주 비자 인정 X), ⑦ 호주 비자/PR/이민 = IELTS Academic 또는 General (Test Centre 응시) 둘 다 인정, ⑧ TOEFL/PTE/Cambridge도 인정 (이민부 공식).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. IELTS 환불 정책**
5주 기준 / 의료 사유 95%

**2. IELTS UKVI**
영국 전용 / 호주 X

**3. IELTS Online**
호주 비자 일반 인정 X

**4. Test Centre 응시**
호주 비자 인정

**5. 의사 진단서**
Medical Certificate / GP 발급

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 시험일까지 5주 이상/이내 확인
**2단계**: 2단계: 코로나 양성 = GP 진단서 즉시 발급
**3단계**: 3단계: IDP/British Council 즉시 연락
**4단계**: 4단계: Refund vs Reschedule 결정
**5단계**: 5단계: 다음 가능한 시험일 예약

---

## 💡 직원이 학생한테 말할 멘트

> "의사 진단서 첨부하면 95% 환불 또는 무료 Reschedule 가능합니다. 호주 비자는 IELTS Online이 아닌 Test Centre 응시본 인정됩니다. IELTS Academic/General 둘 다 OK입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **IELTS 환불 자동 X**
   → 의료 사유 95%

2. **IELTS Indicator 안내**
   → 2023.12 폐지

3. **IELTS Online = 호주 비자**
   → Test Centre만

4. **IELTS UKVI = 호주 인정**
   → 영국 전용

5. **Academic만 호주 비자**
   → General도 인정

6. **PTE 호주 비자 X**
   → PTE Academic 인정

7. **Reschedule 무제한**
   → 1회만 가능 (대부분)

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 시험일까지 남은 일수
2. 의료 사유 여부 (진단서)
3. IELTS 종류 (Academic/General/UKVI)
4. 다음 비자 신청 일정

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('IDP IELTS', 'ielts.com.au')
- ('British Council', 'britishcouncil.org.au')
- ('이민부 영어시험', 'immi.homeaffairs.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- IELTS 일반 정책, 종류 구분, Reschedule 안내

**MARA / 변호사 영역**
- 의료 사유 비자 연장 시 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 5주 기준 환불 안내함
- [ ] 의료 사유 95% 강조함
- [ ] Test Centre vs Online 구분함
- [ ] UKVI 호주 X 명시함
- [ ] Academic/General 둘 다 OK
- [ ] PTE/TOEFL 대안 안내함
