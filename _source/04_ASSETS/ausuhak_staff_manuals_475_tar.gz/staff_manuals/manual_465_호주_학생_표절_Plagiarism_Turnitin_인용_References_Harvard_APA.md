# #465 호주_학생_표절_Plagiarism_Turnitin_인용_References_Harvard_APA

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "에세이 제출했는데 Turnitin Similarity 38% 나왔어요. Plagiarism으로 신고됐어요. 한국에서는 인용 표시 안 해도 됐는데. 호주는 다 인용해야 하나요? Harvard? APA? Reference 어떻게 해야 하나요? 이거 Fail되면 비자 영향 있나요?"

**직원 멘붕 포인트:**
- 호주 학교 = 모든 인용 출처 표시 의무
- Turnitin Similarity 20%+ = 학교별 다름
- Harvard / APA / MLA / Chicago 인용 양식 다양
- Self-Plagiarism(본인 이전 글) = Plagiarism
- 한국 학교와 인용 문화 다름 (한국 = 관대 / 호주 = 엄격)
- Fail Subject = 학생비자 직접 영향 X / 단, GPA 영향 + 졸업 지연

---

## ❌ 절대 하지 말아야 할 답

> "한국에서는 인용 표시 안 해도 됐는데 부당해요"

→ ❌ 호주 표절 정책 = 학교 입학 시 동의 / 'Cultural Difference' 항변 = 항소 어려움 / 단, 첫 위반 시 경고 가능 / 정확한 인용법 학습 필수

---

## ✅ 정답

(1) 학교 인용 양식 확인 - Harvard(상경)/APA(사회)/MLA(영문)/Chicago(역사) (2) Turnitin Similarity 확인 - 보통 20% 이하 권장 (3) 청문회 시 항변 - 첫 위반/실수/문화 차이/배움 의지 (4) Tutor / Learning Centre 무료 자문 (5) 재제출 가능 시 즉시 / Fail 시 재수강

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 인용 양식 (전공별)**
Harvard(저자-연도): 상경/사회 / APA(저자-연도): 심리/교육 / MLA(저자-페이지): 영문/문학 / Chicago(각주): 역사/예술 / Vancouver(번호): 의학 / IEEE(번호): 공학 / 학교/학과 지정.

**2. Turnitin Similarity 기준**
Sydney University: 20% 이하 권장 / UNSW: 25% 이하 / Melbourne: 학과별 / Monash: 30% 이하 / 단, Quotes/Bibliography 제외 후 비교 / 5%+ Single Source = 의심.

**3. Plagiarism 종류 5가지**
(1) Direct Plagiarism(전체 복사) (2) Mosaic(부분 짜집기) (3) Self-Plagiarism(본인 이전 글) (4) Accidental(인용 빠짐) (5) Paraphrasing 부적절(원문 너무 유사) / AI 사용 별도(Misconduct).

**4. 학교 Learning Centre 무료**
거의 모든 호주 대학 무료 / 1:1 Tutoring / 인용 양식 / Paraphrasing / Citation Software(EndNote/Zotero/Mendeley) / Sydney: Learning Hub / UNSW: Learning Centre / Monash: English Connect.

**5. Self-Plagiarism (본인 글)**
동일 과제 다른 수업 제출 = Self-Plagiarism / 학부 ↔ 대학원 글 재사용 = X / 본인 글 인용도 출처 표시 의무 / 한국 학생 다수 위반.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: Turnitin Similarity 보고서 확인 - 단일 출처 5%+ 케이스 파악
**2단계**: 2차: 학교 Learning Centre 무료 자문 - 1주일 내
**3단계**: 3차: Plagiarism 청문회 시 항변 - 첫 위반/실수/배움 의지
**4단계**: 4차: Fail 시 재수강 / Pass 가능성 시 재제출
**5단계**: 5차: 향후 Citation Software(Zotero 무료) + Harvard/APA 학습

---

## 💡 직원이 학생한테 말할 멘트

> "호주 학교는 한국과 달리 모든 출처 표시 의무라서 첫 위반 학생 많습니다. Turnitin Similarity 20% 이하 권장입니다. 학교 Learning Centre(무료) 즉시 자문 받으시고, 청문회 시 첫 위반 + 배움 의지 항변하세요. Fail되어도 학생비자 직접 영향 없습니다(GPA + 졸업 지연만). 향후 Zotero(무료 인용 소프트웨어) + Harvard/APA 양식 학습 추천합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Cultural Difference 항변 약함**
   → 한국 = 관대 / 호주 = 엄격 / '몰랐다' 항변 = 첫 위반 일부 적용 / 입학 시 학교 정책 동의 = 책임.

2. **Self-Plagiarism 한국 학생 다수**
   → 동일 과제 다른 수업 = X / 본인 학부 글 대학원 사용 = 출처 표시 / 한국 = 일반적 / 호주 = 엄격.

3. **Quotation Mark X = Direct Plagiarism**
   → 원문 그대로 인용 = '큰따옴표' + 출처 / 인용 표시 X = 복사 / 이론 설명도 출처.

4. **Paraphrasing = 단어만 바꾸면 X**
   → 원문 구조 유지 + 단어만 = 표절 / 완전히 본인 말로 + 출처 표시 / Learning Centre 1:1 자문.

5. **Turnitin AI Detector 별도**
   → Turnitin Similarity ≠ AI Detection / AI 사용 별도 Misconduct / Self-Plagiarism도 Detector 양성.

6. **Citation Software 무료**
   → Zotero(zotero.org) 무료 / Mendeley(elsevier) 무료 / EndNote(학교 라이센스) / Word/Google Docs 자동 인용.

7. **Fail 후 재수강 학비**
   → Fail = 재수강 학비 $3,000~$5,000/과목 / 졸업 1학기 지연 / 학생비자 만료 시 연장 필요(추가 비용).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. (
2. 1
3. )
4.  
5. T
6. u
7. r
8. n
9. i
10. t
11. i
12. n
13.  
14. S
15. i
16. m
17. i
18. l
19. a
20. r
21. i
22. t
23. y
24.  
25. 몇
26. %
27. ?
28.  
29. (
30. 2
31. )
32.  
33. 학
34. 교
35.  
36. 인
37. 용
38.  
39. 양
40. 식
41. (
42. H
43. a
44. r
45. v
46. a
47. r
48. d
49. /
50. A
51. P
52. A
53. /
54. M
55. L
56. A
57. )
58. ?
59.  
60. (
61. 3
62. )
63.  
64. L
65. e
66. a
67. r
68. n
69. i
70. n
71. g
72.  
73. C
74. e
75. n
76. t
77. r
78. e
79.  
80. 자
81. 문
82.  
83. 받
84. 은
85.  
86. 적
87. ?
88.  
89. (
90. 4
91. )
92.  
93. 첫
94.  
95. 위
96. 반
97.  
98. v
99. s
100.  
101. 재
102. 범
103. ?

---

## 🔍 직원이 직접 확인 가능한 사이트

- Turnitin(turnitin.com), Zotero(zotero.org), Sydney Learning Hub(sydney.edu.au/students/learning-hub), UNSW Learning Centre(student.unsw.edu.au/learning-centre), TEQSA(teqsa.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Plagiarism 종류 / Turnitin Similarity / 학교별 인용 양식 / Learning Centre 무료 / Self-Plagiarism / Citation Software / 청문회 항변

**MARA / 변호사 영역**
- 제명 후 비자 → 이민 변호사 / 학위 박탈 → TEQSA + 변호사 / Misconduct 청문회 외부 → 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] □
- [ ]  
- [ ] T
- [ ] u
- [ ] r
- [ ] n
- [ ] i
- [ ] t
- [ ] i
- [ ] n
- [ ]  
- [ ] S
- [ ] i
- [ ] m
- [ ] i
- [ ] l
- [ ] a
- [ ] r
- [ ] i
- [ ] t
- [ ] y
- [ ]  
- [ ] 보
- [ ] 고
- [ ] 서
- [ ]  
- [ ] 확
- [ ] 인
- [ ]  
- [ ] □
- [ ]  
- [ ] 학
- [ ] 교
- [ ]  
- [ ] 인
- [ ] 용
- [ ]  
- [ ] 양
- [ ] 식
- [ ]  
- [ ] □
- [ ]  
- [ ] L
- [ ] e
- [ ] a
- [ ] r
- [ ] n
- [ ] i
- [ ] n
- [ ] g
- [ ]  
- [ ] C
- [ ] e
- [ ] n
- [ ] t
- [ ] r
- [ ] e
- [ ]  
- [ ] 무
- [ ] 료
- [ ]  
- [ ] □
- [ ]  
- [ ] S
- [ ] e
- [ ] l
- [ ] f
- [ ] -
- [ ] P
- [ ] l
- [ ] a
- [ ] g
- [ ] i
- [ ] a
- [ ] r
- [ ] i
- [ ] s
- [ ] m
- [ ]  
- [ ] 안
- [ ] 내
- [ ]  
- [ ] □
- [ ]  
- [ ] 청
- [ ] 문
- [ ] 회
- [ ]  
- [ ] 항
- [ ] 변
- [ ]  
- [ ] □
- [ ]  
- [ ] C
- [ ] i
- [ ] t
- [ ] a
- [ ] t
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] S
- [ ] o
- [ ] f
- [ ] t
- [ ] w
- [ ] a
- [ ] r
- [ ] e
- [ ]  
- [ ] 추
- [ ] 천
- [ ]  
- [ ] □
- [ ]  
- [ ] F
- [ ] a
- [ ] i
- [ ] l
- [ ]  
- [ ] =
- [ ]  
- [ ] 비
- [ ] 자
- [ ]  
- [ ] 직
- [ ] 접
- [ ]  
- [ ] 영
- [ ] 향
- [ ]  
- [ ] X
- [ ]  
- [ ] 안
- [ ] 내
