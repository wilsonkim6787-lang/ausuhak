# #370 호주_직군_부족_리스트_MLTSSL_STSOL_PR_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 PR 받기 좋은 직업 뭐예요? 컴공 vs 간호 vs 회계 어떤 게 PR 잘 나와요?"

**직원 멘붕 포인트:**
- MLTSSL vs STSOL vs ROL 구분 못함
- 직군별 점수 + 후원 차이
- Skills Assessment (기술 평가) 절차
- PR 비자 (189/190/491) 직군 매칭
- 직군 부족 리스트 변경 위험

---

## ❌ 절대 하지 말아야 할 답

> "컴공이 무조건 1위예요."

→ ❌ MLTSSL 모든 직군 = 189 가능. 컴공 = 인기 (경쟁 고). 간호 = 부족 직군 + 점수 우선. 회계 = MLTSSL 제외 (STSOL). 직군별 시점 + 점수 + 영어 다름.

---

## ✅ 정답

**직군 리스트 3종 (2025)**:

**MLTSSL (Medium and Long-term Strategic Skills List)**:
- 189 (Skilled Independent): 후원 X
- 190 (State Sponsored): 주 후원 5점 가산
- 491 (Regional): 외곽 5점 가산
- 485 (Graduate): 자격
- 일반적: 의료/IT/엔지니어/교사

**STSOL (Short-term Skilled Occupation List)**:
- 190 (주 후원만)
- 491 (외곽 후원만)
- 482 (단기 임시)
- 일반적: 회계/디자인/일부 IT

**ROL (Regional Occupation List)**:
- 491 (외곽만)
- 187 (이미 폐지)

**인기 직군 비교 (2025)**:

**1. 간호사 (RN, ANZSCO 254418)**:
- MLTSSL ✅
- IELTS 7.0 (영역 7.0)
- ANMAC 평가
- 부족 직군 (점수 65점도 가능)
- PR 1년 이내 가능

**2. 컴퓨터 (Software Engineer, ANZSCO 261313)**:
- MLTSSL ✅
- IELTS 6.0 (영역 6.0)
- ACS 평가
- 인기 직군 (점수 90점 이상 일반)
- 경쟁 치열

**3. 회계 (Accountant, ANZSCO 221111)**:
- STSOL (189 X)
- IELTS 7.0 + NAATI/PY
- CPA Australia 평가
- 190 주 후원만
- 점수 95점 이상

**4. 엔지니어 (Civil/Mechanical, ANZSCO 233211/233512)**:
- MLTSSL ✅
- IELTS 6.0 (Engineers Australia)
- EA 평가
- 부족 직군 (점수 70~80점)
- PR 6개월~1년

**5. 교사 (Early Childhood, ANZSCO 241111)**:
- MLTSSL ✅
- IELTS R/W 7.0 + S/L 8.0 (AITSL)
- AITSL 평가
- 유아 교사 부족
- PR 1년 이내

**6. 사회복지사 (Social Worker, ANZSCO 272511)**:
- MLTSSL ✅
- IELTS 7.0
- AASW 평가
- 부족 직군

**Skills Assessment 비용**:
- ANMAC: $1,455 (간호)
- ACS: $530 (IT)
- CPA: $560 (회계)
- EA: $760 (엔지니어)
- AITSL: $735 (교사)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ANZSCO Code**
Australian and New Zealand Standard Classification of Occupations. 6자리 직군 코드. PR 신청 필수.

**2. MLTSSL vs STSOL**
MLTSSL = 장기 부족 + 189 가능. STSOL = 단기 부족 + 190/491만. 분류 = DHA 6개월 단위 갱신.

**3. Skills Assessment**
직군 평가 기관 = 학력 + 경력 평가. ACS/EA/CPA/ANMAC/AITSL. 비자 신청 전 의무.

**4. 485 Graduate Visa**
MLTSSL 직군 졸업생 자격. 2~6년 (2025 단축). PR 점수 5점 (485 + 호주 졸업).

**5. Pro Rata 직군**
Software Engineer/회계사 = 매년 비자 한도 = 점수 90~95점 의무 (실질). 직군 인기 = 컷오프 점수 상승.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 직군 결정: MLTSSL 우선 (189 가능)
**2단계**: 학교 + 학위 결정: 직군 매칭 학과
**3단계**: 영어 점수: 직군별 IELTS 의무
**4단계**: Skills Assessment: 졸업 후 (485 신청 전)
**5단계**: EOI 제출: 65점+ → Invitation

---

## 💡 직원이 학생한테 말할 멘트

> "MLTSSL 직군 = 189 (후원 X) 가능해요. 인기 순위는 ① 간호사 (RN) - 부족 직군 + 65점 가능 ② 엔지니어 - 70~80점 ③ 교사 (유아) - 65점 ④ 컴공 - 90점+ 경쟁 치열 ⑤ 회계 - STSOL 95점+ 입니다. 본인 학력/영어/관심 + 시장 경쟁률 분석 후 결정해야 해서 정확한 시뮬레이션은 윌슨 1:1 상담 필요해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **컴공 1위 무조건**
   → 경쟁 치열 90점+. 부족 직군 X.

2. **회계 = 189 가능**
   → STSOL = 189 X. 190 주 후원만.

3. **간호 = 누구나 가능**
   → IELTS 7.0 (영역 7.0) + ANMAC 인증.

4. **Skills Assessment 자동**
   → 직군별 별도 신청 + 비용.

5. **MLTSSL 직군 영구 보장**
   → DHA 6개월 단위 갱신. 변경 위험.

6. **교사 = 영어 7.0**
   → 유아 교사 = R/W 7.0 + S/L 8.0 (AITSL).

7. **PR 점수 65점 자동 합격**
   → 최소 65점. Pro Rata 직군 = 90~95점 컷오프.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 학력 (학사/석사) + 전공
2. 영어 수준 (IELTS 5.5/6.0/7.0)
3. PR 우선 vs 직업 흥미
4. 외곽 거주 가능 여부 (491 가산점)

---

## 🔍 직원이 직접 확인 가능한 사이트

- MLTSSL: immi.homeaffairs.gov.au/visas/working-in-australia/skill-occupation-list
- ANZSCO: abs.gov.au/statistics/classifications/anzsco
- Skills Assessment Authority: immi.homeaffairs.gov.au/visas/working-in-australia/skills-assessment
- SkillSelect: immi.homeaffairs.gov.au/skillselect
- PR Points: immi.homeaffairs.gov.au/visas/working-in-australia/skillselect/points-table

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 직군 매칭 + 학교 추천
- 영어 의무 + 점수 시뮬레이션
- Skills Assessment 절차 안내

**MARA / 변호사 영역**
- PR 신청 (MARA 등록 변호사)
- 직군 평가 분쟁 시 항소
- Pro Rata 컷오프 변경 모니터링

---

## ✅ 완벽 응대 체크리스트

- [ ] MLTSSL/STSOL/ROL 정확 안내
- [ ] 직군별 IELTS 정확 명시
- [ ] Skills Assessment 비용 안내
- [ ] Pro Rata 직군 90~95점 경고
- [ ] 회계 STSOL 189 X 정확 안내
- [ ] 간호 7.0 (영역 7.0) 강조
- [ ] 윌슨 1:1 상담 자연 유도
