# #428 호주_학생_우편물_분실_Australia_Post_분쟁_Parcel_Locker

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국에서 부모님이 보낸 EMS 소포가 호주 도착 후 사라졌어요. Australia Post 트래킹은 'Delivered' 인데 셰어하우스 우편함에 없어요. 한국 부모님이 화내시는데 어떻게 보상받나요? 비자 서류도 같이 들어있어서 큰일이에요."

**직원 멘붕 포인트:**
- Australia Post 분쟁 절차
- EMS 한국 보상 vs 호주 보상
- 비자 서류 분실 시 재발급
- Parcel Locker 24/7 안전
- 셰어하우스 우편함 도난

---

## ❌ 절대 하지 말아야 할 답

> "우편 분실은 어쩔 수 없어요"

→ ❌ ❌ Australia Post 보상 가능 (Compensation up to $100 무료 + 등기 추가). 한국 EMS도 보상.

---

## ✅ 정답

분쟁 절차: ① auspost.com.au/help 'Lodge a complaint' 온라인 신청 (트래킹 번호 + 사진), ② Australia Post 일반 우편 보상 $100까지 자동, ③ EMS = 한국 우체국 보상 (한국 발송지에서 신고), ④ Parcel Locker (무료) 또는 PO Box 사용 권장 (셰어 우편함 X), ⑤ 비자 서류 분실 시 ImmiAccount 재발급 가능 (디지털), ⑥ 한국 가족관계증명서 = efamily.scourt.go.kr 영문 무료 재발급, ⑦ 여권 분실 = 영사관 긴급 여권 (시드니 02 9210 0234), ⑧ 보험 가입 시 Travel Insurance 또는 Contents Insurance 청구.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Aus Post Compensation**
$100 자동 / 등기 $200~$5,000

**2. EMS 보상**
한국 우체국 / 한국 발송지 신고

**3. Parcel Locker**
auspost.com.au/parcellocker 무료

**4. ImmiAccount**
디지털 비자 / 분실 무관

**5. 긴급 여권**
영사관 / 1-3일 / KRW 53,000

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: Aus Post 트래킹 + 'Delivered' 시간 확인
**2단계**: 2단계: auspost.com.au Lodge complaint 신청
**3단계**: 3단계: 한국 부모님께 EMS 보상 신청 안내
**4단계**: 4단계: 비자 서류는 ImmiAccount 재발급
**5단계**: 5단계: 향후 Parcel Locker 사용 권장

---

## 💡 직원이 학생한테 말할 멘트

> "Australia Post Compensation 신청하세요 (auspost.com.au). EMS는 한국 우체국 보상이라 부모님이 한국에서 신고해야 합니다. 비자 서류는 ImmiAccount에서 재출력 가능합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **EMS 호주 우체국 보상**
   → 한국 우체국 영역

2. **우편물 분실 보상 X**
   → $100까지 자동

3. **셰어 우편함 안전**
   → 공유 = 도난 다발

4. **비자 서류 재발급 불가**
   → ImmiAccount 디지털 가능

5. **여권 분실 새 비자 신청**
   → 긴급 여권 + 비자 자동 연동

6. **Aus Post 콜센터만 신고**
   → 온라인 Complaint 빠름

7. **Parcel Locker 유료**
   → 무료

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 트래킹 번호 / 발송 일자
2. 분실 우편물 내용물 (서류/금전)
3. 셰어 우편함 vs 직접 배송
4. 보험 가입 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Aus Post Help', 'auspost.com.au/help')
- ('Parcel Locker', 'auspost.com.au/parcellocker')
- ('ImmiAccount', 'immi.homeaffairs.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 분실 신고 절차, 비자 서류 재발급 안내

**MARA / 변호사 영역**
- 비자 서류 원본 분실 시 변호사 (대부분 디지털)

---

## ✅ 완벽 응대 체크리스트

- [ ] Compensation $100 안내함
- [ ] EMS 한국 우체국 안내함
- [ ] Parcel Locker 권장함
- [ ] ImmiAccount 재발급 안내함
- [ ] 긴급 여권 영사관 안내함
- [ ] 셰어 우편함 위험 강조함
