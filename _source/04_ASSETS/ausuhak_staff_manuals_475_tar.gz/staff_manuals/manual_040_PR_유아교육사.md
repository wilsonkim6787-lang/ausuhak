# 📚 직원 응대 매뉴얼 #040

**케이스: 유아교육사 (Childcare / Early Childhood Educator) 직군**

---

## 🎬 상황 시뮬레이션

> 호주에서 어린이집 선생님으로 영주권 받는 거 어떻게 진행되나요?

**👉 정답**: **Diploma of Early Childhood Education + ACECQA Skills Assessment + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Childcare 직군 = 호주 MLTSSL 직업군

| 직업 | ANZSCO | PR 리스트 | 자격 |
|---|---|---|---|
| Early Childhood Teacher | 241111 | MLTSSL | 학사 + 등록 |
| Child Care Worker | 421111 | STSOL | Cert III 가능 |
| Child Care Centre Manager | 134111 | STSOL | Diploma + 경력 |

**241111 Early Childhood Teacher = 가장 강력** (학사 必)

### 2️⃣ Childcare 표준 경로

```
ELICOS (필요시)
        ↓
Diploma of Early Childhood Education and Care (1.5년) - $25K~$32K
        ↓
졸업 + 485 (Regional 지역 학업 시 Second PHEW Extension +1/+2년 가능)
        ↓
ACECQA Skills Assessment
        ↓
PR (491/190 가산점 + 직업 코드)
```

**EC Teacher 241111** 노리면 **Bachelor of Early Childhood (3년)** 必

### 3️⃣ 학교 추천

| 학교 | 코스 | 학비 | 위치 |
|---|---|---|---|
| TAFE NSW | Diploma EC | $25K~$30K (1.5년) | Sydney |
| TAFE QLD | Diploma EC | $22K~$28K (1.5년) | Brisbane |
| TAFE SA | Diploma EC | $20K~$26K (1.5년) | Adelaide |
| Macquarie University | Bachelor EC | $36K~$42K/년 | Sydney |
| ACU | Bachelor EC | $28K~$32K/년 | Sydney/Brisbane/Melbourne |

### 4️⃣ ACECQA = Childcare 직업 평가

- **ACECQA**: Australian Children's Education and Care Quality Authority
- Diploma + 호주 경력 평가
- 한국 유아교육 경력 일부 인정

### 5️⃣ Childcare 영어 + 면허

- **IELTS 6.5+ (각 영역 6.0)** = Diploma 입학
- **IELTS 7.5 (R/W) + 8.0 (S/L)** = EC Teacher 등록 (학사 졸업자)
- Working with Children Check (정부 신원조회) 必須

---

## 🎯 정답 경로 (2가지 케이스)

### 케이스 1. Diploma + Childcare Worker (Cert III/Diploma)

```
ELICOS → Diploma EC (1.5년)
        ↓ + 485
ACECQA + 호주 경력 1-2년 + EOI → 491/190 PR
```

**총 3-4년 / 학비 약 $25K~$32K**

### 케이스 2. Bachelor + Early Childhood Teacher (학사)

```
ELICOS → Bachelor EC (3년) - $84K~$126K
        ↓ + 485
EC Teacher 등록 + IELTS 7.5/8.0 + PR (241111)
```

**총 4-5년 / 학비 약 $84K~$126K**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 유아교육 영주권, 두 가지 경로가 있습니다.
> 
> **옵션 A. Diploma + Child Care Worker**
> - 1.5년 / $25K~$32K
> - PR 직업 421111 (STSOL = 491 가능)
> - 빠른 졸업 + 일
> 
> **옵션 B. Bachelor + Early Childhood Teacher**
> - 3년 / $84K~$126K
> - PR 직업 241111 (MLTSSL = 189 가능)
> - 영주권 강력 + 연봉 高
> 
> 영어 조건 다름:
> - Diploma = IELTS 6.5
> - EC Teacher 등록 = IELTS 7.5/8.0 (꽤 까다로움)
> 
> Regional 지역 (Adelaide/Perth/Hobart 등)은 491 +15점 + Australian Study +5점 추가 적용 (Brisbane CBD는 Non-regional).
> 
> 카톡으로 알려주세요:
> ① 영어 수준  
> ② Diploma vs Bachelor 선호  
> ③ 한국 유아교육 경력 (있으면 ACECQA에 일부 인정)  
> ④ 도시 우선"

---

## ⚠️ 함정

1. **"Cert III만으로 PR"** → ❌ Diploma 또는 Bachelor 必
2. **"한국 유아교육 자격 = 자동 인정"** → ACECQA 평가 必
3. **"EC Teacher 영어 = IELTS 7.0"** → ❌ 7.5 (R/W) + 8.0 (S/L)
4. **"Working with Children Check 안 봐도 됨"** → 必須

---

## 📞 카카오 응대 시 필수

1. 영어 수준
2. Diploma vs Bachelor
3. 한국 경력
4. 도시 우선

---

## 🔍 직원 확인 사이트

- ACECQA: acecqa.gov.au
- TAFE NSW Diploma EC: tafensw.edu.au
- Working with Children Check: 각 주 사이트
