# #380 호주_학생_자기소개서_SOP_Statement_of_Purpose_작성

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 대학원 지원하는데 SOP(자기소개서) 어떻게 써야 돼요? 한국식이랑 달라요?"

**직원 멘붕 포인트:**
- SOP = 학교 입학 + 비자 GTE 둘 다 활용
- 한국식 (가족사 위주) vs 호주식 (학업 + 진로)
- 단어수 500~1,000 단어 표준
- GTE Statement (Genuine Temporary Entrant) 별개
- AI 작성 검출 (TurnItIn)

---

## ❌ 절대 하지 말아야 할 답

> "자기소개서는 어릴 적 가족 이야기부터 쓰면 돼요."

→ ❌ 한국식 SOP. 호주 대학은 학업 동기 + 진로 + 학교 선택 사유 + 호주 선택 사유에 집중. 가족사 = 1~2문장만. 한국식 SOP는 호주에서 미숙(Childish)하게 평가.

---

## ✅ 정답

**호주 대학원 SOP 작성 가이드** (2026):

**SOP 표준 구조 (5문단, 800단어)**:

**1) Introduction (100단어)**:
- 본인 학문적 배경 (학사 전공)
- 직업/연구 경험 요약
- 지원 프로그램 명시 (Master of XXX at YYY University)

**2) Academic Background (200단어)**:
- 학사 GPA + 핵심 과목 + 우수 성적
- 졸업 논문/프로젝트 (있는 경우)
- 관련 자격증 (CPA, Engineers Korea 등)
- 한국 대학 = "Korea University, Seoul, ranked 200th globally" 등 객관적 설명

**3) Professional Experience (200단어)**:
- 직업 경력 (있는 경우)
- 인턴십/봉사
- 학생회/프로젝트 리더십
- 구체적 업적 (수치 포함: "팀 5명 리드, 프로젝트 3개월 완수")

**4) Why This Course/University/Australia (200단어)**:
- 학교 선택 사유 (구체적 교수/연구실/커리큘럼 언급)
- 호주 선택 사유 (영어권 + 학문 평판 + 다문화)
- 한국에서 X 안 가능 + 호주에서 가능한 점 강조
- "I selected UTS because Professor Smith's research on AI Ethics aligns with my career goal..." 식

**5) Career Goal + Return Plan (100단어)**:
- 졸업 후 5년 계획
- 한국 귀국 의사 명확 (GTE 핵심)
- "Upon completion, I plan to return to Korea and join Samsung as a Data Scientist" 식
- PR 의사 표현 X (GTE 위반)

**한국식 vs 호주식 차이**:
| 항목 | 한국식 | 호주식 |
|---|---|---|
| 도입 | 가족사 + 어린 시절 | 학문 배경 + 지원 동기 |
| 톤 | 감성적 | 분석적 |
| 길이 | 짧음 (300단어) | 길음 (800단어) |
| 가족 | 부모 영향 강조 | 1~2문장만 |
| 진로 | 추상적 | 구체적 + 수치 |
| 호주 | 환상 표현 | 분석적 + 객관적 |

**GTE Statement** (비자용 별개):
- 학교 SOP와 별개로 비자 신청 시 제출
- "Why temporary stay (not permanent)?" 답변
- 한국 귀국 의사 명확
- 한국 가족/직업/자산 입증
- PR 표현 절대 X

**AI 작성 주의 (ChatGPT 검출)**:
- TurnItIn AI Detection 90%+ 검출
- 학교 SOP 거짓 작성 = 입학 취소
- 한국어로 초안 → 본인 영문 번역 → 원어민 교정 권장

**좋은 SOP 5가지 특징**:
1. Specific (구체적 수치/이름)
2. Concise (간결, 800단어 내)
3. Authentic (본인 목소리)
4. Aligned (학교/코스와 정합성)
5. Future-oriented (졸업 후 계획 명확)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. UTS SOP Guide**
uts.edu.au/study/applying

**2. Monash SOP Sample**
monash.edu/study

**3. USyd Personal Statement**
sydney.edu.au

**4. GTE Genuine Temporary Entrant**
homeaffairs.gov.au - GTE 가이드

**5. TurnItIn AI Detector**
turnitin.com - 표절 + AI 검출

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 학교/코스 결정 (구체적 교수/커리큘럼 조사)
**2단계**: 2. SOP 한국어 초안 작성 (5문단 800단어)
**3단계**: 3. 본인 영문 번역 (Google 번역 X)
**4단계**: 4. 원어민 교정 (학교 Writing Center 무료, $200~$500 유료)
**5단계**: 5. GTE Statement 별개 작성 (비자 신청 시)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주 대학원 SOP(자기소개서) 답변드립니다.

호주 SOP는 한국식과 많이 다릅니다. 가족사/어린 시절은 1~2문장만 쓰고, 학업 배경 + 직업 경험 + 학교 선택 사유 + 진로 계획에 집중합니다. 단어수는 800단어가 표준입니다.

5문단 구조: ① Introduction(100단어, 본인 + 지원 프로그램), ② Academic Background(200단어, GPA + 졸업 논문), ③ Professional Experience(200단어, 경력 + 수치), ④ Why this Course/Uni/Australia(200단어, 구체적 교수/연구실 언급), ⑤ Career Goal(100단어, 한국 귀국 의사 명확).

비자 신청 시는 GTE Statement(Genuine Temporary Entrant)를 별개로 작성합니다. "왜 영주가 아닌 임시 체류인가?"에 답하는 글입니다. 학교 SOP에 PR 의사 표현은 절대 금물입니다.

ChatGPT로 작성하면 TurnItIn AI Detection으로 90% 검출됩니다. 한국어 초안 → 본인 영문 번역 → 원어민 교정 순서가 안전합니다. 학교 Writing Center가 무료 교정 지원하고, 외부 교정은 $200~$500입니다.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **가족사 위주 한국식 권유**
   → 호주 미숙 평가. 학업 + 진로 위주.

2. **ChatGPT 작성 권유**
   → TurnItIn 90% 검출. 입학 취소.

3. **PR 의사 표현 권유**
   → GTE 위반. 비자 거절.

4. **Google 번역 권유**
   → 어색 영어 + 검출. 본인 작성 + 교정.

5. **학교 SOP = GTE 동일 인식**
   → 별개 문서. GTE는 비자용.

6. **길이 무시**
   → 300단어 너무 짧음, 1,500단어 너무 길음. 800단어 표준.

7. **학교/교수 언급 X**
   → 구체적 언급 = 진정성 입증.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 지원 학교/코스 결정?
2. 학사 GPA 3.0/4.0 이상?
3. 직업 경력 있음?
4. 원어민 교정 예산 있음?

---

## 🔍 직원이 직접 확인 가능한 사이트

- 각 학교 International Admissions
- homeaffairs.gov.au (GTE)
- turnitin.com (AI 검출)
- Cambridge Writing Center (교정)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- SOP 구조 가이드 + 학교/코스 매칭 + GTE 별개 안내

**MARA / 변호사 영역**
- SOP 거짓 + 비자 거절 = MARA Agent (PIC 4020).

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국식 vs 호주식 차이 강조
- [ ] 5문단 800단어 구조
- [ ] GTE Statement 별개
- [ ] PR 의사 표현 금지
- [ ] AI 검출 경고
- [ ] 카카오 상담 신청 유도
