# #243 호주 집주인 분쟁 (Bond / 수리 / 퇴거)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 임대 종료했는데 집주인이 Bond 안 돌려줘요. 청소 다 했는데 카펫 손상 핑계 대요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Bond는 정부 보관 (집주인 보관 X)
- Bond 환급 = NSW 14일 / VIC 10영업일 내 합의
- 분쟁 = NCAT (NSW) / VCAT (VIC)

---

## ❌ 절대 하지 말아야 할 답

> "집주인이 안 주면 못 받아요. 그냥 잊으세요."

→ ❌ **Bond는 정부 보관**. 집주인 일방 청구 X. NCAT 항소 가능.

---

## ✅ 정답

호주 집주인 분쟁 (Bond): ① **Bond 정부 보관** (NSW Rental Bond Board / VIC RTBA / Property Manager 임의 사용 X) ② **환급 절차**: 임대 종료 시 양쪽 합의 → 정부 환급 (NSW 14일 / VIC 10영업일 내) ③ **분쟁 시**: 양쪽 합의 X → 정부가 보관 → NCAT/VCAT 결정 ④ **본인 권리 증거**: 입주 시 Condition Report (전 상태 사진) / 출주 시 Final Inspection 사진 ⑤ **수리 의무 (집주인)**: 누수 / 보일러 / 위험 즉시 / 일반 14일 ⑥ **부당 퇴거 (Eviction)**: 60~90일 통보 의무 (Periodic) / Fixed-term = 종료일까지. ⑦ **윌슨 영역 X** (Tenants' Union / NCAT 영역).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Bond 정부 보관**
- 집주인 / Property Manager 임의 사용 X
- NSW Rental Bond Board / VIC RTBA / QLD RTA
- 임대 종료 시 양쪽 합의 → 정부 환급

**2. Condition Report (입주 / 출주)**
- 입주 시 = Property Manager 작성 → 본인 검토 / 사진 추가
- 출주 시 = Final Inspection (Property Manager 동행 권장)
- 입주 시 사진 = Bond 분쟁 결정적 증거

**3. Wear and Tear (자연 마모)**
- 카펫 자연 마모 / 페인트 변색 / 호스 파손 = 집주인 책임
- 본인 손상 (낙서 / 구멍 / 곰팡이) = 본인 책임
- 청소 미흡 = Bond 차감 정당

**4. 수리 의무 (집주인)**
- **즉시 (Urgent)**: 누수 / 보일러 / 가스 / 화장실 막힘 / 위험
- **일반 (Non-urgent)**: 14일 내 (NSW) / 합리적 시간 (VIC)
- 본인 수리 후 청구 가능 (조건 있음)

**5. 부당 퇴거 (Eviction)**
- **Fixed-term (12개월)**: 종료일까지 보호 (집주인 임의 퇴거 X)
- **Periodic (Month-to-Month)**: 60~90일 통보 (No-cause Eviction NSW = 90일)
- **No Grounds Eviction 폐지** (NSW 2025 / VIC 일부)
- 부당 퇴거 = NCAT 항소

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 입주 시 Condition Report / 사진 확인
**2단계**: 출주 시 Final Inspection / 사진
**3단계**: Bond 환급 신청 (Online / 정부 사이트)
**4단계**: 집주인 거부 시 → 협상
**5단계**: NSW Tenants' Union 무료 상담
**6단계**: NCAT 신청 ($55) → 결정

---

## 💡 직원이 학생한테 말할 멘트

> "윌슨님께 이렇게 전달드릴게요:
> 
> 'Bond는 정부 보관 (NSW Rental Bond Board) 라서 집주인이 임의로 보관 / 사용 X예요. 환급은 임대 종료 시 양쪽 합의 → 정부 환급이에요. 입주 시 Condition Report (사진) + 출주 시 Final Inspection 사진이 결정적 증거예요. 카펫 자연 마모 / 페인트 변색 = 집주인 책임 (Wear and Tear)이에요. 분쟁 시 NSW Tenants\' Union 무료 상담 → NCAT 신청 ($55)으로 항소 가능해요. 입주 시 사진 / 출주 시 사진 / 청소 영수증 모두 보관하세요. 윌슨 영역이 아니에요. Tenants\' Union 영역이에요.'"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7개

1. **Bond 집주인 보관**: ❌ 정부 보관
2. **집주인 일방 차감**: ❌ 양쪽 합의 / NCAT 결정
3. **카펫 마모 = 본인 책임**: ❌ Wear and Tear (집주인 책임)
4. **청소 영수증 X**: ⚠️ 영수증 = 증거
5. **Periodic = 자유 퇴거**: ❌ 60~90일 통보 의무
6. **NCAT = 변호사 의무**: ❌ 본인 가능
7. **윌슨 처리**: ❌ Tenants' Union / NCAT 영역

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **분쟁 종류**: Bond / 수리 / 퇴거 / 임대료 인상
2. **계약 형태**: Fixed-term / Periodic
3. **증거 보유**: 사진 / 영수증 / 메시지
4. **임대 종료 시점**: 환급 신청 가능 시기

---

## 🔍 직원이 직접 확인 가능한 사이트

- **NSW Rental Bond Board**: https://www.rental.fairtrading.nsw.gov.au
- **VIC RTBA**: https://rentalbonds.vic.gov.au
- **NSW Tenants' Union**: https://www.tenants.org.au
- **NCAT (NSW)**: https://www.ncat.nsw.gov.au
- **VCAT (VIC)**: https://www.vcat.vic.gov.au
- **NSW Fair Trading**: https://www.fairtrading.nsw.gov.au

---

## 🚨 직원 영역 vs Tenants' Union / NCAT 영역

| 영역 | 직원 가능 | 외부 영역 |
|------|----------|--------|
| Bond 정부 보관 안내 | ✅ | - |
| Condition Report 중요성 안내 | ✅ | - |
| Wear and Tear 개념 안내 | ✅ | - |
| Bond 분쟁 처리 | ❌ | ✅ Tenants' Union |
| NCAT 신청 | ❌ | ✅ 본인 또는 Tenants' Union |
| 부당 퇴거 항소 | ❌ | ✅ NCAT |

---

## ✅ 완벽 응대 체크리스트

- [ ] Bond 정부 보관 명확화
- [ ] Condition Report (입주 사진) 강조
- [ ] Wear and Tear (자연 마모) 개념 안내
- [ ] Tenants' Union 무료 상담 안내
- [ ] NCAT $55 안내
- [ ] 사진 / 영수증 보관 강조
- [ ] 윌슨 = 유학 / Tenants' Union 영역 분리
