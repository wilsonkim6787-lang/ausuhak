# #291 호주_PhD_박사과정_장학금

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 한국 석사 졸업했어요. 호주 PhD 가고 싶은데 장학금 받을 수 있나요? PR도?"

**직원 멘붕 포인트:**
- PhD = 3~4년 + Research Proposal 필수
- RTP (Research Training Program) 장학금
- 한국어 가능 지도교수 매칭 어려움
- PhD 졸업 = 485 4년 (Master 2년보다 길다)
- Research vs Coursework PhD 구분

---

## ❌ 절대 하지 말아야 할 답

> ""PhD 무조건 장학금""

→ ❌ RTP 장학금 경쟁률 매우 높음 (10~20%). 단정 X.

---

## ✅ 정답

"호주 PhD는 Research 중심 3~4년이며 RTP (Research Training Program) 장학금 신청 가능합니다 (학비 면제 + 생활비 $35,000/년). 단, 경쟁률 매우 높고 (10~20%) Research Proposal + 지도교수 매칭 + 영어 IELTS 6.5+ 필요합니다. 졸업 후 485 (PhD = 4년) → PR 경로입니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. PhD 종류**
Research PhD = Thesis 위주 3~4년. 학과 무관. RTP 장학금 신청 가능. Coursework PhD (Doctorate) = 수업 + 논문. Education/Psychology 등 일부. 학비 자비. 한국 학생 = Research PhD 일반.

**2. RTP (Research Training Program) 장학금**
호주 정부 장학금. 학비 면제 + 생활비 $35,452/년 (2025) + OSHC 일부. 경쟁률 10~20%. International Student 대상 RTPI/RTP Stipend. Top 8 (Group of Eight) = Sydney/Melbourne/UNSW/Monash/ANU/UQ/UWA/Adelaide 거의 모두 RTP 운영.

**3. PhD 입학 조건**
한국 석사 졸업 (학점 3.5/4.0+ 우대). Research Proposal 5~10페이지. 지도교수 (Supervisor) 사전 매칭 필수 (이메일 컨택). IELTS 6.5 (각 영역 6.0+). 학과별 차이 (Engineering = 6.5 / Education = 7.0).

**4. 지도교수 매칭**
PhD 입학 = 지도교수 동의 우선. 호주 교수 이메일 컨택 (Cold Email) → CV + Research Proposal → 미팅 → Letter of Acceptance. 한국 학과 추천서 도움. 19년 경력 = 한국 학생 PhD 매칭 도움 가능.

**5. PhD 졸업 후 PR**
485 비자 = PhD 졸업자 4년 (Master 2년보다 길다). 박사 후 연구원 (Postdoctoral Researcher) 취업 → 482 SID 비자 (CSOL 직군) → 186/189. Research 직업 = MLTSSL (189/485용) + CSOL (482용 대부분 등재). 학자 (University Lecturer) = MLTSSL/STSOL → 190 (State Sponsored).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 석사 졸업 + 학점 3.5+ 입증
**2단계**: Research Proposal 작성 (5~10페이지) + 영문
**3단계**: 호주 지도교수 Cold Email + CV 첨부 → 매칭
**4단계**: RTP 장학금 신청 (학교별 마감 8월/3월)
**5단계**: 합격 시 학생비자 + PhD 3~4년 + 485 4년

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 한국 석사 졸업이면 호주 PhD 가능해요. RTP (Research Training Program) 장학금 = 학비 면제 + 생활비 $35,000/년이지만 경쟁률 10~20%로 매우 높아요. 핵심은 호주 지도교수 매칭이에요. Research Proposal 5~10페이지 영문 작성하고 호주 교수한테 직접 이메일 보내야 해요. Wilson이 한국 학과 + Research 분야 보고 매칭 도움드릴게요. 한국 석사 분야 + 학점 + 영어 점수 알려주세요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"PhD 무조건 장학금"**
   → RTP 경쟁률 10~20%. 자비 가능.

2. **"지도교수 매칭 학교가 함"**
   → 학생 본인 Cold Email 필수.

3. **"한국 학사 = PhD 가능"**
   → 한국 석사 졸업 의무. 학사만 = Master 1~2년 추가.

4. **"PhD = 4년 무조건"**
   → Research = 3~4년. Part-time = 6년.

5. **"485 = 2년"**
   → PhD = 4년 (Master 2년).

6. **"한국에서 Research Proposal 작성"**
   → 한국 교수 도움 + 영문 번역 + 호주 교수 검토.

7. **"Wilson이 PhD 신청 다 함"**
   → 윌슨 영역 = 매칭 + 비자. 학술 = 학생 본인.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 석사 졸업 + 학점 (3.5+)
2. Research 분야 (Engineering/Science/Education 등)
3. 영어 IELTS (6.5+)
4. 예산 (장학금 못 받을 시 자비 가능)

---

## 🔍 직원이 직접 확인 가능한 사이트

- RTP (Research Training Program): 호주 정부
- Group of Eight: https://go8.edu.au
- 각 대학 PhD 사이트
- 한국어 지도교수 검색 (LinkedIn)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 지도교수 매칭 도움
- Research Proposal 영문 검토
- 비자 신청 대행
- RTP 장학금 신청 가이드
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- 각 대학 = PhD 입학 평가
- RTP = 호주 정부 장학금
- MARA Lawyer = 졸업 후 PR (485 → 189/190)
- Postdoc = 직접 구직 (학과별)
- 한국 석사 학점 = 학과 평가

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 석사 졸업 확인했다
- [ ] Research 분야 확인했다
- [ ] 영어 IELTS 확인했다
- [ ] 지도교수 매칭 도움 안내했다
- [ ] Research Proposal 작성 안내했다
- [ ] RTP 장학금 안내 (경쟁률 정직)
- [ ] PhD 졸업 = 485 4년 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
