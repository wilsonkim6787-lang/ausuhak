# 📚 직원 응대 매뉴얼 #039

**케이스: 요리사(Chef) 직군 / PR 매칭 가이드**

---

## 🎬 상황 시뮬레이션

> 호주 요리사로 영주권 받는 거 어떻게 진행되나요? 한국 요리 경력 있는 분도 있고 처음부터 시작하는 분도 있어요.

**👉 정답**: **Cert III + Cert IV + Diploma + TRA Skills Assessment + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Chef = 호주 MLTSSL 직업군 (MLTSSL)

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Chef | 351311 | MLTSSL |
| Cook (Cook) | 351411 | STSOL |
| Pastry Cook | 351112 | MLTSSL |
| Baker | 351111 | STSOL |

**Chef 351311**은 매우 강력 = MLTSSL = 189 PR 가능

### 2️⃣ Chef PR 표준 경로

```
ELICOS (필요시 6~12개월)
        ↓
Cert III in Commercial Cookery (1-1.5년)
        ↓
Cert IV in Commercial Cookery (6개월)
        ↓
Diploma of Hospitality Management (1년) - PR 위해 必須
        ↓
TRA Skills Assessment (CSF + Workplace assessment)
        ↓
485 또는 491 → PR
```

**핵심**: Cert III + IV + Diploma 3단계 모두 필요. Cert III만으로는 PR X.

### 3️⃣ TRA (Trades Recognition Australia) Skills Assessment

- **TRA**: Trade 직업 평가 기관
- Chef 평가:
  - **CSF Job Ready Program** (한국 경력자) = 한국 + 호주 일 경험 + 평가
  - 호주 학교 졸업 + 호주 일 경험 = Direct Path
- 영어 IELTS 6.0 (각 영역 5.0)

### 4️⃣ Chef 학교 추천

| 학교 | 위치 | 학비 (3코스 총) |
|---|---|---|
| TAFE NSW | Sydney | $40K~$48K |
| TAFE QLD | Brisbane | $36K~$44K |
| TAFE SA | Adelaide | $34K~$40K |
| William Angliss Institute | Melbourne (TAFE) | $40K~$46K |
| Le Cordon Bleu | Sydney/Adelaide | $60K~$80K (Master 코스) |
| Imagine Education | Gold Coast | $30K~$36K |

### 5️⃣ 한국 요리사 경력자 = CSF Job Ready Program

- 한국 요리 경력 4년 + 자격증 = TRA에 경력 등록
- 호주 식당 1년 일 + Skills Assessment
- 시간 단축 가능

---

## 🎯 정답 경로 (3가지 케이스)

### 케이스 1. 한국 요리 경력 X (처음부터)

```
ELICOS (필요시) → Cert III + IV + Diploma (3년) → 485 → PR
```

**총 3-5년 / 학비 약 $40K~$48K**

### 케이스 2. 한국 요리 경력 4년+ (CSF)

```
TRA에 경력 등록 → 호주 식당 1년 + 평가 → PR
```

**총 1-2년 / 비용 적음**

### 케이스 3. Pastry (제과제빵)

```
ELICOS → Cert III in Patisserie + Diploma → TRA → PR
```

**총 2-3년 / 학비 약 $25K~$35K**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 Chef 영주권은 매우 강력한 경로입니다. 케이스에 따라:
> 
> 1. **요리 처음**: Cert III + IV + Diploma 3년 = $40K~$48K → PR
> 2. **한국 요리 경력 4년+**: CSF Job Ready 단축 가능 = $5K~$10K
> 3. **제빵**: Cert III in Patisserie + Diploma = $25K~$35K
> 
> 학교 추천:
> - TAFE NSW (Sydney) / TAFE QLD (Brisbane CBD = Non-regional, 외곽 Regional) / William Angliss (Melbourne)
> - Le Cordon Bleu (학비 高)
> 
> Regional 지역 학업·거주 시 491 +15점 + Australian Study +5점 적용입니다.
> 
> 카톡으로 알려주세요:
> ① 한국 요리 경력 (자격증 / 식당 경력)  
> ② Chef vs Pastry  
> ③ 도시 우선  
> ④ 영어 수준"

---

## ⚠️ 함정

1. **"Cert III만으로 PR"** → ❌ Cert IV + Diploma 必
2. **"한국 요리 학원 자격증 = TRA 인정"** → 별도 평가
3. **"Cook 351411로도 PR"** → STSOL = 189 X / 491 가능
4. **"Le Cordon Bleu만 인정"** → ❌ TAFE도 OK / 학비 합리적

---

## 📞 카카오 응대 시 필수

1. 한국 요리 경력
2. Chef vs Pastry
3. 도시 + 학교 우선
4. 영어 수준

---

## 🔍 직원 확인 사이트

- TRA: tradesrecognitionaustralia.gov.au
- TAFE NSW Cookery: tafensw.edu.au
- William Angliss: angliss.edu.au
- Le Cordon Bleu Australia: cordonbleu.edu/australia
