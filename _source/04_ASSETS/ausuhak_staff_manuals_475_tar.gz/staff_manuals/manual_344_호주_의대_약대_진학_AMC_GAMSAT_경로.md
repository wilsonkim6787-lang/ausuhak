# #344 호주_의대_약대_진학_AMC_GAMSAT_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 한국에서 학사 졸업했고 호주 의대(MD) 가고 싶어요. GAMSAT 봐야 하나요? 한국 의사면허 호주에서 인정되나요?"

**직원 멘붕 포인트:**
- 한국 의대 호주 자동 인정?
- GAMSAT vs MCAT?
- AMC 시험?
- 비용 + 기간?

---

## ❌ 절대 하지 말아야 할 답

> "한국 의대 졸업하면 호주에서 바로 의사 가능해요."

→ ❌ AMC 시험 + 임상 평가 + 영어 IELTS 7.0 + 면허 등록 절차 모름. 학생 잘못 기대.

---

## ✅ 정답

**호주 의대(MD) = ① Graduate Entry MD(학사 후 4년) ② Undergraduate MD(고졸 후 6년) 두 종류. 한국 의대 호주 자동 인정 X (AMC 시험 필수).**

**핵심 사실:**
- **Graduate Entry MD**: 학사 평균 75%+ + GAMSAT 60+ + 면접 + IELTS 7.0(각 7.0). 4년. 학비 $80,000~$100,000/년.
- **Undergraduate MD**: 고졸 + UCAT + 인터뷰 + IELTS 7.0. 6년. 학비 $80,000~$100,000/년.
- **GAMSAT**: 영국/아일랜드/호주 의대 입학 시험. Section I(인문 과학) + II(글쓰기) + III(생물/화학/물리). 비용 $530.
- **한국 의사면허 + 호주**: 자동 인정 X. AMC(Australian Medical Council) 시험 필수. AMC MCQ + Clinical Exam + 1년 인턴십(임상). 5~7년 소요.
- **약대**: Bachelor of Pharmacy(BPharm) 4년 또는 Master of Pharmacy(MPharm) 2년. PHA(Pharmacy Board) 등록 필수. IELTS 7.0(각 7.0).
- **PR 경로**: MD/Pharmacy 졸업 + AHPRA 등록 + 직업 평가(AMC/PSA) + 1년 인턴 = 189/190 PR. MLTSSL 직업.

**경로:**
한국 학사/의사면허 평가 → Graduate Entry MD vs AMC 시험 결정 → GAMSAT/AMC 응시 → 학교 신청 또는 면허 등록 → 1년 인턴 → 의사 활동

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Graduate Entry MD 학교**
Sydney/Melbourne/Monash/UQ/Flinders/UWA/ANU 등. 평균 75%+ + GAMSAT 60+ + 인터뷰. 합격률 5~10%.

**2. Undergraduate MD 학교**
James Cook University/Adelaide/UNSW/Monash 등. 고졸 + UCAT + 인터뷰. 6년 코스.

**3. GAMSAT 점수**
Section I(인문) 40%, II(글쓰기) 20%, III(과학) 40%. 평균 60+ 합격. Top Tier(Sydney/Melbourne) 70+.

**4. AMC 시험 (외국 의사)**
AMC MCQ($2,540) + Clinical Exam($3,500) + 1년 호주 인턴($60K~$80K). 5~7년 소요. 의사 사회복지 고려.

**5. Pharmacy 면허**
PSA(Pharmacy Society of Australia) 등록. BPharm 4년 + 1년 인턴 + Final Exam. AHPRA 면허 등록.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 학사 평균 + 학과 + 의사면허 보유 여부 평가
**2단계**: Graduate Entry MD vs AMC 시험 (외국 의사) 결정
**3단계**: GAMSAT/UCAT/AMC 시험 응시 (1년 준비)
**4단계**: 학교 신청 또는 AMC Clinical 등록
**5단계**: 졸업 + 1년 인턴 → AHPRA 등록 → 의사 활동

---

## 💡 직원이 학생한테 말할 멘트

> "호주 의대는 Graduate Entry MD vs 외국 의사 AMC 시험 두 가지 경로가 완전히 다릅니다. 한국 의사면허 + 학사도 자동 인정 X.

한국 학사 학과 + 평균 + 의사면허 + 영어 점수 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 의대 = 호주 자동**
   → ❌ AMC 시험 + Clinical + 1년 인턴 5~7년 소요.

2. **GAMSAT = 한 번 응시**
   → ❌ 점수 부족 시 매년 응시 가능. 평균 2~3회.

3. **MD 학비 = 1년 $80K**
   → ❌ Bachelor 평균 + 4년 = 총 $320K~$400K. 의대 학비 가장 비쌈.

4. **의사 = 자동 PR**
   → ❌ 직업 평가 + 영어 + 1년 인턴 + EOI 70+. PR 별개 절차.

5. **AMC Clinical = 1번 합격**
   → ❌ 외국 의사 AMC Clinical 합격률 30~40%. 평균 2~3회 응시.

6. **Pharmacy = MD보다 쉬움**
   → ❌ Pharmacy도 IELTS 7.0 + AHPRA + 1년 인턴 + Final Exam. 면허 까다로움.

7. **MD 졸업 = 즉시 의사**
   → ❌ 1년 인턴(Internship) 의무. 인턴 후 정식 의사(GP/Specialist).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학사 학과 + 평균 + 의사면허 보유
2. Graduate Entry MD vs AMC 외국 의사 결정
3. GAMSAT/AMC 시험 준비 가능 시점
4. 학비 ($80K~$100K/년 × 4년 = $320K+) + 1년 인턴 비용 평가

---

## 🔍 직원이 직접 확인 가능한 사이트

- GAMSAT (gamsat.acer.org)
- UCAT (ucat.ac.uk/ucat-anz)
- AMC (amc.org.au)
- AHPRA (ahpra.gov.au) + Medical Board

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Graduate Entry MD vs AMC 결정 가이드
- GAMSAT/AMC 시험 준비 + 학교 신청
- 졸업 후 인턴 + AHPRA 등록 가이드

**MARA / 변호사 영역**
- AMC 시험 거부 + 항소 (AMC + 변호사)
- AHPRA 등록 거부 + 항소 (AHPRA + 변호사)
- PR 신청 + 직업 평가 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 학사 평균 75%+ + 의사면허 평가
- [ ] GAMSAT/UCAT/AMC 시험 응시 결정
- [ ] MD 학교 후보 3~5개 + 입학 요건 확인
- [ ] IELTS 7.0(각 7.0) 또는 OET B 준비
- [ ] 학비 + 인턴 + 면허 등록비 ($400K+) 재정 확인
- [ ] 1년 인턴십(Internship) 의무 + 호주 거주 결정
- [ ] 졸업 후 AHPRA 등록 + GP/Specialist 진로 결정
