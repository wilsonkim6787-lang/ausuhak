# 📚 직원 응대 매뉴얼 #107

**케이스: 25세 / 멜번 도착 직후 / "혼자 살 집 구하려는데 어떻게 해요? Bond가 뭐예요? 계약 얼마나 해야 해요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 멜번 도착 1주차예요. 셰어하우스 말고 혼자 살 집 (스튜디오 또는 1베드룸) 구하려고요. Realestate.com.au 봤는데 Inspection? Application? Bond? 이게 다 뭐예요? 학생인데 빌릴 수 있나요?

**👉 직원이 멘붕하는 순간**
- "학생이 임대 가능?"
- "Bond = 뭐?"
- "Inspection?"
- "Application = 어떻게?"
- "계약 기간?"

**❌ 절대 하지 말아야 할 답**
- "그냥 돈 내면 돼요" → **거짓. Application 통과해야**
- "Bond 안 내도 돼" → **거짓. 의무**
- "1년 계약만 가능" → **거짓**

**✅ 직원이 알아야 할 정답**
호주 임대 = **Application 통과 → 계약 → Bond → 입주**:

1. **학생 = 임대 가능** (조건 충족시)
2. **Inspection** = 집 보러 가기
3. **Application** = 임대 신청서
4. **Bond (보증금)** = 임대료 4주분
5. **계약 (Lease)** = 6/12개월 일반
6. **Reference** = 추천서 (이전 집주인/직장)
7. **Real Estate Agent** = 중개인

직원 = **시스템 안내**. 윌슨 = **부동산 중개 X**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 학생 임대 가능 + 까다로운 조건

**답**: 호주 = **임대 매우 까다로움**. 학생도 가능하지만 어려움.

**까다로운 이유**:
- 임대 시장 공급 부족
- Application 경쟁 (한 집에 5~20명 신청)
- 학생 = 수입 증명 어려움
- Reference 부족
- 첫 임대 = 우선순위 낮음

**학생 강점 만들기**:
- 부모 보증인 (Guarantor)
- 한국 자금 잔고 증명
- 영문 추천서 (이전 셰어하우스 호스트)
- 학교 입학 증명
- OSHC 가입 증명

**유리한 조건**:
- 6개월 이상 거주 + Reference
- 풀타임 학생 + 알바 수입 증명
- 부모 동반 (가족비자)
- 전액 선납 가능

**불리한 조건**:
- 도착 직후 = Reference 없음
- 알바 X = 수입 증명 어려움
- 영어 부족 = 의사소통 어려움

**학생 일반 패턴**:
- 1~6개월: 셰어하우스
- 6개월 이후: 단독 임대 시도
- 또는 한인 부동산 통해 단독 임대 (외국인 환영)

**출처**: realestate.com.au, fairtrading.nsw.gov.au

---

### 2️⃣ Inspection (집 보러 가기)

**답**: Inspection = **호주 임대의 첫 단계**. 직접 방문 의무.

**방법**:
- Realestate.com.au, Domain.com.au에서 매물 검색
- "Book Inspection" 클릭
- 시간 예약
- 직접 방문

**Inspection 종류**:

**Open Inspection (Open Home)**:
- 정해진 시간에 집 오픈 (15~30분)
- 누구나 방문 가능
- 보통 토요일 오전
- 신청자 많음

**Private Inspection**:
- 1대1 약속
- 시간 자유
- 인기 매물 = 어려움

**Inspection 시 확인**:
- 위치 (대중교통, 슈퍼마켓, 학교 거리)
- 주변 소음 (도로, 기차, 비행기)
- 상태 (벽, 바닥, 창문, 부엌, 욕실)
- 가전 (냉장고, 세탁기, 에어컨)
- 곰팡이, 누수
- 햇빛, 환기
- 주차
- 안전 (잠금, 화재 경보)

**질문**:
- 가구 포함 여부 (Furnished/Unfurnished)
- 공과금 포함 (Bills Included?)
- 인터넷 (NBN 가능?)
- 애완동물 가능 (학생 = 거의 X)
- 입주 가능 날짜

**출처**: realestate.com.au, domain.com.au

---

### 3️⃣ Application (임대 신청)

**답**: Application = **경쟁 입찰**. 통과해야 임대 가능.

**서류**:

**필수**:
- 신분증 (여권, 학생증, 운전면허)
- 비자 증명 (학생비자)
- 학교 입학 증명 (CoE 또는 enrolment)
- 수입 증명 (알바 급여 명세, 부모 송금 증명)
- 은행 계좌 잔고 ($5,000+ 권장)
- 임대료 100점 시스템 충족

**100점 시스템 (NSW)**:
- 여권: 50점
- 학생증: 30점
- 운전면허: 50점
- 은행 카드: 20점
- 학교 입학증: 30점
- Reference: 30점
- 총 100점 이상

**Reference (추천서)**:

**Rental Reference**:
- 이전 집주인 또는 부동산 중개인
- 호주 첫 임대 = 한국 임대주 (영문 번역)
- 또는 셰어하우스 호스트

**Personal Reference**:
- 직장 상사 또는 학교 교수
- 한국에서 가져와도 OK (영문)

**Cover Letter (추천)**:
- 본인 소개
- 학생 신분 강조
- 학기 길이 (1~2년)
- 보증인 (부모) 언급
- 깨끗하게 살 것 약속

**경쟁률**:
- 시드니/멜번 인기 지역: 1집에 20~50명
- 보통 지역: 1집에 5~15명
- 시골 지역: 1집에 1~3명

**Application Fee**:
- 무료 (대부분)
- 일부 = $50~100

**대기**:
- 신청 후 1~7일 결과
- 거절 = 사유 안 줌
- 통과 = Lease 사인 단계

**출처**: 1form.com (호주 표준 신청 시스템)

---

### 4️⃣ Bond (보증금) 시스템

**답**: Bond = **임대료 4주분**. 의무 + 정부 보관.

**Bond 정의**:
- 임대료 4주분 보증금
- 손상/연체 시 차감
- 퇴거 시 반환

**Bond 보관**:

**NSW**:
- Rental Bond Board (NSW Fair Trading)
- Online or Mail
- 14일 이내 등록

**VIC**:
- Residential Tenancies Bond Authority (RTBA)
- 7일 이내 등록

**QLD**:
- Residential Tenancies Authority (RTA)
- Online

**SA**:
- Consumer and Business Services
- 4주 이내

**WA**:
- Department of Mines, Industry Regulation and Safety

**Bond 액수**:
- 임대료 주당 $300 → Bond $1,200
- 임대료 주당 $500 → Bond $2,000
- 가구 포함 = 추가 가능 (최대 6주)

**Bond 반환**:
- 퇴거 시 집 원상 복구
- Final Inspection 통과
- 손상 = 차감
- 청소 부족 = 차감
- 정상 = 100% 반환 (10~14일)

**Bond 분쟁**:
- NCAT (NSW), VCAT (VIC), QCAT (QLD)
- 무료 또는 저렴
- 사진 증거 (입주/퇴거) 필수

**출처**: fairtrading.nsw.gov.au, consumer.vic.gov.au, rta.qld.gov.au

---

### 5️⃣ Lease (임대 계약)

**답**: Lease = **법적 계약**. 의무/권리 명시.

**계약 기간**:

**Fixed Term**:
- 6개월
- 12개월 (가장 일반)
- 2년 (드뭄)
- 깨면 = Break Lease Fee

**Periodic (월간)**:
- Fixed Term 후 자동 전환
- 1~3개월 노티스 가능

**계약서 (Residential Tenancy Agreement)**:
- 주별 표준 양식
- 임대료, Bond, 기간, 가구 등
- 서명 = 법적 효력

**임대료 지불**:
- 주간 (Weekly) 일반
- 격주 (Fortnightly)
- 월간 (Monthly)
- Direct Debit (자동이체) 일반

**임대료 인상**:
- 12개월 이내 1회만
- 60일 노티스
- 시장 가격 기준

**책임**:

**임차인 (Tenant)**:
- 임대료 정시 지불
- 집 손상 X
- 청소
- 공과금 (전기, 가스, 인터넷, 수도 일부)
- 정기 점검 협조

**임대인 (Landlord)**:
- 집 안전 유지
- 수리 (정상 마모)
- Bond 정부 등록
- 정기 점검 (3~6개월)

**Break Lease**:
- 계약 위반 = Break Lease Fee
- 보통 임대료 1~2개월 + 광고비
- Reletting Cost
- 집 비울 때까지 임대료 계속

**Notice 기간**:
- 임차인 퇴거: 14~28일
- 임대인 퇴거: 60~90일
- 무단 퇴거 = 분쟁

**출처**: fairtrading.nsw.gov.au, consumer.vic.gov.au, rta.qld.gov.au

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 예산 + 위치 결정
- 멜번 1베드룸: $400~600/주 (CBD), $300~450/주 (외곽)
- 스튜디오: $350~500/주
- 학교 통학 30분 이내 추천
- 트램/기차 가까움

### Step 2: 매물 검색 (1주)
- Realestate.com.au, Domain.com.au
- 필터: 1 bedroom, $400~500, Furnished
- Inspection 예약

### Step 3: Inspection (1~2주)
- 5~10개 집 방문
- 사진/메모
- 주변 환경 확인

### Step 4: Application (5~15개 신청)
- 1form.com 또는 부동산 사이트
- 모든 서류 준비
- Cover Letter 작성
- 보증인 (부모) 연락처

### Step 5: 통과 후 Lease 사인
- 계약서 정독 (Bond, 기간, 인상)
- 변호사 무료 상담 (Tenants Union)
- Bond 4주분 + 첫 2주 임대료

### Step 6: 입주
- Condition Report 작성 (사진 100장)
- 공과금 셋업 (전기, 가스, 인터넷)
- Bond 정부 등록 확인 (영수증)

### Step 7: 거주
- 임대료 자동이체
- 정기 점검 협조
- 손상 시 즉시 보고

### Step 8: 퇴거 (계약 종료)
- Notice (28일) 사전 통보
- Final Inspection 청소
- Bond 반환 신청

---

## 💡 직원이 학생한테 말할 멘트

```
멜번 1베드룸/스튜디오 임대 고민이시군요.

호주 임대 = 한국과 매우 달라요.
까다롭고 경쟁 치열해요.

[학생 = 임대 가능 / 어려움]
- 학생도 임대 가능
- 다만 Reference, 수입 증명 어려움
- 도착 직후 = 더 어려움
- 권장: 1~6개월 셰어하우스 → Reference 쌓기 → 단독 임대

[멜번 1베드룸 시세]
- CBD: $500~700/주
- 인근 (Carlton, Brunswick): $400~550/주
- 외곽 (Footscray, Sunshine): $350~450/주
- 가구 포함 = +$50~100/주

[프로세스]

1. Realestate.com.au / Domain.com.au 검색
2. Inspection 예약 + 방문 (필수)
3. Application 신청 (5~15개)
4. 통과 = Lease 사인
5. Bond (4주분) + 첫 2주 임대료 = 약 $2,400~3,200
6. 입주

[서류 준비]
- 여권, 학생비자
- 학교 입학증 (CoE)
- 한국 은행 잔고 ($5,000+ 권장)
- 부모 송금 증명
- 영문 추천서 (가능하면)
- 100점 시스템 충족

[Bond (보증금)]
- 임대료 4주분 (의무)
- $400/주 = Bond $1,600
- 정부 (RTBA) 보관
- 퇴거 시 반환

[계약 (Lease)]
- 12개월 일반
- 6개월도 가능 (학생용)
- 깨면 = Break Lease Fee (1~2개월 임대료)
- Periodic = 자동 월간 전환

[입주 시 필수]
- Condition Report (사진 100장)
- 모든 손상 기록 (퇴거 시 분쟁 예방)
- 공과금 셋업 (전기/가스 = Origin, AGL)
- 인터넷 (NBN = 약 $70~100/월)

[현실적 조언]
멜번 도착 직후 = 단독 임대 어려움.
1차 = 셰어하우스 (Flatmates.com.au, Facebook 한인 그룹)
6개월 거주 + Reference = 단독 임대 시도

비용 (1베드룸 $400/주 기준):
- Bond: $1,600
- 첫 2주: $800
- 가구 (Unfurnished): $2,000~5,000
- 공과금 셋업: $200
- 총 초기: $4,600~7,600

자세한 단독 임대 전략은 윌슨이 카카오로 안내드려요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "학생 = 임대 못 함"
- **거짓**. 가능
- 다만 어려움
- 셰어하우스부터 시작 권장

### 함정 2: "Bond = 임대인이 가져감"
- **거짓**. 정부 (RTBA, RTA) 보관
- 임대인은 직접 못 씀
- 분쟁 시 Tribunal 결정

### 함정 3: "한국처럼 깎을 수 있어"
- **거짓**. 호주 = 가격 정해짐
- 시장 공급 부족 = 임대인 우위
- 깎으려 하면 거절

### 함정 4: "1년 계약 평생"
- **거짓**. 6개월/12개월 일반
- 만료 후 Periodic 또는 갱신
- Break Lease 가능 (페널티)

### 함정 5: "공과금 임대료 포함"
- **거짓 (대부분)**. Unfurnished = 별도
- Furnished + Bills Included = 일부 매물
- 일반: 임대료 + 전기/가스/인터넷/수도 별도

### 함정 6: "Inspection 안 가도 돼"
- **거짓**. 직접 봐야 함
- 사진과 실제 차이 큼
- Inspection = 임대 시작

### 함정 7: "Bond 다 돌려받음"
- **부분 사실**. 정상 사용 = 100%
- 손상/청소 부족 = 차감
- 입주 시 Condition Report 필수

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 위치 + 학교
- 학교 통학 시간
- 대중교통 (트램/기차/버스)
- 한인 밀집 지역 vs 호주 동네

### 2. 예산
- 주간 임대료 한도
- Bond 자금 ($1,600~2,800)
- 가구 자금 (Unfurnished 시 $2,000~5,000)
- 첫 달 비용 합계

### 3. 도착 시기
- 도착 직후 = 셰어하우스
- 6개월+ = 단독 임대
- 가족 동반 = 다름

### 4. 가구/시설
- Furnished vs Unfurnished
- 가구 구매 vs 가져오기
- 식기류, 침구 등

---

## 🔍 직원이 직접 확인 가능한 사이트

- Realestate: realestate.com.au
- Domain: domain.com.au
- Flatmates: flatmates.com.au
- 1form: 1form.com
- NSW Fair Trading: fairtrading.nsw.gov.au
- VIC Consumer Affairs: consumer.vic.gov.au
- QLD RTA: rta.qld.gov.au
- VCAT: vcat.vic.gov.au
- NCAT: ncat.nsw.gov.au
- Tenants' Union NSW: tenants.org.au
- Tenants Victoria: tenantsvic.org.au

---

## 🚨 직원 영역 vs 부동산 중개 영역

### 직원이 할 수 있는 것
- ✅ 호주 임대 시스템 설명
- ✅ Bond/Lease 시스템 안내
- ✅ Application 서류 안내
- ✅ 한인 셰어하우스 정보

### 직원이 할 수 없는 것
- ❌ 부동산 중개
- ❌ 매물 추천
- ❌ 계약서 검토
- ❌ 임대 분쟁 중재
- ❌ 가격 협상

---

## ✅ 완벽 응대 체크리스트

- [ ] 위치 + 학교 확인
- [ ] 예산 확인
- [ ] 도착 시기 확인
- [ ] 가구 옵션 (Furnished/Unfurnished)
- [ ] 학생 임대 가능 (어려움) 안내
- [ ] 셰어하우스 우선 권장
- [ ] Inspection 시스템 설명
- [ ] Application 서류 안내
- [ ] 100점 시스템 설명
- [ ] Bond 4주분 의무 강조
- [ ] 정부 등록 (RTBA 등) 설명
- [ ] Lease 6/12개월 일반 안내
- [ ] Break Lease 페널티 경고
- [ ] Condition Report 100장 사진 강조
- [ ] 공과금 별도 (대부분)
- [ ] Tenants Union 무료 상담 안내
- [ ] 부동산 중개 = 안 함

---

**작성**: ausuhak.com 직원 교육팀
**감수**: Wilson Kim (QEAC E240)
**기준**: 2026년 5월
**다음 업데이트**: 임대 정책/시세 변경 시
