# #258 ACS 직업평가 IT PR

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 IT 전공인데 ACS 직업평가 어떻게 받나요?"

**직원 멘붕 포인트:**
- ACS = Australian Computer Society
- IT 직업 평가 (PR Skilled)
- 한국 학사 + 경력 = 인정
- Major / Minor / Closely Related 차이

---

## ❌ 절대 하지 말아야 할 답

> "한국 IT 학사면 ACS 자동 인정됩니다."

→ ❌ **ACS 평가 신청 + 서류 + 수수료 필수**. 자동 X.

---

## ✅ 정답

ACS 직업평가: ① **Australian Computer Society** = IT PR Skilled 평가 기관 ② **한국 IT 학사 + 경력 = Major** (10년 인정) ③ **Non-IT 학사 + IT 경력 = RPL** (Recognition of Prior Learning) ④ **수수료 약 $530 AUD** ⑤ **심사 8~12주** ⑥ **유효 = 2년** ⑦ **ANZSCO 직업 코드 = 261-263 IT**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ACS 평가 종류**
Skills Assessment / Post Australian Study / Recognition of Prior Learning (RPL)

**2. Major / Minor 차이**
Major = IT 학사 70%+ IT 과목 / Minor = IT 학사 33%+ IT 과목 / Closely Related = 4년 경력 인정 후 평가

**3. RPL (Non-IT 학사)**
IT 학력 없음 + 6년 IT 경력 / RPL Form 작성 (4가지 ICT 과목 + 2가지 프로젝트) / 약 200~400시간 작업

**4. 호주 코스 인정**
호주 ICT Master = 자동 Major / 호주 ICT Bachelor = Major (Year 1 = Closely Related)

**5. 경력 인정**
Major / 학사 후 = 학위 졸업 후 경력 인정 / Skilled Employment Date 결정 / PR 점수 영향

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: ACS 공식 사이트 등록 (acs.org.au)
**2단계**: 학력 증빙 (학위증 + 성적표 영문)
**3단계**: 경력 증빙 (Reference Letter / Payslip / Tax)
**4단계**: ACS 신청 + 수수료 납부 ($530)
**5단계**: 심사 8~12주 → 결과 → EOI 입력

---

## 💡 직원이 학생한테 말할 멘트

> "IT 전공 PR은 ACS 직업평가 필수예요. 한국 IT 학사 + 경력 있으시면 Major 평가가 일반적이고, 학위 졸업 후 경력만 인정 (Skilled Employment Date)됩니다. 수수료 약 $530이고 심사 8~12주 걸려요. RPL (학력 없는 경력만)도 가능한데 작업량이 매우 많습니다 (200~400시간). 직업 코드 (261-263) + 결과 분류 (Major / Minor) 따라 PR 점수가 달라요. 윌슨님이 1:1로 ACS 신청 가이드 + 직업 코드 매칭 드려요. 카카오 (studywilson)으로 학위 + 경력 + IT 직무 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **ACS = 자동 인정 ❌**
   → 신청 + 서류 + 심사 필수

2. **학사 = Major 자동 ❌**
   → IT 과목 70%+ 비율 검증

3. **경력 = 졸업 전 포함 ❌**
   → Skilled Employment Date = 졸업 후

4. **ACS = 1번 신청 영구 ❌**
   → 유효 2년 / 만료 재신청

5. **Non-IT = ACS 불가 ❌**
   → RPL 가능 (6년 경력)

6. **ACS 거절 = PR 끝 ❌**
   → Review 신청 + 추가 서류

7. **ACS = 영어 무관 ❌**
   → 영어 = EOI 점수 / ACS = 학력+경력만

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학력 (IT 학사 / 비IT)
2. IT 경력 + Reference Letter 가능 여부
3. 직업 코드 (Software Engineer 261313 / ICT BA 261111 등)
4. ACS 결과 → EOI 입력 시점

---

## 🔍 직원이 직접 확인 가능한 사이트

- ACS: https://www.acs.org.au/migration-skills-assessment.html
- ANZSCO 261313 Software Engineer: https://www.acs.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- ACS 신청 가이드 1:1
- 직업 코드 매칭 + 점수 전략
- RPL 작성 가이드 (Non-IT)

**MARA / 변호사 영역**
- ACS 거절 + Review 신청
- ACS 분쟁 + 변호사 대리

---

## ✅ 완벽 응대 체크리스트

- [ ] ACS = IT 직업 평가 명확
- [ ] Major / Minor / RPL 구분
- [ ] 한국 학사 + 경력 인정
- [ ] 수수료 $530 + 심사 8~12주
- [ ] 유효 2년 / 만료 재신청
- [ ] 직업 코드 매칭 = 윌슨 영역
- [ ] 윌슨 카카오 자연 유도
