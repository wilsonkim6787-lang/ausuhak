# #332 호주_학생_출국_시_세금_환급_TFN_Super

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주에서 졸업하고 한국 들어가는데 그동안 일하면서 낸 세금이랑 슈퍼 어떻게 받나요? TFN, Super, ATO 다 모르겠어요..."

**직원 멘붕 포인트:**
- TFN/Super/ATO = 영문 약어 직원도 모름
- 한국 출국 후 환급 가능?
- 수퍼애뉴에이션 = 65% 세금?
- 환급 신청 어디서 하나?

---

## ❌ 절대 하지 말아야 할 답

> "ATO에 신청하면 자동으로 다 받아요."

→ ❌ DASP(Departing Australia Superannuation Payment) 65% 세금 + Tax Return 차이 모름. 학생이 잘못 알면 큰 손해.

---

## ✅ 정답

**호주 출국 시 환급 = ① Tax Return (소득세 환급) + ② DASP (수퍼 환급) 별개 절차.**

**핵심 사실:**
- **Tax Return**: ATO(Australian Taxation Office)에 7월~10월 신청. 1년치 일한 소득 + 낸 세금 정산. 학생도 환급 대상 (보통 $500~$3,000).
- **DASP (Departing Australia Superannuation Payment)**: 호주 출국 후 임시비자 만료 시 신청. 슈퍼 펀드에서 인출. **65% 세금 자동 차감** (Working Holiday는 65%, Student도 65%).
- 한국 입국 후도 ATO/DASP 모두 신청 가능 (Mygov 또는 종이 신청)
- TFN(Tax File Number) = 평생 유효 (호주 재방문 시 재사용)

**경로:**
호주 출국 전 → 슈퍼 펀드 잔액 확인 → 출국 → 비자 만료 → DASP 신청 (65% 세금 차감 후 수령) / Tax Return은 매년 7월 신청 가능 (한국에서도)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Tax Return vs DASP 차이**
Tax Return = 매년 7월~10월 소득세 정산. DASP = 출국 + 비자 만료 후 1회만 신청. 둘 다 별개.

**2. DASP 65% 세금**
Student/WHV 모두 DASP 신청 시 65% 세금 자동 차감. 즉 슈퍼 $10,000 있으면 $3,500만 수령. 호주 거주자(PR/시민권)는 15~22% (훨씬 적음).

**3. Tax Return 환급**
호주 학생 = 비거주자(Foreign Resident) 또는 거주자(Resident) 중 결정. 거주자 선언 시 $18,200 무세 + 환급 가능. 보통 $500~$3,000.

**4. TFN = 평생 유효**
TFN(세금 식별번호)는 한 번 발급받으면 평생 유효. 호주 재방문 시 재발급 불필요. ATO 계정 myGov 한국에서도 접속 가능.

**5. 슈퍼 펀드 찾기**
ATO myGov에 모든 슈퍼 펀드 자동 조회 (Lost Super 포함). 학생이 여러 직장 다녔으면 슈퍼 펀드 여러 개 가능 → 통합 후 DASP 신청.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 호주 체류 중 myGov 계정 + ATO 연결 + 슈퍼 펀드 확인
**2단계**: 마지막 직장 Final Payslip + Payment Summary(Group Certificate) 수령
**3단계**: 출국 전 또는 후 → ATO Tax Return 신청 (7월~10월, 매년)
**4단계**: 비자 만료 후 → DASP 온라인 신청 (ATO Departing Australia 페이지)
**5단계**: 65% 세금 차감 후 → 한국 계좌 또는 호주 계좌로 송금 (4~6주 소요)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 출국 시 세금 환급은 ① Tax Return (매년 소득세) ② DASP (수퍼애뉴에이션, 65% 세금 차감) 두 가지가 별개입니다. 잘못 신청하면 손해 큽니다.

졸업/출국 일정 + 직장 이력 가지고 카카오 1:1 상담 신청해주세요. 윌슨이 ATO + 슈퍼 펀드 + DASP 정확히 가이드합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **DASP 100% 환급**
   → ❌ 65% 세금 자동 차감. $10,000 있으면 $3,500만 수령.

2. **출국 전 신청 필수**
   → ❌ DASP는 비자 만료 후 신청 가능. 출국 전 신청 X.

3. **Tax Return = 자동 환급**
   → ❌ 매년 7월~10월 본인이 신청해야 함. ATO myGov 또는 H&R Block 같은 회계사 통해.

4. **TFN 만료**
   → ❌ TFN 평생 유효. 재발급 불필요.

5. **슈퍼 펀드 1개만**
   → ❌ 직장 여러 개 = 슈퍼 펀드 여러 개. ATO myGov에서 통합 후 DASP.

6. **한국에서 신청 불가**
   → ❌ ATO myGov + DASP 모두 한국에서 온라인 신청 가능.

7. **비거주자 = 무조건 손해**
   → ❌ 비거주자 신고가 유리한 경우도 있음 (소득 적을 때). 회계사 상담 권장.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 호주 체류 기간 + 일한 직장 수 + 슈퍼 펀드 수
2. 마지막 직장 Final Payslip + Payment Summary 보유 여부
3. TFN + myGov 계정 접속 가능 여부
4. 출국 예정일 + 비자 만료일 (DASP 신청 가능 시점)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ATO Tax Return (ato.gov.au/Individuals/Lodging-your-tax-return)
- ATO DASP (ato.gov.au/individuals/super/in-detail/temporary-residents-and-super/departing-australia-superannuation-payment-(DASP))
- myGov (my.gov.au) - 슈퍼 펀드 + ATO 통합 조회
- Lost Super 검색 (ato.gov.au/forms/searching-for-lost-super)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 출국 전 슈퍼 펀드 통합 + Final Payslip 정리 가이드
- Tax Return 신청 시기 + 비거주자/거주자 선택 가이드
- DASP 신청 절차 + 65% 세금 인지 + 한국 송금 옵션

**MARA / 변호사 영역**
- 복잡한 Tax Return (사업 소득/투자 소득) = 회계사(CPA/Tax Agent)
- 이중 과세 (한국 + 호주) = 세무사
- DASP 거부 + ART 항소 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] TFN + myGov 계정 활성화 + 슈퍼 펀드 통합 확인
- [ ] 마지막 직장 Final Payslip + Payment Summary 수령
- [ ] 출국 전 ATO Tax Return 신청 (가능 시) 또는 한국에서 7월 신청
- [ ] 출국 + 비자 만료 후 DASP 온라인 신청 (65% 세금 인지)
- [ ] 한국 또는 호주 계좌 정보 + 송금 수수료 확인
- [ ] DASP/Tax Return 환급 도착 4~6주 모니터링
