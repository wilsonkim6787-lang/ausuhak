# #503 호주_학생_임신중절_Termination_법적_상태_OSHC_상담_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "원하지 않은 임신을 했어요. 호주에서 임신중절 가능한가요? OSHC 커버되나요? 한국 가족한테는 말 못 해요."

**직원 멘붕 포인트:**
- 호주 임신중절 합법 (각 주별 차이): 22~24주 이내
- OSHC 일부 커버 + Medicare 미적용 (학생비자)
- 공공 진료소 (Family Planning Australia)에서 무료/저비용 가능
- 비밀 보장 절대적 (의료법상)
- 직원이 권유/만류 둘 다 X. 정보만 객관적 제공

---

## ❌ 절대 하지 말아야 할 답

> "임신중절은 죄악이에요 한국 가족한테 알리세요"

→ ❌ 본인 결정 영역. 종교/문화 강요 X. 직업 윤리 + 의료 비밀 보장

---

## ✅ 정답

호주에서 임신중절은 합법입니다. 22주~24주 이내 가능하고 주별로 차이 있어요. 학생비자도 가능하고 비밀 보장됩니다. Family Planning Australia 같은 공공 진료소에서 상담 + 시술 가능해요. OSHC가 일부 커버하지만 학생비자는 Medicare 적용 안 돼서 자비 부담($500~$2,500)도 있어요. Marie Stopes 같은 전문 클리닉도 옵션입니다. 결정은 본인이 하시고, 1800 RESPECT 1800 737 732 한국어 상담 가능해요. 신뢰할 수 있는 친구나 학교 Counselling Service 활용도 권장합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 임신중절 합법 (주별 차이)**
NSW: Abortion Law Reform Act 2019
- 22주 이내 자유 + 22주 이후 의사 2명 동의
VIC: Abortion Law Reform Act 2008
- 24주 이내 자유 + 24주 이후 의사 2명
QLD: Termination of Pregnancy Act 2018
- 22주 이내 자유
ACT/SA/WA/TAS/NT: 각 주별 합법 + 차이
외국인 학생도 동일 적용
한국과 다름 (한국은 2021부터 비범죄화 but 의료 시스템 차이)

**2. OSHC + 비용 (학생비자)**
OSHC 커버:
- 응급 입원 (합병증 등): 100%
- 시술 자체: 보험사별 일부 (Bupa 환급 가능)
Medicare 적용 X (학생비자)
비용 (자비):
- 약물 임신중절 (Mifepristone + Misoprostol): $300~$800
- 외과적 시술 (Surgical): $500~$2,500
Public Hospital: 일부 무료/저비용
Marie Stopes: 약 $470~$2,500

**3. 주요 진료처 (호주)**
Family Planning Australia:
- familyplanning.org.au
- 1300 658 886
- NSW/VIC/QLD/ACT 등
Marie Stopes Australia:
- mariestopes.org.au
- 1300 003 707
- 전문 클리닉, 비밀 보장
Public Hospital:
- 일부 시행 (주별 차이)
- 비용 저렴 but 대기 시간
GP 의뢰 가능 (Bulk-Bill OK)

**4. 절차 + 시간**
1. GP 진찰 (Bulk-Bill)
2. 임신 확인 (혈액/초음파)
3. 상담 (Counselling 의무 일부)
4. 약물 vs 외과 결정
5. 시술 (당일 또는 1~3일)
6. Follow-up 1~2주 후
전체 1~3주 (예약 + 시술)
임신 9주 미만: 약물 우선
임신 9주 이상: 외과 시술

**5. 정신 건강 + 비밀 보장**
비밀 보장:
- 의료법상 절대적
- 한국 가족 알리지 않음
- 학교/대학 비통보
- OSHC 청구도 항목 비공개

심리 지원:
- 1800 RESPECT: 1800 737 732 (한국어)
- Beyond Blue: 1300 22 4636
- Lifeline: 13 11 14
- 학교 Counselling Service
결정 후/전 모두 무료 상담

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: GP 방문 (임신 확인 + 의뢰)
**2단계**: Family Planning Australia 또는 Marie Stopes 예약
**3단계**: 상담 + 결정 (본인 충분한 시간)
**4단계**: 시술 (약물 또는 외과)
**5단계**: Follow-up + 심리 상담 (필요 시)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주에서 임신중절은 합법이고 학생비자도 가능합니다. 비밀 보장 절대적이에요. Family Planning Australia 1300 658 886 또는 Marie Stopes 1300 003 707에서 상담 + 시술 가능해요. 비용은 자비 $500~$2,500 정도입니다. 결정은 본인이 충분한 시간 가지시고, 1800 RESPECT 1800 737 732 한국어 상담도 받으세요. 학교 Counselling Service도 무료 + 비밀 보장입니다. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **호주 임신중절 불법 X**
   → 합법 (각 주별)

2. **OSHC 다 커버 X**
   → 일부만. 자비 $500~$2,500

3. **한국 가족 통보 X**
   → 의료 비밀 보장. 본인 결정

4. **종교/문화 강요 X**
   → 직업 윤리 + 본인 자결권

5. **Public Hospital 무료 X**
   → 일부 무료/저비용 + 대기

6. **학생비자 영향 X**
   → 임신중절 비자 영향 X

7. **후속 케어 안 함 X**
   → Follow-up + 심리 상담 권장

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 임신 몇 주? (9주 미만/9~22주/22주+)
2. 어느 주에 거주? (NSW/VIC/QLD/기타)
3. OSHC 어느 보험사? (Bupa/Medibank/기타)
4. 심리 상담 받고 싶어요? (예/아니오)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Family Planning AU: familyplanning.org.au / 1300 658 886
- Marie Stopes: mariestopes.org.au / 1300 003 707
- 1800 RESPECT 한국어: 1800 737 732
- Pregnancy Birth and Baby: 1800 882 436
- Beyond Blue: 1300 22 4636

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 법적 가능성 1차 안내
- Family Planning/Marie Stopes 연결
- 비용 1차 안내
- 심리 자원 안내

**MARA / 변호사 영역**
- OSHC 보험금 분쟁 (PHIO)
- 의료 사고 (Civil Lawyer)
- 비자 영향 (MARA - 보통 무관)
- 심리 치료 GP MHCP (GP)

---

## ✅ 완벽 응대 체크리스트

- [ ] GP 방문 + 임신 확인
- [ ] Family Planning 또는 Marie Stopes 예약
- [ ] 상담 + 충분한 시간
- [ ] 시술 + Follow-up
- [ ] 1800 RESPECT 한국어 심리 상담
