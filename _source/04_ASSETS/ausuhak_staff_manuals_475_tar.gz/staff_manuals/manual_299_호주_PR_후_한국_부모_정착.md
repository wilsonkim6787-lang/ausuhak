# #299 호주_PR_후_한국_부모_정착

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 호주 영주권 받았는데 한국 부모님 호주로 모셔오고 싶어요. 어떻게 해요?"

**직원 멘붕 포인트:**
- 부모 비자 = 870 (임시) vs 143 (영구) vs 103 (영구 대기 30년) 차이 큼
- 비용 = 870 $5K, 143 $48K, 103 $4,990 + 30년 대기
- Balance of Family Test (자녀 절반 호주 거주) 필수
- Assurance of Support (재정 보증) 학생이 잘 모름
- 직원이 잘못 답하면 학생 비현실적 기대

---

## ❌ 절대 하지 말아야 할 답

> "호주 PR 받으면 부모님도 자동으로 같이 와서 살 수 있어요."

→ ❌ 호주 PR = 부모 자동 동반 X. 부모 비자 별도 신청 필수. 870 (임시 5년 갱신), 143 (영구 $48K, 4-5년 대기), 103 (영구 $4,990 + 30년 대기) 중 선택. 직원이 잘못 답하면 학생 큰 손해.

---

## ✅ 정답

**부모 비자 3가지 옵션 (각 비용/대기 다름)**

| 비자 | 종류 | 비용 | 대기 | 거주 |
|------|------|------|------|------|
| 870 (Sponsored Parent Temp) | 임시 | $5K (3년) / $10K (5년) | 빠름 | 최대 10년 (5+5) |
| 143 (Contributing Parent) | 영구 | $48,365/명 | 4-5년 | 영구 |
| 103 (Parent) | 영구 | $4,990/명 | 약 30년 | 영구 |
| 173 (Contributing Parent Temp) | 임시→143 | $32K + 잔금 $43K | 4-5년 | 영구 (2단계) |
| 884 (Aged Contributing Parent) | 임시→864 | 65세 이상 | 4-5년 | 영구 |

**Balance of Family Test (필수):**
- 부모 자녀 절반 이상이 호주 시민권/PR 거주
- 또는 호주 거주 자녀 수 ≥ 다른 나라 거주 자녀 수
- 부모 자녀 1명 + 호주 PR = 통과 (1/1)
- 부모 자녀 3명 + 호주 PR 1명 + 한국 거주 2명 = 불통과

**Assurance of Support (AoS):**
- 자녀가 부모 재정 보증
- 보증금: $14K (단독 부모) / $20K (부부 부모)
- 10년 보증 (143) / 4년 (870)
- Centrelink 채무 발생 시 자녀가 갚음

**의료보험:**
- 870 = OVHC 의무 (Visitor Health Cover)
- 143/103 = PR 받으면 Medicare 가능

**추천:**
- 빠르게 호주 살게: 870 임시
- 영구 정착 + 자금 충분: 143 ($48K)
- 자금 부족 + 시간 충분: 103 (30년 대기)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Balance of Family Test**
부모 자녀 절반 이상 호주 거주 또는 호주 거주 ≥ 외국 거주. 부모 자녀 1명만 = 자동 통과.

**2. Contributing vs Non-Contributing**
Contributing (143/173/864/884) = 비싼 대신 빠름 (4-5년). Non-Contributing (103/804) = 싸지만 30년.

**3. Assurance of Support**
자녀 = 부모 재정 보증 10년. Centrelink 청구 시 자녀가 갚음.

**4. 870 비자 (Sponsored Parent Temporary)**
임시 비자 5년 갱신, 일 불가, OVHC 의무, 한국 출국 자유롭게.

**5. 부모 비자 + Aged Pension**
PR 받은 후 10년 거주 후 Age Pension 가능 (단, AoS 10년 동안 청구 어려움).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **Balance of Family Test 확인** - 부모 자녀 분포 (호주/한국/기타) 계산
**2단계**: **부모 비자 종류 선택** - 870 (임시) / 143 (영구 빠름) / 103 (영구 대기)
**3단계**: **Sponsor 등록** - 자녀 (PR/시민권자) = Sponsor / Sponsorship 신청
**4단계**: **Assurance of Support 준비** - 자녀 재정 능력 증명 / 보증금 예치
**5단계**: **비자 신청 + 대기** - 870 = 빠름, 143 = 4-5년, 103 = 30년

---

## 💡 직원이 학생한테 말할 멘트

> "부모님 호주 정착은 870 (임시 5년), 143 (영구 $48K, 4-5년 대기), 103 (영구 $5K, 30년 대기) 중 선택입니다. Balance of Family Test (부모 자녀 절반 이상 호주 거주)가 필수 조건이고, Assurance of Support (자녀 재정 보증)도 필요합니다. 본인 상황에 맞는 비자 선택이 중요합니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **호주 PR = 부모 자동 동반**
   → 부모 비자 별도 신청. 자동 X.

2. **부모 비자 = 1개만 있다**
   → 870/143/103/173/864/884 등 6개 이상. 상황별 선택.

3. **103 (싼 비자) 신청하면 빠르다**
   → 103 = 30년 대기. 사실상 부모 사망 후 받을 가능성.

4. **Balance of Family Test 통과는 쉽다**
   → 부모 자녀 5명 + 호주 1명 = 불통과. 한국 자녀 많으면 어려움.

5. **Assurance of Support 보증금 = 못 돌려받음**
   → 10년 후 환급. 단, Centrelink 청구 발생 시 차감.

6. **870 비자도 일할 수 있다**
   → 870 = 일 불가. 관광/방문 목적만.

7. **부모 비자 받으면 즉시 Medicare**
   → 143/103 = PR 받으면 Medicare. 870 = Medicare X, OVHC 의무.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 본인 비자 상태 (PR/시민권/임시 비자)
2. 부모 자녀 수 + 분포 (Balance of Family Test)
3. 본인 재정 능력 (AoS 보증 가능 여부)
4. 부모 호주 거주 의도 (단기 방문/영구 정착)

---

## 🔍 직원이 직접 확인 가능한 사이트

- 870 비자: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/sponsored-parent-temporary-870
- 143 비자: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/contributory-parent-143
- 103 비자: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/parent-103
- Balance of Family Test: immi.homeaffairs.gov.au
- Assurance of Support: www.servicesaustralia.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 한국 학생 PR 후 부모 비자 일반 절차 안내
- Balance of Family Test 일반 자문
- 윌슨 950명 동문 부모 비자 사례 공유

**MARA / 변호사 영역**
- 부모 비자 신청 = MARA 등록 변호사 (복잡한 절차)
- Balance of Family Test 경계 케이스 = MARA
- Assurance of Support 분쟁 = MARA / Services Australia
- 부모 비자 거절 = MARA 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] 부모 비자 6가지 옵션 비교 설명함
- [ ] Balance of Family Test 정확히 설명함
- [ ] Assurance of Support 보증 의무 설명함
- [ ] 비용 + 대기 시간 정확히 안내함 (143 $48K, 103 30년)
- [ ] OVHC vs Medicare 차이 설명함
- [ ] MARA 변호사 권장함
- [ ] 윌슨 1:1 상담 유도함
