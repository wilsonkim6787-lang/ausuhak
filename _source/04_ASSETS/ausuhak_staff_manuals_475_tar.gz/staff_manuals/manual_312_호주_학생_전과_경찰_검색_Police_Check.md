# #312 호주_학생_전과_경찰_검색_Police_Check

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 호주에서 작은 사건으로 경찰 조사 받았어요. 전과 기록되나요? 비자에 영향 있나요?"

**직원 멘붕 포인트:**
- 호주 = Criminal Record vs Police Caution 차이
- Caution (경고) = 기록 X (보통)
- Conviction = 형사 기록 (Police Check 나옴)
- Spent Convictions Scheme = 일정 기간 후 삭제
- 비자 Character Test = 형사 12개월+ 영향

---

## ❌ 절대 하지 말아야 할 답

> "작은 일이면 전과 기록 안 되니까 걱정 마세요."

→ ❌ 경찰 조사 = 즉시 전과 X (Caution / No Further Action 다수). 단, Conviction (유죄 판결) = 기록. Police Check 시 나옴. Spent Convictions Scheme 일정 기간 후 삭제 가능. 직원이 단답하면 안심시킴 + 사실 전달 못함.

---

## ✅ 정답

**호주 형사 기록 시스템**

**경찰 처분 종류:**
1. **No Further Action (NFA)** - 처분 없음, 기록 X
2. **Caution (경고)** - 공식 경고, 기록 (Police Internal) but 일반 검색 X
3. **Penalty Notice (벌금 통지서)** - 벌금만 (예: 무질서 행동)
4. **Court Summons (법원 출석)** - 법원 결정 필요
5. **Conviction (유죄 판결)** - 형사 기록, Police Check 검색
6. **Section 10 (NSW)** - 유죄 인정 but Conviction X (Spent immediately)

**Police Check (Background Check):**
- 신청 시 모든 Conviction 검색
- 비자 신청 / 취업 시 요구
- $42 (NSW)
- 신청자 본인이 받음

**Spent Convictions Scheme:**
- 호주 = 10년 후 자동 삭제 (성인) / 5년 (청소년)
- 단, 30개월+ 징역 = 영구 기록
- 일부 직업 (간호/교사/경찰 등) = 평생 검색

**비자 Character Test (Section 501 Migration Act):**
- 12개월+ 징역 = Character Test Fail
- 누적 24개월+ 징역 = Fail
- 폭력/성범죄 = 자동 Fail
- 단순 벌금/Caution = 영향 X

**한국 신원조회:**
- 비자 신청 시 한국 + 호주 양국 신원조회
- 한국 = 기소유예/벌금형 = 보통 영향 X
- 한국 형사 처벌 (집행유예 포함) = 호주 비자 영향

**Conviction 받은 경우:**
- 변호사 자문 (형사 변호사)
- Section 10 (NSW) 신청 가능 (유죄 인정 + Conviction X)
- 항소 가능 (28일 이내)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Conviction vs Caution 차이**
Conviction = 형사 기록 / Caution = 경찰 내부 기록 (일반 검색 X).

**2. Spent Convictions Scheme**
10년 후 자동 삭제 (성인). 단, 일부 직업 평생 검색.

**3. Section 10 (NSW)**
유죄 인정 but Conviction X. 즉시 Spent. 첫 위반에 자주 적용.

**4. Character Test 501**
12개월+ 징역 = 비자 Fail. 폭력/성범죄 = 자동 Fail.

**5. Police Check 신청**
본인 신청. 비자/취업 시 자주 요구. $42 (NSW).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **처분 결과 확인** - NFA / Caution / Conviction 확인 (경찰 통지서)
**2단계**: **Conviction 시 형사 변호사** - 항소 28일 이내 / Section 10 신청 검토
**3단계**: **Police Check 신청** - 본인 정확한 기록 확인
**4단계**: **비자 영향 평가** - 12개월+ 징역 X = 일반 영향 적음 / 폭력/성 = 영향 큼
**5단계**: **비자 갱신 시 신고** - Form 1023 또는 비자 신청서 신고 의무 (숨김 = 비자 취소)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 경찰 조사 = 즉시 전과 X 입니다. NFA (처분 없음) / Caution (경고) = 일반 검색 X 이고, Conviction (유죄 판결) 시 Police Check에 나옵니다. 비자 Character Test는 12개월+ 징역이 기준이라 단순 사건은 영향이 적습니다. 정확한 처분 결과 확인 + 비자 갱신 시 신고 의무 (숨김 = 비자 취소 위험)가 중요합니다. 형사 변호사 자문이 필요할 수 있습니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **경찰 조사 = 자동 전과**
   → NFA / Caution = 전과 X. Conviction만 전과.

2. **Caution = 영구 기록**
   → Caution = 경찰 내부 기록만. 일반 Police Check X.

3. **Section 10 = 무조건 가능**
   → 법원 결정. 첫 위반 + 경미 = 가능성. 자동 X.

4. **Spent Convictions = 모든 기록 삭제**
   → 10년 후 자동 삭제 but 일부 직업 (간호/교사) 평생 검색.

5. **비자 신청 시 안 적어도 OK**
   → 신고 의무 위반 = 허위 진술 = 비자 취소 + 입국 금지. 정직 신고.

6. **한국 기소유예 = 호주 영향**
   → 한국 기소유예 = 호주 보통 영향 X. 단, 폭력/성범죄 = 영향.

7. **형사 변호사 = 비싸서 X**
   → 형사 변호사 자문 필수. Legal Aid (저소득) = 무료 가능.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 정확한 처분 결과 (NFA/Caution/Conviction/Section 10)
2. 사건 종류 (폭력/절도/마약/음주 운전 등)
3. 법원 출석 일정 (있다면)
4. 현재 비자 갱신 일정 (있는 경우 영향 평가 필요)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW Police Check: www.police.nsw.gov.au
- Spent Convictions: www.aic.gov.au
- Character Test: immi.homeaffairs.gov.au
- Legal Aid NSW: www.legalaid.nsw.gov.au
- Section 10 (NSW): www.lawaccess.nsw.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 전과 기록 일반 정보 안내
- 비자 Character Test 일반 안내
- Police Check 신청 절차 안내

**MARA / 변호사 영역**
- Conviction 후 비자 갱신 = MARA
- Character Test Fail 항소 = MARA
- 형사 사건 변호 = 형사 변호사
- 한국+호주 양국 신원조회 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] NFA / Caution / Conviction 차이 정확히 설명함
- [ ] Spent Convictions 10년 자동 삭제 설명함
- [ ] Character Test 12개월+ 기준 안내함
- [ ] 비자 갱신 시 신고 의무 강조함
- [ ] 형사 변호사 자문 권장함
- [ ] Section 10 (NSW) 옵션 안내함
- [ ] 윌슨 1:1 상담 + MARA 안내함
