# #171 학생회 / 동아리 / 한인회 활동

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 학교 동아리 어떻게 가입해요? 한인회 있어요? 친구 만들기 어려워서 동아리 활동하고 싶어요."

**직원 멘붕 포인트:**
- 호주 학교 동아리 시스템 모름 (Student Union, Society, Club)
- 한인회 위치 모름
- 동아리 가입 절차 모름

---

## ❌ 절대 하지 말아야 할 답

> "한인회 가입하면 한국 친구 많이 만들 수 있어요!"

→ 한인 의존 ↑ = 영어/호주 적응 ↓. 균형 안내 필요.

---

## ✅ 정답

호주 학교 동아리 시스템 매우 잘 갖춰져 있어요 (대학 100~300개 동아리). 학기 초 'O Week' (Orientation Week)에 박람회로 가입. 한인회도 있지만 호주 학생 동아리도 균형 있게 참여 추천. 친구 사귀기 + 영어 향상 + 활동 = 일석삼조예요.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 학교 동아리 종류
**대학 (University):**
- **Student Union** (학생회) - 전체 학생 대표
- **Society / Club** (동아리) - 100~300개
  - Cultural (Korean Society, Chinese Society 등)
  - Academic (Engineering Society, Business Society 등)
  - Sports (Soccer Club, Basketball Club 등)
  - Hobby (Photography Club, Cooking Club 등)
  - Religious (Christian Union 등)
  - Political (Liberal Society, Labor Society 등)
  - Special Interest (Anime Society, LGBTIQ+ Society 등)

**TAFE:**
- 학생회 규모 작음
- 일부 동아리만 존재
- 학교 행사 위주

**고등학교 (Secondary):**
- 학교별 클럽 다수
- Sport Team 위주

### 2. 동아리 가입 (O Week)
- **O Week (Orientation Week):** 학기 첫 주
- **Clubs Day:** 캠퍼스 박람회 1~2일
- 부스 방문 → 가입 신청 → 회비 $10~$30
- 학기 중 가입 가능 (일부 마감)

**가입비:**
- 일반 동아리 $10~$30/년
- 스포츠 클럽 $50~$200 (장비/대회 비용)
- 일부 무료

### 3. Korean Society (한인 학생회)
**주요 대학 한인회:**
- **UNSW Korean Society**
- **University of Sydney Korean Society**
- **UTS Korean Students**
- **Macquarie KSA**
- **Monash KCS (Korean Cultural Society)**
- **University of Melbourne KSA**
- **UQ Korean Society**

**활동:**
- 환영 행사 (학기 초)
- BBQ, 야유회
- 추석/설날 행사
- 한국 영화의 밤
- 학습 도움
- 졸업 선후배 네트워크

**주의:**
- 한인회만 활동 = 영어 안 늘음
- 호주 동아리 + 한인회 균형

### 4. 호주 한인회 (학교 외)
**호주 한인회 (재호한인회):**
- 시드니 한인회: koreansociety.org.au
- 멜번 한인회: kavic.org.au
- 브리즈번 한인회: kabq.org.au
- 애들레이드, 퍼스 한인회

**주요 행사:**
- 한국의 밤 (10월)
- 추석 행사
- 한글날
- 광복절

**유학생 도움:**
- 이민 정보 / 법률 상담
- 응급 도움 (병원, 변호사)
- 일자리 정보
- 한인 네트워크

### 5. 친구 사귀기 전략
**호주 친구 사귀는 활동:**
- 일반 동아리 (Sports, Hobby) - 한국인 적음
- Buddy Program (학교 1:1 호주 학생 매칭)
- 알바 (카페, 식당)
- 자원봉사
- 그룹 운동 (요가, 농구)

**한인 친구 사귀는 활동:**
- Korean Society
- 한인 교회
- 한인 카페/펍
- 한국 음식점

**비율:**
- 호주 친구 1명 = 한인 친구 5명 가치 (영어/문화 학습)
- 호주 친구 70% + 한인 친구 30% 이상적

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. O Week 활용
- 학기 첫 주 박람회 필수 참여
- 동아리 5~10개 가입 (회비 저렴)
- 활동 줄여가며 좋아하는 곳 집중

### Step 2. 호주 동아리 + Korean Society 균형
- 호주 동아리 2~3개 + Korean Society 1개
- 한인회만 X

### Step 3. 친구 만들기 다양화
- 동아리 + 알바 + 자원봉사
- Buddy Program 신청
- 학습 그룹

### Step 4. 한인회 활용
- 한인 정보망 (이민, 법률, 응급)
- 한국 명절 행사
- 균형 있게

### Step 5. 활동 시간 관리
- 학업 우선
- 동아리 주 3~5시간
- 알바 주 20시간 (학생비자 한도)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 학교 동아리 시스템 정말 좋아요! 친구 만들기 + 영어 향상 + 활동 = 일석삼조예요.
>
> **언제:** 학기 첫 주 'O Week' (Orientation Week) 'Clubs Day' 박람회
> **어떻게:** 부스 방문 → 가입 → 회비 $10~$30/년
>
> **동아리 종류:**
> - 문화 (Korean Society, Anime Society 등)
> - 스포츠 (Soccer, Basketball, Tennis Club)
> - 학과 (Engineering, Business Society)
> - 취미 (Photography, Cooking, Music)
> - 종교 (Christian Union 등)
>
> **추천 전략:**
> - 호주 동아리 2~3개 (Sports, Hobby) - 한국인 적음
> - Korean Society 1개 - 한인 네트워크
> - **호주 친구 1명 = 한인 친구 5명 가치** (영어/문화 학습)
>
> **Korean Society:**
> - 주요 대학 모두 있음 (UNSW, UTS, USYD, Monash, Melbourne, UQ 등)
> - 환영 행사, BBQ, 추석/설날, 한국 영화의 밤
>
> **호주 한인회 (학교 외):**
> - 시드니: koreansociety.org.au
> - 멜번: kavic.org.au
> - 브리즈번: kabq.org.au
> - 응급 시 도움, 이민 정보, 한국 명절 행사
>
> **호주 친구 사귀는 추천:**
> - Sports Club (Soccer, Tennis 등)
> - Buddy Program (학교 1:1 매칭)
> - 알바 (카페, 식당)
> - 자원봉사
>
> 어느 도시 / 학교 정해지셨나요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. 한인회만 가입
- 영어 안 늘음
- 한인 네트워크 갇힘
- 균형 필수

### 함정 2. 동아리 가입비
- $10~$30 일반
- 스포츠 클럽 $50~$200 (장비)
- 미리 확인

### 함정 3. O Week 놓침
- 첫 주 박람회 = 동아리 만남 베스트
- 학기 중 가입 가능하지만 미리 알아두기

### 함정 4. 활동 과다
- 5개+ = 활동 못 함
- 2~3개 집중

### 함정 5. 한인회 정치
- 일부 한인회 내부 정치 多
- 거리두기 OK
- 활동만 참여

### 함정 6. 종교 동아리
- 가입 OK 단, 강요 X
- 부담스러우면 탈퇴 OK

### 함정 7. 학업 소홀
- 동아리 = 부수적
- 학업 80%, 동아리 20%

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **어느 학교?** → 동아리 시스템
2. **관심사?** (스포츠/문화/학술) → 추천
3. **친구 만들기 vs 활동 우선?** → 전략
4. **한인 vs 호주 친구 비율?** → 균형 코칭

---

## 🔍 직원이 직접 확인 가능한 사이트

- **각 학교 Student Union:** [학교명] Student Union
- **시드니 한인회:** koreansociety.org.au
- **멜번 한인회:** kavic.org.au
- **브리즈번 한인회:** kabq.org.au

---

## 🚨 직원 영역 vs 윌슨 영역

| 직원 가능 | 윌슨 영역 |
|-----------|-----------|
| 동아리 시스템 일반 | 학생 1:1 활동 코칭 |
| Korean Society 정보 | - |
| 한인회 정보 | - |
| 친구 만들기 전략 | - |

---

## ✅ 완벽 응대 체크리스트

- [ ] O Week (학기 첫 주) Clubs Day 안내
- [ ] 동아리 종류 (문화/스포츠/학술/취미)
- [ ] 가입비 ($10~$30 일반)
- [ ] Korean Society 안내
- [ ] 호주 한인회 (학교 외)
- [ ] 호주 친구 70% + 한인 30% 추천
- [ ] Buddy Program 안내
- [ ] 활동 시간 관리 (주 3~5시간)
- [ ] 학업 우선 강조
- [ ] 학생 학교 확인

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 학생활동
