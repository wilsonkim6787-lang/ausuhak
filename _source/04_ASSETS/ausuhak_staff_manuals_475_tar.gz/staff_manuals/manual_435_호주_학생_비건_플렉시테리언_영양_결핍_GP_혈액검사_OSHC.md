# #435 호주_학생_비건_플렉시테리언_영양_결핍_GP_혈액검사_OSHC

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 비건 시작한지 1년 됐는데 자꾸 어지럽고 피곤해요. 영양제 사야 하나요? 혈액검사는 어디서 받나요? OSHC로 커버되나요? 한국에서 부모님이 비타민 보내주신다는데 호주 입국 시 문제없나요?"

**직원 멘붕 포인트:**
- 비건 영양 결핍 (B12/철/비타민D)
- GP 혈액검사 OSHC 커버
- Pathology Lab 위치
- 한국 영양제 호주 입국 (TGA 규제)
- Vegan Society Australia 자료

---

## ❌ 절대 하지 말아야 할 답

> "비건 그만두세요"

→ ❌ ❌ 식단 평가 X. 직원 영역. 영양 보충 + 의료 검사 안내만.

---

## ✅ 정답

비건 영양 관리: ① GP 예약 → Pathology Lab 의뢰서 (Bulk-Billed면 OSHC 100% 커버), ② 혈액검사 - B12, Iron(Ferritin), Vitamin D, Folate, Zinc, Calcium 표준, ③ 비건 영양 부족 흔함 - B12 (필수 영양제), Iron, Omega-3, Vitamin D, ④ 영양제 호주 - Chemist Warehouse $20~$50, Blackmores/Swisse 호주 브랜드, ⑤ 한국 영양제 입국 - TGA 등록 의약품 X (개인용량 3개월분 OK / 처방약은 처방전 동봉), ⑥ 비건 영양사 - Vegetarian/Vegan Society Australia 명단, ⑦ Plant-based 식단 권장 (단순 비건 X) = 콩/렌틸/견과류/시금치 균형, ⑧ 학생식당 비건 옵션 표시 (대부분 호주 캠퍼스).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 비건 결핍 영양소**
B12/Iron/D/Omega-3/Calcium/Zinc

**2. Bulk-Billed Pathology**
OSHC 100% 커버

**3. 호주 영양제**
Chemist Warehouse 가성비

**4. TGA 규제**
한국 영양제 3개월분 OK

**5. Vegan Society**
vegansociety.com.au

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: GP 예약 (HotDoc 또는 직접)
**2단계**: 2단계: 혈액검사 의뢰서 받기
**3단계**: 3단계: Bulk-Billed Pathology 방문 (Douglass Hanly Moir/Sonic)
**4단계**: 4단계: 결과 후 GP 재방문 - 영양제 처방
**5단계**: 5단계: 비건 영양사 (Dietitian) 의뢰 (필요시)

---

## 💡 직원이 학생한테 말할 멘트

> "GP 예약하고 혈액검사 받으세요. Bulk-Billed면 OSHC 100% 커버됩니다. B12/Iron/D 검사 표준입니다. 한국 영양제는 3개월분까지 입국 OK입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **비건 그만두라 권유**
   → 직원 영역 X

2. **영양제 자가 진단**
   → 혈액검사 후 처방

3. **OSHC 영양제 커버**
   → 처방 영양제만 PBS

4. **Pathology 유료**
   → Bulk-Billed 무료

5. **한국 영양제 X**
   → 3개월분 OK

6. **호주 약국 처방전 X**
   → OTC 영양제만

7. **비건 = 자동 영양 결핍**
   → 균형 식단 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 비건 기간 / 식단 종류
2. 현재 증상 (피로/어지럼/탈모)
3. 영양제 복용 여부
4. OSHC 가입 상태

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Vegan Society AU', 'vegansociety.com.au')
- ('HotDoc GP', 'hotdoc.com.au')
- ('TGA 한국 약품', 'tga.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- GP/Pathology 안내

**MARA / 변호사 영역**
- 비자 영향 X / 무관

---

## ✅ 완벽 응대 체크리스트

- [ ] GP 혈액검사 안내함
- [ ] Bulk-Billed OSHC 커버 안내함
- [ ] B12/Iron/D 표준 검사 안내함
- [ ] 한국 영양제 3개월분 OK 안내함
- [ ] Vegan Society 자료 안내함
- [ ] 식단 평가 X 명확히 함
