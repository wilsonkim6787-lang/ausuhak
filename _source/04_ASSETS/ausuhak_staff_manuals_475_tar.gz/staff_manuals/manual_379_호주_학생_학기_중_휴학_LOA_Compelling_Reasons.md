# #379 호주_학생_학기_중_휴학_LOA_Compelling_Reasons

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니 비즈니스 디플로마 다니는데 어머니 암 진단 받으셔서 한국 가야 해요. 휴학 가능해요?"

**직원 멘붕 포인트:**
- LOA(Leave of Absence) Compelling Reasons만 가능
- Compelling Reasons (가족 위급/의료/사고) 증빙
- PRISMS 통보 (학교 → DOHA)
- 비자 영향 없음 (적절한 LOA만)
- 출국 vs 호주 잔류 결정

---

## ❌ 절대 하지 말아야 할 답

> "아무 때나 휴학 가능해요. 자유롭게 한국 다녀오세요."

→ ❌ LOA = Compelling and Compassionate Reasons만 승인. 단순 여행/휴식 X. 어머니 암 진단 = 인정 사유. 학교 승인 + 증빙(의사 소견서) 필수. 미승인 휴학 = Course Progress 위반 → 비자 취소.

---

## ✅ 정답

**학생비자 휴학(LOA) 가이드** (2026):

**Compelling and Compassionate Reasons (인정 사유)**:
- 본인 중대 질병/사고 (수술/입원)
- 가족 사망/위급 (부모/배우자/자녀)
  - 어머니 암 진단 = 인정 사유 ✓
- 가정 폭력 피해
- 정부 출입국 사유 (비자 거절 대기 등)
- 자연재해 (한국/호주)

**미인정 사유 (LOA 거부)**:
- 단순 여행/휴식
- 친구 결혼식/생일
- 단순 영어 부족 (학교 변경으로 해결)
- 알바 우선 (Work over Study)
- 향수병 (Homesickness만)

**LOA 신청 절차**:
1. 학교 International Student Support Office 즉시 연락
2. LOA Application Form 작성
3. Compelling Reasons 증빙 첨부:
   - 의사 소견서 (NAATI 영문 번역)
   - 한국 가족관계증명서 (영문)
   - 항공권 + 한국 병원 진단서
4. 학교 학과장 승인 (1~2주)
5. PRISMS 통보 (학교 → DOHA, 자동)

**LOA 기간**:
- 1학기 (6개월) ~ 1년 단위
- 최대 2년 (단, 2년 이상 = 비자 재신청 권장)
- LOA 중 호주 체류 가능 (학생비자 유효)
- 한국 출국 가능 + 재입국 가능

**LOA 중 비자 영향**:
- 적절한 LOA = 비자 영향 X
- COE Defer 상태 (학교가 처리)
- Course Progress 의무 정지
- 알바 시간 제한 (48시간/2주) 동일 적용

**LOA 후 복학**:
- 학교에 복학 의사 통지 (3개월 전)
- New COE 발급 + 새 비자 일정
- 학기 시작일 변경 (Feb/Jul Intake)
- 학비 정산 (지불한 학비 이월)

**LOA vs Course Transfer (학과 변경)**:
- LOA = 같은 코스 + 일시 정지
- Course Transfer = 다른 코스/학교 변경
- 학교 결정 vs 본인 결정

**LOA vs Visa Cancellation**:
- LOA = 비자 유지 + 일시 정지
- Cancellation = 비자 자체 취소 (재신청 의무)
- LOA 권장 (재신청 비용 + 시간 절약)

**한국 영구 귀국 결정 시**:
- LOA → Visa Cancellation 통보 (immi.homeaffairs.gov.au)
- 학비 환불 신청 (Refund Policy 학교별)
- TFN 세금 환급 신청 (Tax Return)
- Super 인출 신청 (DASP, 65% 세금)
- OSHC 환불 신청

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ESOS Act Section 19**
Course Progress 휴학 규정

**2. Standard 9 ESOS**
Deferring/Suspending/Cancelling Enrolment

**3. DOHA Compelling Reasons**
homeaffairs.gov.au - LOA 사유

**4. PRISMS 학교 시스템**
DEEWR Provider System

**5. 학교 International Office**
각 학교 LOA 양식 제공

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 학교 International Office 즉시 연락 (이메일 + 면담)
**2단계**: 2. 어머니 암 진단서(영문 번역) + 가족관계증명서 준비
**3단계**: 3. LOA Application Form 작성 + 증빙 제출
**4단계**: 4. 학교 승인 대기 (1~2주) + PRISMS 통보
**5단계**: 5. 한국 출국 → 어머니 간호 → 6개월~1년 후 복학

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 학기 중 휴학 답변드립니다.

어머니 암 진단은 학생비자 LOA(Leave of Absence)의 인정 사유인 Compelling and Compassionate Reasons에 해당합니다. 학교 International Student Support Office에 즉시 연락하시고 LOA를 신청하세요.

필요 서류는 ① 학교 LOA Application Form, ② 어머니 암 진단서(NAATI 영문 번역), ③ 한국 가족관계증명서(영문), ④ 한국행 항공권입니다. 학교 승인이 1~2주 걸리고, 승인되면 학교가 PRISMS 시스템을 통해 DOHA(이민성)에 자동 통보합니다.

적절한 LOA는 비자 영향이 없으니 안심하세요. LOA 기간은 1학기(6개월)~1년이 표준이고 최대 2년까지 가능합니다. LOA 중에 한국 출국 + 재입국도 가능합니다. 복학 시 학교에 3개월 전 통지하면 New COE 발급 + 새 학기 시작 가능합니다.

미승인 휴학(학교 통지 X)은 Course Progress 위반으로 비자 취소됩니다. 반드시 학교 승인 받으세요. 추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학교 통지 없이 한국행 권유**
   → Course Progress 위반 → 비자 취소.

2. **Compelling Reasons 무시**
   → 단순 여행 = LOA 거부.

3. **증빙 한국어 제출**
   → 영문 번역(NAATI 권장) 필수.

4. **LOA 비자 영향 인식**
   → 적절한 LOA = 비자 영향 X.

5. **LOA 무한 가능 인식**
   → 최대 2년. 초과 시 비자 재신청.

6. **LOA = Cancellation 혼동**
   → LOA = 일시 정지 / Cancellation = 영구 취소.

7. **학비 환불 자동 인식**
   → Refund Policy 학교별. 신청 의무.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 어머니 진단서 영문 번역 가능?
2. LOA 기간 (6개월/1년)?
3. 한국 vs 호주 체류 결정?
4. 복학 의사 명확?

---

## 🔍 직원이 직접 확인 가능한 사이트

- homeaffairs.gov.au (LOA)
- esos.gov.au (학생비자법)
- 각 학교 International Office
- NAATI 번역사 디렉토리

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- LOA 신청 가이드 + 증빙 준비 + 복학 일정

**MARA / 변호사 영역**
- LOA 거부 + 비자 취소 + ART 항소 = MARA Agent.

---

## ✅ 완벽 응대 체크리스트

- [ ] Compelling Reasons 인정 확인
- [ ] 학교 즉시 연락 강조
- [ ] 증빙 영문 번역 의무
- [ ] 비자 영향 X 안심
- [ ] 복학 절차 안내
- [ ] 카카오 상담 신청 유도
