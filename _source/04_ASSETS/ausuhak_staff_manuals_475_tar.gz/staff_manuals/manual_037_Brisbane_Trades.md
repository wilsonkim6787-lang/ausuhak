# 📚 직원 응대 매뉴얼 #037

**케이스: 27세 / 고졸 / Brisbane / Trades (전기/배관/목공) / 5천만 예산 / PR**

---

## 🎬 상황 시뮬레이션

> 27살 고졸이고 손재주 있어요. 호주에서 전기나 배관 같은 기술직으로 영주권 받고 싶어요. Brisbane 좋다고 들었어요. 5천만 예산.

**👉 정답**: **Brisbane TAFE QLD + Trade + 영주권 경로 (Brisbane CBD = Non-regional, 491 비적용 / Gold Coast·Sunshine Coast 등 Regional 이주 시 491 +15점)**

---

## ⚠️ 중요 사실: Brisbane CBD = Non-regional (491 비자 적용 X)

**2019.11.16 이후 이민법 변경**:
- **Non-regional** (491 비자 적용 X): 시드니 (postcode 2000-2234), 멜번 (3000-3207), **브리즈번 CBD (4000-4207)**
- **Regional** (491 +15점): 시드니/멜번/브리즈번 CBD를 제외한 모든 호주 지역
  - QLD Regional: Gold Coast, Sunshine Coast, Cairns, Townsville, Toowoomba, Mackay 등
  - Brisbane 외곽 일부 postcode는 Regional로 분류됨 (immi.homeaffairs.gov.au 공식 postcode 검색 필요)

**즉**: Brisbane 거주 + 학업 + 일은 가능하나, **491 +15점 가산점은 Regional 지역 (Gold Coast/Sunshine Coast 등)으로 이주 후 거주·근무 시에만 적용**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Brisbane = 호주 3대 도시 (Non-regional CBD)

- 인구 약 250만 (호주 3위)
- Brisbane CBD (postcode 4000-4207) = Non-regional → 491 적용 X
- 시드니 대비 학비·생활비 약 15-20% 저렴
- 한국인 적당 (10-15% 수준)
- **PR 가산점 받으려면**: Gold Coast (postcode 4207-4225) / Sunshine Coast (4550-4575) / Toowoomba 등 QLD Regional 지역 거주·근무 필요

### 2️⃣ Brisbane Trade 학교

| 학교 | 종류 | Trade 학비 |
|---|---|---|
| TAFE Queensland | TAFE | $24K~$30K/년 |
| Brisbane North TAFE | TAFE | $20K~$26K/년 |
| Skills Tech Australia | 사립 | $22K~$28K/년 |

### 3️⃣ QLD Trade 직업 + 평균 연봉

| 직업 | ANZSCO | 평균 연봉 |
|---|---|---|
| Electrician | 341111 | $80K~$110K |
| Plumber | 334111 | $75K~$105K |
| Carpenter | 331212 | $70K~$95K |
| Welder | 322311 | $70K~$90K |
| Diesel Mechanic | 321212 | $75K~$95K |

QLD는 광산업 多 = 광산업 Trade는 연봉 더 높음.

### 4️⃣ Apprenticeship 시스템 (호주 견습)

- TAFE Cert III + 호주 회사 견습 4년
- 견습 기간 시급 받음 ($15-$25/시간 견습 단계 따라)
- 견습 마치면 Trade 자격 + 즉시 Trade 시급 ($35~$45/시간)

### 5️⃣ Brisbane Trade + PR 경로

```
ELICOS 6개월 ($6K~$8K)
        ↓
TAFE QLD Cert III + IV (2-3년) + 호주 회사 견습
        ↓ 견습 시급 수입
TRA Skills Assessment
        ↓
485 또는 직접 491 (Regional 491+15)
        ↓
PR (189/190/491)
```

---

## 🎯 정답 경로

### Brisbane TAFE + Trade + PR (Regional 지역 거주 권장)

```
한국 IELTS 5.5+ 도달
        ↓
Brisbane ELICOS 6개월 ($6K~$8K)
        ↓
TAFE QLD Cert III in Electrical/Plumbing/Carpentry (2-3년) + Apprenticeship
        ↓ Apprenticeship 시급 ($15-$25/시간)
TRA Skills Assessment + 485 (Bachelor 2년 + Regional Cat 2 +1년 = 3년)
        ↓ Gold Coast/Sunshine Coast 등 QLD Regional 이주 + 일
QLD 정부 491 nomination (+15점) + Regional 학업 +5점
        ↓
PR 신청 (489/190/491)
```

**총 4-5년 / 학비 $40K~$50K + Apprenticeship 시급 수입**

---

## 💡 직원이 학생한테 말할 멘트

> "27세 고졸 + Trade + Brisbane 권역 = 좋은 PR 경로 가능합니다.
> 
> 1. **PR 가산점 주의**: Brisbane CBD (postcode 4000-4207)는 Non-regional이라 491 적용 X. **Gold Coast/Sunshine Coast 등 QLD Regional 지역으로 이주**하면 491 +15점 + Regional 학업 +5점 가능
> 2. **Trade 직업 (MLTSSL)**: 전기 $80-$110K / 배관 $75-$105K / 목공 $70-$95K 평균 연봉
> 3. **Apprenticeship 시스템**: 학교 + 견습 (시급 받으며 학업)
> 4. **TAFE QLD 학비 $24K~$30K** (시드니 대비 효율)
> 5. **485 Second PHEW Extension**: Gold Coast/Sunshine Coast (Cat 2) +1년 연장 가능
> 
> 5천만 예산이면 ELICOS + Cert III 1-2년차 가능, Apprenticeship 시작하면 시급 수입 자급 가능합니다.
> 
> ⚠️ **Apprenticeship 매칭 = 호주 회사 직접 구해야** (윌슨이 매칭 도움 가능). Brisbane CBD에서 학업 → 졸업 후 Gold Coast/Sunshine Coast 이주 권장.
> 
> 카톡으로 알려주세요:
> ① 영어 수준  
> ② 직업 선호 (전기/배관/목공/용접/정비)  
> ③ 한국 손재주 + 일 경험  
> ④ Regional 이주 의향 (Gold Coast/Sunshine Coast)
> ⑤ 신체 조건 (Trade는 체력 必)"

---

## ⚠️ 함정

1. **"Brisbane = 491 +15점"** → ❌ Brisbane CBD = Non-regional. Gold Coast/Sunshine Coast 등 Regional 이주 必
2. **"Cert III만 있으면 PR"** → ❌ Cert III + Cert IV + TRA Skills Assessment 必須
3. **"한국 자격증 인정"** → ❌ 호주 별도 (TRA Skills Assessment)
4. **"Apprenticeship 자동"** → ❌ 직접 호주 회사 구해야
5. **"Trade는 체력만"** → 영어 + 학과 시험도 必
6. **"Brisbane vs Gold Coast 같은 PR 점수"** → Brisbane CBD = Non-regional, Gold Coast = Regional

---

## 📞 카카오 응대 시 필수

1. 영어 수준
2. Trade 선호
3. 한국 일 경험
4. 신체 조건

---

## 🔍 직원 확인 사이트

- TAFE Queensland: tafeqld.edu.au
- TRA: tradesrecognitionaustralia.gov.au
- Apprenticeship: australianapprenticeships.gov.au
