# #408 호주_학생_동물_입양_RSPCA_Pet_렌트_Body_Corp

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주에서 외로워서 강아지나 고양이 입양하고 싶은데, 학생비자라도 가능한가요? RSPCA 가서 데려오면 되는 건가요? 렌트 살고 있는데 집주인이 No Pets라고 하던데, 그리고 졸업하고 한국 데려가려면 어떻게 하나요?"

**직원 멘붕 포인트:**
- 학생비자로 입양 가능한지 모름
- RSPCA vs Animal Welfare League 차이
- Body Corporate / Strata No Pets 규정
- 졸업 후 한국 반입 검역 절차
- Pet Insurance 비용/필요성

---

## ❌ 절대 하지 말아야 할 답

> "학생비자는 입양 못 해요"

→ ❌ ❌ 거짓. 입양은 비자와 무관. RSPCA/AWL/RSPCA 모두 학생비자 OK. 다만 렌트 거주 시 집주인 동의 필수, Body Corp 승인 필요한 경우 多.

---

## ✅ 정답

학생비자도 입양 가능. RSPCA(rspca.org.au), Animal Welfare League, PetRescue 등에서 입양. 입양비 강아지 $300~$700, 고양이 $150~$400. 마이크로칩 + 중성화 포함. 렌트 거주 시 Lease Agreement Pet Clause 확인 + 집주인 동의 (NSW는 2025년부터 No Unreasonable Refusal 법 시행). Body Corporate Strata는 별도 승인. 한국 반입은 검역 6개월 준비 (광견병 항체 검사 + 마이크로칩 + 무광견병 증명).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. RSPCA 입양 절차**
rspca.org.au/adopt → 지역 Shelter 검색 → 동물 프로필 확인 → 방문 예약. Adoption Application 작성 (집 환경 / 거주자 수 / 다른 펫 / 일하는 시간). 인터뷰 + Home Check (일부). 입양비 강아지 $300~$700, 고양이 $150~$400 (마이크로칩 + 중성화 + 1차 백신 포함). 입양 후 14일 Trial - 안 맞으면 반환 가능.

**2. 렌트 거주 Pet Clause + 신법**
표준 Lease Agreement에 'Pets Allowed' 체크 박스 있음. No Pets면 입주 시 조건. 단, 2025년 NSW Residential Tenancies Amendment Act 시행: 집주인이 'Reasonable Grounds' 없이 No Pets 거부 불가. 거부 시 NCAT(Tribunal) 신청. 다만 Body Corp Strata는 별도 (예: 일부 아파트 No Pets By-law 합법). VIC도 비슷한 법 (Renting with Pets 동의 의무). QLD 2022년부터.

**3. Body Corporate / Strata Pet 규정**
아파트(Unit/Apartment) = Strata 관리. Body Corporate(또는 Owners Corporation)가 Pet By-law 결정. 'No Pets' By-law 합법 (Cooper v Body Corp 2020 판례 - NSW). VIC는 2022년부터 No Pets By-law 무효 (모두 허용 원칙). 입주 전 Strata Manager에게 Pet By-law 확인 필수. 거짓 신고 시 강제 퇴거 가능.

**4. 한국 반입 검역 절차**
최소 6개월 준비. 1) 마이크로칩(ISO 11784/11785) 2) 광견병 백신 (마이크로칩 후) 3) 광견병 항체 검사 (RNATT, 0.5IU/mL 이상) - 검사 후 180일 대기 4) 호주 출발 7일 내 수의사 검진 + 무광견병 증명서(Health Certificate) 5) 한국 농림축산검역본부 사전 신고 (qia.go.kr). 비행기 화물칸 케이지. 비용 항공료 $1,500~$3,000 + 검역 $500~$1,000. 일부 항공사 거부 (단두종 강아지: 불독, 시추).

**5. Pet Insurance + 비용 현실**
초기: 입양비 $300~$700 + 사료 $50~$100/월 + 수의사 연 $500~$1,500 + 미용 $80~$150/회. Pet Insurance: Bow Wow Meow, Petplan, RSPCA Pet Insurance. 월 $40~$80 (Accident only) ~ $80~$150 (Comprehensive). 강아지/고양이 일생 비용 $20K~$40K. 학생비자 + 렌트 + 졸업 후 한국행 = 신중 결정 필요.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 거주지 확인 - Lease Agreement Pet Clause + Body Corp By-law 확인 (Strata Manager 연락)
**2단계**: 2단계: 집주인 서면 동의 받기 (이메일 또는 Lease Variation)
**3단계**: 3단계: RSPCA/AWL/PetRescue에서 입양 - Application + Home Check + 입양비
**4단계**: 4단계: 마이크로칩 등록 (Council 등록 의무) + Pet Insurance 가입
**5단계**: 5단계: 졸업 한국 반입 계획 시 - 6개월 전 광견병 항체 검사 시작 (RNATT)

---

## 💡 직원이 학생한테 말할 멘트

> "호주에서 외로움 달래려고 입양 생각하시는군요. 충분히 가능합니다.

학생비자로도 RSPCA(rspca.org.au) 같은 곳에서 입양 가능해요. 강아지 $300~$700, 고양이 $150~$400 정도이고 마이크로칩+중성화 포함이에요.

중요한 건 렌트입니다. Lease에 No Pets면 집주인 서면 동의 필요하고, 아파트 거주면 Body Corporate(Strata) By-law도 확인하셔야 해요. NSW는 2025년부터 집주인이 합리적 이유 없이 거부 못 하게 됐는데 Strata는 별개예요.

그리고 졸업 후 한국 반입은 최소 6개월 전부터 준비하셔야 합니다. 광견병 항체검사 후 180일 대기가 있어요.

일생 비용이 $20K~$40K 들어가는 큰 결정이라, 비자 일정과 졸업 후 진로(한국 귀국 / 호주 잔류) 같이 보고 결정하시는 게 좋아요. 윌슨 카톡(studywilson)에서 종합 상담 도와드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생비자로 입양 안 된다고 안내**
   → ❌ 거짓. RSPCA 등 모두 비자 무관 입양 가능.

2. **NSW에서 집주인이 무조건 No Pets 못 한다고 안내**
   → ❌ 부분 거짓. 합리적 사유 있으면 거부 가능. Strata는 별개로 No Pets 합법.

3. **입양비만 들면 된다고 안내**
   → ❌ 거짓. 일생 비용 $20K~$40K. 사료/수의사/보험/미용 지속 비용.

4. **한국 반입 바로 가능하다고 안내**
   → ❌ 위험. 광견병 항체검사 후 180일 대기 필수. 최소 6개월 준비.

5. **마이크로칩 의무 아니라고 안내**
   → ❌ 거짓. NSW Companion Animals Act 등 모든 주에서 Council 등록 + 마이크로칩 의무.

6. **Pet Insurance 필요 없다고 안내**
   → ❌ 위험. 응급 수술 $5,000~$15,000 케이스 흔함. 보험 없으면 안락사 결정 강요받는 사례 多.

7. **VIC도 NSW처럼 Strata No Pets 가능하다고 안내**
   → ❌ 거짓. VIC 2022년 Owners Corporation Act 개정 - No Pets By-law 무효.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 거주 형태 (House / Townhouse / Apartment-Strata)
2. 거주 주(NSW/VIC/QLD - Pet 법 다름)
3. 졸업 후 계획 (한국 귀국 / 호주 잔류 / 미정)
4. 재정 여력 (월 $100~$300 추가 가능 여부)

---

## 🔍 직원이 직접 확인 가능한 사이트

- RSPCA 입양: rspca.org.au/adopt
- Animal Welfare League: awl.org.au
- PetRescue: petrescue.com.au
- 한국 반려동물 검역: qia.go.kr (검역본부)
- NSW Renting with Pets: fairtrading.nsw.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 졸업 후 진로 (한국 귀국/호주 잔류) + 펫 동반 종합 상담
- 비자 일정과 펫 일생 매칭 컨설팅
- 한국 반입 6개월 준비 일정 코디네이션

**MARA / 변호사 영역**
- Lease 분쟁 (Pet 거부) - NCAT/VCAT/QCAT (Tenancy Tribunal)
- Body Corp By-law 분쟁 - Strata Lawyer
- Pet Insurance 약관 분석 - Insurance Broker
- 한국 검역 통관 - 검역사(Quarantine Agent)

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생비자 입양 가능 (비자 무관) 안내
- [ ] Lease Pet Clause + 집주인 동의 의무 설명
- [ ] Body Corp Strata By-law 별도 확인 안내
- [ ] 주별 Pet 법 차이 (NSW/VIC/QLD) 안내
- [ ] 한국 반입 6개월 준비 + RNATT 안내
- [ ] 일생 비용 $20K~$40K 현실 공유
- [ ] Pet Insurance 권장
- [ ] 윌슨 카톡 종합 상담 유도
