# #438 호주_학생_도박_카지노_Crown_Star_중독_GamblingHelp_BetStop

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니 The Star 카지노에서 친구들이랑 갔다가 빠졌어요. 학비로 쓸 돈 $5,000 다 잃었어요. 멈출 수가 없어요. 한국 부모님께 말 못 하겠고 한국으로 도망가고 싶어요. 도와주세요."

**직원 멘붕 포인트:**
- Gambling Disorder DSM-5 진단
- BetStop (Self-Exclusion Register)
- Gambling Help Online 24/7
- Financial Counsellor 1800 007 007
- 학비 부족 = 학교 Hardship

---

## ❌ 절대 하지 말아야 할 답

> "다음에는 안 가시면 돼요"

→ ❌ ❌ 도박 의존은 의학적 질환. 의지력 평가 X. 즉시 전문 도움 의뢰.

---

## ✅ 정답

긴급 절차: ① BetStop (1800 238 7867 또는 betstop.gov.au) - 호주 정부 Self-Exclusion Register / 모든 카지노+온라인 베팅 자동 차단 / 무료 / 3개월~5년 또는 영구, ② Gambling Help Online 1800 858 858 (24시간 한국어 통역), ③ Financial Counsellor 1800 007 007 (무료 부채 상담), ④ Crown/Star 카지노 직접 Self-Exclusion 신청 = 입장 차단, ⑤ GP - Mental Health Care Plan, ⑥ Gamblers Anonymous (gaaustralia.org.au), ⑦ 학비 - 학교 Hardship Office (대부분 무이자 단기 대여), ⑧ 한국 도주 = 비자 위반 + 부채 호주 추적 가능. ⑨ 자살 사고 시 즉시 Lifeline 13 11 14.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. BetStop**
1800 238 7867 / 호주 정부 / 무료

**2. Gambling Help Online**
1800 858 858 / 24시간 한국어

**3. Financial Counsellor**
1800 007 007 / 무료 부채

**4. Self-Exclusion 카지노**
Crown/Star 직접 신청

**5. 학교 Hardship**
Hardship Office 무이자 대여

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 자살 사고 평가 → 위급 시 Lifeline 13 11 14
**2단계**: 2단계: BetStop 즉시 등록 (모든 카지노+온라인 차단)
**3단계**: 3단계: Financial Counsellor 1800 007 007 부채 상담
**4단계**: 4단계: GP - Mental Health Care Plan
**5단계**: 5단계: 학교 Hardship Office 학비 상담

---

## 💡 직원이 학생한테 말할 멘트

> "도박 의존은 의학적 질환입니다. BetStop 1800 238 7867 즉시 등록하세요 (호주 정부 무료 / 모든 카지노+온라인 자동 차단). Financial Counsellor 1800 007 007 무료 부채 상담 받으세요. 학비는 학교 Hardship Office 단기 무이자 대여 가능합니다. 한국 도주 X 학생비자 위반됩니다. 자살 사고 시 즉시 Lifeline 13 11 14."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **의지력 평가**
   → 윤리 위반

2. **BetStop 유료**
   → 호주 정부 무료

3. **카지노 자체 차단 X**
   → Self-Exclusion 가능

4. **학비 부족 = 비자 즉시 취소**
   → Hardship 옵션

5. **부채 한국 추적 X**
   → 호주 회사 한국 추적 가능

6. **도박 부채 자동 면제**
   → 민사 채무 / 갚아야

7. **Gambling Help 영어만**
   → 한국어 24시간

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 자살 사고 여부 (최우선)
2. 도박 빈도 / 손실 규모
3. 학비/생활비 부족 정도
4. 한국 가족 통보 의향

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('BetStop', 'betstop.gov.au')
- ('Gambling Help', 'gamblinghelponline.org.au')
- ('Financial Counsellor', 'ndh.org.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 자료 안내, 학교 Hardship 의뢰

**MARA / 변호사 영역**
- 비자 영향 X / 부채 변호사 LawAccess

---

## ✅ 완벽 응대 체크리스트

- [ ] 자살 사고 평가 최우선함
- [ ] BetStop 즉시 등록 안내함
- [ ] Financial Counsellor 안내함
- [ ] 학교 Hardship 안내함
- [ ] 한국 도주 X 강조함
- [ ] 한국어 통역 안내함
