# #488 호주_학생_학회_발표_Conference_PhD_PR_Specialist_Qualification

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "박사과정 중인데 호주 학회 발표 기회 생겼어요. 발표 자료 + 논문 저자 등록 어떻게 해요? PR 신청에 도움돼요?"

**직원 멘붕 포인트:**
- 학회 발표 = PhD/연구직 PR Skilled Migration 큰 자산
- 189/190 PR Specialist Education Qualification 가산점
- 논문 저자 호주 대학 Affiliation = 호주 거주 증명
- 학회 비용 학교 RHD Travel Grant $1,500~$5,000 지원
- Census Date 전 출국 권장

---

## ❌ 절대 하지 말아야 할 답

> "학회 발표는 학업이라 비자 무관해요"

→ ❌ PhD/연구 PR 가산점 + 호주 정착 자료. 잘못 안내 시 PR 기회 놓침

---

## ✅ 정답

학회 발표는 PhD/연구 학생에게 PR 신청 시 큰 자산이에요. 189/190 비자 Specialist Education Qualification 가산점 도움됩니다. ORCID 등록 + 호주 대학 + Australia 표기로 거주 증명 보강하세요. 학회 비용은 학교 RHD Travel Grant 신청하면 $1,500~$5,000 지원돼요. 자세한 PR 부분은 윌슨샘과 1:1 상담하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 학회 발표 종류**
Oral: 15~30분 + Q&A
Poster: A0 사이즈
Workshop: 2~4시간
Keynote: 초청 (학생 X)
Abstract 사전 심사

**2. PR 가산점**
Specialist Education (PhD): 10점
Australian Study Requirement: 5점
Professional Year: 5점
Regional Study: 5점
학회 자체 점수 X but 자료

**3. ORCID + Affiliation**
ORCID 무료 (orcid.org)
예: 홍길동, University of Sydney, School of CS, Australia
호주 대학 + Australia 표기 = 거주 증명
PR Genuine Resident 보강

**4. 학회 비용 + 학교 지원**
등록비: $300~$1,500 (학생 50% 할인)
항공: 호주 내 $200~$600 / 해외 $800~$3,000
학교 RHD Travel Grant: $1,500~$5,000
신청: Accept Letter + 견적서

**5. 학회 출장 비자/학업**
호주 내: 영향 X
해외: Multi Entry 학생비자 OK
Census Date 전 출국 권장
Conference Leave 학교 신청
RHD Confirmation 단계 검토

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Abstract 작성 + 학회 제출 → Accept
**2단계**: ORCID 등록 + 호주 대학 + Australia 표기
**3단계**: RHD Travel Grant 신청
**4단계**: Conference Leave 학교 신청
**5단계**: 발표 후 출판 논문 PR 자료 보관

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 학회 발표는 PhD에게 PR 신청 시 큰 자산이에요. ORCID + 호주 대학 + Australia Affiliation으로 거주 증명 보강하세요. 학교 RHD Travel Grant $1,500~$5,000 지원 가능합니다. PR 자세한 부분은 카카오 ID studywilson 으로 1:1 상담하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학회=비자 무관 X**
   → PR 호주 거주 + Specialist 자료

2. **한국 대학 Affiliation X**
   → 호주 대학 표기 = 거주 증명

3. **학회 비용 자비 X**
   → RHD Travel Grant

4. **발표 한국어 X**
   → 학회 표준 영어

5. **Census Date 무시 X**
   → 학비 환불 X

6. **ORCID 안 등록 X**
   → 저자 추적 어려움

7. **학회 후 PR 자동 X**
   → PR 별도 절차 + MARA

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 발표 형식? (Oral/Poster/Workshop)
2. 학회 위치? (호주 내/외)
3. 저자? (1st/Co)
4. RHD Travel Grant? (가능/모름)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ORCID: orcid.org
- USyd RHD: sydney.edu.au/research-students
- ARC: arc.gov.au
- Conference: conference-service.com
- PR Skilled: immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학회 비자/학업 영향
- ORCID 등록 안내
- RHD Travel Grant 안내
- Specialist Qualification 1차 안내

**MARA / 변호사 영역**
- PR Skilled (MARA)
- GTI 858 Top Talent (MARA)
- 학회 비용 Tax Deduction (CPA)
- 논문 출판 분쟁 (Lawyer)

---

## ✅ 완벽 응대 체크리스트

- [ ] Abstract Accept
- [ ] ORCID + 호주 대학 표기
- [ ] RHD Travel Grant 신청
- [ ] Conference Leave
- [ ] 출판 논문 PR 자료 보관
