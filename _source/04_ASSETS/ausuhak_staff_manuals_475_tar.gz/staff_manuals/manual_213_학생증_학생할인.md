# #213 학생증 / 학생 할인

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 학생증 받으면 어디서 할인받을 수 있어요? 한국 학생증도 호주에서 통하나요?"

**직원 멘붕 포인트:**
- 학생증 종류 (Student ID vs ISIC)
- 할인 가능한 곳
- 한국 학생증 인정 여부

---

## ❌ 절대 하지 말아야 할 답

> "학생증 있으면 어디서나 할인돼요!"

→ ❌ **모든 곳 X**. 식당/마트 = 할인 X 대부분.

---

## ✅ 정답

호주 학생 할인: ① **학교 학생증 (Student ID)** = 학교 내 / 일부 외부 ② **ISIC 카드** (International Student Identity Card) = 전 세계 통용 / $30 AUD ③ **할인 가능한 곳**: 대중교통 (학생 정기권) / 박물관 / 갤러리 / 영화관 / 일부 카페 / 옷가게 (UNiDAYS / Student Beans) ④ **한국 학생증** = 호주 인정 X (대부분) ⑤ **온라인**: UNiDAYS / Student Beans (학생 인증 후 옷/IT 할인) ⑥ **대중교통 학생 할인** = 일부 주만 (NSW = X / VIC = X / SA = O / WA = O).

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 학교 학생증 (Student ID)
- 학교 등록 후 발급 (무료)
- 사진 + 학번
- 도서관 / 캠퍼스 출입
- 일부 외부 할인 (학교 제휴)

### 2. ISIC (International Student Identity Card)
- 전 세계 통용
- $30 AUD (1년)
- 박물관 / 항공권 / 호스텔 할인
- 신청: https://www.isic.org

### 3. 할인 가능한 곳
- **대중교통**:
  - VIC: Free Tram Zone / V/Line 학생 X (일반 X)
  - NSW: Opal 학생 카드 (호주 영주권자만)
  - SA: 학생 = 50% 할인
  - WA: SmartRider Student
- **박물관 / 갤러리**: 무료~50% 할인
- **영화관**: Hoyts / Event 학생 할인 ($15 → $13)
- **온라인**: UNiDAYS, Student Beans (Apple, Microsoft, Adobe, 옷)
- **항공권**: STA Travel (학생 전용)

### 4. 한국 학생증
- 호주 인정 X (대부분)
- 한국 대학 학생증 = 호주 ISIC 신청 가능

### 5. 대중교통 (주별)
| 주 | 학생 할인 (국제) |
|----|--------|
| NSW (시드니) | ❌ (영주권자만) |
| VIC (멜번) | ❌ (영주권자만) |
| SA (애들레이드) | ✅ 50% |
| WA (퍼스) | ✅ SmartRider |
| QLD (브리즈번) | ❌ (영주권자만) |
| TAS (호바트) | ✅ |

---

## 🎯 정답 경로

### Step 1: 학교 학생증 발급
- 등록 후 학교에서 무료 발급
- 사진 / 학번 확인

### Step 2: ISIC 카드 신청 (선택)
- $30 AUD / 1년
- 항공권 / 박물관 / 호스텔 할인

### Step 3: 온라인 인증
- UNiDAYS: https://www.myunidays.com
- Student Beans: https://www.studentbeans.com
- Apple / Adobe 학생 할인

### Step 4: 주별 대중교통
- 본인 거주 주 확인
- SA / WA / TAS = 학생 할인 OK

---

## 💡 직원 멘트

> "안녕하세요! 학생 할인 안내드릴게요.
>
> ✅ 학교 학생증 = 등록 후 무료 발급
> ✅ ISIC 카드 = $30 / 전 세계 통용
> ✅ UNiDAYS / Student Beans = 온라인 학생 할인
> ✅ 대중교통: SA / WA / TAS = 학생 할인 / NSW / VIC = X
>
> 도착해서 학교 등록하면 학생증 자동으로 받으세요!
>
> 더 궁금하시면 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 5개

1. ❌ "모든 주 학생 할인" → ✅ NSW/VIC/QLD = 국제학생 대중교통 할인 X
2. ❌ "한국 학생증 호주 인정" → ✅ 호주 인정 X
3. ❌ "ISIC 무료" → ✅ $30 AUD
4. ❌ "식당 학생 할인" → ✅ 식당 = 할인 X 대부분
5. ❌ "학생증 = 신분증" → ✅ 술/담배 구매 시 ID (여권/면허) 별도 필요

---

## 📞 필수 3가지 확인

1. ✅ 거주 주 (대중교통 할인 가능 여부)
2. ✅ 학교 학생증 발급 절차
3. ✅ ISIC / UNiDAYS 안내

---

## 🔍 직원 사이트

- **ISIC**: https://www.isic.org
- **UNiDAYS**: https://www.myunidays.com
- **Student Beans**: https://www.studentbeans.com
- **NSW Opal Concession**: https://transportnsw.info

---

## 🚨 직원 vs 윌슨

**직원**: 학생 할인 종류 안내
**윌슨**: 1:1 상담 (할인 외 비자 / 학교 통합 안내)

---

## ✅ 체크리스트

- [ ] 학교 학생증 / ISIC 안내
- [ ] 거주 주 대중교통 할인 안내
- [ ] 온라인 (UNiDAYS / Student Beans) 안내
- [ ] 한국 학생증 호주 인정 X 명시
