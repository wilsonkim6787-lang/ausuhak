# #226 호주 처방전 / 약국 (PBS)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 약국 가서 감기약 사고 싶은데... 한국이랑 다른가요? 처방전 필요해요?"

**직원 멘붕 포인트:**
- 호주 약국 (Pharmacy / Chemist)
- OTC vs Prescription
- PBS (Pharmaceutical Benefits Scheme)

---

## ❌ 절대 하지 말아야 할 답

> "한국 약 그대로 쓰세요. 호주 약은 비싸요!"

→ ❌ **한국 약 호주 반입 = 일부 제한 (마약류 / 항생제 신고 의무)**.

---

## ✅ 정답

호주 처방전 / 약국: ① **OTC (Over-the-Counter)** = 처방전 X / 일반의약품 (감기약 / 진통제 / 알레르기) ② **Prescription** = 처방전 필수 (항생제 / 호르몬제 / 정신과 약) ③ **PBS** (Pharmaceutical Benefits Scheme) = 영주권자 / 시민권자 처방약 할인 ($31.60 / 일반) ④ **OSHC = PBS X** (학생 자비 / 일부 환급) ⑤ **약국 (Chemist Warehouse / Priceline / Terry White)** = 24시간 약국 일부 ⑥ **GP 처방 → 약국 조제**. 한국 약 반입 신고.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. OTC (Over-the-Counter) - 일반의약품
- 처방전 X
- 감기약 / 진통제 (Panadol / Nurofen)
- 알레르기 (Telfast / Zyrtec)
- 비타민 / 영양제
- 약사와 상담 (10분 내)

### 2. Prescription - 처방약
- GP 처방전 필수
- 항생제 / 호르몬제 / 정신과 약 / 강한 진통제
- PBS 약 / 일반 약 구분
- 처방전 = 반복 처방 (Repeats) 가능

### 3. PBS (Pharmaceutical Benefits Scheme)
- 호주 정부 처방약 보조
- 영주권자 / 시민권자 / RHCA 협정국
- **일반**: $31.60 (2025)
- **Concession (저소득)**: $7.70
- 학생비자 = PBS 적용 X (자비)

### 4. 약국 종류
- **Chemist Warehouse**: 대형 / 가격 저렴
- **Priceline**: 미용 + 약
- **Terry White**: 처방 전문
- **TerryWhite Chemmart**: 종합

### 5. 한국 약 호주 반입
- **신고 필수**: 항생제 / 마약류 (모르핀 / 코데인 등) / 정신과 약
- **신고 X 가능**: 일반 OTC (감기약 / 진통제)
- 한국 처방전 영문 번역 권장
- 호주 GP에서 호주 약으로 재처방 권장

---

## 🎯 정답 경로

### Step 1: 증상 확인
- 가벼움 → OTC (약국 직접)
- 강함 / 만성 → GP 진료 → 처방전

### Step 2: 약국 방문
- 약사 상담 (OTC)
- 처방전 제출 (Prescription)

### Step 3: PBS / OSHC
- 영주권자 → PBS 자동 (Medicare 카드)
- 학생 → 자비 / OSHC 일부 환급

### Step 4: 한국 약 반입
- 입국 시 신고 (Customs Declaration)
- 영문 처방전 / 의사 진단서

---

## 💡 직원 멘트

> "안녕하세요! 호주 약국 안내드릴게요.
>
> ✅ OTC (감기약 / 진통제) = 처방전 X / 약국 직접
> ✅ Prescription (항생제 등) = GP 처방전 필수
> ✅ PBS = 영주권자 처방약 할인 / 학생 X
> ✅ Chemist Warehouse = 대형 / 저렴
> ✅ 한국 약 반입 = 마약류 / 항생제 신고 의무
>
> 만성 약 드시면 호주 GP에서 호주 약으로 재처방 받으세요!
>
> 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 7개

1. ❌ "처방전 자유" → ✅ Prescription 약 = GP 처방
2. ❌ "PBS 학생 적용" → ✅ 학생 = 자비
3. ❌ "한국 약 자유 반입" → ✅ 마약류 / 항생제 신고
4. ❌ "약국 24시간" → ✅ 일부만 (24시 약국 위치 확인)
5. ❌ "OSHC 약값 100% 환급" → ✅ 일부 환급
6. ❌ "한국 처방전 호주 가능" → ✅ 호주 GP 재처방 필수
7. ❌ "감기약 한 박스 = 한국과 동일" → ✅ 호주 = 1주일치 표준

---

## 📞 필수 3가지 확인

1. ✅ 증상 (OTC vs Prescription)
2. ✅ PBS / OSHC 적용 안내
3. ✅ 한국 약 반입 신고 강조

---

## 🔍 직원 사이트

- **PBS**: https://www.pbs.gov.au
- **Chemist Warehouse**: https://www.chemistwarehouse.com.au
- **호주 입국 약 신고**: https://www.tga.gov.au

---

## 🚨 직원 vs 윌슨 vs 의사

**직원**: 약국 / 처방전 일반 안내
**윌슨**: 의료 / OSHC 매칭
**의사 (GP)**: 처방 / 약 변경

---

## ✅ 체크리스트

- [ ] OTC vs Prescription 구분
- [ ] PBS 적용 (영주권자 / 학생) 안내
- [ ] 한국 약 반입 신고 강조
- [ ] GP 처방 안내
- [ ] 카카오톡 1:1 상담 연결
