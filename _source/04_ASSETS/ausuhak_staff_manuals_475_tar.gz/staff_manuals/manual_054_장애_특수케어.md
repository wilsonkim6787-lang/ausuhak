# 📚 직원 응대 매뉴얼 #054

**케이스: 21세 / 시각장애 (저시력) / 호주 어학+학사 / 특수 케어 문의**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 안녕하세요. 21살이고요 시각장애가 있어서 저시력이에요. 호주에서 어학연수랑 학사 진학하고 싶은데, 호주 학교에서 특수 케어 받을 수 있나요? 비자도 받을 수 있을까요?

**👉 직원이 멘붕하는 순간**
- "장애 학생도 호주 학생비자 가능?"
- "건강 진단(Health Examination)에서 거절되나?"
- "학교에서 특수 케어 어떻게 하나?"
- "비용 추가되나?"

**❌ 절대 하지 말아야 할 답**
- "장애 있으면 비자 거절돼요" → **차별 + 틀림. 가능**
- "한국으로 돌아가는 게 좋아요" → **무책임 + 차별**
- "그냥 일반 학생처럼 신청하세요" → **특수 지원 정보 누락**

**✅ 직원이 알아야 할 정답**
**호주는 장애인 차별 금지법(Disability Discrimination Act)** = 학교/비자에서 장애 사유 차별 X. 학생비자 건강 진단 = "공중보건 위협" 또는 "호주 의료비 큰 부담" 시에만 거절. 학교 = **Reasonable Adjustment** (합리적 조정) 의무. 단 **비용 + 케어 수준 학교마다 다름**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 장애 학생 권리 (직원 필수 암기)

**Disability Discrimination Act 1992 (DDA)**:
- 호주는 장애 사유로 교육 / 고용 차별 금지
- 학교는 **합리적 조정 (Reasonable Adjustment)** 의무
- 단 "Unjustifiable Hardship" (학교 운영에 지나친 부담) 시 예외

**Reasonable Adjustment 예시**:
- ✅ 시각장애 → 큰 글씨 자료 / 점자 / 스크린리더
- ✅ 청각장애 → 수어 통역 / 자막 / 노트테이커
- ✅ 학습장애 → 시험 시간 연장 / 별도 시험실
- ✅ 신체장애 → 휠체어 접근 / 엘리베이터

**왜 중요한가?**
"호주 학교가 받아주나?" 물으면 **"법으로 의무 / 단 학교마다 케어 수준 다름"**. 자신감 있게 답해야.

---

### 2️⃣ 학생비자 건강 진단 (Health Examination)

**Subclass 500 신청 시 건강 진단 필수**:

**거절 사유 = 다음 두 가지만**:

**(1) 공중보건 위협 (Public Health Risk)**:
- 활동성 결핵 (잠복결핵 X)
- 일부 전염성 질환

**(2) 호주 의료비 큰 부담 (Significant Cost to Australian Healthcare)**:
- 호주 시스템 5년간 의료비 **약 $86,000 AUD 이상** 예상 시 거절
- 만성 질환 + 지속 치료 필요 + 호주 의료비 큰 부담 케이스

**시각장애(저시력) 케이스**:
- ✅ 일반적으로 비자 영향 X
- ✅ 본인 보유 안경/렌즈/보조기구로 일상 가능 시 OK
- ⚠️ 추가 의료 시술 필요 시만 의료비 평가

**왜 중요한가?**
"장애 = 비자 거절"은 일반화. 정확한 기준 = 의료비 부담 / 공중보건 위협. 시각장애 보통 OK.

---

### 3️⃣ 호주 대학 / 어학원의 장애 학생 지원 (Disability Support)

**모든 호주 대학·TAFE = Disability Support Service 의무 운영**:

**제공 서비스 (예: 호주 시드니대학교 Disability Service)**:
- 1:1 상담 + 학습 계획 수립
- 시험 조정 (시간 연장, 별도 시험실)
- 학습 자료 변환 (점자, 큰 글씨, 음성)
- 노트테이커 / 통역 / 보조 기구
- 캠퍼스 접근성 안내

**신청 절차**:
1. 입학 후 Disability Service 등록
2. 의료 기록 / 진단서 제출 (한국에서 영문 번역 필요)
3. 1:1 미팅 → 개인별 지원 계획(Personal Adjustment Plan)
4. 학기 시작 전 교수진과 조정

**왜 중요한가?**
학생이 "학교에서 케어 어떻게?" 물으면 **"입학 후 학교 Disability Service 등록 → 1:1 지원 계획"** 안내.

---

### 4️⃣ 추가 비용 + 보험

**일반적으로 추가 학비는 X** (Reasonable Adjustment는 학교 의무)

**단 다음은 본인 부담**:
- 개인 보조기구 (점자기, 확대경, 보청기 등)
- 외부 통역사 (학교 제공 외)
- 개인 의료 (안경 교체, 약물 등)

**OSHC (Overseas Student Health Cover)**:
- 학생비자 필수 건강보험
- 일반 의료 커버 (병원 진료, 약값 등)
- ⚠️ **기존 질환(Pre-existing Condition) 12개월 대기**: 학생비자 발급 후 12개월 안에 **기존 장애·질환 관련 치료는 OSHC 미커버**

**대안**:
- Top Cover OSHC = 보험료 ↑ 대신 일부 기존 질환 즉시 커버
- 별도 Private Health Insurance 추가

**왜 중요한가?**
"보험으로 다 커버되나?" 물으면 **"기존 질환 12개월 대기 / Top Cover 또는 추가 보험 필요"** 안내.

---

### 5️⃣ 장애 학생 친화 학교 추천 (직원 참고)

**호주에서 Disability Support 강한 대학**:

| 학교 | 도시 | 특징 |
|---|---|---|
| University of Sydney | 시드니 | Disability Service 큰 규모 / 1860년대부터 운영 |
| Monash University | 멜번 | Accessibility 강함 |
| University of Melbourne | 멜번 | Student Equity & Disability Support |
| UNSW | 시드니 | Equitable Learning Service |
| University of Queensland | 브리즈번 | Student Disability Support |
| RMIT | 멜번 | RMIT Connect Disability Liaison |

**TAFE 중 강한 곳**:
- TAFE NSW: Disability Service 광범위 (CRICOS 00591E)
- TAFE Queensland: 접근성 시설 우수

**왜 중요한가?**
학교 선택이 케어 수준에 큰 영향. 윌슨 19년 경력 기반 = 학생 케이스별 학교 매칭.

---

## 🎯 이 학생에게 안내할 정답 경로

### 옵션 A. 시드니 대학 / UTS / Macquarie + Disability Support 등록

```
한국 의료 기록 영문 번역 + 공증
        ↓
학교 입학 신청 (Disability Service 사전 문의 권장)
        ↓
어학연수 (Direct Entry 학교 / 케어 강한 곳)
        ↓
학사 진학 (Disability Service 등록)
        ↓
1:1 학습 계획 수립 + 시험 조정 + 학습 자료 변환
```

**예상 비용 (시드니 + 학사 3년)**:
- 학사 학비: $40K~$50K x 3 = $120K~$150K
- 생활비: $30K x 3 = $90K
- OSHC + 추가 보험: 약 $1.5K~$3K/년
- 본인 보조 기구: 별도

### 옵션 B. 어학원 + TAFE → 학사 편입 (단계별)

어학연수 → TAFE 디플로마 → 학사 편입 = 단계별 적응 + Reasonable Adjustment 학교 익힘

### 옵션 C. 도시별 비교 (Adelaide / Brisbane = 학비 ↓)

시드니 외 도시도 Disability Support 강한 학교 多. 학비 절약 + 케어 동일.

---

## 💡 직원이 학생한테 말할 멘트 (예시)

> "안녕하세요. 호주 유학 결정 응원합니다. 정확한 정보 드릴게요.
> 
> 1. **호주는 장애인 차별 금지법으로 학교 / 비자에서 차별 못 합니다.** 시각장애로 인한 비자 거절 거의 없어요.
> 
> 2. **모든 호주 대학·TAFE = Disability Support Service 의무 운영**. 큰 글씨 자료 / 시험 시간 연장 / 노트테이커 등 지원 가능.
> 
> 3. **건강 진단은 의료비 부담 큰 케이스만 거절**입니다. 시각장애(저시력) + 본인 보조기구로 일상 가능하시면 보통 OK.
> 
> 4. **학교 보험(OSHC)은 기존 질환 12개월 대기**가 있어요. Top Cover 또는 추가 보험 필요할 수 있어요.
> 
> 5. **학교 선택이 케어 수준에 영향 큽니다.** 시드니대학교 / Monash / UTS = Disability Support 강한 곳.
> 
> 정확한 학교 매칭 + 비자 + 의료 기록 패키지는 윌슨이 직접 카톡 상담으로 드립니다. 다음 5가지를 알려주시면 됩니다:
> 
> ① 본인 의료 기록 (영문 번역 가능?)  
> ② 일상 생활 보조 도구 (현재 사용 중인 것)  
> ③ 희망 전공 + 도시  
> ④ 영어 점수 (IELTS 등)  
> ⑤ 출국 희망 시기
> 
> 윌슨 상담 예약 도와드릴까요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1. "장애 = 비자 거절"
- ❌ 의료비 큰 부담 / 공중보건 위협만 거절. 일반 장애 OK.

### 함정 2. "학교가 거부할 수 있다"
- ❌ DDA 법으로 차별 X. 단 케어 수준은 학교마다 차이.

### 함정 3. "추가 학비 내야 한다"
- ❌ Reasonable Adjustment는 학교 의무 = 무료. 개인 보조 기구만 본인 부담.

### 함정 4. "OSHC가 다 커버한다"
- ❌ 기존 질환 12개월 대기. Top Cover 추가 필요할 수 있음.

### 함정 5. "윌슨이 의료 기록 영문 번역도 해준다"
- ⚠️ 윌슨은 학교/비자 컨설팅. 의료 기록 번역은 공인 번역사 영역.

---

## 📞 카카오 응대 시 필수 5가지 확인

1. **본인 장애 정도 + 일상 보조 도구**
2. **한국 의료 기록 보유 여부** (영문 번역 가능?)
3. **희망 전공 + 도시**
4. **영어 수준** (IELTS / 토익)
5. **출국 희망 시기 + 예산**

---

## 🔍 직원이 직접 확인 가능한 사이트

| 정보 | 사이트 |
|---|---|
| 호주 장애인 차별 금지법 (DDA) | humanrights.gov.au/our-work/disability-rights |
| 학생비자 건강 진단 가이드 | immi.homeaffairs.gov.au/help-support/meeting-our-requirements/health |
| 시드니대학교 Disability Service | sydney.edu.au/students/disability-support.html |
| Monash Accessibility | monash.edu/equity-and-diversity |
| OSHC Pre-existing Condition | health.gov.au |

---

## ✅ 이 케이스 응대 체크리스트

- [ ] 호주 DDA 법으로 차별 X 안내했나?
- [ ] 학생비자 건강 진단 거절 사유 (의료비/공중보건) 안내했나?
- [ ] 학교 Disability Support 의무 운영 안내했나?
- [ ] Reasonable Adjustment 무료 안내했나?
- [ ] OSHC 기존 질환 12개월 대기 안내했나?
- [ ] Disability Support 강한 학교를 추천했나?
- [ ] 의료 기록 영문 번역 필요 안내했나?
- [ ] 차별적 발언 없이 응대했나?
- [ ] 윌슨 1:1 상담 예약을 유도했나?
- [ ] 학생 추가 정보 5가지를 요청했나?
