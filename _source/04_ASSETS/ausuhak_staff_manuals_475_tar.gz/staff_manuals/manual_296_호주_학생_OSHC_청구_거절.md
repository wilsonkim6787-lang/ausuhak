# #296 호주_학생_OSHC_청구_거절

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "OSHC 보험 들었는데 병원비 청구했더니 거절됐어요. 11개월 사용했는데 왜 거절되죠?"

**직원 멘붕 포인트:**
- OSHC가 모든 의료비를 커버한다고 착각하기 쉬움
- Pre-existing condition 12개월 대기기간 모르면 답변 못함
- Public vs Private 병원 차이도 청구 영향
- 직원이 보험 약관 모르고 답하면 학생 분쟁 더 커짐
- 직원이 '보험사에 항의해라'고 말하면 책임 회피처럼 보임

---

## ❌ 절대 하지 말아야 할 답

> "OSHC는 다 커버되니까 보험사에 다시 청구하세요."

→ ❌ OSHC는 Pre-existing condition 12개월 대기, Elective surgery 제외, Ambulance 일부만 커버 등 거절 사유가 다수 있어 무조건 커버 안 됨. 직원이 약관 모르고 답하면 학생이 윌슨 신뢰 잃음.

---

## ✅ 정답

**OSHC 청구 거절 = 약관 확인 필수**

**거절되는 주요 사유:**
1. **Pre-existing condition (기존 질환) 12개월 대기**
   - 호주 입국 전 진단/치료 받은 질환
   - 12개월 OSHC 가입 후에야 커버
2. **Elective Surgery (선택 수술)**
   - 미용 성형, 라식 등 = 영구 제외
3. **Pregnancy (임신)**
   - 12개월 대기 후 커버
4. **Ambulance**
   - 일부 OSHC만 커버, 약관 확인
5. **Public 병원 외래 (Outpatient)**
   - Medicare 가격 75%만 환급
   - 차액 = 본인 부담 (Gap Fee)
6. **처방약 (PBS Subsidy 없음)**
   - 학생은 Medicare 미가입 → 일반가 전액

**절차:**
1. 학생 → OSHC 약관 (PDS) 확인
2. 거절 사유 (Decline Letter) 받기
3. 이의 신청 (Internal Review)
4. 안 되면 PHIO (Private Health Insurance Ombudsman) 신고

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. OSHC 5개 공식 보험사**
Bupa, Medibank, Allianz, NIB, AHM. 학교 추천 받아 가입. 비자 기간 전체 커버 필수.

**2. Pre-existing Condition 정의**
OSHC 가입일 기준 6개월 이내에 증상/진단/치료 받은 질환. 12개월 가입 후에야 커버 시작.

**3. Public vs Private 병원**
Public Hospital = Medicare 가격 100% 커버 (Bulk Bill 시), Private = 차액 발생 가능.

**4. Gap Fee**
OSHC 환급액과 실제 비용 차이. GP 진료비 $80 중 $40만 환급 → $40 본인 부담.

**5. PHIO (옴부즈만)**
Private Health Insurance Ombudsman. 보험사 분쟁 무료 조정. www.ombudsman.gov.au, 1300 362 072.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **거절 사유 확인** - 보험사에 Decline Letter 서면 요청 (이메일/우편)
**2단계**: **약관 검토** - PDS (Product Disclosure Statement) 직접 확인 / 거절 사유 약관 위치 찾기
**3단계**: **Internal Review 신청** - 보험사 내부 이의 신청 (45일 처리)
**4단계**: **PHIO 신고** - 내부 이의 거절 시 옴부즈만 무료 신고 / www.ombudsman.gov.au
**5단계**: **근본 해결** - Pre-existing condition이면 12개월 대기 후 재청구 / 보험 갱신 시 약관 자세히 확인

---

## 💡 직원이 학생한테 말할 멘트

> "OSHC 청구 거절은 약관 사유에 따라 다릅니다. 1) 보험사에 Decline Letter 서면 요청 → 2) 거절 사유 확인 → 3) 이의 신청 → 4) 안 되면 PHIO 무료 신고가 표준 절차입니다. 가장 흔한 거절 사유는 Pre-existing Condition 12개월 대기입니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **OSHC = 한국 건강보험과 같다**
   → 한국 건보 = 거의 무제한, OSHC = 약관 제한 많음. 직접 비교 금지.

2. **Bulk Bill 안 된 GP = 무조건 청구 가능**
   → Bulk Bill 안 한 GP는 차액 (Gap Fee) 본인 부담. 전액 환급 X.

3. **OSHC가 응급실도 커버한다**
   → Public Hospital 응급실 = Medicare 가격 환급. Private Emergency = 본인 부담 큼.

4. **학생 부양가족 OSHC도 같다**
   → Family OSHC = 별도 가입. Single OSHC로 가족 청구 X.

5. **처방약도 OSHC가 다 커버**
   → 처방약 = OSHC 일부만 커버. 학생은 PBS (정부 보조) X → 일반가 전액.

6. **12개월 대기는 보험사 임의 규정**
   → 12개월 대기 = 호주 정부 PHIA 법정 규정. 모든 OSHC 동일 적용.

7. **이의 신청하면 다 받아준다**
   → 내부 Review 거절률 약 30%. 자동 인정 X. PHIO 신고가 더 효과적.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 어느 OSHC 가입했는지 (Bupa/Medibank/Allianz/NIB/AHM)
2. 거절 받은 청구 항목 (병원비/약값/응급실/수술 등)
3. 거절 사유 서면 (Decline Letter) 받았는지
4. Pre-existing Condition 해당 가능성 있는지 (호주 오기 전 진단 받은 질환)

---

## 🔍 직원이 직접 확인 가능한 사이트

- PHIO (옴부즈만): www.ombudsman.gov.au/health-insurance
- PHIO 전화: 1300 362 072 (한국어 통역 가능)
- Bupa OSHC 약관: www.bupa.com.au/health-insurance/oshc
- Medibank OSHC: www.medibank.com.au/oshc
- Allianz Care: www.allianzcare.com.au/oshc

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- OSHC 보험사 선택 자문 (학교/지역별 적합)
- Pre-existing Condition 신고 전략
- 큰 의료비 발생 시 청구 절차 안내
- 보험 분쟁 시 PHIO 신고 방법 안내

**MARA / 변호사 영역**
- OSHC 강제 가입 위반 (비자 조건 위반) → 이민 변호사
- 보험 사기 청구 (허위 청구) → 형사 변호사
- 의료 사고 + 보험 거절 동시 발생 → 의료 전문 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 거절 사유 (Decline Letter) 서면 확보 안내함
- [ ] PDS 약관 확인 안내함
- [ ] Internal Review 절차 안내함
- [ ] PHIO 무료 신고 가능 안내함
- [ ] Pre-existing Condition 12개월 대기 설명함
- [ ] Public/Private 병원 차이 설명함
- [ ] 윌슨 1:1 상담 유도함
