# #476 호주_학생_주거_화재_Fire_Brigade_000_보험_렌터_Insurance_피해

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "자취방 부엌에서 불 났어요. Fire Brigade 와서 진압했는데 가구 다 타버렸어요. 임차인이라 보험도 없는데 어떻게 해요?"

**직원 멘붕 포인트:**
- 호주 주거 화재 = 000 (Triple Zero) Fire Brigade 즉시
- 임차인은 Renter's Insurance(가입 의무 X) 없으면 본인 가구 손실 자비
- 건물 자체는 집주인의 Building Insurance 커버 (임차인 무관)
- 하지만 화재 원인이 임차인 과실(전기/요리)이면 집주인이 손해배상 청구 가능
- 직원이 'OSHC가 화재 커버' 잘못 안내하면 안 됨 (OSHC = 의료만)

---

## ❌ 절대 하지 말아야 할 답

> "OSHC 들으셨으니까 화재도 보장돼요 다 처리해드려요"

→ ❌ OSHC는 의료 보험. 화재/도난/재산은 별개. 잘못된 안내 시 학생 큰 손실

---

## ✅ 정답

Fire Brigade 진압 끝났으면 Incident Report Number 받으세요. 본인 가구는 Renter's Insurance 없으면 자비 부담입니다(보통 학생들은 미가입). 단, 화재 원인이 집주인 시설(낡은 배선/노후 가스)이면 집주인 책임 청구 가능합니다. 임시 거처는 호스텔/Airbnb 알아보시고, 학교 Student Welfare Office에 긴급 지원 요청하세요. 화재 원인이 본인 과실이면 집주인 Loss of Rent + Repair 청구 받을 수 있어 변호사 자문 필요합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Renter's Insurance (Contents Insurance) 호주 표준**
주요 보험사: NRMA, RACV, AAMI, Allianz, Budget Direct, Youi
월 $20~$40 / 한도 $30,000~$60,000
커버 항목: 본인 가구/전자제품/옷/책 (화재/도난/누수)
Excess: $300~$500 (보험금 청구 시 자기부담)
→ 학생들 90% 미가입. 사고 시 자비 부담

**2. 화재 책임 분담 (호주 임대차)**
건물(벽/천장/바닥/내장 가전): 집주인 Building Insurance
본인 가구/전자제품: 임차인 Contents Insurance (없으면 자비)
화재 원인:
1. 건물 시설(배선/가스 노후): 집주인 책임
2. 임차인 과실(요리/담배): 임차인 책임 + Loss of Rent 청구 가능
3. 자연재해(번개): 양측 모두 보험 처리

**3. 화재 후 즉시 할 일 (호주 표준)**
1. 000 즉시 (이미 함)
2. Fire Brigade Incident Report Number 받기
3. 집주인/Real Estate Agent 즉시 통보 (서면)
4. 사진 촬영 (피해 상황 + 원인 추정)
5. 임시 거처 (호스텔/Airbnb)
6. 학교 Student Welfare 긴급 지원 신청

**4. 화재 원인 조사 (Fire Investigation)**
Fire Brigade가 Cause of Fire 조사
→ 의도적/과실/사고 분류
→ Police Report 발급 (보험 청구 필수)
→ 의심 정황 시 Police 형사 수사
→ Insurance Investigator 별도 조사
임차인 과실 의심 시 진술 시 변호사 동행 권장 (Fair Work Lawyer 제외)

**5. 학생 긴급 지원 (호주 대학 표준)**
Student Welfare / Student Services Office:
USyd: Student Centre 1800 SYD UNI
UNSW: Student Support Advisors
UTS: Student Services
Monash: Care Service
지원 내용: 긴급 자금 대출 $500~$2,000, 임시 숙소 안내, 심리 상담, 학업 연장
Centrelink Disaster Recovery는 PR/시민권자만

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Fire Brigade Incident Report Number 받기 + 사진 촬영
**2단계**: Real Estate Agent / 집주인 서면 통보 (이메일 + 카카오/SMS)
**3단계**: 임시 거처 확보 (Airbnb/호스텔/친구 집) + 영수증 보관
**4단계**: 학교 Student Welfare에 긴급 지원 신청
**5단계**: 화재 원인 본인 과실 의심 시 변호사 자문 → 윌슨샘 1:1 상담

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요 학생님. 무사하셔서 다행이에요. 우선 Fire Brigade Incident Report Number 받으시고, 집주인에게 서면으로 통보하세요. 본인 가구 손실은 Renter's Insurance 없으면 자비라 학교 Student Welfare에 긴급 지원 신청하세요. 화재 원인이 본인 과실이면 집주인 손해배상 청구 가능성 있어서 윌슨샘과 1:1 상담 잡으시는 게 좋습니다. 카카오 ID studywilson 입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **OSHC가 화재 커버 X**
   → OSHC는 본인 의료만. 화재/재산/도난 X. 잘못 안내하면 큰 손실

2. **'집주인이 다 책임' X**
   → 집주인은 건물만 책임. 본인 가구는 본인 책임

3. **'한국 부모 보험으로 처리' X**
   → 한국 보험은 호주 거주자 가구 화재 커버 X. 별개 호주 보험 가입 필요

4. **Bond로 손해 메꾸려 함 X**
   → 임차인 과실 시 Bond로 부족하면 추가 청구 가능. NCAT 분쟁

5. **Police 진술 단독 X**
   → 방화 의심 시 형사 수사. 진술 변호사 없이 단독 시 본인 자백 가능성

6. **화재 후 무조건 Lease 종료 X**
   → Lease 자동 종료 X. 거주 불가 상태면 Frustration of Lease 주장 가능 (NCAT)

7. **긴급 지원 신청 안 하고 부모 송금만 의지 X**
   → 학교 Student Welfare 무료 지원 있음. 부모 부담 줄이기 위해 활용

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Fire Brigade Incident Report Number 받았어요? (받음 / 안 받음)
2. 화재 원인 뭐예요? (요리 / 전기 / 미상 / 방화)
3. Renter's Insurance 가입돼 있어요? (가입 / 미가입)
4. 임시 거처 있어요? (있다 / 없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW Fire and Rescue: fire.nsw.gov.au
- VIC CFA: cfa.vic.gov.au
- QLD Fire: qfes.qld.gov.au
- Renter's Insurance 비교: finder.com.au/contents-insurance
- USyd Student Centre: sydney.edu.au/students

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Fire Brigade Report 발급 안내
- 집주인 서면 통보 작성 코칭
- 학교 Student Welfare 연결
- Renter's Insurance 가입 권유

**MARA / 변호사 영역**
- 임차인 과실 손해배상 변호 (Civil Lawyer)
- Insurance Claim 분쟁 (PHIO 또는 Lawyer)
- Police 진술 동행 (Criminal Lawyer)
- Lease Frustration 분쟁 (NCAT 또는 Lawyer)

---

## ✅ 완벽 응대 체크리스트

- [ ] Fire Brigade Incident Report Number 확보
- [ ] 집주인 서면 통보 완료
- [ ] 임시 거처 + 영수증 보관
- [ ] 학교 Student Welfare 긴급 지원 신청
- [ ] 변호사 자문 결정 + 윌슨샘 1:1 상담 예약
