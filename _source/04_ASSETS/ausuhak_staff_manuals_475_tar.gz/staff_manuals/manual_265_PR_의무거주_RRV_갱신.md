# #265 PR 의무거주 RRV 갱신

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 PR 5년 됐는데 호주 거주 1년밖에 안 했어요. 비자 만료되면 어떻게 하나요?"

**직원 멘붕 포인트:**
- PR Travel Facility = 5년 (재입국 권리)
- 5년 중 2년 호주 거주 = RRV 갱신 자동
- 거주 부족 = RRV 거절 위험
- Compelling Reason = 사유서 + 가족 / 사업

---

## ❌ 절대 하지 말아야 할 답

> "PR 받으면 호주 거주 의무 없어요."

→ ❌ **PR Travel Facility 5년마다 갱신 / 2년 거주 의무**.

---

## ✅ 정답

PR + RRV: ① **PR 자체 = 영구 (입국 후 거주 OK)** ② **PR Travel Facility = 5년** (호주 외 → 재입국 권리) ③ **5년 중 2년 호주 거주 = RRV 자동 갱신** ④ **2년 미만 = RRV 거절 위험** ⑤ **Compelling Reason = 가족 / 사업 / 의료** ⑥ **수수료 약 $445** ⑦ **RRV 1년 또는 5년**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. PR 자체 vs Travel Facility 차이**
PR = 영구 거주권 (영구) / Travel Facility = 호주 외 출국 + 재입국 권리 (5년) / Travel Facility 만료 = PR 자체는 유지 + 호주 외 거주 시 재입국 불가

**2. RRV (Resident Return Visa)**
Travel Facility 만료 후 재입국 위해 신청 / 5년 중 2년 거주 = RRV 5년 / 부족 = 1년 또는 거절 / 호주 외 한국에서 신청 가능

**3. Compelling Reason (사유)**
Australian Citizen Spouse / 호주 사업 / 호주 가족 / 호주 직장 / 의료 사유 / 단순 한국 거주 = 사유 X

**4. 거주 부족 후 입국**
Travel Facility 만료 + 미입국 = 재입국 불가 / 호주 입국 후 = 거주 의무 X / 호주 외 거주 시 갱신 시점 주의

**5. 100 / 191 (Permanent) RRV**
100 (Partner Permanent) / 191 (Skilled Regional) 등 모두 동일 / 5년 Travel Facility / 갱신 동일

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Travel Facility 만료일 확인 (VEVO)
**2단계**: 5년 중 2년 호주 거주 자가 확인
**3단계**: 거주 부족 시 = Compelling Reason 사유서
**4단계**: RRV 신청 (immiAccount, $445)
**5단계**: 심사 1~3개월 → 결과

---

## 💡 직원이 학생한테 말할 멘트

> "PR 자체는 영구이지만 Travel Facility (재입국 권리)가 5년 만료예요. 5년 중 2년 호주 거주하면 RRV 자동 5년 갱신되고, 부족하면 Compelling Reason (가족/사업/의료) 사유서가 필요합니다. 단순 한국 거주는 사유 인정이 어려워요. Travel Facility 만료 + 호주 외 거주 = 재입국 불가가 되니 시점 관리가 중요합니다. 호주 입국 후엔 거주 의무가 없어요. 윌슨님이 1:1로 거주 일수 계산 + 사유서 + RRV 신청 가이드 드려요. 카카오 (studywilson)으로 PR 발효일 + 거주 기록 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **PR = 영원 자동 ❌**
   → Travel Facility 5년 / 갱신 필수

2. **거주 5년 = 100% RRV ❌**
   → 5년 중 2년 거주 = RRV 5년

3. **Compelling Reason = 자동 ❌**
   → 가족 / 사업 / 의료 사유 명확 + 증빙

4. **호주 외 = 무제한 ❌**
   → Travel Facility 만료 = 재입국 불가

5. **RRV = 호주 내만 ❌**
   → 한국에서도 신청 가능

6. **RRV 거절 = PR 끝 ❌**
   → PR 유지 / Travel Facility만 영향

7. **PR = 시민권 = RRV 동일 ❌**
   → 시민권 = RRV 무관 / 영원

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Travel Facility 만료일 + 호주 거주 일수
2. Compelling Reason 가능 여부
3. 한국 / 호주 어디서 신청
4. RRV 5년 vs 1년 결정

---

## 🔍 직원이 직접 확인 가능한 사이트

- DHA RRV: https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/return-resident-155-157
- VEVO: https://immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 거주 일수 계산 1:1
- Compelling Reason 사유서
- RRV 시점 전략

**MARA / 변호사 영역**
- RRV 거절 + ART 항소
- Travel Facility 만료 + 재입국 거절

---

## ✅ 완벽 응대 체크리스트

- [ ] PR vs Travel Facility 차이 명확
- [ ] 5년 중 2년 거주 = RRV 자동
- [ ] Compelling Reason 사유 한정
- [ ] 한국 거주 = 사유 X
- [ ] RRV $445 + 1~3개월
- [ ] 호주 입국 후 = 의무 X
- [ ] 윌슨 1:1 = 사유서 + 시점
- [ ] 윌슨 카카오 자연 유도
