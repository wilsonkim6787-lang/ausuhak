# #506 호주_학생_미지급_임금_Underpayment_Fair_Work_회수_Cash_in_Hand_신고

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한식당에서 6개월 일했는데 시급 $15만 줬어요. Payslip도 안 줬고요. 미지급 임금 회수 가능해요?"

**직원 멘붕 포인트:**
- 최저 시급 $24.95 (2025.07~) - $15는 38% 미달
- Cash-in-Hand 미지급 임금 회수 가능 (Fair Work)
- 노동 시간 증빙 부족이라도 본인 진술 + 동료 진술 활용
- Whistleblower 보호 - 학생비자 노동 시간 위반 면책
- 회수 평균 $3,000~$15,000

---

## ❌ 절대 하지 말아야 할 답

> "Cash로 일했으면 신고해도 못 받아요"

→ ❌ Fair Work는 Cash-in-Hand도 회수 가능. Whistleblower 보호

---

## ✅ 정답

시급 $15는 최저임금 $24.95의 40% 미달이라 명백한 미지급 임금이에요. Fair Work Ombudsman 13 13 94(한국어 통역)에 신고하시면 회수 가능합니다. Cash-in-Hand라도 신고 가능하고 학생비자 노동 시간 위반은 Whistleblower 보호로 면책돼요. 노동 시간 증빙 부족하면 본인 일기/카카오톡 출근 메시지/동료 진술 활용 가능합니다. 회수 금액은 차액 + Casual 25% 할증 + Penalty Rates 토일 + Super 12% (2025.07~) 더해서 $5,000~$20,000+ 가능해요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 최저임금 미지급 계산 (2026)**
최저임금: $24.95/시간 (2025.07~)
Casual 25% 할증: $31.19/시간 (Casual, 25% 가산)
토요일 50% 할증: $36.15
일요일 75% 할증: $42.18
공휴일 150% 할증: $60.25

예시: 6개월 X 25시간/주 X $15 (실제 받음)
= 25 X 26 X $15 = $9,750
정상: 25 X 26 X $31.19 = $19,585
차액: $9,835 미지급

**2. 미지급 임금 회수 절차 (Fair Work)**
1. Fair Work Ombudsman 신고
   - 13 13 94 (한국어)
   - fairwork.gov.au
2. 증빙 수집:
   - 출근 일기/카톡 메시지
   - 동료 진술서
   - 식당 영수증/메뉴 (시간 추정)
3. 고용주 통보 (Letter of Demand)
4. Fair Work Inspector 조사
5. 회수 명령 + 미준수 시 Federal Court
처리 3~12개월

**3. Whistleblower 보호 (학생비자)**
Fair Work Act Section 794:
보호:
- 학생비자 노동 시간 위반 면책
- 비자 취소 X
- 보복 행위 금지 (해고/협박)
Department of Home Affairs:
- Whistleblower Visa Cancellation Policy
- 사기 피해자는 비자 보호
→ '신고 시 비자 취소' 협박 무시

**4. 증빙 부족 시 (Cash-in-Hand)**
Fair Work는 본인 진술 + 정황 증거도 인정:
- 카카오톡 출근/퇴근 보고 메시지
- 동료 진술서 (현재 또는 전직 동료)
- 셀카 사진 (식당 배경 + 시간)
- 은행 입출금 (현금 입금 패턴)
- 식당 SNS/광고 (영업 시간)
- 손님 결제 증거 (영수증 받기)

**5. Super 미지급 + Tax 처리**
Super (퇴직연금) 12% (2025.07~):
- ATO Super Guarantee Charge 신고
- 미지급 시 고용주 벌금 + 이자

Tax 처리:
- Cash-in-Hand도 Tax Return 의무
- Voluntary Disclosure 시 면책
- TFN 발급 후 신고
- ATO Tax Help (무료 자원봉사)

회수 금액:
- 임금 차액
- Penalty Rates
- Super
- 미지급 휴가 (Annual Leave Entitlement)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 증빙 수집 (카톡/일기/동료/식당 정보)
**2단계**: Fair Work 13 13 94 (한국어) 신고
**3단계**: Letter of Demand 작성 (고용주에게)
**4단계**: Fair Work Inspector 조사 협조
**5단계**: 회수 + Tax/Super 정산

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 시급 $15는 최저임금 $24.95의 40% 미달이라 명백한 미지급 임금이에요. Fair Work Ombudsman 13 13 94(한국어)에 신고하시면 회수 가능합니다. Cash-in-Hand도 신고 가능하고 Whistleblower 보호로 학생비자 노동 시간 위반 면책돼요. 회수 금액은 차액 + Casual 할증 + Penalty Rates + Super 더해서 $5,000~$20,000+ 가능해요. 자세한 절차는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Cash-in-Hand 회수 X**
   → Fair Work 회수 가능

2. **증빙 없으면 X**
   → 본인 진술 + 정황 증거 인정

3. **학생비자 신고 못함 X**
   → Whistleblower 보호

4. **$15 흔함 X**
   → 최저 $24.95 (2025.07~) 미달

5. **Payslip 없음 = 정상 X**
   → Payslip 의무

6. **Super 무관 X**
   → Super 12% (2025.07~) 미지급도 회수

7. **Tax 안 했으니 신고 못함 X**
   → Voluntary Disclosure 면책

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 근무 기간? (3개월 미만/3~12개월/12개월+)
2. 주당 시간? (10시간 미만/10~25시간/25시간+)
3. Payslip 받았어요? (받음/안 받음)
4. 동료/카톡 증거 있어요? (있다/없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Fair Work: fairwork.gov.au / 13 13 94
- TIS Korean: 13 14 50
- ATO Super Guarantee: ato.gov.au
- ATO Tax Help (무료): ato.gov.au/tax-help
- Whistleblower Policy: immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Fair Work 한국어 신고 안내
- 증빙 수집 가이드
- Whistleblower 보호 안내
- 회수 금액 1차 계산

**MARA / 변호사 영역**
- Fair Work 신고 (Fair Work Ombudsman)
- Letter of Demand (Lawyer)
- Federal Court 회수 (Lawyer)
- Tax 신고 (CPA Australia)

---

## ✅ 완벽 응대 체크리스트

- [ ] 증빙 수집
- [ ] Fair Work 13 13 94 신고
- [ ] Letter of Demand
- [ ] Tax/Super 정산
- [ ] 회수 + 새 직장
