# #434 호주_학생_스마트폰_분실_도난_iCloud_Find_My_Telstra_Block

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "어젯밤 클럽에서 아이폰 잃어버렸어요. 한국에서 산 폰이고 호주 Telstra 유심 끼워서 쓰고 있었어요. 비자 자료, 카톡, 은행 앱 다 들어있어요. 어떻게 해야 하나요? Find My도 위치 안 나와요."

**직원 멘붕 포인트:**
- Find My iPhone (iCloud Lost Mode)
- Telstra/Optus IMEI Block
- 은행 앱 즉시 차단
- 카카오톡 백업 / 본인인증
- 여권/비자 PDF 재발급

---

## ❌ 절대 하지 말아야 할 답

> "포기하고 새 폰 사세요"

→ ❌ ❌ 즉각 IMEI Block + 은행 차단 = 도난 사용 방지 필수. 시간 골든타임.

---

## ✅ 정답

긴급 절차 (시간 순서): ① iCloud.com Find My → 'Lost Mode' 활성화 (전화번호 + 메시지 표시) / Erase는 마지막 수단, ② Telstra/Optus 콜센터 132 200 / 133 9999 → IMEI Block (다른 유심도 차단), ③ 한국 은행 앱 (카카오뱅크/토스/하나) - 분실 신고 (앱별 메뉴), ④ 카카오톡 - 다른 기기에서 비밀번호 변경 + 본인인증 차단, ⑤ 호주 은행 (CBA/Westpac) 콜센터 - 카드 차단, ⑥ Police Report (131 444) - 보험 청구용, ⑦ 보험 청구 (Travel/Contents Insurance), ⑧ 새 폰 - JB Hi-Fi/Apple Store / 한국에서 보내달라 = 관세 (1,000 USD 초과 시 GST 10%).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Find My iPhone**
icloud.com / Lost Mode 즉시

**2. IMEI Block**
Telstra 132 200 / 다른 유심 차단

**3. 카카오톡 본인인증**
차단 → 도용 방지

**4. Police Report**
131 444 / 보험 청구용

**5. 호주 새 폰 관세**
$1,000 초과 시 GST 10%

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 즉시 iCloud Find My 활성화
**2단계**: 2단계: Telstra/Optus IMEI Block
**3단계**: 3단계: 한국+호주 은행 앱/카드 차단
**4단계**: 4단계: 카카오톡 비밀번호 변경
**5단계**: 5단계: Police Report + 새 폰 구매

---

## 💡 직원이 학생한테 말할 멘트

> "우선 iCloud.com Find My에서 Lost Mode 활성화하세요. Telstra 132 200으로 IMEI Block 신청하세요. 한국+호주 은행 앱 분실 신고하세요. 카카오톡은 다른 기기에서 비밀번호 변경하세요. 시간이 골든타임입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Find My 위치 X = 끝**
   → Lost Mode로 전화번호 표시

2. **Erase 우선**
   → 마지막 수단 (위치 추적 불가)

3. **Telstra 차단 자동**
   → 직접 신고해야

4. **은행 앱 자동 안전**
   → 분실 신고 의무

5. **Police 관할 시드니만**
   → 온라인 가능

6. **새 폰 한국 발송 무관세**
   → $1,000 초과 GST

7. **카톡 자동 로그아웃**
   → 본인인증 차단해야

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 분실 시점/장소
2. iCloud 로그인 상태
3. 은행/카톡 앱 차단 여부
4. Police Report 발급 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('iCloud Find My', 'icloud.com/find')
- ('Telstra Lost Phone', 'telstra.com.au')
- ('Police 신고', 'police.nsw.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 긴급 절차 안내

**MARA / 변호사 영역**
- 비자 영향 X / 무관

---

## ✅ 완벽 응대 체크리스트

- [ ] Find My Lost Mode 즉시 안내함
- [ ] IMEI Block 통신사별 안내함
- [ ] 은행 앱 차단 강조함
- [ ] 카톡 본인인증 차단 안내함
- [ ] Police Report 안내함
- [ ] 새 폰 관세 정보 제공함
