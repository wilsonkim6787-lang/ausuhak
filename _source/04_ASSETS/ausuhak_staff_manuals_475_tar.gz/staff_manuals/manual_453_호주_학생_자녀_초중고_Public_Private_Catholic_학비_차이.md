# #453 호주_학생_자녀_초중고_Public_Private_Catholic_학비_차이

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저는 학생비자로 호주 와서 6세 딸이 같이 와요. 호주 초등학교 보내려는데 Public(공립), Private(사립), Catholic 어떻게 다른가요? 학비는요? 학생비자 자녀라 차별 있나요?"

**직원 멘붕 포인트:**
- 학생비자 자녀 = Full Fee (호주 시민 무료 X)
- Public 학비도 외국인 자녀 부담 ($5K~$15K/년)
- Catholic = 종교 X도 가입 가능 (저렴)
- Selective School (영재학교) 시험 - 한국 학생 흔히 도전
- Private 비자 + 사립 = 연 $40K~$60K 부담
- 직원이 학교 추천 X (학구별/지역별 다름)

---

## ❌ 절대 하지 말아야 할 답

> "공립이 무료니까 공립 보내세요"

→ ❌ 학생비자 자녀는 공립도 유료 / 단순 추천 X / 학생 가족 상황별 결정

---

## ✅ 정답

(1) Public Fee-Paying = $5K~$15K/년 (학생비자 자녀) (2) Catholic = $5K~$10K/년 (종교 무관) (3) Private = $20K~$60K/년 (4) Selective School 시험 - 영재 코스 (5) 학교 결정은 가족 영역

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Public School (공립) 학생비자 자녀 학비**
NSW: $5,400~$7,500/년 (DET International) / VIC: $9,295~$15,520/년 (DET) / QLD: $11,160~$13,260/년 / 학년/주별 상이 / 호주 시민/PR = 무료.

**2. Catholic School**
Catholic Education Office 운영 / 비신자도 가입 가능 (Open Enrolment) / $5,000~$15,000/년 / 학업 수준 Public보다 높은 경향 / 한국 학생 인기.

**3. Private (Independent) School**
Anglican / Uniting / Independent / $20,000~$60,000/년 / Boarding 옵션 / 영국식 / Go8 진학률 비교적 높음 / 시드니 Top10: Sydney Grammar, SCEGGS 등.

**4. Selective High School (영재학교)**
NSW Selective Test 5학년/6학년 응시 / 합격 시 Year 7~12 무료 (시민/PR) 또는 Public Fee (외국인) / 한국 학생 다수 도전 / 시험 영어+수학+논리.

**5. Catchment Zone (학구)**
Public School은 거주지 Catchment Zone 자동 배정 / 외국인은 Catchment 적용 X (선택 가능) / Private/Catholic = 거주지 무관 신청.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 본인 비자 종류 확인 - 학생비자 = 자녀 Full Fee
**2단계**: 2차: 거주지 결정 후 Catchment 학교 + 인근 Catholic + Private 리스트
**3단계**: 3차: 학비 비교 + 학교 방문 (Open Day) + 한국 학생 비율 확인
**4단계**: 4차: ESL/EAL Support 있는 학교 선택 (영어 미숙 자녀)
**5단계**: 5차: Selective School 도전 시 6~12개월 시험 준비

---

## 💡 직원이 학생한테 말할 멘트

> "6세 자녀와 함께 오시는 거 결정하셨네요. 좋은 선택입니다.

**학생비자 자녀 = Full Fee (시민/PR 무료 X)**

**비교:**

| 학교 | 연 학비 | 특징 |
|------|---------|------|
| Public 공립 | $5,400~$15,500 | NSW $5,400~$7,500 / VIC $9,295~$15,520 / QLD $11,160~$13,260 |
| Catholic | $5,000~$15,000 | 종교 무관 가입 가능 / 학업 수준 Public 이상 |
| Private 사립 | $20,000~$60,000 | Go8 진학률 비교적 높음 / Anglican/Uniting 등 |

**Selective School (영재학교):**
NSW에서는 5~6학년에 시험 응시 → 합격 시 Year 7~12 진학. 외국인은 Public Fee 내야 하지만 학업 환경 최고 수준. 한국 학생 다수 도전.

**거주지:**
Public은 거주지 Catchment Zone 자동 배정 (외국인은 선택 가능). Catholic/Private은 거주지 무관.

**ESL Support:**
영어 미숙 자녀는 New Arrivals Program (NAP) / EAL Support 있는 학교 선택. 대부분 Public 학교 운영.

**중요:**
학교 선택은 가족 결정 영역이라 윌슨이 추천 못 드려요. 일반 정보는 안내 가능합니다. 거주 예정 지역 알려주시면 인근 학교 리스트 안내드릴게요.

학생비자 자녀 학비는 **본인 학비와 별도**로 부담 가능한지 재정 계획 미리 하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Public은 무료다**
   → 호주 시민/PR만 무료 / 학생비자 자녀 = $5K~$15K/년

2. **Catholic은 천주교 신자만**
   → Open Enrolment / 비신자 가입 가능 / 종교 수업 의무 정도 차이

3. **Private = 무조건 Go8 진학**
   → Private도 학교별 차이 / Top Tier vs 중하위 / 학비만 비싸다고 진학률 보장 X

4. **Catchment Zone 외국인도 적용**
   → 외국인은 Catchment 무관 / 자유 선택 가능 / Public 학교 신청

5. **Selective School은 호주인만**
   → 외국인 응시 가능 / 합격 시 Public Fee 적용 / 학업 환경 최고

6. **자녀 영어 못해도 바로 Year 1 가능**
   → ESL/EAL Support 있는 학교 선택 / NAP(New Arrivals Program) 별도 / 6개월~1년 적응

7. **학생비자 자녀 = 학생비자 의존자**
   → 학생비자 Subclass 500 = 자녀 Subclass 500 (Dependent) / 본인 비자 만료 시 자녀도 만료

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 거주 예정 주/도시
2. 자녀 현재 학년 (한국 1학년 = 호주 Year 1 보통)
3. 자녀 영어 수준 (ESL Support 필요 여부)
4. 예산 (Public/Catholic/Private 결정용)

---

## 🔍 직원이 직접 확인 가능한 사이트

- deinternational.nsw.edu.au (NSW Public 외국인)
- study.vic.gov.au (VIC Public)
- isq.qld.edu.au (QLD International)
- schools.nsw.gov.au (NSW 학교 검색)
- selectiveschools.nsw.edu.au (NSW Selective)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Public/Catholic/Private 일반 비교
- 학비 일반 정보 (주별)
- Selective School 일반 정보
- ESL Support 일반 안내

**MARA / 변호사 영역**
- 자녀 비자 신청 (Subclass 500 Dependent)
- 학교 등록 후 비자 변경
- 자녀 영주권 신청 (가족 합산)

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생비자 자녀 = Full Fee 강조
- [ ] Public/Catholic/Private 학비 차이 안내
- [ ] Catchment Zone 외국인 무관 안내
- [ ] Selective School 일반 정보
- [ ] ESL/EAL Support 안내
- [ ] 학교 추천 X 명확히 (가족 결정)
- [ ] 거주지 정보 받고 일반 정보 제공
- [ ] 재정 계획 강조 (본인 학비 + 자녀 학비)
