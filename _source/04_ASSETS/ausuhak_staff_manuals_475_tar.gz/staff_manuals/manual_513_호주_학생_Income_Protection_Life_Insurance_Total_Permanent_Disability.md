# #513 호주_학생_Income_Protection_Life_Insurance_Total_Permanent_Disability

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 직장에서 Income Protection 보험 들라는데 뭐예요? Super랑 다른 거예요? 학생도 필요해요?"

**직원 멘붕 포인트:**
- Income Protection: 부상/질병 시 75% 임금 보전
- Life Insurance: 사망 시 가족 보상
- TPD: 영구 장애 시 일시금
- Super 자동 가입 일부 + 별도 추가 가능
- 학생/Casual Job은 자동 X. 본인 결정

---

## ❌ 절대 하지 말아야 할 답

> "학생은 보험 필요 없어요"

→ ❌ 부상/질병 위험 모든 사람. 정보 제공 + 본인 결정

---

## ✅ 정답

Income Protection은 부상/질병으로 일 못 할 때 75% 임금 매월 받는 보험이에요(보통 2년 한도). Life Insurance는 사망 시 가족에게 일시금. TPD는 영구 장애 시 일시금입니다. Super 일부 자동 가입돼 있고, Casual Job은 보통 자동 X예요. 학생도 부상 위험은 있으니 검토 가치 있지만 의무는 아니에요. Super 잔액 확인하시면 자동 가입 여부 알 수 있어요. PR 시민권자가 더 보험 활용 많고, 학생비자는 OSHC + 응급 의료가 우선입니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Income Protection (소득 보호)**
보장:
- 부상/질병으로 일 못 할 때
- 임금의 75% 매월 (Up to $30,000/월)
- Waiting Period: 14~90일
- Benefit Period: 2년/5년/65세까지

비용:
- 월 $50~$200 (나이/직업)
- Tax Deduction 가능

주요 보험사:
- AIA, MLC, TAL, Zurich

**2. Life Insurance (사망 보험)**
보장:
- 사망 시 일시금 ($100,000~$2M)
- 가족/Beneficiary에게 지급
- 자살 12개월 대기 (보통)

비용:
- 월 $20~$100
- 나이 + 흡연 + 건강 평가

Super 자동 가입:
- 일부 Default 가입
- $50,000~$200,000 한도
- Super 잔액에서 차감

**3. TPD (Total Permanent Disability)**
보장:
- 영구 장애 시 일시금
- '일 못 할 정도' 정의 엄격
- $100,000~$1M
- Own Occupation vs Any Occupation

비용:
- Income Protection 결합 시 할인
- 월 $30~$150

Super 자동:
- 일부 Default
- 약 $50,000~$100,000

**4. Super 자동 보험 확인**
MyGov + ATO + Super 계정:
- 잔액 확인
- 보험 카테고리 확인
  - Death Cover (Life)
  - TPD Cover
  - Income Protection (일부)
- 매월 Super 잔액에서 차감
Super Funds 별:
- AustralianSuper, Hostplus, REST
- HESTA (간호/교육)
- 옵션 + 변경 가능

**5. 학생비자 vs PR 보험 차이**
학생비자 (500):
- OSHC 의무 (응급 + 입원 일부)
- Income Protection 자동 X
- Casual Job Super 12% (2025.07~) (소액)
- 보험 선택 (의무 X)

PR/시민권자:
- Medicare 의무
- Super 12% (2025.07~) 정규직
- Income Protection 권장
- Life + TPD 권장 (가족 있는 경우)
- Tax Deduction 활용

유학생 단기 체류 보험 (Bupa Working/OSHC 옵션):
- Income Protection 별도 옵션 일부

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Super 계정 잔액 + 자동 보험 확인 (MyGov)
**2단계**: Income Protection 필요성 평가 (직업/가족)
**3단계**: 보험사 비교 (AIA/MLC/TAL/Zurich)
**4단계**: 월 보험료 + 보장 계산
**5단계**: 본인 결정 + 청약

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. Income Protection은 부상/질병 시 75% 임금 보전 보험이고, Life는 사망 시, TPD는 영구 장애 시 일시금이에요. Super 일부 자동 가입돼 있어서 MyGov로 확인하세요. 학생비자는 OSHC가 우선이고 보험은 선택이에요. PR/시민권자는 Income Protection 권장합니다. 자세한 비교는 보험사 직접 또는 IFA(Independent Financial Adviser) 자문 권장하고, 카카오 ID studywilson 으로 1차 안내 가능해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생 무관 X**
   → 위험 평가 + 본인 결정

2. **Super 자동=충분 X**
   → Default 보장 부족 가능

3. **OSHC=Income Protection X**
   → OSHC 의료, IP 임금 보전

4. **자살 즉시 X**
   → 12개월 대기

5. **Tax Deduction 자동 X**
   → Income Protection만

6. **TPD Own vs Any 무관 X**
   → 정의 다름

7. **Casual Job 자동 X**
   → Super 적립만

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 직업? (학생/Casual/Full-time)
2. 가족 있어요? (없음/배우자/자녀)
3. Super 잔액 얼마? (모름/$5K~$50K/$50K+)
4. Income Protection 가입했어요? (안 함/Super 자동/별도)

---

## 🔍 직원이 직접 확인 가능한 사이트

- MyGov: my.gov.au
- AustralianSuper: australiansuper.com
- Hostplus: hostplus.com.au
- Choice 보험 비교: choice.com.au
- IFA: financialplanningassociation.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Super 자동 보험 1차 안내
- Income Protection vs Life vs TPD 비교
- 학생 vs PR 보험 차이
- Tax Deduction 1차 안내

**MARA / 변호사 영역**
- 보험 청구 (보험사)
- Tax Deduction (CPA)
- IFA 자문 (Financial Planner)
- Super 보험 변경 (Super Fund)

---

## ✅ 완벽 응대 체크리스트

- [ ] Super MyGov 확인
- [ ] 보험 필요성 평가
- [ ] 보험사 비교
- [ ] 본인 결정 + 청약
- [ ] Tax Deduction 활용 (PR)
