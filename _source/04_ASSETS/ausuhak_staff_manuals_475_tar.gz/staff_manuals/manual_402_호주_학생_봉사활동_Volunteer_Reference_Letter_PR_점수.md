# #402 호주_학생_봉사활동_Volunteer_Reference_Letter_PR_점수

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주에서 봉사활동 하고 싶어요. 학생비자로 봉사 가능해요? 일주일에 몇 시간까지요? Reference Letter 받으면 PR 점수에 도움돼요? 추천 단체 있어요?"

**직원 멘붕 포인트:**
- 봉사 시간 제한 모름 (학생비자 48시간 적용 여부)
- 유료 봉사 vs 무료 봉사 구분 모름
- PR 점수 가산 항목 모름
- Reference Letter 형식 모름
- 추천 봉사 단체 모름

---

## ❌ 절대 하지 말아야 할 답

> "봉사활동은 무제한이라 학생비자 48시간 룰 적용 안 돼요!"

→ ❌ 100% 무료 + 합법 단체 봉사만 시간 무제한. 유료 변경 또는 일자리 대체 시 = 위반.

---

## ✅ 정답

**호주 학생비자 봉사활동 가이드 (2026.05 기준)**:

1. **봉사 시간 제한**:
   - 100% 무료 봉사 + 등록된 단체 = 무제한
   - 유료 봉사 = 학생비자 48시간/2주 적용
2. **합법 봉사 조건**:
   - 일자리 대체 X (일자리 시장 영향 X)
   - 등록된 NFP (Non-Profit) 단체
   - 자발적 + 무급
3. **추천 단체**:
   - **Lifeline**: 13 11 14 운영 보조
   - **Salvation Army**: 노숙자 지원
   - **Vinnies (St Vincent de Paul)**: 빈곤층 지원
   - **Red Cross Australia**: 재난 + 응급
   - **Headspace**: 청년 정신건강
   - **OzHarvest**: 음식 재분배
4. **PR 점수 직접 가산 X**:
   - Volunteer = PR 점수 항목 아님
   - 단, 학교 추천서/Job Reference에 도움
5. **Reference Letter**:
   - 봉사 단체 매니저 발급
   - PR 신청 시 Character Reference로 가능

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 학생비자 봉사 합법 조건**
DHA 지침 = 100% 자발 + 무급 + NFP 단체 = 시간 무제한. 단, 일자리 대체 X. 예: 카페에서 무급 일하면 = 위반 (유급 일자리 대체). 자선단체 봉사 = OK.

**2. PR 점수 항목 vs 봉사**
PR 점수 = 나이, 영어, 학력, 호주 학력, 직업 경력, NAATI, 지역 거주. 봉사 = 직접 점수 X. 단, Job Ready Program(JRP) 일부 직업군에서 인정 가능 (간호 보조 등).

**3. Reference Letter 형식**
단체 letterhead, 매니저 서명, 봉사 기간/시간/역할 명시. PR/시민권 신청 시 Character Reference (JP 인증 권장). NAATI 번역 권장 (영문이지만).

**4. 추천 단체 + 활동**
Lifeline 자살예방 상담 (자격증 후), Salvation Army 노숙자 무료 식사, Vinnies 옷·가구 분류, Red Cross 헌혈 캠페인 + 재난 응급, Headspace 청년 멘토링, OzHarvest 음식 배달 + 분류.

**5. 봉사 시간 + 영어 향상**
주 5~10시간 봉사 = 영어 회화 향상에 효과적. 호주 친구 사귀기 좋음. 학교 학점 인정 가능 (Service Learning 과목). UTS/Monash 일부 프로그램.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 도착 후 = 거주지 인근 봉사 단체 검색 (volunteeringaustralia.org).
**2단계**: 2단계: 단체 신청 = 영어 인터뷰 + Police Check (일부 단체).
**3단계**: 3단계: 주 5~10시간 봉사 = 학업 + 봉사 균형.
**4단계**: 4단계: 6개월~1년 후 = Reference Letter 요청.
**5단계**: 5단계: PR 신청 시 Character Reference로 첨부 (JP 인증).

---

## 💡 직원이 학생한테 말할 멘트

> "학생비자로 봉사활동은 100% 무료 + 등록 단체면 시간 무제한이에요. Lifeline, Salvation Army, Red Cross 같은 곳 추천드려요. PR 점수 직접 가산은 안 되지만 Reference Letter로 Character Reference에 도움되고 영어 향상에도 좋아요. 거주지 인근 단체는 volunteeringaustralia.org에서 찾으실 수 있고 자세한 안내는 윌슨님 카톡 상담주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **모든 봉사 = 시간 무제한이라고 단정**
   → 100% 무료 + 등록 NFP만. 유료 + 일자리 대체 = 48시간/2주 적용.

2. **봉사 = PR 점수 가산이라고 안내**
   → 직접 점수 X. JRP 일부 직업군만 가산.

3. **Reference Letter = JP 인증 불필요라고 안내**
   → PR 신청 시 JP 인증 권장. 일부 단체 = 자체 인증.

4. **Lifeline = 즉시 봉사 가능이라고 안내**
   → Lifeline 자살예방 = 자격 교육 (170시간 이상) 후 가능. 즉시 X.

5. **호주 친구 사귀기 = 봉사가 유일하다고 안내**
   → 봉사 외 동아리, 스포츠, Meetup 등 다양함. 봉사는 옵션 중 하나.

6. **봉사 = 비자 위반 위험이라고 단정**
   → 합법 단체 + 무급 = 위반 X. 일자리 대체만 위반.

7. **Police Check = 학생비자 자격 박탈이라고 오해**
   → Police Check = 단체 자체 절차. 비자와 무관. 결과만 단체에 제출.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 봉사 동기 (영어/PR/사회 기여)
2. 주 가용 시간 (학업 우선)
3. 선호 분야 (의료/사회/환경)
4. 장기 봉사 vs 단기 봉사

---

## 🔍 직원이 직접 확인 가능한 사이트

- volunteeringaustralia.org - 봉사 검색
- lifeline.org.au, salvationarmy.org.au
- vinnies.org.au, redcross.org.au
- headspace.org.au, ozharvest.org
- homeaffairs.gov.au/visa-500-conditions

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 거주 도시 봉사 단체 안내
- 학업과 균형 안내

**MARA / 변호사 영역**
- PR 신청 시 Character Reference 첨부 = 변호사
- Police Check 인정 = 단체 자체

---

## ✅ 완벽 응대 체크리스트

- [ ] 봉사 시간 무제한 조건 안내
- [ ] 추천 단체 5~6개 안내
- [ ] PR 직접 점수 X 안내
- [ ] Reference Letter 형식 안내
- [ ] JP 인증 권장
- [ ] 영어 향상 효과 안내
- [ ] 윌슨 카톡 상담 유도
