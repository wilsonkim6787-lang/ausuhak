# #440 호주_학생_SNS_스토킹_사이버_폭력_eSafety_Commissioner_Image_Based

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "전 남친이 카카오톡으로 매일 욕하고 인스타그램 사진을 다른 사람들한테 뿌리고 있어요. 사적 사진도 있어서 너무 무서워요. 호주에서 신고 가능한가요? 한국 가서 신고해야 하나요?"

**직원 멘붕 포인트:**
- eSafety Commissioner (호주 정부)
- Image-Based Abuse (Revenge Porn)
- Online Safety Act 2021
- Cyberbullying 학생 대상
- 한국 vs 호주 관할 분쟁

---

## ❌ 절대 하지 말아야 할 답

> "한국 사람이 한국에서 한 거면 한국에서 신고하세요"

→ ❌ ❌ 호주 거주자 피해 = 호주 eSafety Commissioner 관할 가능. Online Safety Act 2021 글로벌 적용.

---

## ✅ 정답

긴급 절차: ① eSafety Commissioner (esafety.gov.au) - 호주 정부 / 무료 / 24시간 신고, ② Image-Based Abuse - 사적 사진 동의 없이 공유 = 호주에서 형사 처벌 ($111K 벌금/7년 징역), ③ Online Safety Act 2021 - 24시간 내 콘텐츠 삭제 명령 (인스타/페북/카톡 의무 준수), ④ 1800 RESPECT (1800 737 732) - 24시간 한국어 통역, ⑤ 호주 경찰 신고 (131 444) - 형사 사건 가능, ⑥ 한국 가해자 = 호주 법 적용 가능 (호주 거주 피해자 보호), ⑦ 증거 캡처 (스크린샷 + URL + 시간), ⑧ 카톡/인스타 신고 + 차단, ⑨ AVO 신청 (Local Court 무료) - 가해자 호주 입국 시 차단.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. eSafety Commissioner**
esafety.gov.au / 호주 정부 무료

**2. Image-Based Abuse**
사적 사진 = 형사 처벌

**3. Online Safety Act 2021**
24시간 콘텐츠 삭제

**4. AVO**
Local Court 무료 / 가해자 차단

**5. 1800 RESPECT**
1800 737 732 / 한국어 24시간

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 즉시 증거 캡처 (스크린샷 저장)
**2단계**: 2단계: eSafety Commissioner 온라인 신고
**3단계**: 3단계: 카톡/인스타 직접 신고 + 차단
**4단계**: 4단계: 1800 RESPECT 한국어 상담
**5단계**: 5단계: AVO 신청 (가해자 호주 차단)

---

## 💡 직원이 학생한테 말할 멘트

> "eSafety Commissioner (esafety.gov.au) 호주 정부 무료입니다. 증거 캡처 먼저 하시고 신고하세요. 사적 사진 공유는 호주에서 형사 처벌 ($111K 벌금/7년 징역) 가능합니다. 1800 RESPECT 한국어 통역 24시간 무료입니다. 한국 가해자도 호주 법 적용 가능합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 사건 호주 X**
   → 호주 거주자 피해 호주 관할

2. **eSafety 영어만**
   → Free Translating 13 14 50

3. **증거 없으면 신고 X**
   → 캡처 즉시 / 가능

4. **한국 가해자 처벌 불가**
   → 호주 법 적용 가능

5. **AVO 호주 영주권자만**
   → 학생비자도 가능

6. **카톡/인스타 신고 무용**
   → Online Safety Act 의무 준수

7. **Image-Based Abuse = 가벼운 사건**
   → 형사 처벌 중대

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 즉각 위험도
2. 사적 사진 유포 여부
3. 가해자 한국/호주 거주
4. 증거 캡처 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('eSafety Commissioner', 'esafety.gov.au')
- ('1800 RESPECT', '1800respect.org.au')
- ('AVO Local Court', 'localcourt.nsw.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 신고 절차, 자료 안내

**MARA / 변호사 영역**
- 형사 사건 변호사 / Family Violence Provision

---

## ✅ 완벽 응대 체크리스트

- [ ] eSafety Commissioner 강조함
- [ ] 증거 캡처 즉시 안내함
- [ ] Image-Based Abuse 형사 처벌 안내함
- [ ] 1800 RESPECT 한국어 안내함
- [ ] AVO 학생비자 가능 명시함
- [ ] Online Safety Act 글로벌 적용 안내함
