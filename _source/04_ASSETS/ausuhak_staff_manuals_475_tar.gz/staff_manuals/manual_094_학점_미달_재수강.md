# 📚 직원 응대 매뉴얼 #094

**케이스: 22세 / 호주 대학 1학년 / 3과목 F 학점 / "다음 학기 잘릴까봐"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니대 1학년인데 첫 학기에 4과목 중 3과목 F 받았어요. 영어가 너무 어려워요. 학교에서 'Academic Probation' 통보 왔는데 무슨 뜻이에요? 다음 학기에 잘릴까요?

**👉 직원이 멘붕하는 순간**
- "Academic Probation?"
- "재수강?"
- "비자 영향?"
- "퇴학?"

**❌ 절대 하지 말아야 할 답**
- "F 3개면 자동 퇴학" → **틀림. 절차 있음**
- "재수강하면 OK" → **부분 사실. 학업 진척도 영향**
- "걱정 마세요" → **부정확. 위험 실재**

**✅ 직원이 알아야 할 정답**
호주 대학 = **Academic Progress 조건** 엄격. F 학점 다수 시 **3단계 처분**:
1. **Academic Probation (학업 보호 관찰)** = 1차 경고
2. **Academic Suspension (학업 정지)** = 1~2학기 중단
3. **Academic Exclusion (학적 박탈)** = 사실상 퇴학

학생비자 = **학업 진척도 (Course Progress)** 의무. F 학점 = **재수강 + Compelling 사유**로 회복 가능. **Probation = 1차 경고 단계, 즉시 퇴학 X**. 학교 절차 + Student Union + 윌슨 영역. Suspension/Exclusion 단계 = 변호사.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 대학 Academic Progress - 학업 진척도 의무

**답**: 호주 대학 모두 **Academic Progress 정책** 보유. 학교별 기준 다름.

**일반적 기준 (학교별 변동)**:
- **Pass Rate**: 학기당 50% 이상 합격 의무
- **GPA**: 4.0 이상 (7점 만점) 또는 1.5 이상 (4점 만점)
- **연속 2학기 미달** = Probation
- **3학기 연속 미달** = Suspension
- **4학기 연속 미달** = Exclusion

**시드니대 기준 (예시)**:
- 학기당 50% 미만 합격 = "At Risk"
- 2학기 연속 미달 = Show Cause (사유 소명 의무)
- 3학기 연속 미달 = Exclusion 검토

**근거**: Higher Education Standards Framework + 대학 자체 정책.

### 2️⃣ Academic Probation - 1차 경고 단계

**답**: Probation = "보호 관찰", 회복 기회 단계.

**Probation 의미**:
- 1차 경고 (Warning)
- 다음 학기 의무 사항 부과
- 학업 카운슬링 의무
- Show Cause Letter (사유 소명서) 제출 가능

**Probation 의무 사항 (학교별 다름)**:
- 다음 학기 모든 과목 합격
- 주당 학습 시간 보고
- 튜터링 / Academic Support 의무 참여
- 정기 학업 카운슬러 면담

**핵심**: Probation = **회복 가능 단계**. 다음 학기 회복하면 종결.

**한국 학생 흔한 오해**: "Probation = 정학" X. **경고 단계**일 뿐.

### 3️⃣ Academic Suspension vs Exclusion 차이

**답**: Suspension = **일시 중단** (1~2학기). Exclusion = **학적 박탈** (사실상 퇴학).

**Suspension (정학)**:
- 1~2학기 강제 휴학
- 학적 유지
- 정학 후 재입학 가능 (조건 충족 시)
- **CoE 일시 정지** → 학생비자 영향

**Exclusion (학적 박탈)**:
- 학적 자동 박탈
- 같은 학과 재입학 X (보통 2~5년)
- **CoE 취소** → 학생비자 즉시 영향
- 다른 학교 / 다른 학과 전과 가능

**비자 영향**:

| 단계 | CoE 영향 | 비자 영향 |
|---|---|---|
| At Risk | X | X |
| Probation | X | X |
| Show Cause | X (소명 진행 중) | X |
| Suspension | 일시 정지 | 휴학 협의 가능 |
| **Exclusion** | **취소** | **NOICC 발송 → 28일 답변** |

### 4️⃣ Show Cause Letter - 사유 소명서 작성법

**답**: Show Cause = 학생이 학교에 **"왜 학업 미달인지 + 향후 회복 계획"** 제출.

**Show Cause 구조**:
1. **학업 미달 사유**
   - 영어 어려움 (구체적)
   - 가족 사정 (사망, 질병)
   - 본인 건강 (의사 진단서)
   - 호주 적응 어려움 (첫 학기 일반)
   - 학습 방법 차이 (한국 vs 호주)

2. **반성 + 책임 인정**
   - 변명 X
   - 구체적 실수 인정

3. **향후 회복 계획**
   - 영어 보충: ELICOS 추가 / 영어 튜터링
   - 학업 지원: Academic Skills Centre
   - 시간 관리: 주간 학습 계획
   - 멘탈 관리: GP / Counselling

4. **외부 지원 계획**
   - 학교 튜터링 신청 증빙
   - 가족 지원 (재정, 정서)
   - 윌슨 1:1 학업 상담

5. **학업 의지 강조**
   - 코스 완수 의지
   - 직업 목표 (간호사, 회계사 등)

**Show Cause 한국어 초안 → 영어 번역 → Student Union 검토 권장**.

### 5️⃣ 학업 회복 전략 - 5가지

**답**: F 학점 회복 = **재수강 + 학습 방식 변화**.

**전략 1: 재수강 (Repeat)**
- F 받은 과목 다음 학기 재수강
- 새 학점 = 기존 F 대체
- 추가 학비 발생
- 코스 기간 연장 (CoE 연장)

**전략 2: Course Variation (코스 변경)**
- 같은 학과 내 과목 변경
- 더 쉬운 선택 과목
- 학교 카운슬러 협의

**전략 3: Reduced Study Load (학업 부담 감소)**
- 학기당 4과목 → 3과목
- 학생비자 = 풀타임 의무, 그러나 Compelling 사유 시 가능
- 코스 연장 = CoE 연장

**전략 4: Foundation Year 추가**
- 1학년 = Foundation Year로 전환
- 영어 + 학습 방법 강화
- 1년 추가 학비
- 본과정 진학 시 학점 일부 인정

**전략 5: 코스 변경 (다른 학과)**
- 본인에게 맞는 학과로 전환
- Release Letter + 새 CoE
- 6개월 룰 적용 (1학년 = 적용)

---

## 🎯 이 학생에게 안내할 정답 경로

### 1단계: Academic Probation 통지서 정확히 읽기
- Probation 의무 사항
- Show Cause 마감일
- 학업 카운슬러 면담 일정

### 2단계: 학교 Academic Skills Centre 방문
- 학습 지원 무료 서비스
- 영어 작문 / 시험 준비 / 시간 관리
- 시드니대: Learning Hub (https://www.sydney.edu.au/students/learning-hub)

### 3단계: Show Cause Letter 작성 (윌슨 1:1)
- 한국어 초안
- 영어 번역
- Student Union 검토

### 4단계: 학업 회복 계획 수립
- 재수강 vs 코스 변경 vs Reduced Load
- 영어 보충 (ELICOS / IELTS 학원)
- 튜터링 / 카운슬링

### 5단계: 다음 학기 의무 충족
- 모든 과목 합격 목표
- 주간 학습 보고
- 카운슬러 정기 면담

### 6단계: 학기 종료 후 회복 확인
- Probation 종결
- 또는 Suspension / Exclusion 검토 (회복 실패 시)

---

## 💡 직원이 학생한테 말할 멘트

```
안녕하세요 ○○님.
첫 학기 어려우셨겠어요. 침착하게 회복 가능해요.

먼저 좋은 소식: Academic Probation = 1차 경고예요.
즉시 퇴학 X예요. 회복 기회 단계예요.

호주 대학 학업 처분 3단계:
1. Probation (보호 관찰) ← ○○님 단계
2. Suspension (정학)
3. Exclusion (학적 박탈) - 사실상 퇴학

비자 영향:
- Probation = 비자 영향 X
- Suspension = CoE 일시 정지
- Exclusion = CoE 취소 + 비자 위험

오늘 바로 해주실 일:

1️⃣ Probation 통지서 정확히 읽기
   - Show Cause 마감일
   - 의무 사항 (튜터링, 카운슬링)
   - 윌슨님께 카톡 캡처 전송

2️⃣ 시드니대 Learning Hub 즉시 방문
   - https://www.sydney.edu.au/students/learning-hub
   - 무료 학업 지원 (영어 작문, 시간 관리)
   - 1:1 튜터링 신청

3️⃣ Show Cause Letter 작성 시작
   구조:
   ✅ 학업 미달 사유 (영어 어려움 솔직히)
   ✅ 반성 + 책임 인정
   ✅ 향후 회복 계획
     - 영어 보충 (ELICOS / 영어 튜터링)
     - 학업 지원 (Learning Hub)
     - 시간 관리 (주간 학습 계획)
   ✅ 학업 의지 강조

4️⃣ 학업 회복 전략 결정 (윌슨 1:1)
   - 재수강 vs 코스 변경 vs Reduced Load
   - 영어 보충 ELICOS 추가 가능

5️⃣ Student Union 무료 학업 상담
   - 시드니대 SRC: https://srcusyd.net.au

6️⃣ 멘탈 관리 + 가족 소통
   - GP 방문 (스트레스 / 우울)
   - 부모님과 솔직히 소통
   - 윌슨이 가이드해드려요

다음 학기 회복하면 Probation 종결이에요.
재수강 가능한 과목, 영어 보충 방법
윌슨님과 1:1 상담으로 결정해요.

혼자 숨기지 마세요. 한국 학생 첫 학기 어려움 일반적이에요.
회복한 학생도 많아요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7가지

### 함정 1: "Probation = 정학"
- **사실**: Probation = 보호 관찰, 1차 경고
- 정학 ≠ Probation

### 함정 2: F 3개 = 자동 퇴학
- **사실**: 절차 있음, Show Cause 기회
- Suspension → Exclusion 단계별

### 함정 3: 재수강 = 자동 회복
- **사실**: 재수강 + 학업 진척도 회복 필요
- 학습 방식 변화 필수

### 함정 4: 학생비자 = 풀타임 의무, Reduced Load X
- **사실**: Compelling 사유 시 가능
- 학교 + 이민성 협의

### 함정 5: 영어 어려움 = 약한 사유
- **사실**: 첫 학기 영어 어려움 = Compelling
- 보충 계획과 함께 제시

### 함정 6: 한국 부모께 숨기기
- **사실**: 학비 영향, 코스 연장 = 부모 소통 필수
- 윌슨이 가이드

### 함정 7: ELICOS 추가 = 비자 위반
- **사실**: ELICOS + 본과정 패키지 가능
- CoE 연장 신청

---

## 📞 카카오 응대 시 필수 5가지 확인

### 1. Probation / Suspension / Exclusion 단계
- 학교 통지서 정확히

### 2. F 받은 과목 + 합격 과목
- 학업 진척도 정확히

### 3. 학교 + 학과 + 학년
- 시드니대 / 멜번대 / TAFE 정책 다름

### 4. 영어 점수 (입학 시 + 현재)
- 영어 보충 필요성

### 5. 가족 / 본인 사정 (Compelling)
- 가족 사망 / 의료 / 호주 적응

---

## 🔍 직원이 직접 확인 가능한 사이트

- **시드니대 Academic Progress 정책**: https://www.sydney.edu.au/students/academic-progression
- **시드니대 Learning Hub**: https://www.sydney.edu.au/students/learning-hub
- **멜번대 Academic Progress**: https://policy.unimelb.edu.au
- **UNSW Academic Progress**: https://student.unsw.edu.au
- **Higher Education Standards Framework**: https://www.legislation.gov.au
- **TEQSA Student Complaints**: https://www.teqsa.gov.au/students
- **Commonwealth Ombudsman (외국 학생)**: https://www.ombudsman.gov.au/Internationalstudents

---

## 🚨 직원 영역 vs 윌슨 영역 vs 변호사 영역

### 직원이 할 수 있는 일
- 3단계 처분 일반 안내
- Show Cause Letter 구조 안내
- 학교 학습 지원 정보

### 윌슨 1:1 영역
- Show Cause Letter 한국어 초안 + 영어 검토
- 학업 회복 전략 (재수강 vs 코스 변경 vs Reduced Load)
- 영어 보충 (ELICOS 추가)
- 부모님 소통 가이드

### Student Union 영역 (무료)
- Show Cause 답변서 작성 도움
- 학업 권리 자문

### MARA 변호사 영역
- Suspension / Exclusion 단계 항소
- CoE 취소 후 비자 대응
- ART 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] Probation = 1차 경고, 즉시 퇴학 X 명확히
- [ ] 3단계 처분 (Probation → Suspension → Exclusion) 안내
- [ ] Show Cause Letter 구조 명확히
- [ ] 학교 Learning Hub 즉시 안내
- [ ] Student Union 무료 자문 안내
- [ ] 영어 보충 (ELICOS / 튜터링) 권장
- [ ] 학업 회복 전략 (재수강/변경/Reduced) 옵션
- [ ] CoE 연장 가능성 안내
- [ ] 부모님 소통 윌슨이 가이드
- [ ] 멘탈 헬스 (GP / Counselling) 권장
- [ ] Suspension/Exclusion 단계 = 변호사 즉시
- [ ] 윌슨 1:1 Show Cause 검토 권장

---

## 📌 윌슨 19년 경력 기반 정리

> **첫 학기 학업 미달은 한국 학생들이 가장 자주 직면하는 위기.**
>
> 한국과 호주 학습 차이:
> - 한국: 시험 위주, 암기, 강의 듣기
> - 호주: 에세이, 비판적 사고, 토론, 그룹 과제
> - 한국 학생 첫 학기 = 학습 방식 적응 필요
>
> 핵심 3단계:
> 1. **Probation (보호 관찰)** = 회복 기회
> 2. **Suspension (정학)** = 1~2학기 중단
> 3. **Exclusion (학적 박탈)** = 사실상 퇴학
>
> Show Cause 핵심:
> - **영어 어려움 = 정직하게 인정** (Compelling)
> - **구체적 회복 계획** (튜터링, ELICOS, 학습 방식 변화)
> - **학업 의지** (직업 목표 명확)
>
> 직원 함정:
> - "F 3개 = 자동 퇴학" 잘못된 정보
> - 한국 부모 숨기기 권유 X
> - Reduced Load 옵션 모르기
>
> Probation = 윌슨 + Student Union + 학교 영역.
> Suspension/Exclusion = 변호사 영역.
