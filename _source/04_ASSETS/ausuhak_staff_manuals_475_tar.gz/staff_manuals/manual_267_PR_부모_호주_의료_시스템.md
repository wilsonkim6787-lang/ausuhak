# #267 PR 부모 호주 의료 시스템

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 부모님 870 비자로 호주 모셔왔는데 의료비 너무 비싸요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- 870 = Medicare 자격 X (학생 OSHC도 X)
- Visitor Health Cover 의무
- Bupa / Allianz / Medibank 부모 보험
- PR 부모 = Medicare OK (다른 비자)

---

## ❌ 절대 하지 말아야 할 답

> "Medicare 자동으로 적용됩니다."

→ ❌ **870 = Medicare X / Visitor Health Cover 별도**.

---

## ✅ 정답

부모 비자 의료: ① **870 (임시) = Medicare X** = Visitor Health Cover 의무 ② **143 (영구 PR) = Medicare 자격** ③ **103 = Medicare 자격** (영구) ④ **OSHC ≠ 부모용** (학생 전용) ⑤ **Bupa Visitor Cover** 약 $250/월 ⑥ **고령 + 만성 질환 = 비싸짐** ⑦ **응급실 = 보험 없으면 자비 $1,000+**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 870 + Medicare**
870 비자 = 임시 / Medicare 자격 없음 / Visitor Health Cover 의무

**2. 143 / 103 + Medicare**
143 (영구 Contributory) / 103 (영구) / 발효 즉시 Medicare 자격 / 한국과 호주 의료 보장 비슷

**3. Visitor Health Cover**
Bupa / Allianz / Medibank Visitor Cover / 입원 + 외래 + 응급 / 보통 $200~$400/월 / 만성 질환 가입 거부 가능

**4. 응급실 비용 (보험 없음)**
응급실 진찰 $500~$1,500 / 입원 1박 $2,000+ / 수술 $10,000+ / 보험 가입 절대 권장

**5. PR 부모 의료 활용**
GP 무료 (Bulk Billing) / 전문의 일부 / 응급실 무료 / 입원 무료 (Public Hospital) / 약값 PBS 보조

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 부모 비자 종류 확인 (870 / 143 / 103)
**2단계**: 임시 = Visitor Health Cover 가입
**3단계**: 영구 = Medicare 등록
**4단계**: GP 등록 + 응급 연락처
**5단계**: PBS 등록 (영구 비자만)

---

## 💡 직원이 학생한테 말할 멘트

> "부모 비자 종류에 따라 의료 다르게 적용돼요. 870 (임시 5년)은 Medicare 자격이 없어서 Visitor Health Cover 의무로 가입해야 하고, 143 (영구) 또는 103 (영구)은 Medicare 자격이 있어서 한국 의료보험과 비슷한 보장 받을 수 있어요. Visitor Cover는 보험사 (Bupa/Allianz/Medibank)별로 $200~$400/월 정도이고, 만성 질환은 가입 거부될 수 있습니다. 응급실 무보험 비용이 매우 비싸요. 윌슨님이 1:1로 부모 비자 + 보험 매칭 + GP 등록 가이드 드려요. 카카오 (studywilson)으로 부모 비자 + 건강 상태 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **870 + Medicare ❌**
   → 임시 = Medicare 자격 없음

2. **OSHC = 부모 OK ❌**
   → OSHC = 학생 전용

3. **Visitor Cover = 모두 가입 ❌**
   → 만성 질환 거부 가능

4. **응급실 = 무료 ❌**
   → 보험 없으면 $500~$1,500

5. **Medicare = 즉시 ❌**
   → PR 발효 후 등록 필요

6. **PBS = 모든 약 무료 ❌**
   → Generic Brand 보조 / 일부 자비

7. **부모 + 자녀 보험 동일 ❌**
   → 별도 가입 / 본인 명의

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 부모 비자 종류 (870 / 143 / 103)
2. 한국 의료 기록 + 만성 질환
3. Visitor Cover 예산 ($200~$400/월)
4. GP / 전문의 등록 도움 필요

---

## 🔍 직원이 직접 확인 가능한 사이트

- Bupa Visitor Cover: https://www.bupa.com.au/health-insurance/cover/visitors
- Medicare: https://www.servicesaustralia.gov.au/medicare
- PBS: https://www.pbs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자별 의료 적합도 1:1
- 보험사 매칭 가이드
- GP / 전문의 추천

**MARA / 변호사 영역**
- 보험사 분쟁 + AFCA
- 의료 분쟁 + 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 비자별 의료 권한 차이
- [ ] 870 = Visitor Cover 의무
- [ ] 143 / 103 = Medicare 자격
- [ ] 응급실 무보험 = 매우 비쌈
- [ ] 만성 질환 = 가입 거부 가능
- [ ] PBS = 영구 비자만
- [ ] 윌슨 1:1 = 비자 매칭
- [ ] 윌슨 카카오 자연 유도
