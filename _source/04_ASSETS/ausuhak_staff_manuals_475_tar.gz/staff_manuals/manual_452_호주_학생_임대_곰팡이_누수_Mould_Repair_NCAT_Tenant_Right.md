# #452 호주_학생_임대_곰팡이_누수_Mould_Repair_NCAT_Tenant_Right

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니 셰어 본드(보증금) 내고 입주했는데 화장실 곰팡이가 너무 심해요. 천장에서 물도 새고요. 집주인은 '학생이 환기 안 해서 그렇다'고 책임 안 지려고 해요. 본드 돌려받기 어려울까요? 어디 신고해야 하나요?"

**직원 멘붕 포인트:**
- Tenancy Tribunal (NCAT/VCAT) - 학생도 신청 가능
- 본드 = Rental Bond Board 보관 (집주인 X)
- Repair Order 강제 가능
- 건강 위험 (곰팡이 호흡기) 입증 시 강제력 강함
- 한국 학생 흔히 본드 분쟁 패배 - 법 모름
- Tenant Union NSW/VIC 무료 도움

---

## ❌ 절대 하지 말아야 할 답

> "집주인이랑 잘 얘기해서 해결하세요"

→ ❌ 구두 협상은 한국 학생 패배 일반 / 호주는 강력한 임차인 보호 시스템 있음 / Tenant Union/Tribunal 적극 활용

---

## ✅ 정답

(1) Repair Request 서면 통보 (2) Tenant Union 무료 상담 (3) NCAT/VCAT 신청 (Repair Order + 본드 보호) (4) 본드는 Rental Bond Board에 안전 보관 (집주인 못 가져감)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Rental Bond (보증금) 보관**
NSW: Rental Bond Board (rentalbonds.nsw.gov.au) / VIC: RTBA / QLD: RTA / 정부 기관 보관 / 집주인 임의 인출 불가 / 분쟁 시 Tribunal 결정.

**2. NCAT (NSW Civil and Administrative Tribunal)**
ncat.nsw.gov.au / Tenancy 분쟁 / 신청비 $54 / 14~28일 처리 / 본인 또는 통역 / 학생도 신청 가능 / Repair Order 강제.

**3. Tenants Union (무료 임차인 단체)**
NSW: Tenants Union NSW (tenants.org.au) / VIC: Tenants Victoria / QLD: Tenants Queensland / 무료 법률 자문 + 양식 도움 + 한국어 통역.

**4. Repair Request (수리 요청)**
Urgent Repair (긴급): 24~48시간 (전기/가스/물 누수) / Non-Urgent: 14일 / 서면 통보 후 미진행 시 Tribunal.

**5. 호주 곰팡이 (Mould) 건강 위험**
Stachybotrys / Aspergillus 등 호흡기 위험 / 의사 진단서(Asthma/Allergy 악화) 있으면 Tribunal 강제력 강함 / RTA 권고 사항.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 곰팡이/누수 사진 + 영상 (날짜 표시) 증거 수집
**2단계**: 2차: 집주인/Real Estate Agent에 서면 Repair Request (이메일/문자 - 증거)
**3단계**: 3차: 응답 없거나 거부 시 Tenant Union 무료 상담
**4단계**: 4차: NCAT/VCAT 신청 ($54) - Repair Order + 본드 보호
**5단계**: 5차: 의사 진단서 받아두기 (호흡기/알레르기) - Tribunal 증거

---

## 💡 직원이 학생한테 말할 멘트

> "안심하세요. 호주는 임차인 보호 강력한 시스템 있어요.

**즉시 할 일:**

1. **증거 수집**: 곰팡이/누수 사진 + 영상 (날짜 표시 필수)
2. **서면 Repair Request**: 이메일/문자로 (구두 X). "I request urgent repair for mould and water leak as per Residential Tenancies Act."
3. **본드 안전 확인**: 본드는 Rental Bond Board(NSW)에 보관됩니다. 집주인이 임의로 못 가져가요. **rentalbonds.nsw.gov.au**에서 본인 본드 ID로 확인.

**무료 도움:**
4. **Tenants Union NSW**: tenants.org.au (한국어 통역 가능)
5. **NCAT 신청** ($54, 14~28일): 집주인이 안 고치면 Repair Order 강제 가능. **본인 직접 신청 가능**합니다.

**의사:**
곰팡이로 기침/알레르기 심하면 GP 진단서 받아두세요. Tribunal 증거 강력.

**집주인이 환기 탓 한다고:**
거짓말 화법이에요. 호주 법은 곰팡이/누수 책임이 집주인에게 있다고 명시. 환기는 학생 책임이지만 **누수 + 구조적 곰팡이는 집주인 책임**.

학교/지역 알려주시면 한국어 가능 Tenant Union 안내드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **집주인이 본드 안 돌려주면 끝**
   → 본드는 Rental Bond Board 보관 / 집주인 임의 인출 불가 / Tribunal 결정

2. **학생은 Tribunal 신청 못 한다**
   → 외국인/학생 모두 신청 가능 / 통역 무료 / 신청비 $54

3. **Tenant Union은 호주인만 도와준다**
   → 거주자 모두 무료 / 한국어 통역 가능

4. **환기 안 하면 학생 책임**
   → 환기 = 학생 책임 / 누수 + 구조 곰팡이 = 집주인 책임 / 분리

5. **Real Estate Agent가 집주인이다**
   → Agent = 대리인 / 결정권자 = 집주인 / 분쟁 시 집주인에게 직접 통보

6. **Repair 요청은 구두로 충분**
   → 구두 = 증거 X / 이메일/문자 필수 / Tribunal 증거

7. **의사 진단서는 필요 없다**
   → 건강 영향 입증 시 Tribunal 강제력 강함 / GP 진단서 권장

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 임대 형태 (Lease 본인 명의 vs 셰어 서브렛)
2. 본드 ID (Rental Bond Board 등록 여부)
3. 건강 영향 (기침/알레르기 발생 여부)
4. Real Estate Agent vs 집주인 직접 임대 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- rentalbonds.nsw.gov.au (NSW)
- consumer.vic.gov.au/RTBA (VIC)
- tenants.org.au (NSW Tenants Union)
- tenantsvic.org.au (VIC)
- ncat.nsw.gov.au (NSW Tribunal)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Tenants Union 안내
- Rental Bond Board 일반 정보
- NCAT/VCAT 일반 절차 안내
- Repair Request 서면 양식 일반 안내

**MARA / 변호사 영역**
- Tribunal 사건 변호 (복잡한 경우)
- 비자 영향 (주거지 강제 이전 시)
- 집주인 형사 고소 평가

---

## ✅ 완벽 응대 체크리스트

- [ ] 임차인 보호 강력하다 강조
- [ ] 본드 안전 보관 안내 (집주인 못 가져감)
- [ ] Repair Request 서면 강조
- [ ] Tenant Union 무료 안내
- [ ] NCAT 학생 신청 가능 안내
- [ ] 곰팡이 = 집주인 책임 명확히
- [ ] 의사 진단서 권장
- [ ] 한국어 통역 안내
