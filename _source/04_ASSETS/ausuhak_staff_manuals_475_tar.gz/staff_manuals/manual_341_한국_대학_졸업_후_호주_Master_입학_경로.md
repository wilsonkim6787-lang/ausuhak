# #341 한국_대학_졸업_후_호주_Master_입학_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 한국에서 4년제 대학 경영학과 졸업했어요. 호주에서 Master(MBA) 도전하려고 하는데 가능한가요? 영어 점수랑 학비 알려주세요."

**직원 멘붕 포인트:**
- 한국 학사 = 호주 Master 자동?
- MBA = 직장 경력 필수?
- 영어 IELTS 점수?
- 학비 + 비자?

---

## ❌ 절대 하지 말아야 할 답

> "한국 4년제면 바로 MBA 가능해요."

→ ❌ MBA는 직장 경력 + GMAT/GRE 필수 학교 다수. 일반 Master는 학사로 가능. 구분 모름.

---

## ✅ 정답

**호주 Master 입학 = ① Coursework Master(일반) ② MBA(직장 경력 필수) ③ Research Master(논문 + 학사 평균 65%+) 세 종류.**

**핵심 사실:**
- **Coursework Master**: 한국 4년제 학사 + 평균 70%+ + IELTS 6.5(각 6.0). 1.5~2년. 학비 $30,000~$50,000/년.
- **MBA**: 학사 + 직장 경력 2~5년 + GMAT 550~700 + IELTS 7.0(각 6.5) + 면접. Top MBA(Melbourne Business School, AGSM) = 직장 5년+.
- **Research Master(MPhil/MRes)**: 학사 평균 65%+ + 연구 제안서 + 지도교수 매칭 + IELTS 6.5. 1~2년 논문.
- **Pathway Master**: 학사 평균 60% 미만 = Graduate Diploma 1년 → Master 1년 (편입). 시드니/UTS/RMIT 등.
- **485 비자 (Post-Higher Education Work Stream, 구 PSW) 자격**: Master 2년 = 졸업 후 485 비자 3년 (PR 경로).
- **PR 경로**: Master(IT/회계/엔지니어링/간호) + 직업 평가 + EOI 70+ = 189/190 PR.

**경로:**
한국 학사 + 평균 + 영어 → Master 종류 결정(Coursework/MBA/Research) → 학교 신청 (1년 전) → CoE → 학생비자 500

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Coursework vs MBA vs Research**
Coursework = 강의 위주 + 학사로 입학. MBA = 직장 경력 + GMAT. Research = 논문 + 지도교수.

**2. MBA 학교 차이**
Top Tier(MBS, AGSM): 5년 경력 + GMAT 650+. Mid Tier(USyd, Monash): 3년 + GMAT 550+. Open MBA(RMIT, QUT): 경력 1~2년.

**3. 학사 평균 70% 이상**
Coursework Master = 한국 4.5/4.5 만점 기준 3.0(B) 이상. 평균 80%+ = Go8 가능. 70~79% = USyd 일부 + Mid Tier.

**4. Pathway Master**
학사 60% 미만 또는 학과 매칭 안 될 시 = Graduate Certificate(6개월) → Graduate Diploma(1년) → Master(1년) 단계 가능.

**5. 485 비자 (Post-Higher Education Work Stream, 구 PSW)**
Master Coursework 2년 + 호주 졸업 = 485 비자 (Post-Higher Education Work Stream, 구 PSW) 3년. Research Master 1.5년+ = 485 4년. PR 직업군 매칭 시 우대.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 학사 평균 + 학과 + 영어 점수 평가
**2단계**: Master 종류 결정 (Coursework/MBA/Research)
**3단계**: 학교 후보 3~5개 선정 + 입학 요건 확인 (1년 전)
**4단계**: 온라인 신청 → CoE → 비자 500 신청 ($2,000, 2025.07.01부터 인상)
**5단계**: 졸업 후 → 485 비자 (Post-Higher Education Work Stream, 구 PSW) 3년 → 직업 평가 → 189/190 PR

---

## 💡 직원이 학생한테 말할 멘트

> "한국 학사 + 호주 Master는 Coursework/MBA/Research 종류에 따라 입학 요건이 완전히 달라요. MBA는 직장 경력 필수.

학사 학과 + 평균 + 직장 경력 + 영어 점수 + Master 목표 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 학사 = 자동 Master**
   → ❌ 평균 70%+ + IELTS 6.5+ + 학과 매칭 필요.

2. **MBA = 학사로 가능**
   → ❌ MBA는 직장 경력 2~5년 필수.

3. **Research Master = 쉬움**
   → ❌ Research = 지도교수 매칭 + 연구 제안서 + 평균 65%+. Coursework보다 어려움.

4. **485 = 무조건 3년**
   → ❌ Master 2년+ = 485 3년. 1.5년 = 2년.

5. **Master = 자동 PR**
   → ❌ 직업군 MLTSSL + EOI 70+ + 직업 평가 + 영어 + 나이 합산. PR 별개 절차.

6. **MBA = 한국 회사 인정**
   → ❌ 한국 회사 MBA 가산점 미미. 호주/싱가포르 취업 유리.

7. **Pathway Master = 비자 1번**
   → ❌ Pathway = Grad Cert/Dip + Master 별도 CoE + 비자 연장 가능.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학사 학과 + 평균 + 졸업 연도
2. 직장 경력 (MBA 시) + 분야
3. 영어 IELTS/PTE/TOEFL 점수
4. Master 목표 (취업/PR/학문) + 호주 거주 의사

---

## 🔍 직원이 직접 확인 가능한 사이트

- 각 학교 Master Admission 페이지
- MBA Top 100 (FT, Economist, QS) 랭킹
- GMAT 시험 (mba.com)
- 한국 외국대학 학력 인증 (NIIED)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Master 종류 결정 + 학교 후보 가이드
- GMAT/IELTS 준비 + 입학 신청 가이드
- 졸업 후 485 + PR 경로 설계

**MARA / 변호사 영역**
- 학생비자 500 거절 + ART (MARA)
- PR 신청 + 직업 평가 + EOI (MARA)
- MBA 학위 한국 인증 거부 (NIIED + 변호사)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 학사 평균 70%+ + 학과 매칭 확인
- [ ] Master 종류 (Coursework/MBA/Research) 결정
- [ ] MBA 시 직장 경력 + GMAT 점수 준비
- [ ] IELTS 6.5(각 6.0) 또는 7.0(각 6.5) 준비
- [ ] 학교 후보 3~5개 + 1년 전 신청
- [ ] 학생비자 500 + 재정 증명 + OSHC 준비
- [ ] 졸업 후 485 (Post-Higher Education) 3년 + PR 직업군 평가
