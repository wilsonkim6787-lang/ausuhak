# #290 호주_MBA_입학_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 한국에서 직장 5년차예요. 호주 MBA 가고 싶은데 어디가 좋아요? PR 가능?"

**직원 멘붕 포인트:**
- MBA Top 5 (Melbourne/AGSM UNSW/Monash/MGSM/QUT) 차이
- GMAT 시험 + 직장 경력 5년+ 요구
- MBA = STSOL/MLTSSL X (PR 어려움)
- 비용 $80,000~$120,000 (1~2년)
- 한국 직장 경력 영문 증명서 필수

---

## ❌ 절대 하지 말아야 할 답

> ""MBA = PR 보장""

→ ❌ MBA 자체는 PR 가산 X. Skilled Occupation 별도 평가.

---

## ✅ 정답

"호주 MBA Top 5 = Melbourne Business School / AGSM (UNSW) / Monash / MGSM / QUT입니다. GMAT 600+ + 직장 경력 5년+ + IELTS 7.0 필요. 비용 $80,000~$120,000. MBA 자체는 PR 가산 없으며 졸업 후 직업 (회계/IT/마케팅 등)으로 PR 별도 평가합니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 MBA Top 5**
Melbourne Business School (MBS) = QS World Top 50. Australian Graduate School of Management (AGSM, UNSW) = Top 50. Monash Business School. Macquarie Graduate School (MGSM). QUT Graduate School. 학비 $80,000~$120,000 (1~2년). 입학 = GMAT + 경력 + Essay.

**2. 입학 조건**
학사 졸업 (전공 무관). 직장 경력 최소 3~5년 (Manager/팀장급 우대). GMAT 600+ (Top 5는 650+). IELTS 7.0 (각 영역 6.5+). Essay + 추천서 2~3통. 면접. 한국 학사 + 한국 직장 경력 인정.

**3. MBA 학비 + 생활비**
1년 MBA = $80,000~$100,000. 2년 MBA = $120,000~$160,000. 생활비 $30,000/년 추가. 총 $150,000~$200,000 (1~2년). 장학금 = MBS 50% (경쟁) / AGSM 일부. 한국 학생 장학금 거의 X.

**4. MBA + PR 경로**
MBA 자체 = STSOL/MLTSSL X. 졸업 후 직업으로 PR. Marketing Manager = STSOL. Management Consultant = MLTSSL. ICT Manager = MLTSSL. 졸업 후 485 (2년) + 직업 경력 + Skill Assessment → 189/190.

**5. 19년 경력 = MBA 추천 케이스**
한국 직장 경력 5년+ + 영어 우수 + 예산 $200,000 = MBA 추천. 졸업 후 호주 취업 (현지 회사) → 482/186 또는 직업으로 189/190. PR 경로 어려우니 Partner Visa 동시 고려.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 직장 경력 5년+ 입증 + 영문 증명서
**2단계**: GMAT 응시 + 600+ 목표 (한국 응시 가능)
**3단계**: MBA Top 5 지원 + Essay + 추천서
**4단계**: 합격 시 학생비자 신청 + 1~2년 학습
**5단계**: 졸업 후 직업으로 PR (485 → 189/190)

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 직장 5년차면 MBA 적합한 시점이에요. 호주 MBA Top 5 = Melbourne / AGSM / Monash / MGSM / QUT. GMAT 600+ + 영어 IELTS 7.0 + 직장 경력 영문 증명서 필요해요. 학비 + 생활비 1~2년 = $150,000~$200,000. MBA 자체는 PR 가산 없고 졸업 후 직업으로 PR 받아야 해요. 한국 직장 분야 (마케팅/IT/컨설팅 등) + 영어 점수 + 예산 알려주시면 학교 매칭해드릴게요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"MBA = PR 보장"**
   → MBA 자체 X. 직업으로 별도 평가.

2. **"GMAT 한국에서 어려움"**
   → 한국 Pearson VUE 응시. 평균 600+.

3. **"직장 경력 1년 가능"**
   → Top 5 = 5년+ 우대. 3년 미만 거의 X.

4. **"영어 IELTS 6.5"**
   → Top 5 = 7.0 (각 영역 6.5+).

5. **"장학금 무조건"**
   → 한국 학생 장학금 거의 X. 자비.

6. **"MBA 졸업 = 호주 취업 보장"**
   → 현지 인맥 + 영어 + 직무 경력 필요.

7. **"한국 학사 인정 X"**
   → 한국 학사 = 호주 학사 인정 (학교별).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 직장 경력 (3년+ vs 5년+)
2. 직장 분야 (마케팅/IT/컨설팅 등)
3. 영어 IELTS (7.0 필요)
4. 예산 ($200,000+)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Melbourne Business School: https://mbs.edu
- AGSM (UNSW): https://www.business.unsw.edu.au/agsm
- GMAT: https://www.mba.com
- MBA QS World Ranking

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = MBA 매칭 + 입학
- 한국 직장 경력 영문 증명 도움
- GMAT 학원 추천 가능
- 비자 신청 대행
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- GMAT = 별도 응시 (학원)
- 각 MBA = 입학 평가
- MARA Lawyer = 졸업 후 PR 비자
- Skill Assessment = 직업별 평가기관
- Partner Visa = MARA Lawyer 별도

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 직장 경력 확인했다 (5년+)
- [ ] 직장 분야 확인했다
- [ ] 영어 IELTS 확인했다
- [ ] 예산 확인했다 ($200,000+)
- [ ] GMAT 안내했다
- [ ] MBA Top 5 안내했다
- [ ] MBA = PR 가산 없음 정직 전달했다
- [ ] 윌슨 직접 카카오 ID 안내했다
