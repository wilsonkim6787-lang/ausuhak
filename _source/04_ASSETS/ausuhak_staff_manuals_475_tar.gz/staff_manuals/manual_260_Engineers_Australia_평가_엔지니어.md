# #260 Engineers Australia 평가 엔지니어

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 한국 공대 졸업했는데 호주 엔지니어 PR 어떻게 받아요?"

**직원 멘붕 포인트:**
- EA = Engineers Australia
- Washington Accord 회원 = 한국 공대 인정 (KEC2015)
- Non-Accord 학교 = CDR 작성 필수
- 직업 코드 = Civil / Mechanical / Electrical 등

---

## ❌ 절대 하지 말아야 할 답

> "한국 공대 출신이면 EA 자동 인정입니다."

→ ❌ **KEC2015 인증 학교 + 학과만 자동 / 그 외 CDR**.

---

## ✅ 정답

Engineers Australia 평가: ① **Washington Accord (KEC2015 한국공학교육인증)** = 자동 인정 ② **Non-Accord = CDR (Competency Demonstration Report)** = 3개 Career Episode + Summary ③ **수수료 약 $760** ④ **심사 8~16주** ⑤ **3개 카테고리** (Professional Engineer / Engineering Technologist / Engineering Associate) ⑥ **IELTS 6 또는 PTE 50** (직업 평가용).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Washington Accord (KEC2015)**
한국공학교육인증원 인증 학과 = 자동 인정 / 서울대 / 카이스트 / 포항공대 등 KEC2015 인증 학과 / 졸업증 + 성적표 + KEC2015 증명서

**2. Non-Accord (CDR)**
Competency Demonstration Report / 3개 Career Episode (각 1500~2500단어) / Summary Statement (각 Episode 매핑) / Continuing Professional Development

**3. 직업 카테고리**
Professional Engineer (4년 학사 / ANZSCO 233xxx) / Engineering Technologist (3년 학사 / 233914) / Engineering Associate (2년 Diploma / 312xxx)

**4. CDR 표절 검출**
CDR 표절 = 12개월 평가 금지 + PR 영구 영향 / Turnitin 검출 시스템 / 본인 작성 필수

**5. 호주 학위 인정**
호주 EA 인증 학사 = 자동 / Master 추가 = 점수 가산 / Engineering Technologist → Master = Professional Engineer 가능

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 학과 KEC2015 인증 확인
**2단계**: 인증 학교 = 학위 + 성적표 + 인증서 / Non-인증 = CDR 작성
**3단계**: EA 사이트 등록 (engineersaustralia.org.au)
**4단계**: 신청 + 수수료 ($760)
**5단계**: 심사 8~16주 → 결과 → EOI 입력

---

## 💡 직원이 학생한테 말할 멘트

> "한국 공대 PR은 KEC2015 (한국공학교육인증) 인증 학과면 자동 인정이에요. 인증 학교 (서울대 / 카이스트 등) 출신이면 학위 + 성적표 + 인증서로 빠르게 진행 가능합니다. 인증 안 된 학과는 CDR (Competency Demonstration Report) = 3개 프로젝트 사례 + Summary 작성해야 하고 표절 절대 금지입니다. 직업 카테고리 3종 중 본인 학력 + 경력 매칭이 중요해요. 윌슨님이 1:1로 KEC2015 확인 + CDR 가이드 + 직업 코드 매칭 드려요. 카카오 (studywilson)으로 학교 + 학과 + 졸업년도 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 공대 = 모두 자동 ❌**
   → KEC2015 인증 학과만 자동

2. **CDR = 표절 OK ❌**
   → 12개월 평가 금지 + 영구 영향

3. **CDR = 짧게 OK ❌**
   → Episode 1500~2500단어 / 총 5000~7500단어

4. **Engineering Associate = PR 불가 ❌**
   → ANZSCO 312xxx PR 가능 직업

5. **EA = IELTS 7 ❌**
   → 직업 평가 = IELTS 6 / PR EOI = 별개

6. **호주 학사 = CDR 면제 ❌**
   → EA 인증 호주 학사만 면제

7. **CDR 본인 영어 작성 ❌**
   → 한국어 작성 후 영어 번역 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학교 + 학과 + KEC2015 인증 여부
2. 직업 카테고리 결정 (PE / ET / EA)
3. 영어 IELTS 6 가능 여부
4. CDR 작성 가능 여부 (Non-Accord)

---

## 🔍 직원이 직접 확인 가능한 사이트

- EA: https://www.engineersaustralia.org.au/migration-skills-assessment
- Washington Accord: https://www.ieagreements.org
- KEC2015: https://www.abeek.or.kr

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- KEC2015 인증 확인 + CDR 가이드
- 직업 코드 매칭 + 점수 전략
- Engineering Associate → Technologist → PE 전환

**MARA / 변호사 영역**
- EA 거절 + Review
- PR 거절 + ART 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] KEC2015 = Washington Accord 자동
- [ ] Non-Accord = CDR 필수
- [ ] CDR = 5000~7500단어 본인 작성
- [ ] 직업 카테고리 3종 매칭
- [ ] IELTS 6 = 평가용
- [ ] CDR 표절 = 12개월 금지
- [ ] 윌슨 1:1 = CDR + 직업 코드
- [ ] 윌슨 카카오 자연 유도
