# #294 호주_학생_신용카드_은행_사기

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 카드 도용당해서 $3,000 결제됐어요. 은행 (CommBank) 신고했는데 환불 안 된대요. 어떡하죠?"

**직원 멘붕 포인트:**
- AFCA (Australian Financial Complaints Authority) 절차
- Chargeback vs Fraud 신고 차이
- 한국 신용카드 (BC카드 등) 호주 도용
- 경찰 Police Report 필수 여부
- OSHC/유학생 보험 보상 X

---

## ❌ 절대 하지 말아야 할 답

> ""은행이 안 해주면 끝""

→ ❌ AFCA 무료 분쟁 조정. 단정 X.

---

## ✅ 정답

"호주 신용카드 사기는 1단계 은행 Fraud Department 신고 → 2단계 경찰 Police Report → 3단계 AFCA (Australian Financial Complaints Authority, 무료) 분쟁 조정 가능합니다. 환불 거부 시 AFCA가 강제 결정 가능합니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 신용카드 사기 절차**
1단계 = 카드 즉시 정지 (은행 24시간 핫라인). 2단계 = Fraud Department 신고 (서면). 3단계 = 경찰 Police Report 발급. 4단계 = 은행 조사 (15~45일). 환불 또는 거부. Chargeback = Visa/Mastercard 분쟁 (60일 내 가능).

**2. AFCA 분쟁 조정**
Australian Financial Complaints Authority = 무료 + 강제력. 1800 931 678. 은행 환불 거부 시 신청. AFCA 결정 = 은행 의무 이행 ($1M까지). 처리 기간 60~120일. 한국어 통역 가능.

**3. Chargeback (Visa/Mastercard)**
60일 내 Chargeback 신청 (은행 통해). 카드 도용 + 본인 동의 X 입증. Chargeback 성공률 70%+. 단, 본인 카드 빌려준 케이스 = 거부.

**4. 경찰 Police Report**
Hate Crime/Fraud = 경찰 신고 의무. Police Event Number 발급 → 은행/AFCA 제출. 호주 경찰 = 한국 카드 사기도 신고 받음 (호주 거주 학생). NSW Police: 131 444 (Non-emergency).

**5. 한국 신용카드 호주 도용**
BC/신한/국민카드 호주 사용 시 도용 = 한국 카드사 분쟁 신청. Visa/Mastercard 글로벌 Chargeback 적용. 한국 카드사 24시간 핫라인 (해외 분실 신고). 호주 경찰 Police Report 한국 카드사 제출.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 카드 즉시 정지 (24시간 은행 핫라인)
**2단계**: 은행 Fraud Department 서면 신고 + 거래 내역 캡처
**3단계**: 경찰 Police Report 발급 (NSW 131 444)
**4단계**: 은행 조사 결과 → 환불 거부 시 AFCA 신청 (1800 931 678)
**5단계**: AFCA 분쟁 조정 → 강제 환불 결정

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 정말 놀라셨겠어요. 호주 신용카드 사기는 환불 받을 수 있어요. 일단 카드 즉시 정지하셨죠? 은행이 환불 거부했으면 끝이 아니에요. 1단계 = 경찰 Police Report 발급 (NSW 131 444). 2단계 = AFCA (Australian Financial Complaints Authority) 무료 분쟁 신청 (1800 931 678). AFCA 결정은 은행이 무조건 따라야 해요. 처리 기간 60~120일. 한국어 통역도 가능해요. 거래 내역 캡처 + 본인 위치 알리바이 (CCTV/택시 영수증) 준비하세요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"은행 거부 = 끝"**
   → AFCA 분쟁 조정 (무료 + 강제력).

2. **"경찰 신고 X"**
   → Police Report 필수 (AFCA 제출용).

3. **"한국 카드 호주 도용 = 한국 신고만"**
   → 양쪽 동시 (한국 카드사 + 호주 경찰).

4. **"OSHC 보상"**
   → OSHC = 의료만. 사기 보상 X.

5. **"Chargeback 60일 후도 가능"**
   → 60일 시한. 시급.

6. **"본인이 빌려줘도 Chargeback"**
   → 본인 동의 = 거부.

7. **"AFCA 한국어 X"**
   → TIS National 통역 가능 (131 450).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 도용 금액 + 거래 일시
2. 카드 정지 여부 (즉시 X면 추가 도용)
3. 은행 신고 여부 + 결과
4. Police Report 발급 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- AFCA: 1800 931 678
- NSW Police Non-emergency: 131 444
- CommBank Fraud: 13 2221
- TIS National 통역: 131 450

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 절차 안내
- AFCA 신청 가이드
- 한국 영사관 통역 도움
- 한국 가족 연락 중재
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- 은행 Fraud Department = 1차 조사
- 경찰 = Police Report
- AFCA = 분쟁 조정 (무료)
- Visa/Mastercard = Chargeback
- 민사 변호사 = AFCA 결정 거부 시 (드뭄)

---

## ✅ 완벽 응대 체크리스트

- [ ] 도용 금액 확인했다
- [ ] 카드 정지 확인했다
- [ ] 은행 신고 확인했다
- [ ] 경찰 Police Report 안내했다
- [ ] AFCA 분쟁 안내했다 (1800 931 678)
- [ ] Chargeback 60일 시한 안내했다
- [ ] 한국어 통역 가능 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
