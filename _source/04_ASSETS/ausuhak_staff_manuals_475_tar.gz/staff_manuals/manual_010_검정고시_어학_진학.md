# 📚 직원 응대 매뉴얼 #010

**케이스: 20세 / 검정고시 / 어학연수 + 진학 / 영어 없음 / 6천만 예산**

---

## 🎬 상황 시뮬레이션

> 20살이고 검정고시 봤어요. 영어 못해서 어학연수 먼저 하고 학사 가고 싶어요. 1년 6천만 정도예요.

**👉 정답**: **ELICOS 1년 + Foundation 또는 Diploma Pathway → 학사**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 검정고시 학생의 진학 옵션

| 옵션 | 가능 |
|---|---|
| Go8 직접 입학 | ❌ 어려움 |
| 일반 대학 직접 입학 (UNE/Federation/ACU) | ✅ 일부 학교 |
| Foundation → Go8 | ✅ |
| Diploma Pathway → Bachelor 2학년 | ✅ |
| TAFE Diploma → 학사 편입 | ✅ |

### 2️⃣ 영어 없음 = ELICOS 30~52주 + IELTS 시험

- General English 시작 → EAP로 레벨업
- 1년 학습 시 평균 IELTS 5.5~6.0 도달 (개인차 大)
- 간호/의료직 = IELTS 7.0 별도 필요 / 일반 코스 = 5.5~6.5

### 3️⃣ Foundation vs Diploma Pathway 선택

| 검정고시 + Foundation | 검정고시 + Diploma |
|---|---|
| 9~12개월 | 8~12개월 |
| Bachelor 1학년 | Bachelor 2학년 (1년 단축) |
| Go8 가능 | 일반 대학 우선 |
| 학비 $25K~$45K | 학비 $28K~$38K |

### 4️⃣ 검정고시 OK 학교 (학사 직접 입학 가능)

- UNE (Armidale, Regional)
- Federation University (Ballarat)
- UniSQ (Toowoomba)
- ACU (전국)
- Avondale University

이 학교들은 일부 학과 검정고시 직접 입학 받음 (Foundation 불필요).

### 5️⃣ 1년 6천만 예산 = 어학연수 + Pathway 가능

- ELICOS 1년: $15K~$20K
- Foundation/Diploma: $28K~$45K
- 합계: $43K~$65K → **6천만 가능**

---

## 🎯 정답 경로 (3가지 비교)

### 옵션 A. ELICOS + Diploma Pathway → 학사 2학년 (1년 단축)

```
ELICOS 1년 ($15K~$20K)
        ↓ EAP Direct Entry
Diploma 1년 ($28K~$38K)
        ↓ 1년 학점 인정
Bachelor 2학년 (2년) ($48K~$60K)
```

**총 4년 / 학비 약 $90K~$120K**

### 옵션 B. ELICOS + Foundation → Go8 1학년

```
ELICOS 1년 ($15K~$20K)
        ↓
Foundation 1년 ($25K~$45K)
        ↓
Go8 학사 3년 ($150K~$200K)
```

**총 5년 / 학비 약 $190K~$265K (예산 초과)**

### 옵션 C. ELICOS + 검정고시 OK 학교 직접

```
ELICOS 1년 ($15K~$20K)
        ↓
UNE / FedUni / ACU 학사 직접 (3년)
```

**총 4년 / 학비 약 $90K~$120K (예산 안)**

---

## 💡 직원이 학생한테 말할 멘트

> "검정고시 + 영어 없음 + 6천만 예산이면, 두 가지 안전한 길이 있습니다.
> 
> **옵션 A. ELICOS + Diploma Pathway → 학사 2학년 직진** (1년 단축)
> **옵션 C. ELICOS + 검정고시 OK 학교 직접 학사** (UNE/FedUni/ACU)
> 
> 두 옵션 모두 4년 안에 학사 졸업 가능하고 예산 안에서 가능합니다.
> 
> Go8 직접 입학은 검정고시로는 어려워서 Foundation 거쳐야 하는데, 학비가 비싸서 6천만 예산으로는 빠듯합니다.
> 
> 카톡으로 알려주세요:
> ① 희망 전공 (간호 / 비즈니스 / IT 등)  
> ② 졸업 후 한국 귀국 vs 호주 취업 vs 영주권  
> ③ 도시 선호 (시드니/멜번 vs 영어 환경 좋은 곳)"

---

## ⚠️ 함정

1. **"검정고시도 Go8 직접 가능"** → ❌ 거의 불가
2. **"ELICOS 끝내면 IELTS 자동 면제"** → 간호는 X / 일반은 가능
3. **"UNE/FedUni는 수준 낮다"** → ❌ 인증된 학사 / 491 +15점 (Regional 지역)
4. **"검정고시 사유 학교에 말해야"** → 보통 안 묻음 / 학생 본인 결정

---

## 📞 카카오 응대 시 필수

1. 희망 전공
2. 졸업 후 계획 (귀국 / 호주 취업 / 영주권)
3. 도시 선호
4. 입학 희망 시기

---

## 🔍 직원 확인 사이트

- UNE: une.edu.au
- Federation University: federation.edu.au
- ACU: acu.edu.au
- Diploma Pathway 학교들 (UTS Insearch / WSU College / SIBT)
