# 📚 직원 응대 매뉴얼 #023

**케이스: 32세 / 한국 간호사 면허 + 5년 경력 / 호주 RN 등록 / OBA 시험**

---

## 🎬 상황 시뮬레이션

> 한국에서 간호사 면허 받고 5년 일했어요. 호주에서 간호사로 일하고 싶은데 어떻게 해야 하나요? 32세이고 IELTS 7.0 있어요.

**👉 정답**: **OBA (Outcome-Based Assessment) 시험 = NCLEX-RN + OSCE**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ OBA = 한국 간호사의 호주 RN 전환 시험

**OBA** (Outcome-Based Assessment) = 해외 간호사가 호주 RN 등록을 위한 평가 시스템.

```
한국 간호사 + IELTS 7.0
        ↓
1단계: AHPRA Eligibility Assessment (한국 학위 평가)
        ↓
2단계 NCLEX-RN: 컴퓨터 이론 시험 (4시간)
        ↓
3단계 OSCE: 임상 실기 시험 (호주 현지)
        ↓
AHPRA RN 등록
```

### 2️⃣ NCLEX-RN = 미국 간호사 시험

- 컴퓨터 기반 / 4시간 / 다지선다
- 한국에서도 응시 가능 (Pearson VUE 시험장)
- 시험비 약 $400 USD
- 영어 시험

### 3️⃣ OSCE = 임상 실기 시험

- 호주 현지에서만 응시 (Adelaide / Newcastle 등 지정 센터)
- 시뮬레이션 환자 대상 임상 술기 평가
- 시험비 약 $4,000 AUD
- 호주 단기 체류 必 (관광비자 또는 방문 필요)

### 4️⃣ 영어 조건

- **IELTS 7.0 (각 영역 7.0)**
- 일반 시험과 다른 OET (Occupational English Test) 가능 (B grade)
- 한국 학력으로 영어 면제 받기 어려움

### 5️⃣ OBA vs Bridging Course (대안)

| OBA | Bridging Course |
|---|---|
| 시험 통과 = 즉시 등록 | 호주 대학 1-1.5년 코스 수료 |
| 비용 $4,400 | 학비 $30K~$45K |
| 빠름 (3-6개월) | 1-1.5년 호주 학업 |
| 영어 + 임상 자신 있음 | 안정적 경로 선호 |

---

## 🎯 정답 경로 (2가지 비교)

### 옵션 A. OBA 시험 (빠름)

```
한국 간호사 면허 + 5년 경력 + IELTS 7.0
        ↓
AHPRA 자격 평가 (Online) - 약 3개월
        ↓
NCLEX-RN 시험 (한국에서 응시) - 약 3개월
        ↓
OSCE 시험 (호주 단기 방문) - 약 3개월
        ↓
AHPRA RN 등록 + 호주 취업
```

**총 9-12개월 / 비용 약 $4,400 + 영어 시험비 + 호주 단기 체류**

### 옵션 B. Bridging Course (안정적)

```
한국 간호사 + IELTS 7.0
        ↓
Bridging Course 1-1.5년 (Curtin / UTS / Murdoch / La Trobe)
        ↓
졸업 = 자동 RN 자격
        ↓
AHPRA 등록 + 호주 취업
```

**총 1.5-2년 / 학비 약 $30K~$45K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 간호사 면허 + 5년 경력 + IELTS 7.0이면 두 가지 경로 가능합니다.
> 
> **옵션 A. OBA 시험 (빠름, 학비 적음)**
> - NCLEX-RN (한국 응시 가능, $400 USD)
> - OSCE (호주 단기 방문, $4,000 AUD)
> - 9-12개월 안에 등록 가능
> - 영어 + 임상 자신 있는 분 적합
> 
> **옵션 B. Bridging Course (안정적, 학비 많음)**
> - Curtin / UTS / Murdoch / La Trobe 1-1.5년
> - 학비 $30K~$45K
> - 졸업 = 자동 RN 자격
> - 호주 적응 + 취업 강세
> 
> 둘 다 IELTS 7.0 (각 영역 7.0) 必須이고, 한국 한국 영어 면허 있어도 별도 시험 必요합니다.
> 
> 카톡으로 알려주세요:
> ① 정확한 IELTS 점수 (각 영역)  
> ② 한국 간호 분야 (응급/내과/외과 등)  
> ③ OBA vs Bridging 선호"

---

## ⚠️ 함정

1. **"한국 간호 학사 = 호주 자동 인정"** → ❌ AHPRA 평가 必
2. **"OSCE 한국에서 응시 가능"** → ❌ 호주 현지만
3. **"5년 경력 = 영어 면제"** → ❌ IELTS 7.0 必
4. **"OBA가 무조건 좋다"** → 영어/임상 자신 없으면 Bridging 안전

---

## 📞 카카오 응대 시 필수

1. 정확한 IELTS 각 영역 점수
2. 한국 경력 + 분야
3. 호주 단기 방문 가능 여부
4. OBA vs Bridging 선호

---

## 🔍 직원 확인 사이트

- AHPRA OBA: ahpra.gov.au
- NCLEX-RN: ncsbn.org
- OSCE 정보: ahpra.gov.au
- Bridging Course: 각 대학 사이트
