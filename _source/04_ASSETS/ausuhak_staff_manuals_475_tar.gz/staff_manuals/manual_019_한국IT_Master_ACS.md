# 📚 직원 응대 매뉴얼 #019

**케이스: 27세 / 한국 IT 학사 / 호주 IT Master / 시드니 / 1억 예산 / 영주권**

---

## 🎬 상황 시뮬레이션

> 한국 컴공과 졸업하고 IT 회사에서 2년 일했어요. 호주 IT 분야로 이직하면서 영주권 받고 싶어요. 시드니 위주로 보고 있고 1년 1억까지 가능합니다.

**👉 정답**: **Master of IT/Computing + ACS Skills Assessment + 485 + 189/190**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ IT 직업군 = 호주 MLTSSL 직업군

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Software Engineer | 261313 | MLTSSL |
| Software Tester | 261314 | MLTSSL |
| ICT Business Analyst | 261111 | MLTSSL |
| Systems Analyst | 261112 | MLTSSL |
| Computer Network Professional | 263111 | MLTSSL |
| Cyber Security Specialist | 262112 | MLTSSL |
| Web Developer | 261212 | STSOL |
| Database Administrator | 262111 | MLTSSL |

### 2️⃣ ACS Skills Assessment = IT 직업 평가

- **ACS** (Australian Computer Society) = IT 직업 평가 기관
- 한국 학사 + 호주 Master + 한국 경력 평가
- 평가 결과: 직업 코드 매칭 + 경력 인정 연수
- 영주권 신청 시 必須

### 3️⃣ 시드니 IT Master 학교

| 학교 | 학비 (연간) | IELTS | 특징 |
|---|---|---|---|
| USyd Master IT | $52K~$56K | 6.5 | Go8 |
| UNSW Master Computing | $50K~$55K | 6.5 | 컴공 강함 |
| UTS Master IT | $44K~$48K | 6.5 | IT 강세 |
| Macquarie Master IT | $42K~$46K | 6.5 | 학비 합리적 |
| WSU Master IT | $32K~$38K | 6.5 | 학비 저렴 + Regional 일부 |

### 4️⃣ ACS 평가 시간 + 경력 인정

- 호주 Master 졸업 = ACS 자동 인정 (Most Closely Related)
- 한국 경력 = 4년 미만은 일부만 인정 / 4년 이상은 거의 다 인정
- 27세 + 한국 2년 경력 = ACS 평가에서 일부 차감 → 호주 1-2년 경력 추가 必

### 5️⃣ 시드니 IT 회사 취업 + PR

- 시드니는 IT 회사 多 (Atlassian, Canva 등)
- 시드니/멜번/브리즈번 CBD = **Non-regional** (491 비자 +15점 적용 X)
- Adelaide / Perth / Hobart / Canberra 등 Regional 지역 = **491 nomination 시 +15점**
- 190 (주 정부 nomination) = 도시 무관 +5점
- 2019.11.16 이후 Cat 2/3 차등 폐지, Regional 지역 모두 동일하게 +15점

---

## 🎯 정답 경로

### Master IT + ACS + 485 + PR

```
한국 IT 학사 + 2년 경력 + IELTS 6.5+
        ↓
Master IT 2년 ($90K~$110K)
        ↓
졸업 + ACS Skills Assessment
        ↓
485 졸업비자 2년 (호주 IT 회사 취업)
        ↓
경력 1-2년 + EOI + 189/190 PR
```

**총 4-5년 / 학비 약 $90K~$110K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 IT 학사 + 2년 경력 + 시드니 Master + 영주권, 매우 강력한 PR 경로입니다.
> 
> 1. **IT 직업군 = MLTSSL 직업군** (Software Engineer, Cyber Security 등)
> 2. **ACS Skills Assessment** = 한국 학사 + 호주 Master + 경력 평가
> 3. **시드니 학교 옵션**: USyd $52-56K / UNSW $50-55K / UTS $44-48K / Macquarie $42-46K
> 4. **시드니 IT 회사 多** (Atlassian, Canva 등) = 취업 강세
> 
> 다만 시드니 (Non-regional) = 영주권 가산점 0점이라 **Adelaide(Regional 491+15)도 검토**해보시면 좋습니다. Adelaide도 IT 회사 점점 多.
> 
> 1억 예산이면 시드니 학교 1년 학비 + 생활비 가능합니다.
> 
> 카톡으로 알려주세요:
> ① IELTS 정확한 점수  
> ② 한국 IT 경력 + 분야 (백엔드/프론트/클라우드/Cyber 등)  
> ③ 시드니 vs Adelaide 검토"

---

## ⚠️ 함정

1. **"한국 IT 경력 = 호주 자동 인정"** → ❌ ACS 평가 必要
2. **"Master = ACS 자동 통과"** → 학과/세부 매칭 필요
3. **"시드니가 PR 빠름"** → ❌ Non-regional (491 비적용)
4. **"한국 경력 풀 인정"** → 한국 경력 4년 미만은 일부만 인정

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수
2. 한국 IT 경력 (분야 + 연수)
3. 시드니 vs Adelaide 검토
4. 호주 IT 분야 우선

---

## 🔍 직원 확인 사이트

- ACS: acs.org.au
- USyd Master IT: sydney.edu.au
- UTS Master IT: uts.edu.au
- 시드니 IT 회사 정보: seek.com.au
