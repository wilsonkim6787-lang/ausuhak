# 📚 직원 응대 매뉴얼 #035

**케이스: 26세 / 고졸 / MLTSSL 직업군 / Hobart 거주 / 4천만 예산**

---

## 🎬 상황 시뮬레이션

> 26살 고졸이에요. 영주권이 가장 중요합니다. 시드니 멜번보다 Hobart가 빠르다고 들었어요. 4천만 예산이에요.

**👉 정답**: **Hobart UTAS / TasTAFE + 491 비자 +15점 (Regional) + Australian Study +5점**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Hobart = Regional 지역 = 491 비자 +15점

**중요**: 2019.11.16 이후 Cat 1/2/3 차등 시스템 폐지. 모든 Regional 지역(시드니/멜번/브리즈번 CBD 제외) = 491 nomination 시 +15점 동일.

| 분류 | 점수 | 예시 도시 |
|---|---|---|
| Non-regional (491 비적용) | 491 X | Sydney CBD (2000-2234), Melbourne CBD (3000-3207), Brisbane CBD (4000-4207) |
| Regional (491 +15점) | +15 | Hobart, Adelaide, Perth, Canberra, Newcastle, Wollongong, Gold Coast, Sunshine Coast, Geelong, Darwin, Cairns 등 |

**Hobart 영주권 가산점 합산**:
- 491 nomination: +15점
- Australian Study Requirement (Regional 학업): +5점
- 총 추가 가산점: **+20점**

**485 비자 Second PHEW Regional Extension** (별도 시스템):
- **Hobart**: 2025.09.12부터 +**2년** 추가 (이전 +1년에서 변경)
- 다른 Regional 지역 (Adelaide/Perth/Gold Coast 등 Cat 2): +1년 추가
- Darwin/Cairns 등 (Cat 3): +2년 추가

### 2️⃣ Hobart 학교 옵션

| 학교 | 종류 | 학비 (연간) |
|---|---|---|
| University of Tasmania (UTAS) | 종합대 | $30K~$40K |
| TasTAFE | TAFE | $16K~$22K |
| Hobart College (Year 11-12) | 공립 고등 | $13K~$17K |

### 3️⃣ Hobart 단점도 알아야

- 인구 약 25만 (작은 도시)
- 알바 자리 시드니/멜번 대비 적음
- 한국 식당/한인 커뮤니티 적음
- 겨울 추움 (호주 최남단)

### 4️⃣ Hobart 거주 + Tasmania PR 스폰서십

- **TAS Skilled Occupation List**: TAS 정부 별도 운영
- TAS 거주 + 일 = 491/190 신청 강세
- TAS 졸업생 우대 시스템

### 5️⃣ Hobart 영주권 코스 (PR 직군 강세)

| 코스 | 학비 | PR 직업 |
|---|---|---|
| TasTAFE Diploma Nursing | $30K | EN 411411 |
| UTAS Bachelor of Nursing | $36K~$40K/년 | RN 254499 |
| UTAS Bachelor of Engineering | $42K/년 | Engineer MLTSSL |
| TasTAFE Cookery | $24K (1.5년) | Chef 351311 |
| UTAS IT | $36K/년 | IT MLTSSL |

---

## 🎯 정답 경로

### Hobart UTAS / TasTAFE + 491 PR

```
ELICOS 6개월 ($6K~$8K)
        ↓
TasTAFE Diploma 또는 UTAS Bachelor (1-3년)
        ↓ Hobart Regional 지역 거주
졸업 + 485 (2년 + Hobart 거주 시 +2년 = 4년)
        ↓ Tasmania 정부 491 nomination + Regional 학업 +5
EOI 점수 강화 → 491 (5년) → 191 영주권
```

**총 3-5년 / 학비 약 $40K~$120K (학교 따라)**

---

## 💡 직원이 학생한테 말할 멘트

> "영주권 우선이면 Hobart는 강력한 선택지입니다.
> 
> 1. **491 비자 +15점 (Regional) + Australian Study +5점 = 추가 20점**
> 2. **TAS 정부 nomination 시스템** = Hobart 학업·거주·근무 학생 우대 多
> 3. **485 Second PHEW Extension**: 2025.09부터 Hobart +2년 (이전 +1년에서 강화)
> 4. **TasTAFE 학비 $16K~$22K** = 호주에서 학비 효율 좋은 편
> 5. **호주 코스 예시**: TasTAFE Cookery (1.5년 $24K) / UTAS Nursing (3년) / IT
> 
> 단점도 알려드리면:
> - 인구 25만 작은 도시
> - 알바 자리 시드니/멜번 대비 적음
> - 한인 커뮤니티 적음
> - 겨울 추움 (호주 최남단)
> 
> 영주권 우선이면 그 단점 감수할 가치 있습니다.
> 
> 4천만 예산이면 ELICOS + Diploma 1년차 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 영어 수준  
> ② 직업 흥미  
> ③ Hobart 거주 가능 여부 (작은 도시 + 추위)"

---

## ⚠️ 함정

1. **"Hobart = 시드니보다 학교 수준 낮다"** → ❌ UTAS는 Go8은 아니지만 종합대 정식 자격
2. **"Tasmania만 거주 = 평생"** → 491 5년 + 191 영주권 후 호주 어디든 이주 가능
3. **"한인 多 = 좋은 환경"** → Hobart는 한인 적음 = 영어 환경 더 강함
4. **"Hobart 가산점 +20점"** → 정확히는 491 +15점 (Regional 모두 동일) + Australian Study +5점 = +20점
5. **"Cat 3 도시 다 비슷"** → 도시 인프라 차이 큼 (Hobart 인구 25만 / Darwin 15만 / Cairns 16만)

---

## 📞 카카오 응대 시 필수

1. 영어 수준
2. 직업 흥미
3. Hobart 작은 도시 OK?
4. 가족 동반 여부

---

## 🔍 직원 확인 사이트

- UTAS: utas.edu.au
- TasTAFE: tastafe.tas.edu.au
- Tasmania 정부 이민: migration.tas.gov.au
