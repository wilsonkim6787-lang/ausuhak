# #436 호주_학생_음주_의존_숙취_알코올_DrinkWise_GP_상담

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 1년 됐는데 매주 4-5일 술 마셔요. 한국에서는 가끔 마셨는데 여기는 친구들 다 마시고 외로워서 자꾸 마셔요. 아침에 손 떨리고 우울해요. 멈추고 싶은데 어떻게 해야 하나요? 학생비자라 병원 가기 무서워요."

**직원 멘붕 포인트:**
- Alcohol Use Disorder 평가
- GP 또는 Counsellor 의뢰
- DrinkWise / Hello Sunday Morning
- OSHC 정신건강 커버
- AA (Alcoholics Anonymous) 한국어

---

## ❌ 절대 하지 말아야 할 답

> "술 끊으세요. 의지력 부족이에요"

→ ❌ ❌ 의존증은 의학적 질환. 의지력 평가 X. 윤리 위반 + 실효성 X.

---

## ✅ 정답

음주 의존 단계별: ① 자가 평가 - AUDIT 테스트 (drinkwise.org.au), ② 손 떨림+아침 우울 = 신체 의존 가능성 → 즉시 GP, ③ GP - Mental Health Care Plan 작성 시 OSHC 부분 커버 (10세션/년), ④ AA Australia (aaaustralia.org) - 24/7 무료 모임 / 시드니 Korean 한인 모임 일부, ⑤ Lifeline 13 11 14 (24시간 정신건강), ⑥ Beyond Blue 1300 22 4636, ⑦ Hello Sunday Morning 앱 (호주 정부 무료 앱 / 비공식 익명), ⑧ 학생비자 = 의료 이용 비자 영향 X / 정보 비공개 보장 (의료 비밀), ⑨ 한국 가족 통보 의무 X (성인 의료 사생활).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. AUDIT 테스트**
drinkwise.org.au 자가 평가

**2. Mental Health Care Plan**
GP 작성 / OSHC 10세션

**3. AA Australia**
aaaustralia.org / 무료

**4. Lifeline**
13 11 14 / 24시간 / 한국어

**5. Hello Sunday Morning**
호주 정부 앱 / 무료

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: AUDIT 자가 평가
**2단계**: 2단계: GP 예약 (HotDoc)
**3단계**: 3단계: Mental Health Care Plan 신청
**4단계**: 4단계: Counsellor 또는 AA 모임 참여
**5단계**: 5단계: 한국 가족 알림 = 본인 결정

---

## 💡 직원이 학생한테 말할 멘트

> "음주 의존은 의학적 질환입니다. 의지력 문제 X. GP 예약하시고 Mental Health Care Plan 받으면 OSHC 부분 커버됩니다. Lifeline 13 11 14 한국어 통역 24시간 무료입니다. 비자 영향 절대 없고 의료 비밀 보장됩니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **의지력 평가**
   → 윤리 위반

2. **학생비자 영향**
   → 법적으로 무관

3. **의료 정보 학교 통보**
   → Privacy Act 위반

4. **한국 부모 자동 통보**
   → 성인 사생활

5. **OSHC 정신건강 X**
   → Care Plan 부분 커버

6. **AA 영어만**
   → 한국어 모임 일부

7. **Hello Sunday Morning 유료**
   → 정부 무료

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 음주 빈도 / 양
2. 신체 증상 (손 떨림/우울)
3. OSHC 가입사
4. 응급 위험도 (자살/자해 사고)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('DrinkWise', 'drinkwise.org.au')
- ('AA Australia', 'aaaustralia.org')
- ('Lifeline', 'lifeline.org.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 자료 안내, 비자 영향 X 안내

**MARA / 변호사 영역**
- 형사 사건 동반 시 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 의학적 질환 인식 강조함
- [ ] Mental Health Care Plan 안내함
- [ ] Lifeline 한국어 안내함
- [ ] AA Australia 안내함
- [ ] 비자/학교 통보 X 강조함
- [ ] 한국 가족 자동 통보 X 명시함
