# #225 호주 응급실 사용법

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 친구가 갑자기 배가 아파서 응급실 가야 한대요. 어떻게 가나요? 비용은요?"

**직원 멘붕 포인트:**
- 000 응급 전화
- Public vs Private Hospital
- Triage (긴급도 분류)
- OSHC 환급

---

## ❌ 절대 하지 말아야 할 답

> "응급실 가면 한국처럼 바로 진료받아요!"

→ ❌ **호주 응급실 = Triage (긴급도 분류) / 비응급 = 4~8시간 대기**.

---

## ✅ 정답

호주 응급실: ① **000** = 응급 전화 (구급차 / 경찰 / 소방) ② **응급실 (ED)** = Public Hospital만 (사립 응급실 X 대부분) ③ **Triage** = 5단계 (1=즉시 / 5=2시간) - 비응급 = 4~8시간 대기 ④ **OSHC 환급** = Public Hospital 입원 일부 ⑤ **구급차 (Ambulance)** = 호주 일부 주 자비 ($1,000~$2,500) - VIC / TAS / QLD 가입자 무료 ⑥ **응급 vs After Hours GP** 구분 필요. 한국과 다름.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 응급 vs 비응급
- **응급 (000)**: 의식 X / 호흡 X / 큰 출혈 / 가슴 통증 / 발작
- **비응급 GP After Hours**: 감기 / 소화 불량 / 가벼운 부상

### 2. 000 (응급 전화)
- 24시간 무료
- 구급차 / 경찰 / 소방
- 위치 / 증상 설명

### 3. Triage (긴급도 분류)
| Category | 대기 시간 |
|----------|-----------|
| 1 (Resuscitation) | 즉시 |
| 2 (Emergency) | 10분 |
| 3 (Urgent) | 30분 |
| 4 (Semi-urgent) | 1시간 |
| 5 (Non-urgent) | 2시간 (실제 4~8시간) |

### 4. 구급차 (Ambulance) 비용
- **NSW**: $400~$8,000 (Health Cover 환급)
- **VIC**: $1,200~$2,500 (Ambulance Victoria 가입 시 무료)
- **QLD**: 무료 (정부 지원)
- **WA**: $400~$1,000
- **OSHC**: 구급차 환급 (보험사별 다름)

### 5. Public vs Private Hospital
- **Public**: 응급실 / 무료 (Medicare) / 대기 길음
- **Private**: 응급실 X 대부분 / 입원 자비 / 즉시 진료 가능

---

## 🎯 정답 경로

### Step 1: 응급도 판단
- 의식 / 호흡 / 출혈 → 000 (구급차)
- 비응급 → After Hours GP / Walk-in Clinic

### Step 2: 응급실 도착
- Public Hospital ED
- Triage Nurse 등록 (여권 / 비자 / OSHC 카드)
- 대기

### Step 3: 진료
- 의사 진료 (Triage 순)
- 검사 / 처방 / 입원 결정

### Step 4: OSHC 청구
- 영수증 보관
- OSHC 보험사 청구 (앱 / 온라인)
- 일부 환급

---

## 💡 직원 멘트

> "안녕하세요! 호주 응급실 안내드릴게요.
>
> ✅ 응급 (의식 / 호흡 / 큰 출혈) → 000 (구급차)
> ✅ 비응급 → After Hours GP / Walk-in Clinic
> ✅ Public Hospital ED만 (사립 응급실 X 대부분)
> ✅ Triage 분류 (비응급 4~8시간 대기)
> ✅ 구급차 비용 (주별 다름 / OSHC 환급)
>
> 호주 응급실 = 한국과 달라서 비응급은 GP / Walk-in이 빨라요!
>
> 응급 시 즉시 000! 평소 보험 / 진료 윌슨님 상담받으세요. 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 6개

1. ❌ "응급실 즉시 진료" → ✅ Triage 대기 (비응급 4~8시간)
2. ❌ "구급차 무료" → ✅ 주별 자비 (NSW $400+)
3. ❌ "Private 응급실 OK" → ✅ Private = 응급실 X 대부분
4. ❌ "OSHC 응급실 무료" → ✅ Public 입원 일부 / 외래 일부
5. ❌ "응급실 = GP 대체" → ✅ Triage / 비응급 우선순위 낮음
6. ❌ "한국 응급실과 같음" → ✅ 다름 (대기 / Triage)

---

## 📞 필수 4가지 확인

1. ✅ 응급도 판단 (의식 / 호흡 / 출혈)
2. ✅ 000 vs After Hours GP
3. ✅ OSHC 카드 / 보험사 안내
4. ✅ 구급차 비용 / 환급

---

## 🔍 직원 사이트

- **Healthdirect (응급도 판단)**: https://www.healthdirect.gov.au
- **각 주 응급실 위치**: 주별
- **Ambulance Victoria**: https://www.ambulance.vic.gov.au

---

## 🚨 직원 vs 윌슨 vs 응급

**직원**: 응급 시스템 일반 안내
**윌슨**: OSHC / 일반 의료 안내 (응급 X)
**응급**: 즉시 000 (의사 / 119)

---

## ✅ 체크리스트

- [ ] 응급 vs 비응급 구분 강조
- [ ] 000 즉시 안내 (응급 시)
- [ ] After Hours GP / Walk-in 안내
- [ ] 구급차 비용 / OSHC 환급 안내
- [ ] OSHC 카드 항상 소지 강조
