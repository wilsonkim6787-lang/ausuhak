# #321 호주_IELTS_점수_부족_어학원_Foundation_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 IELTS 5.0인데 호주 대학 가고 싶어요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- IELTS 5.0 = 학생비자 가능 (DHA 최저 5.5 단, 어학원 포함 패키지 가능)
- 어학원 (ELICOS) 패키지 = 일반 경로
- Foundation 1년 = 영어 + 학과 사전 준비
- Pathway College = Diploma → Bachelor 자동 1년 인정
- 직원이 정확한 경로 안내 = 학생 안심

---

## ❌ 절대 하지 말아야 할 답

> "IELTS 5.0이면 호주 대학 못 가요."

→ ❌ IELTS 5.0 = 직접 입학 X. 단, 어학원/Foundation/Pathway 다양한 경로로 진학 가능. 특히 한국 학생 다수 활용. 직원이 옵션 정확히 안내 필요.

---

## ✅ 정답

**IELTS 점수별 호주 진학 경로:**

**IELTS 5.0~5.5 (가장 흔한 케이스):**
- 어학원 (ELICOS) Direct Entry 패키지 = 가장 일반
- Foundation Program 1년
- Pathway College Diploma

**IELTS 5.5~6.0:**
- ELICOS 단기 (10~20주) + Foundation/Diploma
- 일부 학교 = Direct Entry (조건부)

**IELTS 6.0~6.5:**
- Bachelor 직접 입학 (대부분 학교)
- ELICOS 단축 (선택)

**IELTS 7.0+:**
- 간호 / 의료 / 교직 직접 입학
- G8 Top Tier 입학

**1. 어학원 (ELICOS) Direct Entry 패키지:**

**구조:**
- 어학원 10~50주 + 본 코스 패키지
- 어학원 졸업 = IELTS 면제 (ELICOS Direct Entry)
- 학교 부설 어학원 또는 제휴 어학원

**주요 어학원:**
- USyd Centre for English Teaching (CET)
- UNSW Institute of Languages
- Monash English (Monash College)
- UQ ICTE
- ANU Centre for Continuing Education

**비용:**
- $400~$600/주
- 10주 = $4,000~$6,000
- 25주 = $10,000~$15,000

**중요 ⚠️:**
- 간호 = ELICOS Direct Entry IELTS 면제 X (NMBA 7.0 필수)
- 일반 학과 = 면제 가능

**2. Foundation Program (1년):**

**구조:**
- 1년 영어 + 학과 사전 준비
- 영어 IELTS 5.5+ 시작 가능
- Bachelor 1학년 자동 진학 (학교 합격 시)

**주요 Foundation:**
- USyd Foundation (Taylors College)
- UNSW Foundation (UNSW College)
- Monash Foundation (Monash College)
- UTS Foundation (UTS Insearch)
- UQ Foundation

**비용 + 기간:**
- $25,000~$35,000/년
- Standard 1년, Extended 1.5년 (영어 부족 시)

**3. Pathway College Diploma:**

**구조:**
- 1년 Diploma → Bachelor 2학년 직접 입학
- 영어 IELTS 5.5~6.0 시작
- 학과별 전문 (Business/Engineering/IT/Health)

**주요 Pathway:**
- USyd College (Diploma)
- UNSW College (Diploma)
- UTS Insearch (Diploma)
- Monash College (Diploma)
- Eynesbury College (Adelaide)

**비용:**
- $30,000~$45,000/년
- Bachelor 2학년 자동 1년 인정

**4. TAFE Diploma 경로:**

**구조:**
- TAFE NSW/VIC/QLD Diploma (1~2년)
- IELTS 5.5 시작
- 대학 Bachelor 2학년 편입 (TAFE NSW Diploma → UTS Bachelor 자동)

**비용:**
- $14,000~$20,000/년
- Bachelor 학비 절약

**경로 비교:**

| 경로 | IELTS 시작 | 기간 | 총 비용 | Bachelor 졸업 |
|------|-----------|------|---------|--------------|
| 어학원 + Bachelor | 5.0 | 4년 | $80K~$120K | 4년 |
| Foundation + Bachelor | 5.5 | 4년 | $90K~$130K | 4년 |
| Pathway Diploma + Bachelor | 5.5 | 3.5년 | $70K~$110K | 3.5년 |
| TAFE Diploma + Bachelor | 5.5 | 3년 | $50K~$80K | 3년 |

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ELICOS Direct Entry**
어학원 졸업 = IELTS 면제. 단, 간호 = 면제 X. 학교 부설 어학원 일반.

**2. Foundation Program**
1년 영어 + 학과 준비. 영어 5.5 시작. Taylors/UNSW College/UTS Insearch.

**3. Pathway Diploma**
1년 Diploma → Bachelor 2학년 직접. USyd College/Monash College/UTS Insearch.

**4. TAFE Diploma → Bachelor 편입**
TAFE NSW Diploma → UTS Bachelor 1년 자동 인정. 일반 경로 (학비 효율적).

**5. 간호 IELTS 7.0 (NMBA)**
간호 = ELICOS Direct Entry IELTS 면제 X. 7.0 필수.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **현재 IELTS + 목표 학과 확인** - 5.0/5.5/6.0 + 간호/일반
**2단계**: **경로 결정** - 어학원/Foundation/Pathway/TAFE
**3단계**: **학교 + 어학원 패키지 신청** - CoE 발행, 학생비자 신청
**4단계**: **어학원 단계 졸업** - IELTS 면제 (간호 제외)
**5단계**: **Bachelor 진학** - Foundation/Diploma 졸업 후 자동/조건

---

## 💡 직원이 학생한테 말할 멘트

> "IELTS 5.0이면 어학원 (ELICOS) Direct Entry 패키지 + Foundation 1년 + Pathway Diploma + TAFE Diploma 4가지 경로 모두 가능합니다. 가장 학비 효율 좋은 경로는 TAFE Diploma → Bachelor 2학년 편입이고, Pathway Diploma도 1년 단축 가능합니다. 단, 간호 = IELTS 7.0 (각 영역) 필수이고 ELICOS 면제 X입니다. 학생님 학과 + 영어 + 예산 들려주시면 4가지 경로 객관적 비교 안내드립니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **IELTS 5.0 = 호주 못 감**
   → 어학원/Foundation/Pathway/TAFE 다 가능. 다양한 경로 일반.

2. **어학원 = 학사 시간 낭비**
   → 어학원 졸업 = IELTS 면제 + 본 코스 진학. 한국 학생 다수 활용.

3. **Foundation = 1년 추가**
   → Foundation = 1년 단축 효과 (Bachelor 자동 진학). Pathway Diploma = 더 단축.

4. **Pathway Diploma = 인정 안 됨**
   → USyd College/UNSW College = 학교 부설. Bachelor 1년 자동 인정 학교 정책.

5. **TAFE = 사립**
   → Holmesglen/Chisholm/TAFE NSW = 정부 TAFE. 사립 X.

6. **간호 어학원 면제**
   → 간호 = NMBA 7.0 필수. ELICOS Direct Entry 면제 X.

7. **어학원 패키지 = 학생비자 1개**
   → 어학원 + 본 코스 = 단일 학생비자 (포괄). 단, 학교 변경 시 갱신.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 IELTS 점수 + 시험 시기
2. 목표 학과 (간호 = 7.0 별도)
3. 예산 + 기간 (단축 vs 학비 효율)
4. 한국 학력 + 출국 시기

---

## 🔍 직원이 직접 확인 가능한 사이트

- Taylors College (USyd Foundation): www.taylorscollege.edu.au
- UNSW College: www.unswcollege.edu.au
- UTS Insearch: www.utscollege.edu.au
- Monash College: www.monashcollege.edu.au
- TAFE NSW: www.tafensw.edu.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 4가지 경로 일반 정보 비교
- 어학원/Foundation/Pathway/TAFE 객관적 안내
- 간호 IELTS 7.0 별도 강조

**MARA / 변호사 영역**
- 패키지 비자 신청 = MARA
- 비자 거절 분쟁 = MARA
- ELICOS 학교 변경 분쟁 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] 현재 IELTS + 목표 학과 확인
- [ ] 4가지 경로 객관적 비교
- [ ] 간호 = 7.0 + ELICOS 면제 X 강조
- [ ] TAFE = 학비 효율 안내
- [ ] 어학원 패키지 일반 경로 안내
- [ ] 주관적 추천 X (객관적 정보만)
