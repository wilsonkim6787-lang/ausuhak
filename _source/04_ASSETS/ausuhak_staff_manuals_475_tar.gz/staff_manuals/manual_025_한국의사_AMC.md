# 📚 직원 응대 매뉴얼 #025

**케이스: 33세 / 한국 의사 + 5년 경력 / 호주 의사 / AMC 시험**

---

## 🎬 상황 시뮬레이션

> 한국에서 의사 면허 받고 5년 일했어요. 호주에서 의사로 일하고 싶은데 어떻게 해야 하나요?

**👉 정답**: **AMC 시험 (Australian Medical Council) + AHPRA 등록**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ AMC = 호주 의사 평가 + 등록 기관

**AMC** (Australian Medical Council) = 해외 의사가 호주 의사 등록을 위한 평가 시스템.

```
한국 의사 면허 + 경력 + IELTS 7.0
        ↓
1단계: AMC Eligibility Check (학위 평가) - 약 6개월
        ↓
2단계 AMC MCQ Examination: 컴퓨터 이론 시험
        ↓
3단계 AMC Clinical Examination: 임상 시험 (호주 현지)
        ↓
AHPRA 등록 (제한 또는 일반)
```

### 2️⃣ AMC MCQ + Clinical 시험

| 시험 | 형식 | 시험비 | 위치 |
|---|---|---|---|
| AMC MCQ | 컴퓨터 다지선다 (3.5시간) | 약 $2,800 | Pearson VUE (한국 응시 가능) |
| AMC Clinical | OSCE 16개 시뮬레이션 | 약 $4,800 | 호주 현지 (Sydney/Melbourne/Adelaide) |

### 3️⃣ 영어 조건

- **IELTS 7.0 (각 영역 7.0)** 또는 OET B grade
- 한국 영어 학위 증명도 일부 가능

### 4️⃣ AMC 통과 후 = Provisional Registration → General Registration

- **Provisional**: AMC 통과 + 호주 병원 1년 인턴 必
- **General**: 인턴 마치고 정식 등록
- General Practitioner (GP) = 추가 RACGP 시험 필요

### 5️⃣ Wisdom 한국 의사 vs 호주 의사

- 한국 의사 → 호주 GP 전환 = 매우 어렵고 시간 多 (5-7년)
- 한국 의사 → 호주 Specialist = 전문의 시험 별도
- **현실**: 한국 의사 2/3는 호주 와도 다른 진로 (경영/연구) 선택

---

## 🎯 정답 경로

### AMC + Provisional + General Registration

```
한국 의사 + 5년 경력 + IELTS 7.0
        ↓
AMC Eligibility Check (6개월)
        ↓
AMC MCQ 시험 (한국 응시) - 통과 약 50%
        ↓
AMC Clinical 시험 (호주 현지) - 통과 약 60%
        ↓
Provisional Registration + 호주 병원 인턴 1년
        ↓
General Registration → GP 또는 Specialist
```

**총 3-7년 / 비용 약 $7,600 + 호주 체류비**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 의사가 호주 의사로 전환하는 길은 가능하지만 매우 길고 어렵습니다. 솔직히 말씀드리면:
> 
> 1. **AMC 시험 통과율 약 50%** (MCQ) / **60%** (Clinical) = 한 번에 통과 어려움
> 2. **호주 인턴 1년 필수** = 호주 병원 자리 직접 구해야
> 3. **GP 자격 추가** = RACGP 시험 별도 (3년 추가)
> 4. **총 3-7년** + 비용 多
> 
> 한국 의사 분들이 호주에서 의사 전환하는 케이스는 적습니다. **현실적 대안**:
> 
> - **Master of Public Health** (보건 정책 / 연구)
> - **Master of Health Administration** (병원 경영)
> - **Research Fellow** (대학 연구원)
> - **현지 의대 재진학** (한국 학력 인정 일부)
> 
> 카톡 1:1 상담에서 본인 5년 후 목표 + 호주 거주 우선순위에 따라 정확한 경로 안내드립니다.
> 
> ① IELTS 정확한 점수  
> ② 한국 의사 분야 (내과/외과/소아 등)  
> ③ 의사 전환 vs 다른 분야 검토 가능 여부"

---

## ⚠️ 함정

1. **"한국 의사 자격 = 호주 자동 인정"** → ❌ AMC 시험 必
2. **"AMC 한 번 통과"** → 통과율 50-60% / 여러 번 응시 多
3. **"의사 = 즉시 PR"** → 인턴 1년 + General Reg + 경력 必
4. **"GP 쉬움"** → RACGP 시험 + 3년 추가

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수
2. 한국 의사 분야
3. 의사 전환 의지 vs 다른 분야 OK
4. 가족 동반 여부

---

## 🔍 직원 확인 사이트

- AMC: amc.org.au
- RACGP: racgp.org.au
- AHPRA: ahpra.gov.au
