# #524 호주_학생_휴학_LOA_후_재입학_비자_영향_Compassionate_Defer

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국 가족 일로 1학기 휴학(LOA)하고 싶은데, 학생비자에 영향 있어요? 호주 떠나면 비자 자동 종료돼요?"

**직원 멘붕 포인트:**
- Leave of Absence (LOA) = 학교 휴학 절차 (학기 단위)
- Compassionate Grounds 인정 시 비자 보호
- LOA 시 호주 거주 가능 (학생비자 유지)
- 출국 시 BVB 또는 학생비자 Multi Entry 활용
- Section 19 PRISMS Report 학교 통보 의무

---

## ❌ 절대 하지 말아야 할 답

> "휴학하면 비자 자동 종료돼요 한국 가세요"

→ ❌ Compassionate LOA는 비자 보호. 잘못 안내 시 학생 권리 박탈

---

## ✅ 정답

Compassionate Grounds(가족 사망/중병 등) LOA는 학생비자 영향 없어요. 학교에 LOA 신청하시면 1학기 휴학 가능하고, 학교가 Compassionate 인정 시 Section 19 PRISMS Report에 사유 명시해서 비자 보호받습니다. 호주 거주 가능하고, 출국 시 학생비자 Multi Entry 자동이라 BVB 별도 X(비자 처리 중 X). 단, 휴학 사유 비-Compassionate(여행/단순 결정)면 비자 영향 가능해서 MARA 자문 권장해요. 재입학 시 학교 등록 + Census Date 안 진행하시면 됩니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. LOA (Leave of Absence) 종류**
Compassionate LOA:
- 가족 사망/중병 (직계)
- 본인 중병 (Mental/Physical)
- 재해
- 비자 보호 (Section 19)

Non-Compassionate LOA:
- 여행/휴식
- 직업 시도
- 단순 결정
- 비자 위험 (Course Progress 미달)

Compassionate 권장:
- GP/심리 상담사 진단서
- Death Certificate
- Police Report (재해)

**2. LOA 신청 절차 (학교)**
1. 학생 포털 LOA Form
2. 사유 작성 + 증빙 첨부:
   - GP 진단서 (Mental Health 포함)
   - Death Certificate
   - 가족관계증명서
3. 학과 + Faculty 승인
4. 학생비자 Section 19 PRISMS Report 자동
5. 휴학 기간 (보통 1~2 semester)
6. 재등록 + Census Date 안 통보

처리 5~14일
Compassionate은 빠른 처리

**3. 학생비자 Section 19 PRISMS**
Section 19 (ESOS Act):
- 학교 의무 (DHA 통보)
- 사유 명시 (Compassionate vs Non)

Compassionate 인정 시:
- 비자 보호
- Course Progress 면제
- 출석률 면제

Non-Compassionate (Course Progress 미달):
- DHA 검토
- Section 116 NOICC 가능
- 비자 취소 위험
- ART 항변 가능

**4. LOA 중 거주 + 출국**
호주 거주:
- 학생비자 유지
- Casual Job 가능 (학기 중 24시간/주)
- LOA 중 학기 외 = 무제한 (방학 처리)

한국 출국:
- 학생비자 Multi Entry 자동
- BVB 별도 X (비자 처리 중 X 시)
- 비자 카드 + 학생증 휴대

재입국:
- 비자 유효 기간 안 자유
- 재등록 후 학교 출석 의무

**5. 재입학 + 비자 영향**
재입학 절차:
1. LOA 종료 통보 (학교)
2. 새 학기 등록
3. Census Date 안 학비 + 출석
4. 학생비자 변경 X (자동 유지)

비자 영향:
- LOA 1~2 semester: 학생비자 유효 기간 안 OK
- 학생비자 곧 만료: Course 연장 + 비자 갱신 필요
- Compassionate LOA = Course Progress 면제

Course Progress 추적:
- 졸업 예상 시점 확인
- 학교 + 비자 일치

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Compassionate vs Non-Compassionate 사유 확인
**2단계**: GP 진단서 또는 Death Certificate 챙기기
**3단계**: 학생 포털 LOA Form + 증빙 업로드
**4단계**: 학교 승인 + Section 19 PRISMS Report
**5단계**: 재입학 시 학교 등록 + Census Date 안 통보

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. Compassionate Grounds(가족 사망/중병 등) LOA는 학생비자 영향 없어요. 학교에 LOA 신청 + GP 진단서/Death Certificate 첨부하시면 학교가 Compassionate 인정합니다. 호주 거주 가능하고, 출국 시 학생비자 Multi Entry 자동이라 BVB 별도 X 입니다. Non-Compassionate(여행/단순)는 비자 영향 가능해서 MARA 자문 권장해요. 재입학은 새 학기 등록 + Census Date 안 진행하세요. 카카오 ID studywilson 입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **LOA 자동 비자 종료 X**
   → Compassionate 보호

2. **Compassionate vs Non 무관 X**
   → 사유별 영향 다름

3. **증빙 없음 X**
   → GP/Death Certificate 필수

4. **BVB 의무 X**
   → Multi Entry 학생비자

5. **Course Progress 무관 X**
   → Non-Compassionate 위험

6. **재입학 자동 X**
   → 학교 등록 + Census

7. **Section 19 모름 X**
   → 학교 의무 사유 명시

---

## 📞 카카오 응대 시 필수 4가지 확인

1. LOA 사유? (Compassionate/Non)
2. 휴학 기간? (1학기/2학기/1년)
3. GP/Death Certificate? (있다/없다)
4. 비자 만료 언제? (1년 미만/1년+)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Section 19 ESOS: legislation.gov.au
- Section 116 비자 취소: immi.homeaffairs.gov.au
- USyd LOA: sydney.edu.au
- UNSW LOA: unsw.edu.au
- TEQSA: teqsa.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Compassionate vs Non LOA 비교
- LOA 절차 1차 안내
- 비자 영향 1차 안내
- 재입학 절차 안내

**MARA / 변호사 영역**
- Section 116 항변 (MARA)
- Course Progress 변경 (MARA)
- LOA 학교 절차 (학과)
- Compassionate 증빙 (GP/영사관)

---

## ✅ 완벽 응대 체크리스트

- [ ] LOA 사유 확인
- [ ] GP/Death Certificate
- [ ] 학생 포털 LOA Form
- [ ] Section 19 PRISMS 확인
- [ ] 재입학 + Census Date
