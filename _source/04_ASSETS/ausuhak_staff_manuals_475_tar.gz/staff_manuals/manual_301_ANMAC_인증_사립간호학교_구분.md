# #301 ANMAC_인증_사립간호학교_구분

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "간호학과 사립학교 알아봤는데 학비 싸고 IELTS 6.0이래요. 이 학교 괜찮은가요?"

**직원 멘붕 포인트:**
- ANMAC 인증 사립학교 거의 없음 (TAFE 정부 학교 다수)
- IELTS 6.0 = ANMAC 인증 X 신호 (간호 = IELTS 7.0 절대)
- CRICOS 등록 = 호주 정부 학생비자 발급용 / 간호 면허와 무관
- AHPRA 면허 = ANMAC 인증 학교 졸업 필수
- 직원이 모르고 안내 시 학생 졸업 후 면허 X 큰 손해

---

## ❌ 절대 하지 말아야 할 답

> "CRICOS 등록 학교면 호주 정부 인정이니까 간호사 가능해요."

→ ❌ CRICOS = 학생비자 발급 가능 학교 등록만. 간호 면허와 무관. AHPRA (간호사 면허) = ANMAC 인증 코스 졸업 필수. ANMAC 미인증 사립 간호 코스 졸업 = 간호 면허 신청 거부 = 호주 간호사 일 불가.

---

## ✅ 정답

**간호 = ANMAC 인증 학교만 = AHPRA 면허 가능**

**3가지 등록 차이:**

| 등록 | 의미 | 간호 면허 영향 |
|------|------|---------------|
| CRICOS | 학생비자 발급 가능 | 무관 (전부 등록) |
| TEQSA | 대학/사립대 등록 | 무관 |
| ANMAC | 간호 코스 인증 | **필수** (인증 X = 면허 X) |

**ANMAC 인증 학교 (한국 학생 다수 진학):**
- TAFE NSW (Diploma of Nursing) - 정부
- TAFE Queensland (Diploma) - 정부
- TAFE SA (Diploma) - 정부
- Holmesglen (Diploma) - 정부
- Chisholm (Diploma) - 정부
- 호주 모든 공립대 간호학과 (Bachelor)
- ACU (Australian Catholic University) - 사립대
- Notre Dame - 사립대

**ANMAC 미인증 사립학교 위험 신호:**
- IELTS 5.5~6.0만 요구 (정상은 7.0)
- 학비 매우 저렴 (Diploma $10K 이하 = 의심)
- "간호 보조" "간호 자격증" 모호한 명칭
- ANMAC 웹사이트 검색 X
- 졸업 후 AHPRA 면허 신청 = 거부

**확인 방법:**
- ANMAC 공식 사이트: www.anmac.org.au
- "Accredited Programs" 검색
- 학교명 + 코스명 (예: "Diploma of Nursing")
- 인증 만료일 확인

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ANMAC 정의**
Australian Nursing and Midwifery Accreditation Council. 호주 간호 코스 인증 정부 기관.

**2. AHPRA 면허 기준**
ANMAC 인증 코스 졸업 + IELTS 7.0 + Police Check + 보험 = 면허 발급.

**3. CRICOS 등록과 차이**
CRICOS = 학생비자 발급용 / ANMAC = 간호 면허 인증. 다른 시스템.

**4. 정부 TAFE = 안전**
TAFE NSW/QLD/SA/Holmesglen/Chisholm = 정부 + ANMAC 인증 100%.

**5. 사립학교 위험**
사립학교 ANMAC 인증 = 거의 없음. 인증 미확인 사립 진학 = 졸업 후 면허 X.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **ANMAC 사이트 직접 확인** - www.anmac.org.au / Accredited Programs 검색
**2단계**: **학교명 + 코스명 입력** - 예: 'Diploma of Nursing' + 'XX College'
**3단계**: **인증 만료일 확인** - Active Accreditation 확인 (만료일 향후 5년 이상)
**4단계**: **IELTS 7.0 요구 확인** - 7.0 미만 요구 = ANMAC 인증 X 의심 신호
**5단계**: **최종 결정** - 인증 학교만 진학 / 미인증 = 다른 학교 안내

---

## 💡 직원이 학생한테 말할 멘트

> "간호 학교 선택 시 ANMAC 인증이 절대 필수입니다. CRICOS 등록 학교라도 ANMAC 인증 없으면 졸업 후 호주 간호사 면허 받을 수 없습니다. 사립학교가 IELTS 6.0만 요구하면 거의 ANMAC 미인증입니다. ANMAC 공식 사이트 (www.anmac.org.au)에서 직접 확인 가능하고, 안전한 학교는 TAFE NSW/QLD/SA, Holmesglen, Chisholm 등 정부 TAFE입니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **CRICOS 등록 = 간호 면허 가능**
   → CRICOS = 학생비자 발급. ANMAC = 면허. 별개 시스템.

2. **IELTS 6.0 간호 학교도 진학 OK**
   → IELTS 7.0 미만 = ANMAC 인증 X 의심 신호. 졸업 후 면허 X.

3. **학비 싸면 좋은 학교**
   → 사립 간호 $10K 이하 = ANMAC 미인증 가능성 매우 높음.

4. **호주 정부 등록 = 다 같은 인증**
   → 정부 등록 (CRICOS/TEQSA/ASQA) ≠ ANMAC. 별도 인증.

5. **ANMAC 인증 X 학교도 한국 인정**
   → 한국 보건복지부 = 호주 AHPRA 면허 기준 인정. ANMAC 미인증 = 한국에서도 인정 X.

6. **Diploma of Nursing = 다 같다**
   → 공립 TAFE = ANMAC 인증, 사립 = 미인증 다수. 학교명 확인 필수.

7. **Holmesglen / Chisholm = 사립**
   → 둘 다 정부 TAFE. ANMAC 인증. 안전한 선택.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 관심 학교 정확한 이름 (영문)
2. 코스 정확한 명칭 (Diploma of Nursing 등)
3. IELTS 요구 점수 (7.0 미만 = 의심)
4. 학비 (Diploma 기준 $25K~$30K가 정상)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ANMAC 인증 검색: www.anmac.org.au/accredited-programs
- AHPRA 면허: www.ahpra.gov.au
- TAFE NSW 간호: www.tafensw.edu.au
- Holmesglen 간호: www.holmesglen.edu.au
- Chisholm 간호: www.chisholm.edu.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- ANMAC 인증 학교 일반 안내
- 한국 학생 간호 진학 표준 경로 (TAFE EN → Bachelor RN)
- 윌슨 19년 동문 간호 진학 사례

**MARA / 변호사 영역**
- ANMAC 인증 X 학교 졸업 후 분쟁 = 호주 변호사
- AHPRA 면허 거부 항소 = 의료법 변호사
- 학교 환불 분쟁 = 호주 ESOS Act 절차

---

## ✅ 완벽 응대 체크리스트

- [ ] ANMAC 인증 = 간호 면허 절대 필수 강조함
- [ ] CRICOS ≠ ANMAC 차이 설명함
- [ ] 정부 TAFE 안전 옵션 안내함 (NSW/QLD/SA/Holmesglen/Chisholm)
- [ ] ANMAC 공식 사이트 직접 확인 안내함
- [ ] IELTS 7.0 = 모든 간호 = 절대 강조함
- [ ] 사립 학교 위험 신호 설명함
- [ ] 윌슨 1:1 상담 유도함
