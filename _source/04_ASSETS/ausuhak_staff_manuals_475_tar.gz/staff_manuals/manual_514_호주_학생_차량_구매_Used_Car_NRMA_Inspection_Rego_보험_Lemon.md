# #514 호주_학생_차량_구매_Used_Car_NRMA_Inspection_Rego_보험_Lemon

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "중고차 사려는데 NRMA Inspection 받으래요. 뭐예요? Rego 이전이랑 보험 어떻게 해야 해요?"

**직원 멘붕 포인트:**
- NRMA Inspection: 차량 사전 검사 ($295~$395)
- Rego (Registration) 이전 절차 (각 주별)
- CTP (Compulsory Third Party) 보험 의무
- Comprehensive vs Third Party Property 보험
- Lemon Car (불량차) 사전 방지 = Inspection 필수

---

## ❌ 절대 하지 말아야 할 답

> "중고차는 그냥 사면 돼요 검사 필요 없어요"

→ ❌ Lemon Car 위험 큼. NRMA Inspection 필수 + 사후 분쟁 방지

---

## ✅ 정답

중고차 구매는 NRMA Inspection 필수예요(NSW $295~$395, 2~3시간). 차 결함 + 사고 이력 다 확인합니다. 구매 후 (1) Rego 이전 14~21일 안 (각 주별), (2) CTP(Compulsory Third Party) 보험 의무 - Rego 포함, (3) Comprehensive Insurance 또는 Third Party Property 가입 권장. 학생비자도 호주 운전면허로 Rego/보험 다 가능합니다. 한국 면허는 12개월 후 호주 면허 변환 의무예요(NSW). 가격은 시장가 비교 (CarSales/Gumtree) 후 협상하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. NRMA Inspection (NSW)**
NRMA: nrma.com.au
Mobile Inspection (방문):
- $295 (Basic)
- $395 (Comprehensive)
- 2~3시간
검사:
- 엔진/변속기
- 브레이크/타이어
- 차체/녹
- 사고 이력 (PPSR)
- 주행거리 위조 확인

VIC: RACV / QLD: RACQ / SA: RAA / WA: RAC

**2. Rego 이전 절차 (NSW)**
Service NSW: service.nsw.gov.au
필요 서류:
1. NSW 운전면허
2. 차량 매매 영수증
3. 차량 등록증 (REVS)
4. Pink Slip (eSafety Check) - 5년+ 차
5. Blue Slip (구매자 검사) - 일부
비용:
- Stamp Duty (가격 3~5%)
- Transfer Fee $36
기한: 14일 안
VIC/QLD/WA 비슷한 절차

**3. CTP (Compulsory Third Party) 의무**
CTP = Greenslip (NSW)
보장:
- 사고 시 다른 사람 부상/사망 보상
- 차량/재산 X (Comprehensive 필요)
비용:
- $400~$1,000/년 (NSW)
- 차종 + 운전 이력
Rego와 함께 자동
주요 회사:
- AAMI, Allianz, GIO, NRMA, QBE, Suncorp

**4. Comprehensive vs Third Party Property**
Comprehensive (종합 보험):
- 본인 차 + 다른 차 + 재산
- 도난, 화재, 자연재해
- $800~$2,500/년
- 신차/고가차 권장

Third Party Property:
- 다른 차/재산만
- 본인 차 X
- $300~$700/년
- 중고차 일반

Excess: $500~$2,000 (사고 시 본인 부담)

**5. 학생비자 운전면허 + 보험**
학생비자 운전:
- 한국 면허 12개월 (NSW International Driver Permit)
- 12개월 후 호주 면허 변환 의무
- 변환 비용 $50~$100
- 시험 면제 (한국 면허 인정)

보험 가입:
- 학생비자 OK
- 운전 이력 짧음 (Loaded Premium)
- 한국 운전 이력 일부 인정 (NRMA Loyalty)
- Comprehensive 권장 (사고 시 큰 손실)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 차량 검색 + 시장가 비교 (CarSales/Gumtree)
**2단계**: NRMA Inspection $295~$395 예약
**3단계**: Inspection 후 협상 또는 거절
**4단계**: 구매 + Rego 이전 14일 안 (Service NSW)
**5단계**: Comprehensive 또는 Third Party Property 보험

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 중고차 구매는 NRMA Inspection $295~$395 필수예요. Rego 이전 14일 안, CTP 보험 의무(Rego 포함), Comprehensive 또는 Third Party Property 보험 가입하세요. 한국 면허는 12개월 후 호주 면허 변환 의무입니다(시험 면제). 학생비자도 운전 + 보험 다 가능해요. 시장가 비교(CarSales/Gumtree) 후 협상하세요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Inspection 안 함 X**
   → Lemon Car 위험

2. **Rego 14일 무시 X**
   → Stamp Duty 가산

3. **CTP만 충분 X**
   → 본인 차 X. Comprehensive 필요

4. **한국 면허 평생 X**
   → 12개월 후 호주 변환

5. **Pink Slip 무관 X**
   → 5년+ 차 의무

6. **운전 이력 한국 인정 X**
   → NSW 시험 면제만

7. **Excess 무관 X**
   → 사고 시 본인 부담

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 차량 가격? ($5K 미만/$5K~$15K/$15K+)
2. 어느 주? (NSW/VIC/QLD/기타)
3. 한국 면허 호주 변환했어요? (했다/안 했다)
4. Inspection 받았어요? (예/아니오)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NRMA Inspection: nrma.com.au
- Service NSW Rego: service.nsw.gov.au
- PPSR (사고 이력): ppsr.gov.au
- CarSales: carsales.com.au
- 보험 비교: youi.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- NRMA Inspection 1차 안내
- Rego 이전 절차 안내
- CTP vs Comprehensive 비교
- 한국 면허 변환 안내

**MARA / 변호사 영역**
- Lemon Car 분쟁 (NCAT/Civil Lawyer)
- Rego 분쟁 (Service NSW)
- 보험 청구 분쟁 (AFCA)
- 사고 손해배상 (Civil Lawyer)

---

## ✅ 완벽 응대 체크리스트

- [ ] 시장가 비교
- [ ] NRMA Inspection
- [ ] Rego 14일 이전
- [ ] Comprehensive 또는 Third Party
- [ ] 한국 면허 12개월 변환
