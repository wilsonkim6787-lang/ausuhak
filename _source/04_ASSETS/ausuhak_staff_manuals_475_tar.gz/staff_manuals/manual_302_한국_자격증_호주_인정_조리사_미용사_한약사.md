# #302 한국_자격증_호주_인정_조리사_미용사_한약사

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 한국에서 조리사 자격증 있는데 호주에서 인정되나요? 바로 일할 수 있나요?"

**직원 멘붕 포인트:**
- 한국 자격증 ≠ 호주 자격증 (대부분 인정 X)
- 직업별 평가 기관 다름 (TRA / VETASSESS / 직종별)
- 조리사 = TRA Skills Assessment (Trade)
- 미용사 = TRA
- 한약사 = 호주 인정 없음 (한국 한의학 호주 시스템 외)
- 직원이 잘못 답하면 학생 비자/PR 계획 무너짐

---

## ❌ 절대 하지 말아야 할 답

> "한국 조리사 자격증 있으면 호주에서 바로 일할 수 있어요."

→ ❌ 한국 조리사 자격증 = 호주 자동 인정 X. TRA (Trades Recognition Australia) Skills Assessment 통과 필수. 통과 시에도 호주 Cookery Certificate III/IV 추가 학습 필요한 경우 다수. 한약사 = 호주 의료 시스템 외 (인정 없음).

---

## ✅ 정답

**한국 자격증별 호주 인정 여부**

| 한국 자격증 | 호주 인정 | 경로 |
|------------|---------|------|
| 조리사 | TRA 평가 가능 | TRA + Cookery Cert III/IV 추가 학습 다수 |
| 미용사 (헤어) | TRA 평가 가능 | TRA + Cert III/IV |
| 미용사 (네일/피부) | TRA 평가 가능 | Cert III/IV Beauty |
| 간호사 | ANMAC + AHPRA | RN = AHPRA 면허 시험 + IELTS 7.0 |
| 의사 | AMC | AMC 시험 + 인턴 (어려움) |
| 약사 | KAPS | KAPS 시험 + IELTS 7.0 |
| 치과의사 | ADC | ADC 시험 (매우 어려움) |
| 한약사/한의사 | **인정 X** | 호주 의료 시스템 외 |
| 회계사 | CPA Australia | 학력 평가 + 시험 |
| IT (정보처리기사 등) | ACS | 학력 + 경력 평가 |
| 변호사 | Legal Profession Admission Board | 어려움 (호주 법대 LLB 필요) |
| 교사 | AITSL | 학력 + IELTS 7.0/8.0 |
| 엔지니어 | Engineers Australia | KEC2015 또는 CDR |
| 사회복지사 | AASW | 학력 평가 + 자격 시험 |

**TRA Skills Assessment (Trade):**
- Trades Recognition Australia
- 한국 자격증 + 경력 (3~5년)
- Pathway: Job Ready Program (JRP) - 4단계 호주 일+학습
- 비용: $1,580
- 결과: PR Skill Assessment 인정

**JRP 구체:**
- Stage 1: Provisional Assessment (학력+경력 검토)
- Stage 2: Job Ready Employment ($925)
- Stage 3: Job Ready Workplace Assessment
- Stage 4: Job Ready Final Assessment

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. TRA 정의**
Trades Recognition Australia. 호주 정부 트레이드 평가 기관. 조리사/미용사/용접/배관 등.

**2. Job Ready Program (JRP)**
TRA 평가 4단계. 호주에서 1년 + 360시간 일하며 평가.

**3. VETASSESS**
TRA 외 직업 (Track A: 학사+경력, Track B: 학사 무관, Track C/D: 학력 다양). $1,055.

**4. AHPRA 의료 직종**
간호/의사/약사/치과/물리치료/사회복지 등 = AHPRA 산하 별도 평가.

**5. 한약사/한의사 호주 시스템 외**
호주 = 서양 의학 + 일부 보완대체의학. 한국 한의학 = 호주 면허 없음.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **한국 자격증 종류 확인** - 조리사/미용사/간호 등 정확한 자격명
**2단계**: **호주 평가 기관 식별** - TRA/VETASSESS/AHPRA/직종별
**3단계**: **평가 신청** - 평가 기관 사이트 / 서류 + 비용
**4단계**: **Pathway 진행** - JRP (Trade) / 시험 (의료) / 추가 학습 다수
**5단계**: **Skill Assessment 통과 후 PR/취업** - PR EOI 또는 직접 취업 비자

---

## 💡 직원이 학생한테 말할 멘트

> "한국 자격증의 호주 인정은 직종별 다릅니다. 조리사/미용사 = TRA + Job Ready Program (호주 1년 일+학습), 간호 = AHPRA 면허 시험, 한약사 = 호주 인정 없음입니다. 대부분 호주 추가 학습/시험이 필요하고, 자격증만으로 호주에서 바로 일하기는 어렵습니다. 본인 자격증 + 호주 계획에 맞는 경로 안내가 필요합니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 자격증 = 호주 자동 인정**
   → 거의 모든 직종 추가 평가 + 호주 학습/시험 필수.

2. **조리사 자격증 + 호주 입국 = 즉시 취업**
   → TRA Skill Assessment + JRP (호주 1년) 통과 후 가능.

3. **미용사 = 한국 경력 만으로 PR 가능**
   → TRA + JRP 통과 + 영어 점수 + EOI 점수 (60점 이상) 필요.

4. **한약사도 호주에서 인정**
   → 호주 = 한약사/한의사 면허 시스템 없음. 보완대체의학 일부 (Acupuncture)만 있음.

5. **간호 한국 자격 = AHPRA 인정**
   → 한국 RN = AHPRA 면허 시험 + IELTS 7.0 + 호주 추가 학습 다수.

6. **의사 자격은 호주에서 쉽게 인정**
   → AMC = 매우 어려움. 한국 의사 호주 면허 = 약 5~7년.

7. **자격증 평가 = 1번에 끝남**
   → JRP 4단계 / 의료 시험 / 추가 학습 등 보통 1~3년 소요.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 자격증 종류 + 정확한 자격명
2. 한국 경력 (몇 년 / 어떤 분야)
3. 호주 비자 상태 (학생/워홀/PR 등)
4. 호주 계획 (일/학습/PR)

---

## 🔍 직원이 직접 확인 가능한 사이트

- TRA: www.tradesrecognitionaustralia.gov.au
- VETASSESS: www.vetassess.com.au
- AHPRA: www.ahpra.gov.au
- AMC (의사): www.amc.org.au
- Engineers Australia: www.engineersaustralia.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 한국 자격증 호주 진학/취업 일반 절차 안내
- 윌슨 950명 동문 자격증 인정 사례
- 직종별 학교 + 평가 일반 정보

**MARA / 변호사 영역**
- 복잡한 자격 평가 = 직종별 평가 기관
- Skill Assessment 거절 항소 = MARA
- PR 신청 + Skill Assessment 결합 = MARA
- 한약사 호주 시스템 진입 = 보완대체의학 별도 진로

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 자격증 ≠ 호주 자동 인정 명확히 함
- [ ] 직종별 평가 기관 정확히 안내함
- [ ] TRA/VETASSESS/AHPRA 차이 설명함
- [ ] JRP (Trade) 4단계 절차 안내함
- [ ] 한약사/한의사 호주 인정 X 정정함
- [ ] 추가 학습 + 시험 일반적임 설명함
- [ ] 윌슨 1:1 상담 유도함
