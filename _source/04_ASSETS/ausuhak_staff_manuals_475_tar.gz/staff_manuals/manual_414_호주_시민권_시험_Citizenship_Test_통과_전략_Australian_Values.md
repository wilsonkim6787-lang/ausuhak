# #414 호주_시민권_시험_Citizenship_Test_통과_전략_Australian_Values

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "PR 받고 4년 거주 채워서 시민권 신청하려고요. 시민권 시험 어렵다는데 영어 부족한데 통과 가능한가요? 한국어 시험 있나요? 떨어지면 어떻게 되나요?"

**직원 멘붕 포인트:**
- 시민권 시험 영어 수준 모름
- 한국어 시험 가능 여부
- Australian Values 5문제 새 룰
- 재시험 가능 여부
- 면접까지 통과 후 Ceremony 일정

---

## ❌ 절대 하지 말아야 할 답

> "시험 어려워요, 영어 부족하면 떨어져요"

→ ❌ ❌ 부정확. 시험 매우 쉬운 편(통과율 95%+). 영어는 기초 수준 충분. 한국어 시험 없음. 떨어져도 무료 재시험.

---

## ✅ 정답

시민권 시험: 20문제 중 75% 정답 + Australian Values 5문제 100% 정답 (2020년 추가). 영어 객관식, 매우 쉬움. 통과율 95%+. 한국어 시험 없음 (영어만). 60세 이상 면제. 떨어지면 28일 후 재시험 무료(2회 추가 가능). 시험 후 1~12개월 내 Citizenship Ceremony → 시민권 부여. 한국 국적 자동 상실(이중국적 아님).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 시험 구조 + 통과 기준**
20문제 중 15문제 정답(75%) + Australian Values 5문제 100% 정답. 객관식 4지선다. 시간 45분. 컴퓨터 시험. 즉시 결과. 시험 장소: Service Centre (Sydney CBD, Parramatta, Bankstown 등 NSW 17개 + 전국 70개). 비용 $575 (2025.07부터 인상, 신청비에 포함). 통과 후 Interview + Citizenship Ceremony. 통과율 95%+ (영어 부족자 포함).

**2. Australian Values 5문제 (2020 추가)**
2020.11부터 추가. 100% 정답 의무. 주제: 1) Freedom of speech/association/religion 2) Equality of all (gender/race/religion) 3) Compassion for those in need 4) Equality of opportunity 5) Mutual respect/tolerance/fairness. 'Our Common Bond' 책 Chapter 5 'Australian Values'에서 출제. 매우 명확한 정답 (예: '여성과 남성은 평등한가? Yes').

**3. Our Common Bond 책 (공식 교재)**
homeaffairs.gov.au에서 무료 다운로드 (한국어 번역본 X, 영어만). 이전 정부의 짧은 버전 + 공식 시험 출제 내용 + 호주 역사/지리/정부 구조. 전체 약 80페이지 중 'Testable Section'만 시험 출제 (Part 1 Australia and its people / Part 2 Australia's democratic beliefs / Part 3 Government and the law / Part 4 Australian Values). 모의시험 제공.

**4. 60세 이상 면제 + 영어 면제**
60세 이상: 시험 면제 + 영어 면제 (Citizenship Test 자체 안 봄). 50~59세: 시험 면제 X, 영어는 인터뷰에서 기초만. 시각/청각 장애: 의료 증명서로 면제 가능. 정신 건강 영향(Specialist 진단서): 면제 가능. 한국어 통역 시험 X (영어만). 학생비자 한국 부모님 PR 후 시민권 → 60세 이상 면제 활용 多.

**5. 재시험 + 거부 시나리오**
1차 떨어지면 28일 후 재시험 무료. 2차 떨어지면 28일 후 재시험 무료. 3차 떨어지면 신청 거부 (Refuse) → ART(Administrative Review Tribunal (2024.10.14 AAT 대체)) 항소 가능. Character Test 별도 (전과/세금 미납 등). 재시험 부담 시 'Our Common Bond' Part 1~4만 집중 + 모의시험 5회 반복하면 99% 통과.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: PR 4년 + 마지막 12개월 PR 거주 + 호주 거주 4년(1년/년 이상 부재 X) 조건 확인
**2단계**: homeaffairs.gov.au에서 Citizenship Application 신청 ($575, 2025.07~) + Our Common Bond 다운로드
**3단계**: 교재 1~2주 학습 + 모의시험 (homeaffairs.gov.au Practice Test) 5회 이상
**4단계**: Service Centre에서 시험 + 인터뷰 (당일 처리 多)
**5단계**: 통과 후 1~12개월 내 Citizenship Ceremony 초청장 → 선서 → 시민권 부여

---

## 💡 직원이 학생한테 말할 멘트

> "시민권 시험 걱정 안 하셔도 돼요. 영어 부족해도 95% 이상 통과해요.

시험 구조: 20문제 객관식 + Australian Values 5문제. 매우 쉬워요.
- 일반 20문제: 75% 정답(15개)
- Australian Values 5문제: 100% 정답(5개)

Our Common Bond라는 공식 교재 (homeaffairs.gov.au 무료 다운로드)만 1-2주 보시면 충분해요. 한국어 번역본은 없고 영어만이에요.

한국어 시험은 없습니다. 다만 60세 이상이면 시험 자체 면제예요 (부모님 PR 시민권은 보통 면제).

떨어져도 무료로 재시험 가능해요 (2회 추가 가능). 28일 후 다시 보면 됩니다.

중요한 점: 한국 국적 자동 상실됩니다. 호주는 이중국적 인정하지만 한국이 단일국적주의라 시민권 받는 순간 한국 국적 잃어요(국적법 제15조).

부모님 시민권 + 한국 부동산 + 한국 연금 등 동반 영향이 있어서 윌슨 카톡(studywilson)으로 가족 상황 보내주시면 종합 컨설팅 도와드려요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **시험 매우 어렵다고 안내**
   → ❌ 부정확. 통과율 95%+. 1-2주 공부면 충분.

2. **한국어 시험 가능하다고 안내**
   → ❌ 거짓. 영어만. 다만 60세+ 면제.

3. **재시험 비용 든다고 안내**
   → ❌ 거짓. 첫 신청비 $575에 재시험 2회 무료 포함.

4. **Australian Values 75% 정답 OK라고 안내**
   → ❌ 거짓. 100% (5/5) 정답 의무. 이 부분 가장 중요.

5. **시민권 받아도 한국 국적 유지된다고 안내**
   → ❌ 위험. 한국 국적법 15조 - 외국 국적 취득 시 자동 상실. 이중국적 X.

6. **PR 4년만 채우면 된다고 안내**
   → ❌ 부분 부정확. PR 4년 + 마지막 12개월 PR 거주 + 호주 거주 4년 (해외 1년/년 이상 X).

7. **시험 통과 즉시 시민권이라고 안내**
   → ❌ 거짓. 시험 통과 후 Interview → Citizenship Ceremony → 선서까지 끝나야 부여. 1~12개월 소요.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. PR 거주 기간 (4년 + 마지막 12개월 PR + 1년/년 부재 미만)
2. 60세 이상 여부 (시험 + 영어 면제)
3. Character Test 영향 (전과/세금 미납)
4. 한국 국적 상실 인지 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Citizenship Application: immi.homeaffairs.gov.au
- Our Common Bond 교재: homeaffairs.gov.au (검색: our common bond)
- Practice Test (모의시험): homeaffairs.gov.au/citizenship/test-and-interview
- 한국 국적법 15조: law.go.kr (검색: 국적법)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 시민권 + 한국 국적 상실 + 한국 자산 종합 평가
- 가족 동반 시민권 (부모/자녀) 단계별 안내
- 한국 부동산/연금/병역 영향 분석

**MARA / 변호사 영역**
- PR 4년 거주 입증 (출입국 기록) - MARA 변호사
- Character Test 통과 평가 (전과/세금) - MARA + Criminal Lawyer
- 한국 국적 상실 신고 - 한국 영사관 / 한국 가족관계등록 변호사
- ART 항소 (시험 3회 떨어진 경우) - MARA 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 시험 통과율 95%+ 사실 안내 (걱정 덜기)
- [ ] Our Common Bond 교재 + Practice Test 안내
- [ ] Australian Values 100% 정답 의무 강조
- [ ] 한국어 시험 없음, 60세+ 면제 안내
- [ ] 재시험 무료 2회 안내
- [ ] 한국 국적 자동 상실 명확히
- [ ] PR 4년 + 마지막 12개월 거주 조건 정확히
- [ ] 윌슨 카톡 가족 통합 컨설팅 유도
