# 📚 직원 응대 매뉴얼 #103

**케이스: 23세 / 멜번 / TAFE 졸업 후 485 / "호주 이력서랑 Cover Letter 어떻게 써요? 한국 이력서랑 다르대요."**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 멜번에서 TAFE Hospitality 졸업했어요. 이제 일자리 구해야 하는데 호주 이력서가 한국이랑 다르대요. Cover Letter도 같이 쓰래요. 어떻게 써요? 사진 넣어요? 영문 이력서는 처음이에요.

**👉 직원이 멘붕하는 순간**
- "호주 이력서 = 한국 다름"
- "사진? 생년월일?"
- "Cover Letter 형식?"
- "양식 어디서?"

**❌ 절대 하지 말아야 할 답**
- "한국 이력서 영어로 번역하세요" → **거짓**
- "사진 넣으세요" → **거짓** (호주 = 사진 X)
- "생년월일 넣으세요" → **거짓** (차별 방지 = 안 넣음)

**✅ 직원이 알아야 할 정답**
호주 이력서 = **한국과 완전 다름**:

1. **사진 X** (차별 방지)
2. **생년월일 X**
3. **결혼/자녀 X**
4. **국적 = 영주권 상태 OK** (Working Rights)
5. **2~4페이지** (한국 1페이지 X)
6. **Achievements 중심** (역할 X)
7. **Cover Letter** = 회사별 맞춤
8. **Referees** = 2명 (전화/이메일)

직원 = **호주 표준 양식 + 작성법** 안내.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 이력서 표준 구조

**답**: 호주 이력서 = **CV (Curriculum Vitae)** 또는 **Resume**. 표준 구조 = 7~8섹션.

**호주 이력서 구조**:

**1. Personal Details (상단)**
- Name (Full Name)
- Email + Phone
- LinkedIn URL (선택)
- Suburb + State (주소 X)
- ❌ 사진 / 생년월일 / 결혼 / 사진 = 모두 X

**2. Career Objective / Profile (4~5줄)**
- 자기 요약
- 직무 + 경력 + 강점

**3. Key Skills (5~10개)**
- 직무 관련 스킬
- 예: Customer Service, Microsoft Excel, Conflict Resolution

**4. Work Experience (역순 = 최근 먼저)**
- 회사명 / 직무 / 기간 / 위치
- **Achievement 중심** (Action Verbs)
- 3~5 bullet points

**5. Education (역순)**
- 학교명 / 학위 / 기간
- Diploma of Hospitality, TAFE NSW, 2024-2025

**6. Certifications (선택)**
- RSA / RCG / First Aid 등 (호주 자격증)
- Driver's License

**7. Referees (2명)**
- 이름 / 직책 / 회사 / 연락처
- 또는 "Available upon request"

**페이지 수**:
- Junior (졸업~3년): **1~2페이지**
- 경력 (5년+): **2~3페이지**
- 한국식 1페이지 X

**출처**: SEEK Resume Guide, Indeed Australia

---

### 2️⃣ Career Objective + Achievements

**답**: 호주 이력서 핵심 = **Career Objective** + **Achievements** (역할 X).

**Career Objective (4~5줄)**:

예시 (TAFE Hospitality 졸업):
> Recent Diploma of Hospitality graduate from TAFE NSW with 6 months of customer service experience in busy Sydney cafes. Proven ability to deliver excellent customer service in fast-paced environments. Skilled in cash handling, point-of-sale systems, and Italian coffee preparation. Seeking a hospitality supervisor role at a quality-focused venue to apply leadership skills.

**핵심**:
- 졸업 학과 + 경력
- 강점 (구체)
- 목표 직무

**Achievement (Bullet Points)**:

❌ **잘못 (한국식, 역할만)**:
- Worked at a cafe in Sydney
- Made coffee for customers
- Cleaned tables
- Handled cash

✅ **올바름 (호주식, Achievement)**:
- **Served 200+ customers per shift** in a busy Sydney CBD cafe, maintaining 4.8/5 customer satisfaction rating
- **Trained 3 new baristas** on espresso machine operations and reduced coffee preparation time by 25%
- **Implemented new cleaning checklist**, improving health inspection scores from 4.5 to 5.0
- **Cash handling** = managed up to $3,000/day with zero discrepancies

**Action Verbs**:
- Achieved / Improved / Increased / Reduced
- Trained / Led / Managed / Coordinated
- Implemented / Developed / Created
- Served / Delivered / Maintained

**숫자 = 핵심**:
- 고객 수
- 매출
- 시간 절약 %
- 만족도

**출처**: SEEK Resume Guide

---

### 3️⃣ Cover Letter 형식

**답**: Cover Letter = **회사별 맞춤** 1페이지. 4문단 구조.

**Cover Letter 구조 (4문단)**:

**상단**:
- 본인 이름 / 연락처
- 날짜
- 회사 이름 / 주소
- "Dear [Hiring Manager]" (이름 알면 = 이름)
- 또는 "Dear Hiring Manager"

**문단 1: Introduction**
- 어떤 직무 지원
- 어디서 봤나 (SEEK / LinkedIn)
- 1줄 자기 요약

예:
> I am writing to apply for the Hospitality Supervisor position advertised on SEEK. As a recent Diploma of Hospitality graduate from TAFE NSW with 6 months of café experience, I am excited about the opportunity to contribute to your team at [Company Name].

**문단 2: Why You're Right**
- 직무 요건 매칭
- 강점 + Achievement 1~2개
- STAR 짧게

예:
> In my recent role at Sydney CBD Café, I served over 200 customers per shift and trained three new baristas, reducing preparation time by 25%. My ability to handle high-volume environments while maintaining excellent customer service makes me well-suited for this role.

**문단 3: Why This Company**
- 회사 조사 결과
- 회사 가치/제품과 본인 매칭

예:
> I am particularly drawn to [Company Name] because of your commitment to local Australian produce and your award-winning customer service. I share your passion for quality coffee and would love to contribute to your team's continued success.

**문단 4: Closing**
- 면접 기다림
- 감사 인사
- "Yours sincerely" (이름 알 때) / "Yours faithfully" (모를 때)

예:
> I would welcome the opportunity to discuss how my skills and experience align with your team's needs. Thank you for considering my application. I look forward to hearing from you.
>
> Yours sincerely,
> [Name]

**길이**: 1페이지 (반페이지~3/4페이지 일반).

**출처**: SEEK Cover Letter Guide

---

### 4️⃣ Referees (추천인)

**답**: 호주 = **Referees 2명** 일반. 회사 = 직접 전화/이메일 확인.

**Referees 정의**:
- 이전 직장 매니저
- TAFE/대학 교수
- 인턴십 supervisor
- (가족 X, 친구 X)

**Referees 정보 (이력서 하단)**:
- Full Name
- Job Title / Company
- Email + Phone
- 관계 (Manager, Supervisor)

예:
```
REFEREES

1. John Smith
   Café Manager, Sydney CBD Café
   Email: john@cafe.com.au
   Phone: 0412 345 678
   (Direct manager, 6 months)

2. Sarah Lee
   Head of Hospitality, TAFE NSW
   Email: sarah.lee@tafensw.edu.au
   Phone: (02) 9217 3000
   (Course instructor, 12 months)
```

**또는 = "Available upon request"**:
- 이력서에 "Referees available upon request"
- 인터뷰 후 = 회사 요청 시 제공
- 현재 직장 비밀 보호 시

**Referees 미리 알리기**:
- 추천인에게 미리 동의 받기
- "회사 X에서 연락올 수 있어요"
- 예상 질문 미리 준비

**호주 직장 = Referee Check 일반**:
- 채용 전 = 추천인 직접 통화
- 학생 = 한국 직장 매니저 = 영어 가능?
- → 호주 매니저 우선

**출처**: SEEK Referee Guide

---

### 5️⃣ 호주 채용 사이트 + 양식

**답**: 호주 채용 사이트 + 무료 이력서 양식.

**채용 사이트**:
- **SEEK** = 호주 1위 (seek.com.au)
- **LinkedIn** = 전문직 / 직장
- **Indeed** = au.indeed.com
- **Jora** = jora.com
- **Adzuna** = adzuna.com.au
- **Hospitality only**: barcats.com.au, hospoworld.com.au
- **Trades**: tradiesalary.com.au

**무료 이력서 양식**:
- **Canva** (canva.com) = 디자인 양식 무료
- **Google Docs** (template gallery)
- **Microsoft Word Templates**
- **SEEK** (Resume Builder)
- **LinkedIn Resume Builder**

**파일 형식**:
- **PDF 권장** (포맷 깨짐 X)
- 파일명: "Firstname_Lastname_Resume.pdf"
- 또는 "Firstname_Lastname_CoverLetter.pdf"

**제출 = SEEK / LinkedIn**:
- SEEK = 회원 가입 + 이력서 업로드 + Apply
- LinkedIn = Easy Apply 기능
- 회사 사이트 = Career 페이지

**출처**: SEEK, LinkedIn, Indeed Australia

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 한국 vs 호주 차이 인지
- 한국 이력서 영어 번역 X
- 새로 작성

### Step 2: 호주 이력서 작성 (1주일)

**구조 (1페이지~2페이지)**:
1. Personal Details (이름, 이메일, 전화, LinkedIn)
2. Career Objective (4~5줄)
3. Key Skills (5~10개 bullet)
4. Work Experience (역순, Achievement 중심)
5. Education
6. Certifications
7. Referees

**금기**:
- 사진 X
- 생년월일 X
- 결혼/자녀 X
- 한국 주소 X (Suburb, State만)

### Step 3: Cover Letter 작성 (회사별)
- 4문단 = Intro / Why You / Why Company / Closing
- 1페이지
- 회사명 정확히

### Step 4: Referees 2명 확보
- 호주 매니저 (TAFE 인턴십 / 알바)
- TAFE 교수
- 미리 동의 받기

### Step 5: 양식 + 디자인
- Canva 무료 양식
- 깨끗한 폰트 (Calibri, Arial)
- 색상 = 1~2가지 (검정 + 진한 파랑)
- PDF 변환

### Step 6: 채용 사이트 등록
- SEEK 회원 가입
- LinkedIn 프로필 업데이트
- Indeed 회원 가입

### Step 7: 첫 지원 (10개 정도)
- 직무별 Cover Letter 맞춤
- SEEK Apply
- 1주일 후 Follow-up

### Step 8: 윌슨 직접 첨삭 (선택)
- 이력서 + Cover Letter 검토
- 회사별 맞춤 조언
- 인터뷰 준비 연계

---

## 💡 직원이 학생한테 말할 멘트

**[카카오톡 답장 멘트]**

> 호주 이력서 = 한국이랑 완전 달라요. 차근차근 안내드릴게요.
>
> **🚫 한국식 안 됨**:
> - 사진 X
> - 생년월일 X
> - 결혼/자녀 X
> - 1페이지 압축 X
> - "주식회사" 같은 한국 직장명 X
>
> **🟢 호주 표준 (1~2페이지)**:
>
> **1. Personal Details**
> - Full Name
> - Email + Phone
> - LinkedIn URL
> - Suburb, State (정확한 주소 X)
>
> **2. Career Objective (4~5줄)**
> 예: "Recent Diploma of Hospitality graduate from TAFE NSW with 6 months café experience. Skilled in customer service, cash handling, and Italian coffee. Seeking a supervisor role."
>
> **3. Key Skills (5~10개)**
> - Customer Service
> - Cash Handling
> - Espresso Machine Operations
> - Microsoft Excel
> - First Aid Certified
>
> **4. Work Experience (역순)**
> 회사명 / 직무 / 기간 / 위치
>
> ❌ **한국식**:
> - Made coffee
> - Cleaned tables
>
> ✅ **호주식 (Achievement)**:
> - **Served 200+ customers per shift** with 4.8/5 satisfaction rating
> - **Trained 3 new baristas**, reducing prep time by 25%
> - **Cash handling** $3,000/day with zero discrepancies
>
> **숫자 + Action Verbs (Achieved, Improved, Trained)**
>
> **5. Education**
> - Diploma of Hospitality, TAFE NSW, 2024-2025
> - 한국 학력 (있으면)
>
> **6. Certifications**
> - RSA (Responsible Service of Alcohol)
> - First Aid
> - Driver's License (Manual)
>
> **7. Referees (2명)**
> - 호주 매니저 + TAFE 교수
> - 이름 / 직책 / 이메일 / 전화
> - **미리 동의** 받기
> - 또는 "Available upon request"
>
> **📝 Cover Letter (4문단)**:
>
> **문단 1**: 어떤 직무 지원 + 어디서 봤나
> **문단 2**: 본인 강점 + Achievement
> **문단 3**: 회사 가치 + 본인 매칭
> **문단 4**: 면접 기다림 + 감사
>
> **💻 작성 도구**:
> - **Canva** (canva.com) = 무료 양식
> - **Google Docs** templates
> - **SEEK Resume Builder**
> - **PDF로 변환** (포맷 안 깨짐)
> - 파일명: "Firstname_Lastname_Resume.pdf"
>
> **🎯 채용 사이트**:
> - **SEEK** (seek.com.au) = 호주 1위
> - **LinkedIn**
> - **Indeed Australia**
> - **Hospitality**: barcats.com.au
>
> **🚨 첫 단계**:
> 1. Canva에서 호주 이력서 양식 다운
> 2. 7개 섹션 채우기 (Career Objective + Work Experience 핵심)
> 3. PDF 변환
> 4. SEEK 회원 가입 + 업로드
> 5. 10개 회사 지원
>
> 윌슨이 이력서 + Cover Letter 직접 첨삭해드릴 수 있어요. 카카오로 PDF 보내주시면 1:1 피드백 드립니다.
>
> 카카오 ID: studywilson

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "사진 넣어야 전문적"
- **사실**: 호주 = **사진 X** (차별 방지법)
- **올바른 안내**: "사진 절대 X"

### 함정 2: "1페이지로 줄여요"
- **사실**: 호주 = 1~2페이지. 경력 풍부 = 2~3페이지
- **올바른 안내**: "Junior 1~2페이지, 경력 2~3페이지"

### 함정 3: "역할만 적어요"
- **사실**: 역할 = 약함. **Achievement** + 숫자 핵심
- **올바른 안내**: "Action Verbs + 숫자 = 호주 표준"

### 함정 4: "Cover Letter = 같은 거 복사"
- **사실**: 회사별 맞춤. "Why this company" 핵심
- **올바른 안내**: "회사별 다시 작성, 회사 이름 정확히"

### 함정 5: "Referees = 친구 OK"
- **사실**: 직장 매니저 / 교수만. 친구/가족 X
- **올바른 안내**: "직장 매니저 + 학교 교수"

### 함정 6: "Word 파일로 보내기"
- **사실**: PDF = 포맷 안 깨짐
- **올바른 안내**: "PDF로 변환 후 제출"

### 함정 7: "한국 이력서 번역"
- **사실**: 구조 자체가 다름
- **올바른 안내**: "처음부터 호주 표준으로"

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 직무 / 산업
- Hospitality / IT / Marketing?
- 직무별 = 강점 다름
- → 학과 매칭

### 2. 경력
- 졸업 직후 (인턴십만)?
- 한국 경력 있음?
- → 페이지 수 / 강조 다름

### 3. 영문 작성 가능
- 본인 영어 작성 가능?
- 윌슨 첨삭 필요?
- → 윌슨 첨삭 영역

### 4. 시점
- 즉시 지원?
- 시간 여유?
- → 1주일 / 2주일 작성 시간

**4가지 확인 후 → 본인의 영역(가이드 + 양식) → 윌슨 영역(첨삭)**

---

## 🔍 직원이 직접 확인 가능한 사이트

### 이력서 양식
- canva.com (무료 양식)
- docs.google.com (templates)
- seek.com.au/career-advice/resume

### 채용 사이트
- seek.com.au
- linkedin.com
- au.indeed.com
- jora.com
- adzuna.com.au
- barcats.com.au (hospitality)

### Cover Letter 가이드
- seek.com.au/career-advice/cover-letter
- au.indeed.com/career-advice

### Action Verbs
- linkedin.com/learning (검색: "resume action verbs")
- harvardbusiness.org

**확인 사항**: 위 사이트 = 호주 채용 시장 표준.

---

## 🚨 직원 영역 vs 변호사/MARA 영역

### 직원 영역 (이 매뉴얼 활용)
- ✅ 호주 이력서 7섹션 안내
- ✅ Cover Letter 4문단 구조
- ✅ Achievement vs 역할 차이
- ✅ Referees 2명 안내
- ✅ 채용 사이트 안내
- ✅ Canva 양식 안내

### 윌슨 직접 처리 영역
- ⚠️ 이력서 + Cover Letter 1:1 첨삭
- ⚠️ 회사별 맞춤 조언
- ⚠️ 본인 Achievement 발굴
- ⚠️ 인터뷰 연계 준비

### 영어 학원 영역 (직원 X)
- ❌ Business English 문법
- ❌ Cover Letter 글쓰기 강의

### 채용 회사 영역 (직원 X)
- ❌ Hays / Robert Half 등 = 본인 컨택
- ❌ 채용 추천 (윌슨도 X)

**원칙**: 직원 = **표준 가이드**. 첨삭 = **윌슨**.

---

## ✅ 완벽 응대 체크리스트

응대 끝나기 전 이 체크리스트 확인:

- [ ] **사진/생년월일 X** 명시했나?
- [ ] **호주 이력서 7섹션** 안내했나?
- [ ] Career Objective 4~5줄 강조했나?
- [ ] **Achievement vs 역할** 차이 명시했나?
- [ ] Action Verbs (Achieved, Improved, Trained) 안내했나?
- [ ] 숫자 (200+, 25%, $3,000) 강조했나?
- [ ] 1~2페이지 (Junior) 안내했나?
- [ ] **Cover Letter 4문단** 구조 안내했나?
- [ ] 회사별 맞춤 강조했나?
- [ ] **Referees 2명** (직장 매니저 + 교수) 안내했나?
- [ ] **PDF 변환** 강조했나?
- [ ] 파일명 표준 (Firstname_Lastname_Resume.pdf) 안내했나?
- [ ] **SEEK + LinkedIn** 채용 사이트 안내했나?
- [ ] Canva 무료 양식 안내했나?
- [ ] **윌슨 첨삭** 가능 안내했나?
- [ ] "한국 이력서 번역" 같은 잘못된 답변 안 했나?

**핵심**: 호주 이력서 = **사진 X + Achievement + 1~2페이지**. Cover Letter = **회사별 4문단**. Referees = 직장 매니저 + 교수. 윌슨 = 첨삭.

---

**작성**: ausuhak.com 직원 교육 시스템 v1.0
**기준일**: 2026-05-04
**참고**: seek.com.au, au.indeed.com, linkedin.com, canva.com
**다음 매뉴얼**: #104 호주 자녀 학교 (보호자 비자 자녀)
