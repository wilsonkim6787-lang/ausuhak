# #454 호주_학생_가족_사고_자녀_배우자_부상_OSHC_Dependent

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "학생비자로 호주 와서 같이 사는 5세 아들이 놀이터에서 떨어져서 팔 부러졌어요. 응급실 갔는데 어떻게 OSHC 청구하나요? 자녀도 OSHC 가입했는데 따로 처리하나요? 학교 가야 하는데 출석 어떻게 되나요?"

**직원 멘붕 포인트:**
- OSHC = 본인 + 가족 동반 별도 가입 (Family Cover)
- 자녀 OSHC 별도 카드 + 청구 절차
- 응급실(ER) Public Hospital = 100% 커버 가능
- Specialist (Orthopaedic) Referral 필요
- 학교 결석은 Compassionate 인정
- 자녀 학교 통보 (해당 학년)

---

## ❌ 절대 하지 말아야 할 답

> "응급실 무료니까 청구 안 해도 돼요"

→ ❌ 공공병원 응급실은 OSHC 처리 별도 / 청구해야 환급 / Specialist 비용 별도 / 잘못된 정보 = 큰 자기부담

---

## ✅ 정답

(1) 응급실 = OSHC 카드 제시 → Direct Billing 가능 (2) Specialist Referral 받아서 진료 (3) 영수증 보존 → OSHC 청구 (4) 본인 학교 결석은 Compassionate 인정 (5) 자녀 학교 통보

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. OSHC Family Cover**
Single $580/년 / Couple $2,800/년 / Family $4,200~$5,500/년 (Bupa/Medibank/Allianz/NIB/AHM) / 자녀 포함 시 Family Cover 필수.

**2. Public Hospital ER (응급실)**
Triage Category 1~5 / Cat 1(즉시) ~ Cat 5(2시간 대기) / OSHC Direct Billing 일부 병원 / 청구 시 95~100% 환급.

**3. Specialist (전문의)**
GP Referral 필수 / Orthopaedic(정형외과) 등 / Public 병원 무료 (Medicare 학생 X but OSHC 일부) / Private $300~$800/방문 → OSHC 환급.

**4. MBS Schedule Fee**
Medicare Benefits Schedule = 정부 기준 진료비 / OSHC 환급 = MBS 100% 또는 그 이상 (정책별) / Gap 발생 가능.

**5. Compassionate 사유 결석**
ESOS National Code Standard 9 / 자녀 부상 = Compassionate 인정 / Medical Certificate (자녀 진단서) + 본인 보호자 증명.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: Public Hospital ER (000 또는 직접) - OSHC 카드 제시
**2단계**: 2차: GP Referral 받아 Specialist 진료 (Orthopaedic)
**3단계**: 3차: 본인 학교 International Student Office에 Compassionate 결석 사전 통보
**4단계**: 4차: 자녀 학교에 진단서 제출 + 회복 기간 통보
**5단계**: 5차: 영수증 보존 → OSHC 보험사 청구 (4주 내 환급)

---

## 💡 직원이 학생한테 말할 멘트

> "놀라셨죠. 자녀 응급 처리 절차 안내드릴게요.

**즉시 (지금):**
1. **Public Hospital ER**: OSHC 카드 제시 → Direct Billing 가능 (Bupa/Medibank/Allianz/NIB/AHM)
2. 큰 부상 = 000 (Ambulance 호출)

**이번 주:**
3. **GP Referral** 받아서 **Orthopaedic Specialist** 진료
4. **영수증 모두 보존** - OSHC 보험사 청구용

**OSHC 청구:**
- Public Hospital ER = 95~100% 환급 일반
- Specialist Private = MBS 100% + α (정책별)
- Gap 발생 가능 - 본인 부담 일부

**본인 학교:**
**Compassionate Reason** (자녀 부상)으로 결석 사전 통보. ESOS National Code 인정 사유. Medical Certificate(자녀 진단서) + 본인 보호자 관계 증명 제출.

**자녀 학교:**
자녀 학교 (해당 학년)에 진단서 제출 + 회복 기간 통보.

**확인:**
자녀 OSHC Family Cover 가입되어 있죠? 자녀 별도 OSHC ID 있을 거예요. 청구 시 자녀 ID 사용하세요.

학교/OSHC 보험사 알려주시면 청구 절차 자세히 안내드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **응급실 무료 = 청구 X**
   → OSHC 청구 별도 / 일부 비용 환급 / 영수증 보존 필수

2. **OSHC 본인 카드로 자녀 청구**
   → 자녀 별도 OSHC ID / Family Cover 가입자만 자녀 포함

3. **Specialist 본인이 직접 예약**
   → GP Referral 필수 / Referral 없으면 OSHC 환급 X

4. **자녀 부상 = 본인 결석 인정 X**
   → Compassionate Reason 인정 / Medical Certificate + 보호자 증명

5. **Private Hospital 더 빠르다**
   → Private = 비용 큼 / Public ER이 응급은 동일 처리 / 비응급은 Private 대기 짧음

6. **학교 안 알리면 결석 처리**
   → 사전 통보 필수 / 사후 통보 = 결석 처리 위험 / 출석률 영향

7. **OSHC 청구 1년 후 가능**
   → 보통 30~60일 내 청구 권장 / 1년 경과 시 거부 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. OSHC Family Cover 가입 여부 (자녀 포함)
2. 자녀 OSHC ID 별도 카드
3. 본인 학교 + 자녀 학교 (둘 다 통보용)
4. 부상 정도 (응급 vs 회복 기간 평가)

---

## 🔍 직원이 직접 확인 가능한 사이트

- bupa.com.au (Bupa OSHC)
- medibank.com.au (Medibank OSHC)
- allianzcare.com.au (Allianz)
- healthdirect.gov.au / 1800 022 222 (24시간 의료)
- TIS National 131 450 (한국어 통역 무료)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- OSHC Family Cover 일반 안내
- Public Hospital ER 절차
- Specialist Referral 일반 정보
- Compassionate Reason 학교 결석 안내

**MARA / 변호사 영역**
- 자녀 비자 영향 (장기 회복 시)
- Compassionate Circumstances 비자 신청
- 자녀 학년 변경 후 비자 영향

---

## ✅ 완벽 응대 체크리스트

- [ ] OSHC Family Cover 자녀 포함 확인
- [ ] 자녀 별도 OSHC ID 안내
- [ ] Public Hospital ER OSHC 처리 강조
- [ ] GP Referral 필수 안내 (Specialist)
- [ ] 본인 학교 Compassionate 사전 통보
- [ ] 자녀 학교 진단서 제출
- [ ] 영수증 보존 + 60일 내 청구
- [ ] 한국어 통역 131 450 안내
