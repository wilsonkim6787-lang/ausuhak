# #342 호주_IELTS_점수_부족_PTE_TOEFL_Cambridge_대안

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 IELTS 6.0 받으려고 4번 시험 봤는데 5.5에서 안 올라요. PTE나 TOEFL이 더 쉽나요? 다른 길 없나요?"

**직원 멘붕 포인트:**
- IELTS 점수 정체
- PTE/TOEFL 비교?
- 학교/비자별 인정?
- ELICOS Direct Entry?

---

## ❌ 절대 하지 말아야 할 답

> "PTE가 IELTS보다 쉬워요. 바꾸세요."

→ ❌ 시험별 난이도 + 학교/비자 인정 여부 + 점수 환산 정확히 모름. 학생이 시간/돈 낭비.

---

## ✅ 정답

**IELTS 대안 = ① PTE Academic ② TOEFL iBT ③ Cambridge C1 Advanced ④ ELICOS Direct Entry. 시험별 학교/비자 인정 다름.**

**핵심 사실:**
- **PTE Academic**: 컴퓨터 시험 + 결과 24시간 내. 호주 대부분 학교/비자 인정. IELTS 6.0 = PTE 50, IELTS 6.5 = PTE 58, IELTS 7.0 = PTE 65.
- **TOEFL iBT**: 인터넷 시험. IELTS 6.0 = TOEFL 60, IELTS 6.5 = TOEFL 79, IELTS 7.0 = TOEFL 94.
- **Cambridge C1 Advanced(CAE)**: 영국 영어 + 호주 일부 학교 인정. IELTS 6.5 = CAE 176, IELTS 7.0 = CAE 185.
- **ELICOS Direct Entry**: 학교 부설 어학원 졸업 = IELTS 면제(간호 제외). UNSW Insearch, Sydney CET, USyd Centre for English Teaching 등.
- **학교별 인정**: Go8 대학 = IELTS/PTE/TOEFL/CAE 모두 OK. 일부 TAFE = IELTS만 인정.
- **비자별 인정**: 학생비자 500 = IELTS/PTE/TOEFL/CAE/OET 모두 OK. 485 = IELTS 6.5 (각 5.5) 또는 PTE 58 (Academic) (2024.03.23부터 인상, 이전 6.0/5.0). PSW는 구 명칭. 2024.07부터 Post-Higher Education / Post-Vocational 분리.
- **간호는 ELICOS Direct Entry 면제 불가**. IELTS 7.0(각 영역) 또는 OET B(각 영역) 필수.

**경로:**
현재 IELTS 점수 + 약점 분석 → PTE/TOEFL/CAE 비교 → 학교/비자 인정 확인 → 시험 변경 또는 ELICOS 추가

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. PTE 특징**
컴퓨터 + AI 채점 = 객관적. Speaking 부담 적음(컴퓨터 대화). 24시간 결과. 비용 $400. IELTS Speaking 약한 학생 유리.

**2. TOEFL 특징**
미국 영어 + 학술적. Reading/Listening 강한 학생 유리. 비용 $400. 호주 대학 인정하지만 영국식 IELTS 보다 적음.

**3. Cambridge CAE**
영국식 영어 + 평생 유효(IELTS는 2년). 호주 일부 학교(USyd, UNSW, Monash) 인정. 비용 $475.

**4. ELICOS Direct Entry**
학교 부설 어학원 10~30주 + 졸업 = IELTS 면제. UNSW Insearch, Sydney CET, Monash English Connect, RMIT English Worldwide 등. 학비 $500~$700/주.

**5. 간호 영어 = 면제 불가**
AHPRA 면허 = IELTS 7.0(각 영역) 또는 OET B(각 영역). ELICOS Direct Entry로 면제 안 됨. 5년 영어권 학력 면제 가능 (호주/영국/미국/캐나다/뉴질랜드/아일랜드).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 현재 IELTS 점수 + 약점 영역(Speaking/Writing/Listening/Reading) 분석
**2단계**: 약점에 따라 PTE/TOEFL/CAE 적합 시험 선택
**3단계**: 학교/비자 인정 시험 확인 (Go8 = 모두, 일부 학교 = IELTS만)
**4단계**: ELICOS Direct Entry 옵션 (IELTS 0.5점 부족 시) 평가
**5단계**: 시험 응시 또는 ELICOS 등록 → 점수 충족 → 입학

---

## 💡 직원이 학생한테 말할 멘트

> "IELTS 점수 안 나올 때 PTE/TOEFL/Cambridge CAE/ELICOS 대안 있어요. 시험별 본인 약점 + 학교/비자 인정 다릅니다.

현재 IELTS 점수 + 약점 영역 + 목표 학교/비자 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **PTE = 무조건 쉬움**
   → ❌ PTE Speaking 부담 적지만 Listening + Writing 어려움. 본인 약점에 따라 다름.

2. **TOEFL = 호주 인정 X**
   → ❌ 호주 Go8 대학 모두 TOEFL 인정. 일부 TAFE만 IELTS 강요.

3. **ELICOS = 모든 학과 면제**
   → ❌ 간호/의대/약대/PT/OT 등 보건 직군은 ELICOS 면제 X. AHPRA 별도 IELTS 7.0 필수.

4. **CAE = 한국에서 흔함**
   → ❌ CAE는 한국에서 응시 가능하지만 호주에서 한국식 학원 부재. 독학 + 영국 시험 센터 응시 일반.

5. **485 비자 = IELTS 7.0**
   → ❌ 485는 IELTS 6.5(각 5.5) 또는 PTE 58 (2024.03.23부터 인상). 7.0 아님. PR(189) 영어가 7.0~8.0.

6. **ELICOS = 한국에서 신청**
   → ❌ ELICOS는 호주 학교 부설 어학원. 한국 영어학원과 다름. 호주 입국 후 다님.

7. **점수 환산표 = 절대 기준**
   → ❌ IELTS 6.0 = PTE 50은 평균. 학교/비자별 미세 차이 있음. 학교 사이트 확인 필수.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 IELTS 점수 + 약점 영역 (Speaking/Writing 등)
2. 목표 학교 + 비자 종류 (500/485/PR)
3. 시험 비용 + 응시 가능 시점
4. ELICOS 옵션 (학교 부설 어학원) 가능 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- PTE Academic (pearsonpte.com) - 응시 + 점수
- TOEFL iBT (ets.org/toefl) - 응시 + 점수
- Cambridge CAE (cambridgeenglish.org/exams-and-tests/advanced) - 응시 + 점수
- 각 학교 ELICOS Direct Entry 페이지

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 본인 약점 분석 + 적합 시험 가이드
- ELICOS Direct Entry 옵션 + 학교 매칭
- 학교/비자별 시험 인정 가이드

**MARA / 변호사 영역**
- 비자 영어 면제 사유 (5년 영어권 학력 등) = MARA
- 학교 영어 요구 면제 신청 = 학교 직접
- AHPRA 영어 면제 (간호/의대) = AHPRA + 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 현재 IELTS 점수 + 약점 영역 분석
- [ ] PTE/TOEFL/CAE 본인 적합 시험 선택
- [ ] 학교 + 비자 인정 시험 확인
- [ ] ELICOS Direct Entry 옵션 평가 (간호 제외)
- [ ] 시험 응시 또는 ELICOS 등록 결정
- [ ] 점수 환산표 + 학교 사이트 직접 확인
- [ ] 간호/의대 = IELTS 7.0 또는 OET B 필수 인지
