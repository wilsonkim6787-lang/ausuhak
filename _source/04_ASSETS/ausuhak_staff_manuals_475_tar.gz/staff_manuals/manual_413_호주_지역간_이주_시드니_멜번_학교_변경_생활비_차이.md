# #413 호주_지역간_이주_시드니_멜번_학교_변경_생활비_차이

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니에서 회계 전공하고 있는데 너무 비싸서 멜번이나 애들레이드로 옮길까 고민이에요. 학교 변경하면 비자 다시 받아야 하나요? 생활비 얼마나 차이나요? 학교는 어떻게 바꾸나요?"

**직원 멘붕 포인트:**
- 주간 이주 비자 영향 모름
- Course Transfer Release Letter 절차
- 주별 생활비 차이 정확히 모름
- PR 점수 (Regional 가산점) 모름
- 주별 직업 시장 차이

---

## ❌ 절대 하지 말아야 할 답

> "그냥 옮기시면 돼요"

→ ❌ ❌ 부정확. 6개월 미만 Release Letter 필요. 비자 통보 28일 의무. 주별 PR 가산점 다름. 주거비 차이 30~40%.

---

## ✅ 정답

비자 자체는 호주 전역 유효(주간 이주 자유). 학교 변경 = Course Transfer Standard 7 ESOS - 6개월 미만 Release Letter 필요. 시드니 vs 멜번 생활비 25~35% 저렴, 시드니 vs 애들레이드 35~45% 저렴. PR 점수: Sydney/Melbourne = Major City (가산점 X). Adelaide/Perth/Brisbane/Gold Coast = Regional Centre (5점). Hobart/Darwin/기타 = Regional (5점). 주소 변경 ImmiAccount 28일 의무.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 주간 이주 = 비자 자체 영향 X**
학생비자(Subclass 500)는 호주 전역 유효. 시드니→멜번 이주 자유. 단, 1) 학교 변경 시 Course Transfer 절차 필요 2) 주소 변경 ImmiAccount 28일 내 통보 의무 (Migration Regulations 2.43A) 3) 비자 조건 8533 위반 시 비자 취소. Course Transfer 별도 (#383 매뉴얼).

**2. 주별 생활비 정확한 차이 (2026)**
시드니 1Bed 렌트: $650~$900/주 (CBD), $400~$600 (외곽). 멜번: $500~$700 (CBD), $350~$500. 브리즈번: $450~$650, $300~$450. 애들레이드: $350~$500, $250~$400. 퍼스: $450~$650, $300~$500. 호바트: $400~$550, $280~$400. 식료품 시드니 100 기준 멜번 95 / 애들레이드 85 / 호바트 90. 교통: 시드니 Opal $50/주, 멜번 Myki $52/주.

**3. PR Regional 5점 가산점 (2026)**
Major City (가산점 X): Sydney, Melbourne, Brisbane(2022 수정), Perth(2022 추가). 단, Brisbane/Perth는 'Designated Regional Area'로 재분류되어 5점 가산점 부활. Regional Centre 5점: Adelaide, Hobart, Darwin, Canberra, Newcastle, Wollongong, Geelong, Gold Coast(2022~), Sunshine Coast. Other Regional 5점: 그 외 모든 지역. 학생비자는 직접 가산점 없으나 졸업 후 491(Skilled Regional) 신청 시 5점.

**4. Course Transfer Release Letter**
Standard 7 ESOS Code: 학생이 6개월 미만 재학 시 원학교 Release Letter 필수. 6개월 이상 재학 + 새 학교 CoE = 자동 가능. AQF 동급/상위만 (Bachelor → Diploma 불가). 단, Bachelor → 다른 Bachelor OK. 비자 재신청 X (학교만 통보). PRISMS 시스템에서 변경 자동 반영.

**5. 주별 직업 시장 차이 (회계 기준)**
회계(ACS) NSW: 가장 큰 시장, 경쟁 치열, 평균 연봉 $70K~$95K(2년차). VIC: 두 번째 큰 시장, $65K~$85K. SA(애들레이드): 작은 시장, $55K~$75K, but 489/491 Regional 가산점. WA(퍼스): $65K~$90K, 광산업 회계 강세. ACT(캔버라): 정부 회계 강세, $65K~$85K. 졸업 직장 → 491 신청 → 4년 → 191 PR 경로 가능.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 학교 정보 확인: 현재 재학 6개월 이상 여부 (Release Letter 필요 여부)
**2단계**: 새 주의 학교 알아보기 (회계 = 멜번 RMIT/Deakin, 애들레이드 UniSA-합병 후 Adelaide Uni)
**3단계**: 새 학교 CoE 받기 → 6개월 미만이면 원학교 Release Letter 신청
**4단계**: 새 주에서 거주지 마련 + 짐 이사 (#412 매뉴얼)
**5단계**: ImmiAccount 주소 변경 28일 내 통보 + 학교 변경 자동 반영 (PRISMS)

---

## 💡 직원이 학생한테 말할 멘트

> "시드니가 비싸서 다른 주로 이주 고민이시군요. 좋은 방향입니다. 정리해드릴게요.

생활비 차이 (2026 기준):
- 시드니 1Bed CBD $650~$900/주
- 멜번 $500~$700 (-25%)
- 브리즈번 $450~$650 (-30%)
- 애들레이드 $350~$500 (-45%)
- 호바트 $400~$550 (-40%)

비자 자체는 호주 전역 유효해서 이주는 자유롭게 가능해요.

학교 변경은 Course Transfer 절차예요. 현재 학교에 6개월 이상 재학 중이시면 자유롭게 가능, 6개월 미만이면 원학교 Release Letter 필요해요.

PR 점수 측면에서 큰 차이가 있어요:
- 시드니/멜번: Major City (가산점 없음)
- 브리즈번/퍼스: Regional 재분류 5점
- 애들레이드/호바트/캔버라: Regional Centre 5점

회계 전공이면 졸업 후 491(Skilled Regional) 신청 시 Regional 거주가 절대 유리해요. 애들레이드 강력 추천드립니다.

Adelaide University가 2026.01부터 University of Adelaide + UniSA 합병해서 회계 강세고, 학비도 시드니 대비 30% 저렴해요.

학교 + 비자 + PR 점수 + 직업 시장까지 종합 평가가 필요한 의사결정이라 윌슨 카톡(studywilson)으로 현재 상황 보내주시면 시뮬레이션해드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **주간 이주가 비자에 영향 있다고 안내**
   → ❌ 거짓. 학생비자 호주 전역 유효. 주소만 통보.

2. **Adelaide가 Regional 5점이라고 단순 안내 X**
   → ❌ 부정확. Regional Centre 5점. 정확한 분류 필요.

3. **Brisbane/Perth는 Major City라 가산점 없다고 안내**
   → ❌ 거짓. 2022년 재분류 - 둘 다 Designated Regional Area 5점.

4. **Course Transfer 6개월 자동 가능하다고 안내**
   → ❌ 부분 거짓. 6개월 이상 = 자유, 6개월 미만 = Release Letter 필요.

5. **AQF 등급 무관하게 변경 가능하다고 안내**
   → ❌ 거짓. 동급/상위만. Bachelor→Diploma 불가.

6. **생활비만 보면 Adelaide가 무조건 좋다고 안내**
   → ❌ 단순. 직업 시장도 봐야 함. 회계 큰 시장은 SYD/MEL.

7. **UniSA가 아직 별도 학교라고 안내**
   → ❌ 거짓. 2026.01부터 Adelaide University로 합병.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 학교 재학 기간 (6개월 미만/이상)
2. 이주 우선순위 (생활비 / PR 점수 / 직업 / 가족)
3. 전공 분야 (회계는 모든 주, 광산업은 WA, 정부직 ACT 등)
4. 졸업 후 PR 계획 (491 Regional 5점 활용 여부)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ImmiAccount 주소변경: immi.homeaffairs.gov.au
- Regional Postcodes 확인: immi.homeaffairs.gov.au (검색: regional postcode)
- Numbeo 도시별 생활비: numbeo.com
- 각 학교 입학 (RMIT/Deakin/Monash 멜번, Adelaide/Flinders 애들레이드)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 주별 비교 시뮬레이션 (시드니/멜번/브리즈번/애들레이드/퍼스/호바트)
- PR 경로 + Regional 가산점 통합 컨설팅
- 졸업 후 직업 시장 + 491 vs 189 vs 190 비교
- Adelaide University 합병 후 회계 학과 정보

**MARA / 변호사 영역**
- Course Transfer 분쟁 (Release Letter 거부) - MARA 변호사
- 491 Skilled Regional 비자 신청 - MARA 변호사
- 주별 직업 시장 분석 - 자체 조사 + Wilson 컨설팅

---

## ✅ 완벽 응대 체크리스트

- [ ] 주간 이주 비자 영향 없음 명확히
- [ ] Course Transfer 6개월 룰 안내
- [ ] 주별 생활비 정확한 수치 제공
- [ ] Regional 가산점 5점 + 도시 분류 정확히
- [ ] Brisbane/Perth Regional 재분류 안내
- [ ] Adelaide University 합병 사실 안내
- [ ] 졸업 후 491 경로 시뮬레이션 제안
- [ ] 윌슨 카톡 종합 비교 시뮬레이션 유도
