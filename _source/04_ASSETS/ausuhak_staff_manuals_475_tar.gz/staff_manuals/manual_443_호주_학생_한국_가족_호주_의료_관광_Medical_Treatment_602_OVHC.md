# #443 호주_학생_한국_가족_호주_의료_관광_Medical_Treatment_602_OVHC

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국 어머니가 한국 의사 치료 안 듣는다고 호주 와서 진료받고 싶다고 하세요. 비자는 어떻게 받나요? 호주 의료비 많이 나오나요? 메디케어 안 되는데 어떻게 하죠?"

**직원 멘붕 포인트:**
- Medical Treatment Visa 602
- Visitor 600 (Medical Treatment)
- OVHC 의료보험
- 호주 의료비 (메디케어 X)
- Specialist Referral 한국 의사

---

## ❌ 절대 하지 말아야 할 답

> "호주가 의료 무료라 좋아요"

→ ❌ ❌ 호주 의료 = 메디케어 거주자만 / 외국인 = 100% 자비. 응급실 1만 달러+.

---

## ✅ 정답

한국 가족 호주 의료: ① Medical Treatment Visa 602 - 의료 목적 전용 / 거주 1년+ 가능 / $355, ② Visitor 600 (Medical Stream) - 의료 사유 / 3-12개월 / $200 (Off) / $500 (On), ③ Visitor 600 (Tourist) - ETA로 입국 후 의료 받기 = 가능 (단순 외래만), ④ OVHC 의료보험 - 입국 전 가입 필수 (Bupa Visitor/Allianz Visitor 등) - 외래 80% / 입원 100% 일부, ⑤ 호주 의료비 (자비) - GP 진료 $80~$120 / Specialist $200~$400 / 입원 $5,000+/일 / 수술 $10,000~$100,000+, ⑥ 영문 진료기록 한국 병원 발급 (영사관 무관 / 병원 직접), ⑦ Specialist Referral - 호주 GP 통해서만 (직접 X) → 5만~$10만 추가, ⑧ 한국 의료가 호주보다 우수 분야 多 (성형/치과 등) - 안내 권장.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Medical Treatment 602**
$355 / 1년+ / 의료 전용

**2. Visitor 600 Medical**
$190 / 의료 사유

**3. OVHC 호주 의료보험**
Bupa/Allianz Visitor

**4. 호주 의료비 자비**
GP $80+ / 입원 $5K+/일

**5. Specialist Referral**
GP 통해서만

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 의료 진단명 확인 (호주 우수 분야인지)
**2단계**: 2단계: 한국 영문 진료기록 발급
**3단계**: 3단계: Visitor 600 (Medical) 또는 602
**4단계**: 4단계: OVHC 의료보험 가입
**5단계**: 5단계: 호주 도착 후 GP → Specialist Referral

---

## 💡 직원이 학생한테 말할 멘트

> "Medical Treatment Visa 602 또는 Visitor 600 (Medical Stream) 신청 가능합니다. OVHC 의료보험 입국 전 가입 필수입니다. 호주 의료비는 자비 부담이 큽니다 (입원 $5K+/일). 한국 영문 진료기록 + Specialist Referral 준비하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **호주 의료 무료**
   → 메디케어 거주자만

2. **OSHC = 가족 커버**
   → OSHC X / OVHC

3. **Specialist 직접 진료**
   → GP Referral 필수

4. **Visitor 600 자동 의료**
   → Medical Stream 별도

5. **한국 의사 호주 자동 인정**
   → AHPRA 등록 X

6. **호주 의료가 한국보다 우수**
   → 분야별 다름

7. **Medical Treatment 602 단기**
   → 1년+ 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 진단명 / 치료 목적
2. 체류 기간
3. OVHC 가입 의향
4. 한국 의료 가능성 비교

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Medical Treatment 602', 'immi.homeaffairs.gov.au')
- ('Bupa Visitor', 'bupa.com.au/visitor')
- ('Allianz OVHC', 'allianzcare.com.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 일반 안내, 의료비 정보

**MARA / 변호사 영역**
- 복잡한 의료 케이스 / 장기 체류 비자

---

## ✅ 완벽 응대 체크리스트

- [ ] Medical Treatment 602 안내함
- [ ] Visitor 600 Medical Stream 안내함
- [ ] OVHC 강조함
- [ ] 호주 의료비 자비 안내함
- [ ] 한국 영문 진료기록 안내함
- [ ] GP Referral 시스템 안내함
