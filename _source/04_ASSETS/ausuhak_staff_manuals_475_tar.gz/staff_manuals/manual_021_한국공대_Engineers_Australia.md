# 📚 직원 응대 매뉴얼 #021

**케이스: 29세 / 한국 공대 학사 + 경력 / 호주 엔지니어 / 영주권 / 1억 예산**

---

## 🎬 상황 시뮬레이션

> 한국에서 기계공학 졸업하고 회사 4년 다녔어요. 호주 엔지니어로 영주권 받고 싶습니다. 29세고 IELTS 6.5 있어요. 1년 1억 예산이에요.

**👉 정답**: **Engineers Australia 직업 평가 → Master 또는 직접 PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 엔지니어 = MLTSSL 직업군 직업

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Mechanical Engineer | 233512 | MLTSSL |
| Civil Engineer | 233211 | MLTSSL |
| Electrical Engineer | 233311 | MLTSSL |
| Chemical Engineer | 233111 | MLTSSL |
| Software Engineer | 261313 | MLTSSL |
| Mining Engineer | 233611 | MLTSSL |
| Petroleum Engineer | 233612 | MLTSSL |

### 2️⃣ Engineers Australia = 엔지니어 직업 평가 기관

- 한국 공대 학사 + 경력 평가
- Washington Accord 가입국 학위 = 자동 인정 (한국 ABEEK 인증 학위)
- 한국 ABEEK 인증 안 받은 학위 = CDR (Competency Demonstration Report) 必須

### 3️⃣ Washington Accord = 엔지니어 학위 상호 인정

- 한국 ABEEK (한국공학교육인증원) 인증 학위 = 호주 자동 인정
- 한국 SKY/포스텍/카이스트 등 ABEEK 인증 多
- ABEEK 인증 X = CDR 보고서 必 (엔지니어 사례 3개 작성)

### 4️⃣ 한국 공대 + 4년 경력 = Master 없이 PR 가능

```
한국 ABEEK 학위 + IELTS 6.5+
        ↓
Engineers Australia 평가 (학위 자동 인정 시)
        ↓
호주 엔지니어 회사 취업 (Direct)
        ↓
PR 신청 (189/190/491)
```

**Master 안 해도 됨! 학위 + 경력으로 직접 PR 가능**

### 5️⃣ Master 추가 시 = 더 강한 PR + 호주 적응

```
한국 학사 + 경력 + Master Engineering (1.5~2년)
        ↓
호주 학위 추가 + 호주 적응 + 호주 인맥
        ↓
PR 더 강력 + 호주 회사 취업 쉬움
```

---

## 🎯 정답 경로 (2가지 비교)

### 옵션 A. Direct PR (Master 없이)

```
한국 ABEEK 학위 + 4년 경력
        ↓
Engineers Australia 평가 (Skills Assessment)
        ↓
호주 엔지니어 회사 (스폰서 482) 또는 직접 EOI
        ↓
189/190/491 PR
```

**총 1-2년 / 학비 0 (영어만 보강) / 가장 빠름**

### 옵션 B. Master + Direct PR (안전)

```
한국 학사 + IELTS 6.5
        ↓
Master of Engineering 1.5~2년 ($70K~$100K)
        ↓
졸업 + 485 + 호주 회사 취업
        ↓
PR (호주 학위 가산점 +5)
```

**총 3-4년 / 학비 약 $80K~$100K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 공대 학사 + 4년 경력 + ABEEK 인증이면, **Master 없이 바로 PR 가능**한 빠른 경로가 있습니다.
> 
> **옵션 A. Direct PR**
> - Engineers Australia에 한국 학위 평가 신청 (Washington Accord = 자동 인정)
> - 호주 엔지니어 회사 직접 취업 또는 EOI 신청
> - **Master 없이 1-2년 안에 PR 가능**
> 
> **옵션 B. Master + PR**
> - Master 1.5~2년 추가 (호주 학위 + 적응)
> - 호주 회사 취업 강해짐 + PR 가산점 +5
> - 학비 $80K~$100K
> 
> 1억 예산이면 두 옵션 다 가능합니다. 한국 학교가 ABEEK 인증인지부터 확인 필요해요.
> 
> 카톡으로 알려주세요:
> ① 한국 학교 ABEEK 인증 여부  
> ② 분야 (기계/전기/토목/화공 등)  
> ③ 호주 회사 취업 시도 vs Master 추가 안전"

---

## ⚠️ 함정

1. **"한국 공대 = 자동 인정"** → ABEEK 인증 학위만 자동 / 그 외 CDR 必
2. **"4년 경력 다 인정"** → 일부만 인정 (직무 매칭 따라)
3. **"Master 필수"** → ABEEK + 경력이면 불필요
4. **"한국 SKY = 자동 PR"** → SKY도 Engineers Australia 평가 必

---

## 📞 카카오 응대 시 필수

1. 한국 학교 ABEEK 인증?
2. 분야 + 경력 연수
3. Master 추가 의향
4. 도시 선호

---

## 🔍 직원 확인 사이트

- Engineers Australia: engineersaustralia.org.au
- Washington Accord: washingtonaccord.org
- 한국 ABEEK 인증 학교 리스트: abeek.or.kr
- Skilled Occupation List
