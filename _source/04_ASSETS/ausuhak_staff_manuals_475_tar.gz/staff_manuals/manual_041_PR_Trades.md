# 📚 직원 응대 매뉴얼 #041

**케이스: Trade (전기/배관/목공/용접/정비) PR 종합**

---

## 🎬 상황 시뮬레이션

> 호주 기술직 영주권 가능한 직업 다 알려주세요. 전기, 배관, 목공, 용접 같은 거요.

**👉 정답**: **모두 MLTSSL 직업군 = Trade Cert III + IV + Apprenticeship + TRA + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Trade 직업군 PR 매트릭스

| 직업 | ANZSCO | 평균 연봉 | PR 리스트 |
|---|---|---|---|
| Electrician | 341111 | $80K~$120K | MLTSSL |
| Electrician (Special Class) | 341112 | $90K~$140K | MLTSSL |
| Plumber | 334111 | $75K~$110K | MLTSSL |
| Carpenter | 331212 | $70K~$100K | MLTSSL |
| Bricklayer | 331111 | $65K~$85K | STSOL |
| Welder (Metal Fabricator) | 322311 | $70K~$95K | MLTSSL |
| Diesel Mechanic | 321212 | $75K~$100K | MLTSSL |
| Automotive Mechanic | 321211 | $65K~$90K | MLTSSL |
| Painter (Painting Trades) | 332211 | $55K~$80K | STSOL |
| Cabinetmaker | 394111 | $65K~$85K | MLTSSL |
| Air-conditioning Mechanic | 342111 | $75K~$100K | MLTSSL |
| Refrigeration Mechanic | 342112 | $75K~$100K | MLTSSL |
| Joiner | 331213 | $65K~$90K | STSOL |
| Roof Tiler | 333311 | $60K~$80K | STSOL |
| Stonemason | 331112 | $65K~$85K | STSOL |

### 2️⃣ Trade 표준 경로 (모든 직업 공통)

```
ELICOS (필요시 6~12개월)
        ↓
TAFE Cert III in [직업] (2-3년) - $30K~$45K
        ↓ Apprenticeship (호주 회사 견습 4년)
Cert IV (6개월~1년) - $7K~$10K
        ↓
TRA Skills Assessment (Job Ready Program 또는 Direct)
        ↓
485 또는 491 → PR
```

### 3️⃣ Apprenticeship 시스템

- **TAFE 학교 + 호주 회사 견습** 결합
- 견습 4년 = 정식 자격 + 시급 받음
- 견습 시급 ($15-$25/시간) → 자격 획득 후 ($35-$45/시간)
- Apprenticeship Network Provider가 매칭 (Australian Apprenticeships Centre)

### 4️⃣ Trade 영어 조건

- Cert III: IELTS 5.5 (각 영역 5.0)
- Cert IV: IELTS 5.5
- Trade는 영어 조건 가장 낮음

### 5️⃣ Trade 학교

| 학교 | 위치 | Trade 학비 (Cert III) |
|---|---|---|
| TAFE NSW | Sydney | $24K~$30K/년 |
| TAFE QLD | Brisbane | $20K~$26K/년 |
| TAFE SA | Adelaide | $18K~$24K/년 |
| TIWA | Perth | $18K~$24K/년 |
| TAFE NT | Darwin | $14K~$20K/년 |
| TasTAFE | Hobart | $16K~$22K/년 |

---

## 🎯 정답 경로 (Trade 공통)

### Trade Cert III + IV + Apprenticeship + PR

```
한국에서 IELTS 5.5+ 도달
        ↓
ELICOS (필요시) + TAFE Cert III (2-3년) + Apprenticeship
        ↓ 견습 시급 수입
Cert IV (6개월) + TRA Assessment
        ↓
485 (Post-Vocational, 18개월) + 491 비자 +15점 (Regional 지역)
        ↓
PR 신청 (189/190/491)
```

**총 5-6년 / 학비 $40K~$60K + 견습 시급 수입**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 Trade는 가장 강력한 PR 경로 중 하나입니다. 직업별 연봉 강세:
> 
> - **전기** $80K~$120K (특수 분야 $140K)
> - **배관** $75K~$110K
> - **목공** $70K~$100K
> - **용접** $70K~$95K
> - **정비** $65K~$100K
> - **에어컨/냉동** $75K~$100K
> 
> 모두 MLTSSL 직업군 가능합니다.
> 
> **핵심 시스템**: TAFE + Apprenticeship (호주 회사 견습 4년) = 견습 시급 받으면서 학교 + 자격
> 
> 영어 조건 낮음 (IELTS 5.5)
> 
> Regional 지역 (Adelaide/Perth/Hobart/Darwin 등)은 491 +15점 + Australian Study +5점 추가 적용 (Brisbane CBD는 Non-regional)입니다.
> 
> 카톡으로 알려주세요:
> ① 직업 선호 (전기/배관/목공/용접/정비/에어컨)  
> ② 영어 수준  
> ③ 한국 손재주/일 경험  
> ④ 도시 우선  
> ⑤ 신체 조건"

---

## ⚠️ 함정

1. **"한국 자격증 = 호주 인정"** → ❌ 호주 Cert III + IV 必
2. **"Apprenticeship 자동"** → 직접 호주 회사 구해야
3. **"Cert III만으로 PR"** → ❌ Cert IV + TRA 必
4. **"전기는 호주 비자 안 줌"** → ❌ 매우 강력 PR
5. **"용접 비자 안 됨"** → ✅ MLTSSL 직업군

---

## 📞 카카오 응대 시 필수

1. 직업 선호
2. 영어 수준
3. 한국 일 경험 + 신체 조건
4. 도시 + 학교

---

## 🔍 직원 확인 사이트

- TRA: tradesrecognitionaustralia.gov.au
- TAFE 각 주 사이트
- Apprenticeship: australianapprenticeships.gov.au
- Skilled Occupation List: immi.homeaffairs.gov.au
