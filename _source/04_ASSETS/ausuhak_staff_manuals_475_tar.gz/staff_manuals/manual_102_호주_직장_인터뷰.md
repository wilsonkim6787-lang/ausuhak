# 📚 직원 응대 매뉴얼 #102

**케이스: 24세 / 시드니 / TAFE 졸업 후 485 / "호주 회사 인터뷰 잡혔는데 영어 너무 떨려요. 어떻게 준비해요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니 IT 회사 인터뷰 잡혔어요. 다음주 화요일이에요. 영어로 인터뷰래요. 떨려서 잠도 안 와요. 어떻게 준비해요? 호주 회사 분위기는 어때요? 한국이랑 다른가요?

**👉 직원이 멘붕하는 순간**
- "직원 = 인터뷰 코치 X"
- "한국 vs 호주 직장 차이 모름"
- "영어 인터뷰 = 윌슨 영역"
- "그래도 무엇 안내?"

**❌ 절대 하지 말아야 할 답**
- "영어 학원 다니세요" → **시간 부족**
- "걱정마세요" → **무책임**
- "한국이랑 비슷해요" → **거짓**

**✅ 직원이 알아야 할 정답**
호주 직장 인터뷰 = **한국과 다름**. 직원 = **공식 정보 + 호주 문화**:

1. **호주 인터뷰 문화** (캐주얼 + 평등)
2. **STAR 답변 기법** (Situation-Task-Action-Result)
3. **Behavioural Questions** (호주 일반)
4. **호주 인터뷰 복장**
5. **자주 나오는 질문 + 모범 답변**
6. **Salary 협상**
7. **인터뷰 후 Follow-up**

직원 = **공식 가이드 + 자료**. 윌슨 = **개별 코칭** (필요 시).

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 직장 문화 (한국과 차이)

**답**: 호주 직장 = **평등 + 직설 + 워크라이프밸런스**.

**한국 vs 호주 차이**:

| 항목 | 한국 | 호주 |
|------|------|------|
| 호칭 | 부장님/팀장님 | First name (이름) |
| 위계 | 강함 | 약함 (평등) |
| 회의 | 윗사람 발언 | 모두 발언 |
| 야근 | 일반적 | 거의 없음 |
| 점심 | 같이 먹음 | 개별/책상 |
| 회식 | 자주 | 가끔 (Friday drinks) |
| 휴가 | 눈치 | 권리 (4주/년) |
| 휴직 | 어려움 | 자유 |
| 옷차림 | Formal | Smart Casual 일반 |

**호주 직장 = "Mate" 문화**:
- CEO도 First name
- 자유 발언
- 의견 직설
- 갈등 = 직접 대화

**워크라이프밸런스**:
- 5시 = 퇴근
- 야근 = 거절 가능
- 휴가 = 언제든
- 가족/취미 우선

**출처**: Fair Work Ombudsman, 호주 노동법

---

### 2️⃣ STAR 답변 기법

**답**: 호주 인터뷰 = **STAR 기법** (행동 기반 질문). 영어 모범 답변 구조.

**STAR**:
- **S**ituation (상황): 어떤 상황이었나?
- **T**ask (과제): 무엇을 해야 했나?
- **A**ction (행동): 어떻게 행동했나?
- **R**esult (결과): 어떤 결과였나?

**STAR 예시**:

질문: "Tell me about a time you handled a difficult customer."

답변 (STAR):
> **Situation**: At my previous part-time job at a cafe in Sydney, a customer complained loudly that her coffee was cold.
>
> **Task**: I had to resolve the issue quickly to keep the customer happy and avoid disturbing other customers.
>
> **Action**: I apologised, took the coffee back, made a fresh hot one, and offered her a free cookie. I also explained politely that we always serve hot coffee.
>
> **Result**: The customer thanked me and left a positive Google review. My manager praised my customer service skills.

**STAR 장점**:
- 구조화 = 면접관 이해 쉬움
- 영어 = 외운 답변 자연스러움
- 행동 = 능력 증명

**출처**: SEEK 호주, indeed Australia, LinkedIn Australia

---

### 3️⃣ 자주 나오는 호주 인터뷰 질문 (10가지)

**답**: 호주 인터뷰 = **반복되는 질문**. 미리 답 준비 = 핵심.

**일반 질문**:

1. **"Tell me about yourself"**
   - 1분 자기소개
   - 학력 + 경력 + 강점 + 지원 동기

2. **"Why are you interested in this role?"**
   - 회사 + 직무 + 자기 매칭

3. **"Why do you want to work for our company?"**
   - 회사 사이트 미리 조사
   - 회사 가치/제품/문화 언급

4. **"What are your strengths?"**
   - 직무 관련 3가지
   - 예시 포함 (STAR)

5. **"What are your weaknesses?"**
   - 진실한 약점 + 개선 노력

**행동 기반 (STAR 적용)**:

6. **"Tell me about a time you worked in a team"**
7. **"Describe a challenge you overcame"**
8. **"Give an example of leadership"**
9. **"Tell me about a mistake and what you learned"**
10. **"How do you handle stress?"**

**기술 질문 (직무별)**:
- IT = 프로그래밍 / 시스템
- Hospitality = 고객 서비스 케이스
- Marketing = 캠페인 경험

**마무리**:
11. **"Do you have any questions for us?"**
   - 항상 질문 준비 (3개)
   - 회사 / 팀 / 본인 역할

**출처**: SEEK, Indeed Australia 인터뷰 가이드

---

### 4️⃣ 호주 인터뷰 복장 + 매너

**답**: 호주 인터뷰 = **Smart Casual 일반**. 회사/직무별.

**복장 (직무별)**:

**Smart Casual** (대부분):
- IT, 스타트업, 디자인, 미디어
- 셔츠 + 슬랙스 (남)
- 블라우스 + 슬랙스/스커트 (여)
- 스니커즈 X, 깨끗한 신발

**Business** (Formal):
- 은행, 법률, 정부, 공기업
- 정장 (남: 넥타이)
- 정장 / 블라우스 + 스커트 (여)

**Casual** (드물음):
- 스타트업 일부, 크리에이티브
- 청바지 + 셔츠 OK

**원칙**: 모르면 **Smart Casual** 권장.

**매너**:
- 5분 일찍 도착 (10분 X = 부담)
- 면접관 = First name 사용
- 악수 = 가벼움 (한국식 양손 X)
- Eye Contact = 자연스럽게
- 미소 = 적절히
- 핸드폰 = 무음

**자기소개 첫 멘트**:
- "Hi, I'm [Name]. Nice to meet you."
- "Hi, thanks for having me today."
- 한국식 90도 X

**출처**: SEEK, 호주 채용 가이드

---

### 5️⃣ Salary 협상 + Follow-up

**답**: 호주 = **연봉 협상 일반**. 인터뷰 후 = **Thank-you Email**.

**Salary 질문**:
- "What are your salary expectations?"
- 답변 = 호주 시장 조사 후

**시장 조사**:
- SEEK Salary Insights
- Glassdoor Australia
- LinkedIn Salary
- Hays Salary Guide

**호주 평균 연봉 (Junior, IT)**:
- Sydney IT Junior Developer: $70,000~85,000
- Marketing Coordinator: $55,000~70,000
- Hospitality Supervisor: $55,000~65,000
- Accountant: $60,000~75,000

**답변 멘트**:
- "Based on my research, the market range for this role is $70,000 to $85,000. I'd be looking for somewhere in that range."
- 협상 여지 두기

**입사 후 협상**:
- Job offer 후 = 협상 OK
- 1~2일 시간 요청 정상
- "Could I have 24 hours to consider?"

**Follow-up Email**:

인터뷰 후 24시간 내:
- 제목: "Thank you - [Job Title] Interview"
- 내용:
  - 인터뷰 시간 감사
  - 직무 흥미 재확인
  - 본인 강점 강조 (1줄)
  - 다음 단계 기다림

**예시**:
> Subject: Thank you - Software Developer Interview
>
> Dear [Manager],
>
> Thank you for taking the time to meet with me today. I really enjoyed learning about [Company] and the team's work on [project].
>
> I'm very excited about the opportunity to contribute my [skill] to your team.
>
> Please let me know if there's any further information I can provide. Looking forward to hearing from you.
>
> Best regards,
> [Name]

**출처**: SEEK, Hays Australia, LinkedIn

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 회사/직무 사전 조사
- 회사 웹사이트
- LinkedIn 회사 페이지
- 면접관 LinkedIn 확인
- 회사 최근 뉴스

### Step 2: 자기소개 1분 영어 준비
- 학력 + 경력 + 강점 + 지원 동기
- 외워서 자연스럽게

### Step 3: STAR 답변 5개 준비
- 팀워크 / 도전 / 리더십 / 실수 / 스트레스
- 미리 영어 작성 + 외움

### Step 4: 회사 질문 3개 준비
- "What does success look like in this role?"
- "How would you describe the team culture?"
- "What are the next steps?"

### Step 5: 복장 준비
- IT 회사 = Smart Casual
- 깨끗한 셔츠 + 슬랙스
- 신발 = 깨끗

### Step 6: 인터뷰 당일
- 5분 일찍 도착
- First name 사용
- Eye Contact + 미소
- STAR 답변
- 핸드폰 무음

### Step 7: Salary 답변 준비
- SEEK Salary 조사
- Sydney IT Junior = $70,000~85,000
- 답변 = 시장 범위 + 협상 여지

### Step 8: Follow-up Email (24h 내)
- Thank-you Email
- 제목 + 내용 표준 형식

---

## 💡 직원이 학생한테 말할 멘트

**[카카오톡 답장 멘트]**

> 인터뷰 잡힌 거 축하드려요! 호주 인터뷰 = 한국과 달라요. 핵심만 안내드릴게요.
>
> **🎯 1단계: 회사 조사 (오늘 저녁)**
> - 회사 사이트 / LinkedIn
> - 회사 가치 / 제품 / 최근 뉴스
> - 면접관 LinkedIn 확인
>
> **🎯 2단계: STAR 답변 5개 (이번주 평일)**
>
> STAR = **S**ituation, **T**ask, **A**ction, **R**esult
>
> 예시 답변 구조:
> - Situation: "At my previous job..."
> - Task: "I had to..."
> - Action: "I did..."
> - Result: "As a result..."
>
> 미리 준비할 STAR 답변 5개:
> 1. 팀워크 경험
> 2. 어려움 극복
> 3. 리더십
> 4. 실수와 배움
> 5. 스트레스 대처
>
> **🎯 3단계: 자주 나오는 질문 (외워!)**
> 1. "Tell me about yourself" (1분)
> 2. "Why this company?"
> 3. "Why this role?"
> 4. "Strengths/weaknesses"
> 5. "Where do you see yourself in 5 years?"
>
> **🎯 4단계: 회사 질문 3개 준비**
> - "What does success look like in this role?"
> - "How would you describe the team culture?"
> - "What are the next steps?"
>
> **🎯 5단계: 복장**
> - IT 회사 = **Smart Casual**
> - 깨끗한 셔츠 + 슬랙스
> - 깨끗한 신발 (스니커즈 X)
> - 정장 X (과함)
>
> **🎯 6단계: 매너**
> - **5분 일찍 도착** (10분 X)
> - **First name 사용** ("Hi John, nice to meet you")
> - 가벼운 악수 (한국식 90도 X)
> - 미소 + Eye Contact
> - 핸드폰 무음
>
> **🎯 7단계: Salary 질문**
> - "What are your salary expectations?"
> - SEEK 조사 = Sydney IT Junior = $70,000~85,000
> - 답: "Based on my research, the market range is $70k to $85k. I'd be looking for somewhere in that range."
>
> **🎯 8단계: Follow-up (24시간 내)**
> - Thank-you Email 필수
> - 제목: "Thank you - [Job Title] Interview"
> - 짧게 (3~4줄)
>
> **🚨 한국 vs 호주 차이**:
> - 호주 = **평등 + 직설 + 캐주얼**
> - First name 사용 (부장님 X)
> - 자기 의견 표현 OK
> - Eye Contact 자연스럽게
> - 한국식 90도 절 X
>
> **💪 떨림 관리**:
> - 자기소개 = 외워서 자연스럽게
> - 모르는 질문 = "That's a great question, let me think..."
> - 영어 100% X = OK. 호주 = 다양성
> - 미소 + 자신감 = 70%
>
> 윌슨이 1:1 모의 인터뷰 도와드릴 수 있어요. 시간 잡으면 카카오로 알려주세요!
>
> 카카오 ID: studywilson

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "정장 입어요"
- **사실**: IT/스타트업 = Smart Casual. 정장 = 과함
- **올바른 안내**: "회사별 다름. 모르면 Smart Casual"

### 함정 2: "한국식 절"
- **사실**: 호주 = 가벼운 악수. 90도 X
- **올바른 안내**: "Eye Contact + 가벼운 악수"

### 함정 3: "직책 호칭"
- **사실**: First name 사용
- **올바른 안내**: "Mr/Ms X. First name OK"

### 함정 4: "약점 = 거짓말"
- **사실**: 진짜 약점 + 개선 노력 = 좋음
- **올바른 안내**: "진실 + 보완 노력"

### 함정 5: "Salary 질문 회피"
- **사실**: 호주 = 협상 일반. 답변 준비
- **올바른 안내**: "시장 범위 + 협상 여지"

### 함정 6: "회사 질문 = 안 해도 됨"
- **사실**: "No questions" = 흥미 부족 평가
- **올바른 안내**: "3가지 질문 준비"

### 함정 7: "Follow-up Email = 형식"
- **사실**: 호주 = Thank-you Email 일반. 안 보내면 -점
- **올바른 안내**: "24시간 내 Thank-you Email 필수"

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 직무 / 회사
- IT? Hospitality? Finance?
- 회사 = 대기업? 스타트업?
- → 복장/문화 다름

### 2. 인터뷰 형식
- 1차/2차?
- 영어 100%? 한국어 가능?
- 화상/대면?
- → 준비 다름

### 3. 시점
- 며칠 후?
- 1주일 = 충분 / 내일 = 핵심만
- → 우선순위

### 4. 영어 수준
- IELTS 점수
- 회화 자신감
- → 답변 난이도 조절

**4가지 확인 후 → 본인의 영역(공식 가이드) → 윌슨 영역(모의 인터뷰)**

---

## 🔍 직원이 직접 확인 가능한 사이트

### 인터뷰 가이드
- seek.com.au/career-advice
- au.indeed.com/career-advice
- linkedin.com/learning

### Salary 조사
- seek.com.au (Salary Insights)
- glassdoor.com.au
- au.linkedin.com (Salary)
- hays.com.au (Salary Guide)

### 회사 조사
- linkedin.com (회사 페이지)
- glassdoor.com.au (직원 리뷰)

### 영어 인터뷰 연습
- ChatGPT (모의 인터뷰)
- Pramp (peer mock)
- YouTube ("Australian job interview")

**확인 사항**: 위 사이트 = 호주 채용 시장 표준.

---

## 🚨 직원 영역 vs 변호사/MARA 영역

### 직원 영역 (이 매뉴얼 활용)
- ✅ 호주 직장 문화 안내
- ✅ STAR 기법 안내
- ✅ 자주 나오는 질문 + 모범 답변
- ✅ 복장 / 매너
- ✅ Salary 시장 조사
- ✅ Follow-up Email

### 윌슨 직접 처리 영역
- ⚠️ 1:1 모의 인터뷰
- ⚠️ STAR 답변 첨삭
- ⚠️ 학생 영어 코칭
- ⚠️ 회사별 맞춤 준비

### 영어 학원 영역 (직원 X)
- ❌ 영어 회화 강의
- ❌ 발음 교정
- ❌ Business English 코스

### 채용 회사 영역 (직원 X)
- ❌ 채용 추천
- ❌ 이력서 직접 작성
- ❌ 회사 컨택

**원칙**: 직원 = **가이드**. 모의 인터뷰 = **윌슨**. 영어 학습 = 학원/온라인.

---

## ✅ 완벽 응대 체크리스트

응대 끝나기 전 이 체크리스트 확인:

- [ ] **STAR 기법** 안내했나?
- [ ] STAR 5개 답변 미리 준비 권장했나?
- [ ] 자주 나오는 질문 10가지 안내했나?
- [ ] **자기소개 1분** 외우기 강조했나?
- [ ] **회사 조사** (사이트, LinkedIn) 권장했나?
- [ ] **회사 질문 3개** 준비 강조했나?
- [ ] **복장** (Smart Casual) 안내했나?
- [ ] **5분 일찍** 도착 강조했나?
- [ ] **First name** 사용 안내했나?
- [ ] **한국식 90도 X** 명시했나?
- [ ] Salary 시장 범위 (SEEK Salary) 안내했나?
- [ ] **Follow-up Email** (24h) 강조했나?
- [ ] 한국 vs 호주 차이 (평등/직설/캐주얼) 안내했나?
- [ ] 윌슨 모의 인터뷰 가능 안내했나?
- [ ] "걱정마세요" 같은 무책임 답변 안 했나?

**핵심**: 호주 인터뷰 = **STAR + Smart Casual + First name + Salary 협상 + Follow-up**. 한국식 90도 X. 직원 = 가이드, 모의 인터뷰 = 윌슨.

---

**작성**: ausuhak.com 직원 교육 시스템 v1.0
**기준일**: 2026-05-04
**참고**: seek.com.au, au.indeed.com, glassdoor.com.au, hays.com.au
**다음 매뉴얼**: #103 호주 이력서 / Cover Letter 작성
