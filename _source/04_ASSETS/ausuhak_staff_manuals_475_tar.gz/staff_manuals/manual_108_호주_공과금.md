# 📚 직원 응대 매뉴얼 #108

**케이스: 27세 / 시드니 1베드룸 입주 직후 / "전기 가스 인터넷 어떻게 신청해요? 수도는요? 비싸요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니 1베드룸 입주했어요. 전기, 가스, 인터넷 어떻게 신청해요? 수도세는요? 어디 회사 좋아요? 한 달 얼마예요? 한국처럼 자동이체 되나요?

**👉 직원이 멘붕하는 순간**
- "전기/가스 = 회사 선택?"
- "어디가 좋아?"
- "수도 = 누가 내?"
- "인터넷 = NBN?"
- "월 비용?"

**❌ 절대 하지 말아야 할 답**
- "전기 무료" → **거짓**
- "수도세 임대인" → **부분 사실**
- "인터넷 자유" → **부분 사실. NBN 의존**

**✅ 직원이 알아야 할 정답**
호주 공과금 = **회사 선택 자유 + Plan 비교 필수**:

1. **전기 (Electricity)** = 회사 선택 (Origin, AGL, Energy Australia 등)
2. **가스 (Gas)** = 일부 집만 (전기로 대체 가능)
3. **수도 (Water)** = 임대인 부담 (대부분)
4. **인터넷 (Internet)** = NBN 회사 선택 (Telstra, TPG, Aussie Broadband 등)
5. **자동이체 (Direct Debit)** = 가능
6. **Plan 비교** = 절약 가능

직원 = **시스템 안내**. 윌슨 = **공과금 회사 영역 X**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 전기 (Electricity) 시스템

**답**: 호주 = **자유 시장**. 회사 선택 가능.

**주요 회사 (Big 3)**:
- Origin Energy (가장 큼)
- AGL
- Energy Australia

**중소 회사 (저렴)**:
- Red Energy
- Powershop
- Alinta Energy
- Simply Energy
- Lumo Energy

**Plan 종류**:

**Standing Offer (기본)**:
- 정부 표준 가격
- 비쌈
- 비추

**Market Offer (할인)**:
- 회사별 할인
- 일반 추천

**고려 사항**:
- Usage Rate (kWh당 요금)
- Daily Supply Charge (일일 기본료)
- Discount % (조기 결제, 자동이체 등)
- Solar Feed-in Tariff (태양광 판매)

**비교 사이트 (정부 무료)**:
- **EnergyMadeEasy.gov.au** (NSW, QLD, SA, ACT)
- Victorian Energy Compare (VIC)

**계약**:
- 2주~6주 영업일 셋업
- ID + 임대 계약서 + 미터 번호
- 별도 계약금 X
- Bond 가끔 ($150~300)

**평균 비용 (1베드룸)**:
- 시드니: $80~150/월
- 멜번: $90~160/월 (난방 전기 시)
- 브리즈번: $70~130/월
- 퍼스: $80~140/월

**출처**: energymadeeasy.gov.au, originenergy.com.au

---

### 2️⃣ 가스 (Gas) 시스템

**답**: 호주 = **가스 일부 지역만**. 없는 집 많음.

**가스 사용 지역**:
- 시드니 (광범위)
- 멜번 (광범위, VIC = 가스 강국)
- 브리즈번 (일부)
- 애들레이드 (일부)
- 퍼스 (광범위)
- 호바트 (적음)

**가스 종류**:

**Natural Gas (도시가스)**:
- 파이프 연결
- 안정적
- 일부 집만

**LPG (가스통)**:
- 봄베 가스
- 시골/일부 단독주택
- 정기 배달

**전기 대체**:
- 전기 인덕션
- 전기 히터
- 가스 없어도 OK

**주요 회사**:
- AGL
- Origin Energy
- Energy Australia
- Alinta Energy

**비용**:
- 1베드룸 + 가스: $30~80/월
- 가족 + 가스 난방: $100~250/월

**Dual Fuel (전기 + 가스 한 회사)**:
- 할인 가능
- 청구서 1개

**출처**: aer.gov.au

---

### 3️⃣ 수도 (Water) 시스템

**답**: 호주 = **수도 = 임대인 부담 (대부분)**.

**원칙**:
- 정수 (Sydney Water 등) = 임대인이 지불
- 사용량 (Water Usage Charge) = **임차인 부담** (조건 충족 시)

**조건 충족 (NSW)**:
- 별도 미터 (Individual Meter)
- 효율 인증 (3-Star Water Saver)
- 집 명세에 명시

**조건 미충족**:
- 임대인 전액 부담
- 임차인 X

**평균 비용**:
- 1베드룸 사용량: $20~50/분기 (3개월)
- 가족 사용량: $80~150/분기

**청구**:
- 분기 (3개월마다)
- 임대인 → 임차인에 청구서 전달
- 임차인 임대인에게 송금

**Sydney Water (NSW)**:
- 서비스: 임대인
- 사용량: 임차인 (조건시)
- 1300 985 626

**Yarra Valley Water (VIC)**:
- Melbourne Water 권역
- 비슷 정책

**Urban Utilities (QLD)**:
- 브리즈번
- 비슷

**출처**: sydneywater.com.au, yvw.com.au, urbanutilities.com.au

---

### 4️⃣ 인터넷 (Internet) - NBN 시스템

**답**: 호주 = **NBN (National Broadband Network)** 의무.

**NBN 종류**:

**FTTP (Fibre to the Premises)**:
- 광케이블 직접
- 가장 빠름 (1Gbps)
- 도시 일부

**FTTC (Fibre to the Curb)**:
- 광케이블 길가까지
- 빠름 (250Mbps)

**FTTN (Fibre to the Node)**:
- 광케이블 분배함까지 + 구리선
- 보통 (50~100Mbps)
- 가장 흔함

**HFC (Hybrid Fibre Coaxial)**:
- 케이블 TV 선
- 빠름 (100~250Mbps)
- 도시 일부

**Fixed Wireless**:
- 무선 (시골)
- 25~50Mbps

**Satellite**:
- 위성 (오지)
- 25Mbps

**NBN 회사 (Retailer)**:
- Telstra (가장 큼, 비쌈)
- Optus
- TPG
- Aussie Broadband (인기)
- Belong
- iiNet
- Dodo
- More Telecom

**Plan 종류 (Speed Tier)**:

**NBN 25 (Basic)**:
- 25Mbps Download
- $50~70/월
- 가벼운 사용 (이메일, 웹)

**NBN 50 (Standard)**:
- 50Mbps
- $70~90/월
- 일반 (Netflix, Zoom)
- 가장 인기

**NBN 100 (Fast)**:
- 100Mbps
- $90~110/월
- 4K 스트리밍, 게임

**NBN 250 / 1000**:
- 250~1000Mbps
- $130~170/월
- 헤비 사용

**계약**:
- 1개월 계약 (Month-to-Month) 일반
- 12/24개월 = 모뎀 무료
- Setup Fee: $0~99

**셋업**:
- 가입 후 5~10일
- 모뎀 우편
- 자가 설치 (대부분)
- 기술자 방문 가끔

**Mobile Internet (대안)**:
- Telstra/Optus/Vodafone 4G/5G
- Pocket WiFi
- 임시용 (NBN 셋업 전)
- $30~100/월

**출처**: nbnco.com.au, whistleout.com.au (비교)

---

### 5️⃣ 자동이체 (Direct Debit) + 청구

**답**: 호주 공과금 = **자동이체 + 분기 청구 일반**.

**자동이체**:
- Direct Debit (계좌 자동 인출)
- BPay (계좌 송금)
- Credit Card 자동 결제
- 할인 (가끔)

**청구 주기**:
- 전기: 분기 (3개월) 또는 월간
- 가스: 분기 또는 월간
- 수도: 분기
- 인터넷: 월간

**청구서 (Bill)**:
- 이메일 (Paperless)
- 우편
- 앱 (대부분 회사 앱 있음)

**Late Payment Fee**:
- 늦으면 $5~20 페널티
- 14일 후 = 단전/단수 경고
- 30일 후 = 단전/단수
- 한국 송금 늦음 = 자동이체 권장

**Concession (할인)**:
- 학생 할인 = 거의 없음
- 노인/장애인 = 있음 (PR/시민권)
- Healthcare Card = 일부

**비교 사이트**:
- Energy Made Easy: 정부 (NSW, QLD, SA, ACT)
- Victorian Energy Compare: VIC
- WhistleOut: 인터넷
- Finder.com.au: 종합

**출처**: bpay.com.au, finder.com.au

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 입주 1~3일 전기 가입
- Energy Made Easy 비교 (NSW)
- Origin/AGL/Red Energy 등 선택
- 전화 또는 온라인 가입
- ID + 임대계약서

### Step 2: 가스 (있는 집만)
- Dual Fuel (전기 + 가스 한 회사)
- 또는 별도 가스 회사
- 없는 집 = 패스

### Step 3: 인터넷 1주 안에
- NBN 50 Plan ($70~90)
- Aussie Broadband / Belong 추천
- 모뎀 우편 5~10일
- 임시: Pocket WiFi 또는 휴대폰 핫스팟

### Step 4: 수도 (임대인)
- 임대인 부담 확인 (대부분)
- 사용량 청구서 = 임차인 (조건 충족 시)
- 분기 청구

### Step 5: 자동이체 셋업
- 호주 은행 계좌 (CommBank, NAB, ANZ, Westpac)
- BPay 또는 Direct Debit
- 모든 청구서 자동

---

## 💡 직원이 학생한테 말할 멘트

```
시드니 1베드룸 입주 축하드립니다!
공과금 셋업은 입주 첫 주 안에 다 하시는 게 좋아요.

[전기 (Electricity)]
- 호주 = 회사 선택 자유
- 추천: Origin Energy, AGL, Red Energy, Powershop
- 비교 사이트: EnergyMadeEasy.gov.au (정부, 무료)
- 1베드룸: 월 $80~150
- 가입 = 온라인 또는 전화
- 셋업 = 2~6일

[가스 (Gas)]
- 시드니 = 가스 있는 집 많음
- 가스 + 전기 = Dual Fuel (한 회사) 추천
- 가스 없는 집 = 패스 (전기 인덕션, 전기 히터)
- 1베드룸 + 가스: 월 $30~80

[수도 (Water)]
- Sydney Water = 임대인 부담 (서비스 요금)
- 사용량 = 임차인 (조건 충족 시)
- 별도 미터 + 효율 인증 = 임차인 부담
- 임대인이 청구서 주면 송금
- 1베드룸: 분기 $30~70

[인터넷 (NBN)]
- 호주 = NBN 의무 (광인터넷)
- NBN 50 Plan = $70~90/월 (가장 인기)
- 추천 회사: Aussie Broadband, Belong, TPG
- Telstra = 비쌈 (퀄리티 좋음)
- 가입 = 온라인 5분
- 모뎀 우편 = 5~10일

[셋업 순서]
1. 입주 1~3일: 전기 가입
2. 입주 1주: 인터넷 가입
3. 임시 인터넷: 휴대폰 핫스팟 또는 카페 WiFi
4. 자동이체 셋업 (호주 은행 계좌)

[월 공과금 합계 (1베드룸)]
- 전기: $80~150
- 가스 (있는 집): $30~80
- 수도: $20 (분기 $30~70 / 3개월)
- 인터넷: $70~90
- 휴대폰: $30~50
- 총: 월 $230~390

[자동이체]
- Direct Debit (계좌 자동)
- BPay (계좌 송금)
- 신용카드
- 늦으면 페널티 $5~20

[비교 사이트 (절약)]
- EnergyMadeEasy.gov.au (전기/가스)
- WhistleOut.com.au (인터넷)
- Finder.com.au (종합)
- 매년 1회 비교 후 변경 가능

[주의]
- Standing Offer = 기본 (비쌈) → Market Offer 선택
- 12개월 계약 = 깨면 페널티
- Month-to-Month = 자유

자세한 회사 추천은 Eastwood/Strathfield 한인 커뮤니티에서 후기 보세요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "전기 무료"
- **거짓**. 의무 + 자기 부담
- 임대인 X = 임차인 부담

### 함정 2: "수도세 = 임차인"
- **부분 사실**. 사용량 = 임차인 (조건 충족 시)
- 서비스 = 임대인
- 별도 미터 없으면 임대인 100%

### 함정 3: "인터넷 = WiFi 자동"
- **거짓**. NBN 별도 신청
- 매물에 인터넷 포함 = 드뭄
- Furnished = 가구만, 인터넷 별도

### 함정 4: "Telstra가 최고"
- **부분 사실**. 가장 안정적이지만 비쌈
- 학생 = Aussie Broadband, Belong 추천
- 가격 50% 차이

### 함정 5: "한 회사 = 평생"
- **거짓**. 매년 비교 + 변경 가능
- 자유 시장 = 경쟁
- 절약 가능

### 함정 6: "가스 의무"
- **거짓**. 전기로 대체 가능
- 가스 없는 집도 많음
- 가스만 의존 = 비쌈

### 함정 7: "Bond 공과금"
- **거짓**. 임대 Bond와 다름
- 일부 전기 회사 = 작은 Bond ($150~300)
- 신용도 따라

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 위치 (시/주)
- 회사 다름
- 가스 유무
- 수도 정책

### 2. 입주 형태
- 단독 (1베드룸/스튜디오) = 본인 셋업
- 셰어하우스 = 호스트 명의
- Furnished + Bills = 셋업 X

### 3. 사용량
- 1베드룸 = 절약 가능
- 가족 = 더 큼
- 에어컨/난방 = 큼

### 4. 예산
- 절약형 = $200~250/월
- 일반 = $300~400/월
- 가족 = $500~700/월

---

## 🔍 직원이 직접 확인 가능한 사이트

- Energy Made Easy: energymadeeasy.gov.au (정부 비교, NSW/QLD/SA/ACT)
- Victorian Energy Compare: compare.energy.vic.gov.au
- Origin Energy: originenergy.com.au
- AGL: agl.com.au
- Red Energy: redenergy.com.au
- NBN Co: nbnco.com.au
- WhistleOut: whistleout.com.au (인터넷 비교)
- Aussie Broadband: aussiebroadband.com.au
- Belong: belong.com.au
- Sydney Water: sydneywater.com.au
- Yarra Valley Water: yvw.com.au
- Urban Utilities: urbanutilities.com.au
- Finder: finder.com.au

---

## 🚨 직원 영역 vs 회사 직접 영역

### 직원이 할 수 있는 것
- ✅ 호주 공과금 시스템 설명
- ✅ 회사 선택 자유 안내
- ✅ 비교 사이트 정보
- ✅ 평균 비용 안내

### 직원이 할 수 없는 것
- ❌ 특정 회사 추천 강요
- ❌ 가입 대행
- ❌ 청구서 분쟁
- ❌ 미납 해결

---

## ✅ 완벽 응대 체크리스트

- [ ] 위치 확인
- [ ] 입주 형태 확인
- [ ] 전기 회사 선택 자유 설명
- [ ] EnergyMadeEasy 비교 사이트 안내
- [ ] Origin/AGL/Red Energy 등 옵션
- [ ] 가스 유무 (집마다 다름)
- [ ] Dual Fuel 옵션 안내
- [ ] 수도 = 임대인 부담 (대부분) 안내
- [ ] 사용량 분담 조건 설명
- [ ] NBN 50 Plan 권장
- [ ] Aussie Broadband, Belong 등 옵션
- [ ] Telstra = 비쌈 (안정적)
- [ ] 자동이체 셋업 권장
- [ ] BPay/Direct Debit 설명
- [ ] 월 공과금 합계 ($230~390) 안내
- [ ] 비교 + 매년 변경 권장
- [ ] 특정 회사 추천 = 절제

---

**작성**: ausuhak.com 직원 교육팀
**감수**: Wilson Kim (QEAC E240)
**기준**: 2026년 5월
**다음 업데이트**: 공과금 정책 변경 시
