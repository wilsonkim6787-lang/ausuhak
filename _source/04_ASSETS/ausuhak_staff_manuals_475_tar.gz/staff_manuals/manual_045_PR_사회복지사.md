# 📚 직원 응대 매뉴얼 #045

**케이스: 사회복지사 (Social Worker) PR 종합**

---

## 🎬 상황 시뮬레이션

> 호주 사회복지사로 영주권 받을 수 있나요? 한국에서 사회복지 했어요.

**👉 정답**: **Master of Social Work (Qualifying) + AASW + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Social Worker 직업군 PR

| 직업 | ANZSCO | 평균 연봉 | PR 리스트 |
|---|---|---|---|
| Social Worker | 272511 | $70K~$100K | MLTSSL |
| Welfare Worker | 411711 | $60K~$85K | STSOL |
| Welfare Centre Manager | 134214 | $80K~$120K | STSOL |
| Family Support Worker | 411712 | $55K~$75K | STSOL |

**Social Worker 272511 = MLTSSL 직업군**

### 2️⃣ AASW = 사회복지사 등록 + 평가 기관

**AASW** (Australian Association of Social Workers) = 호주 사회복지사 등록 기관.

- 한국 사회복지 학사 평가
- 호주 학사/Master 졸업자 자동 인정
- 영어 IELTS 7.0 (각 영역 7.0)

### 3️⃣ Social Worker 표준 경로

```
한국 학사 + IELTS 7.0
        ↓
[옵션 A: 한국 사회복지 학사] AASW 평가 → Direct
[옵션 B: 비전공 학사] Master of Social Work (Qualifying) 2년
        ↓
AASW 등록 + 485
        ↓
호주 회사 취업 + PR
```

### 4️⃣ Master of Social Work 학교

| 학교 | 위치 | 학비 (연간) | IELTS |
|---|---|---|---|
| UMelb | Melbourne | $48K | 7.0 |
| USyd | Sydney | $52K | 7.0 |
| Monash | Melbourne | $44K | 7.0 |
| UNSW | Sydney | $48K | 7.0 |
| ACU | Sydney/Brisbane/Melbourne | $34K | 7.0 |
| Federation | Ballarat (Regional, 491 +15점) | $30K | 7.0 |
| Charles Sturt | Regional NSW | $30K | 7.0 |
| Western Sydney | Sydney | $34K | 7.0 |

### 5️⃣ Social Worker 영어 조건 + 면허

- **IELTS 7.0 (각 영역 7.0)** = AASW 등록 (까다로움)
- Working with Children Check 必
- Police Check 必

---

## 🎯 정답 경로

### Master Social Work + AASW + PR

```
한국 학사 + IELTS 7.0
        ↓
Master of Social Work (Qualifying) 2년 ($60K~$110K)
        ↓
졸업 + AASW 등록
        ↓
485 + 호주 회사 (Department of Social Services 등) 취업
        ↓
PR (272511 MLTSSL)
```

**총 4-5년 / 학비 $60K~$110K**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 사회복지사 영주권 가능합니다.
> 
> 1. **Social Worker 272511 = MLTSSL** 직업군 (PR 신청 비교적 빠름)
> 2. **연봉** $70K~$100K
> 3. **AASW 등록** 必須 (영어 IELTS 7.0)
> 
> 한국 사회복지 학사 + 경력 있으시면 AASW 평가에서 일부 인정 가능, 그래도 호주 Master of Social Work (Qualifying) 추가 권장입니다.
> 
> 학교 옵션:
> - **Go8** (Group of Eight): UMelb $48K / USyd $52K / Monash $44K / UNSW $48K
> - **사립/기타**: ACU $34K / WSU $34K
> - **Regional 지역 (491 +15점 + Australian Study +5점 + Regional Study +5점 = +25점)**: Federation Ballarat $30K, Charles Sturt $30K
> 
> 카톡으로 알려주세요:
> ① 한국 학사 전공 (사회복지 / 비전공)  
> ② 한국 사회복지 경력  
> ③ IELTS 점수  
> ④ 도시 우선"

---

## ⚠️ 함정

1. **"한국 사회복지 자격 = 호주 자동"** → AASW 평가 必
2. **"IELTS 6.5 OK"** → ❌ 7.0 必須
3. **"비전공도 가능"** → Master Social Work (Qualifying) 必
4. **"Welfare Worker = Social Worker"** → 다름 (Welfare는 STSOL)
5. **"Federation = Cat 3 +20점"** → ❌ 2019.11.16 이후 Cat 2/3 차등 폐지. 모든 Regional 지역 = 491 +15점 동일. 다만 Australian Study +5점 + Regional Study +5점 = 추가 +10점 가능

---

## 📞 카카오 응대 시 필수

1. 한국 학사 전공
2. 한국 경력
3. IELTS 점수
4. 도시 우선

---

## 🔍 직원 확인 사이트

- AASW: aasw.asn.au
- Master Social Work 학교들
