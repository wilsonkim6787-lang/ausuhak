# #510 호주_학생_캠퍼스_성폭력_Sexual_Assault_신고_절차_1800_RESPECT

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "대학 파티에서 성폭력 당했어요. 너무 무서워서 어떻게 해야 할지 모르겠어요. 신고하면 비자 영향 있나요?"

**직원 멘붕 포인트:**
- 성폭력 = 즉시 안전 + 의료 + 신고 (Forensic Evidence 72시간)
- 1800 RESPECT 1800 737 732 (24시간 한국어 통역)
- Sexual Assault Service 각 주 (긴급 의료 + 증거 수집)
- 비자 영향 X (피해자 보호)
- 직원이 의심 X. 즉시 자원 연결

---

## ❌ 절대 하지 말아야 할 답

> "술 마셨으면 본인 책임도 있어요"

→ ❌ 피해자 책임 X. 가해자 100% 책임. 직업 윤리 + 법적 보호

---

## ✅ 정답

가슴 아픈 일이에요. 본인 잘못 절대 아니에요. 즉시 (1) 1800 RESPECT 1800 737 732 (24시간 한국어 통역), (2) Sexual Assault Service 응급실 (Forensic Evidence 72시간 안 수집 가능), (3) 안전한 곳 이동 + 신뢰할 사람 연락하세요. 신고는 본인 결정이고 즉시 안 해도 됩니다. 비자에 영향 없으니 안심하세요(피해자 보호). 학교 Sexual Assault Officer + Counselling 무료입니다. NSW Police Sexual Assault Squad 02 8835 6500 한국어 통역 가능해요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 성폭력 즉시 대응 (72시간)**
1. 안전 확보 (현장 떠나기)
2. 신뢰할 사람 연락 (친구/가족)
3. 1800 RESPECT 1800 737 732 (24시간 한국어 통역)
4. 응급실 + Sexual Assault Service:
   - 의료 검진 (STI/임신 예방약)
   - Forensic Evidence 72시간 안
   - 옷/시트 보관 (씻지 말기)
5. 신고 결정 (즉시 안 해도 OK)

**2. Sexual Assault Service (각 주)**
NSW: NSW Health 1800 211 028
VIC: CASA 1800 806 292
QLD: DV Connect 1800 010 120
WA: SARC 1800 199 888
ACT: Canberra Rape Crisis 02 6247 2525
SA: Yarrow Place 1800 817 421

지원:
- 24시간 응급 의료
- Forensic Evidence Kit
- 심리 상담
- 변호사 연결
- 통역 (한국어 OK)

**3. 학교 자원 (Sexual Misconduct)**
USyd Safer Communities: sydney.edu.au
UNSW Sexual Misconduct: unsw.edu.au
UTS Sexual Assault: uts.edu.au
Monash Safer Community: monash.edu

지원:
- Sexual Assault Officer 1대1
- 학업 Special Consideration
- 가해자 학생인 경우 학교 처분
- 무료 Counselling
- 학교 안 처분 (무관 시 휴학 강요 X)

**4. 경찰 신고 (선택 + 비자 영향 X)**
NSW Police Sexual Assault Squad: 02 8835 6500
Crime Stoppers: 1800 333 000
각 주 Sexual Assault Squad

비자 영향:
- 피해자 보호 (Section 116 X)
- 학생비자 영향 X
- 신고 의무 X (본인 결정)
- Crime Victims Compensation 신청 가능
신고 시점:
- 즉시 (Forensic Evidence)
- 추후 (시효 NSW 무제한 - 성폭력)

**5. 심리 + 법적 자원**
심리:
- 1800 RESPECT 1800 737 732 (한국어)
- Beyond Blue 1300 22 4636
- Lifeline 13 11 14
- 학교 Counselling Service
- GP MHCP 10회 무료

법률:
- LawAccess NSW 1300 888 529
- Women's Legal Service 1800 801 501
- Crime Victims Compensation $1,500~$15,000
- Civil Lawsuit 가해자 손해배상

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 안전 확보 + 신뢰할 사람 연락
**2단계**: 1800 RESPECT 1800 737 732 (한국어 통역)
**3단계**: Sexual Assault Service 응급실 (Forensic 72시간)
**4단계**: 학교 Sexual Assault Officer + 무료 Counselling
**5단계**: 신고 결정 (즉시 안 해도 OK + 비자 영향 X)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 본인 잘못 절대 아니에요. 즉시 1800 RESPECT 1800 737 732 (24시간 한국어 통역) 연락하시고, Sexual Assault Service 응급실 가셔서 의료 + Forensic Evidence 72시간 안 수집하세요. 옷/시트 씻지 말고 보관하세요. 신고는 본인 결정이고 비자 영향 없습니다(피해자 보호). 학교 Sexual Assault Officer 무료 Counselling도 가능해요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **피해자 책임 X**
   → 본인 잘못 X. 가해자 100%

2. **씻고 옷 갈아입기 X**
   → Forensic 72시간

3. **즉시 신고 의무 X**
   → 본인 결정

4. **비자 영향 X**
   → 피해자 보호

5. **학교 처분 자동 X**
   → 신고 + 학교 절차

6. **외국인 자원 X**
   → 전부 외국인 학생도 무료

7. **수치심으로 침묵 X**
   → 1800 RESPECT 한국어 비밀 보장

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사건 후 며칠? (72시간 미만/72시간+)
2. 현재 안전해요? (안전/안전 X)
3. 신뢰할 사람 있어요? (있다/없다)
4. 신고 의향? (즉시/추후/안 함)

---

## 🔍 직원이 직접 확인 가능한 사이트

- 1800 RESPECT 한국어: 1800 737 732
- NSW Sexual Assault: 1800 211 028
- VIC CASA: 1800 806 292
- Beyond Blue: 1300 22 4636
- Crime Victims Compensation: 각 주

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 1800 RESPECT 한국어 연결
- Sexual Assault Service 안내
- 학교 Sexual Assault Officer 안내
- 비자 영향 X 안내

**MARA / 변호사 영역**
- 신고 절차 (Police)
- Crime Victims Compensation (Lawyer)
- Civil Lawsuit (Civil Lawyer)
- 비자 보호 (MARA - 일반 무관)

---

## ✅ 완벽 응대 체크리스트

- [ ] 안전 + 신뢰할 사람
- [ ] 1800 RESPECT 한국어
- [ ] Sexual Assault Service 72시간
- [ ] 학교 Sexual Assault Officer
- [ ] 비자 영향 X 확인
