# #316 호주_영어시험_대안_PTE_TOEFL_Cambridge

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "IELTS 5.5 나왔는데 학교에서 6.0 요구해요. PTE나 TOEFL로 다시 보면 더 잘 나올까요?"

**직원 멘붕 포인트:**
- 호주 학교 = IELTS 외 PTE Academic / TOEFL iBT / Cambridge C1 Advanced 인정
- DHA 비자 = IELTS / PTE / TOEFL / Cambridge / OET 모두 인정
- PTE Academic = 컴퓨터 응시 + 결과 빠름 (5일)
- TOEFL iBT = 미국 기반, 호주 학교 일부 인정 X
- 직원이 시험별 환산표 모르면 잘못 안내

---

## ❌ 절대 하지 말아야 할 답

> "PTE가 더 쉬우니까 PTE로 보세요."

→ ❌ 시험 난이도는 학생마다 다름. PTE = 컴퓨터 응시, 발음 인식 기반 → 한국 학생 일부 유리. 단 무조건 더 쉽다 X. 학생 영어 패턴 + 학교 인정 여부 확인 후 안내.

---

## ✅ 정답

**호주 학교 인정 영어 시험:**

| 시험 | 응시 방식 | 결과 발표 | 응시료 | 유효 |
|------|----------|----------|--------|------|
| IELTS Academic | 종이/컴퓨터 | 13일/3~5일 | $410 | 2년 |
| PTE Academic | 컴퓨터 | 2~5일 | $375 | 2년 |
| TOEFL iBT | 컴퓨터 | 6일 | $300 USD | 2년 |
| Cambridge C1/C2 | 종이/컴퓨터 | 4~6주 | $385 | 평생 |
| OET (의료) | 종이/컴퓨터 | 17일 | $587 | 2년 |

**점수 환산표 (Bachelor 입학 IELTS 6.5 = 다른 시험):**
- IELTS 6.5 = PTE 58 = TOEFL 79 = Cambridge 176
- IELTS 7.0 = PTE 65 = TOEFL 94 = Cambridge 185 (간호)
- IELTS 7.5 = PTE 73 = TOEFL 102 = Cambridge 191 (교직 R/W)
- IELTS 8.0 = PTE 79 = TOEFL 110 = Cambridge 200 (교직 S/L)

**학교별 인정 (확인 필수):**
- Group of Eight (G8) = IELTS / PTE / TOEFL / Cambridge 전부
- 일부 의료 학과 = IELTS / OET만 인정 (PTE/TOEFL X)
- 간호 (NMBA) = IELTS / OET만 (PTE 인정 X) ⚠️
- 의학/치의학 = IELTS / OET만

**시험별 특징:**
- IELTS = Speaking 사람 면접 / Writing 손글씨 가능
- PTE = 100% 컴퓨터 / Speaking 마이크 / 결과 빠름
- TOEFL = 미국 발음 / 호주 학교 인정 일부 제한
- Cambridge = 평생 유효 / 응시 횟수 제한

**한국 학생 PTE 유리점:**
- 발음 인식 = 한국식 발음 일부 관대
- Reading + Listening = 컴퓨터 = 한국 학생 친숙
- Writing = 자동 채점 = 패턴 학습 가능
- 단, Speaking = 마이크 인식 어려움

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. IELTS vs PTE vs TOEFL**
한국에서 모두 응시 가능. PTE 결과 가장 빠름 (5일). TOEFL 미국 기반.

**2. 간호 OET (Occupational English Test)**
의료 직군 영어. NMBA 인정. IELTS 7.0 = OET B (각 영역). 응시료 $587.

**3. Cambridge C1 Advanced (CAE)**
유럽 기반. 평생 유효. 호주 학교 인정. 응시료 $385.

**4. DHA 비자 영어 인정**
IELTS / PTE / TOEFL / Cambridge / OET 모두 인정. 학생비자 = SVP 면제 가능.

**5. EAP / Direct Entry**
ELICOS (어학원) 졸업 = IELTS 면제 (간호 제외). 어학원-대학 패키지 = 일반.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **현재 영어 점수 + 목표 점수 확인** - IELTS 5.5 → 6.0 등
**2단계**: **시험 적성 확인** - 한국 학생 일부 PTE 유리. 단, 학교 인정 확인 필수
**3단계**: **학교 인정 시험 확인** - 간호 = IELTS/OET / 일반 = IELTS/PTE/TOEFL/Cambridge
**4단계**: **응시 일정 + 비용 비교** - PTE 결과 빠름 / IELTS 응시료 저렴
**5단계**: **대안 경로** - 어학원 (ELICOS) Direct Entry / Foundation 입학 / Pathway College

---

## 💡 직원이 학생한테 말할 멘트

> "IELTS 외 PTE Academic, TOEFL iBT, Cambridge C1, OET (의료) 모두 호주 학교 인정합니다. 학생님 시험 적성 + 목표 학교 인정 시험 확인 후 안내가 필요해요. 간호는 IELTS/OET만 (PTE 인정 X)이고, 일반 학과는 PTE/TOEFL도 인정됩니다. 한국 학생 일부 PTE 유리하지만, 학교별 인정 여부 + 학과 (간호/의학/일반) 따라 다릅니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **PTE가 무조건 쉬움**
   → 학생별 다름. Speaking = 마이크 인식 어려움. 단, 컴퓨터 응시 + 빠른 결과 유리.

2. **TOEFL = 호주 학교 모두 인정**
   → TOEFL iBT 인정 학교 다수. 단, 일부 의료 학과 = IELTS/OET만.

3. **간호도 PTE 인정**
   → NMBA = IELTS / OET만. PTE 인정 X. 절대 PTE 안내 금지.

4. **Cambridge = 응시 어려움**
   → Cambridge C1 = 호주 학교 인정 + 평생 유효. 한국 응시 가능.

5. **어학원 졸업 = 간호 IELTS 면제**
   → 간호 = ELICOS Direct Entry IELTS 면제 X. 일반 학과는 가능.

6. **OET = 모든 직군 인정**
   → OET = 의료 직군 (간호/의사/약사 등). 일반 학과 X.

7. **IELTS 점수 = 학생비자 점수**
   → DHA = IELTS 5.5 / PTE 42 / TOEFL 46. 학교 입학 점수 별개.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 영어 점수 (어떤 시험)
2. 목표 학교 + 학과 (간호 = IELTS/OET 한정)
3. 한국 응시 일정 + 시험 가능 시기
4. Direct Entry / Foundation 대안 고려

---

## 🔍 직원이 직접 확인 가능한 사이트

- IELTS: www.ielts.org
- PTE Academic: www.pearsonpte.com
- TOEFL: www.ets.org/toefl
- Cambridge English: www.cambridgeenglish.org
- OET: www.occupationalenglishtest.org

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 시험별 일반 정보 + 환산표 안내
- 학교 인정 여부 확인 + 안내
- 어학원/Foundation 대안 안내

**MARA / 변호사 영역**
- 비자 영어 시험 면제 분쟁 = MARA
- 시험 부정 적발 + 비자 영향 = MARA + 변호사
- 학력/시험 인증 분쟁 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] 현재 영어 점수 + 시험 종류 확인
- [ ] 목표 학교 + 학과 인정 시험 확인
- [ ] 간호 = IELTS/OET 한정 명시
- [ ] 한국 응시 일정 + 비용 비교
- [ ] Direct Entry/Foundation 대안 안내
- [ ] 주관적 추천 X (시험별 객관적 정보만)
