# #449 호주_학생_호주_회사_본사_한국_이전_482_Sponsor_변경_무자격

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 482 비자로 호주 회사 다니는데 회사가 한국으로 본사 이전한대요. 호주 지사도 정리한다고. 비자 어떻게 되나요? 다른 회사 찾아야 하나요? 영주권 진행 중인데 다 망가지나요?"

**직원 멘붕 포인트:**
- Sponsor 변경 60일 룰
- Cessation 비자 자동 취소
- Visa Condition 8607
- 186/189 영주권 영향
- Bridging Visa 적용

---

## ❌ 절대 하지 말아야 할 답

> "회사 이전하면 비자 끝이에요"

→ ❌ ❌ Sponsor Cessation Notification 60일 후 새 Sponsor 찾을 시간 있음. 자동 취소 X.

---

## ✅ 정답

482 Sponsor Cessation: ① 회사 = Sponsor Cessation Notification 의무 (이민부 통보), ② 비자 = 60일 내 새 Sponsor 또는 다른 비자 변경 가능 (학생/Visitor), ③ 새 Sponsor = 같은 직군/유사 직군 가능 (Skilled Occupation List 동일), ④ Visa Condition 8607 - 같은 회사만 일 가능 (조건 변경 시 새 비자), ⑤ Bridging Visa A (BVA) - 비자 만료 시 자동 발급, ⑥ 영주권 진행 (186 ENS) - Sponsor 변경 시 새 Sponsor 가 186 다시 신청 (기존 진행 X), ⑦ 189 (Independent) = Sponsor 무관 / 점수 + 직군 / 진행 중이면 영향 X, ⑧ 호주 한국 본사 자회사 - 호주 직원 잔류 시 Sponsor 자격 유지 가능 (확인 필요), ⑨ 60일 내 안 정해지면 = 출국 또는 학생비자 등 변경.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Sponsor Cessation**
회사 통보 / 60일 룰

**2. Condition 8607**
같은 회사만 일

**3. Bridging Visa A**
자동 발급

**4. 186 ENS**
새 Sponsor 가 다시 신청

**5. 189 Independent**
Sponsor 무관 / 진행 영향 X

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 회사 Cessation Notification 일자 확인
**2단계**: 2단계: 60일 카운트 시작
**3단계**: 3단계: 같은 직군 새 Sponsor 즉시 찾기
**4단계**: 4단계: MARA 변호사 즉시 의뢰
**5단계**: 5단계: 60일 내 안 되면 학생비자/Visitor 변경

---

## 💡 직원이 학생한테 말할 멘트

> "회사 본사 이전 시 Sponsor Cessation Notification 60일 내 새 Sponsor 찾으셔야 합니다. 즉시 같은 직군 새 회사 찾으시고 MARA 변호사 의뢰하세요. 186 진행 중이면 새 Sponsor 가 다시 신청합니다. 189는 Sponsor 무관해서 영향 X입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **회사 이전 = 비자 즉시 취소**
   → 60일 유예

2. **Bridging Visa 직접 신청**
   → 자동

3. **186 자동 승계**
   → 새 Sponsor 재신청

4. **189 Sponsor 필요**
   → Independent / 무관

5. **60일 후 다른 비자 X**
   → 학생/Visitor 변경 가능

6. **8607 위반 처벌**
   → 비자 취소 위험

7. **Sponsor 변경 자유**
   → 이민부 승인 절차

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 회사 이전 일자 / 잔류 옵션
2. 현재 비자 만료일
3. 영주권 (186/189) 진행 단계
4. 같은 직군 회사 옵션

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('482 Cessation', 'immi.homeaffairs.gov.au')
- ('MARA 등록', 'mara.gov.au')
- ('Bridging Visa', 'immi.homeaffairs.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 일반 원칙 안내

**MARA / 변호사 영역**
- 482 Cessation = MARA 변호사 즉시 의뢰

---

## ✅ 완벽 응대 체크리스트

- [ ] 60일 룰 강조함
- [ ] 새 Sponsor 즉시 찾기 안내함
- [ ] MARA 변호사 강조함
- [ ] 186 vs 189 영향 차이 안내함
- [ ] Bridging Visa A 자동 안내함
- [ ] 8607 조건 안내함
