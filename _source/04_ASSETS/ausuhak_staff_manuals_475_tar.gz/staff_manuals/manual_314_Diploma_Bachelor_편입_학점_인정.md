# #314 Diploma_Bachelor_편입_학점_인정

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주에서 Diploma 끝나고 Bachelor 가려고 하는데 학점 얼마나 인정되나요?"

**직원 멘붕 포인트:**
- Diploma 학점 인정 = 학교마다 + 학과마다 다름
- Pathway College (대학 부속) = 자동 1년 인정 다수
- TAFE Diploma → 일반 대학 = 6개월~1년 인정 일반
- 사립 Diploma → 대학 = 인정 적음 (학교마다)
- 직원이 일반화 시 학생 잘못된 기대

---

## ❌ 절대 하지 말아야 할 답

> "Diploma 끝나면 Bachelor 1년 자동 인정돼요."

→ ❌ 자동 1년 인정 = Pathway College (대학 부속) 케이스만. TAFE/사립 Diploma → 다른 대학 = 학교 평가 별도. 같은 학과 (회계 → 회계) = 6개월~1년 인정 일반. 다른 학과 (요리 → 회계) = 인정 거의 X.

---

## ✅ 정답

**Diploma → Bachelor 학점 인정 패턴**

**1. Pathway College (대학 부속) → 부속 대학:**
- 예: USyd Foundation → University of Sydney
- 예: UNSW Diploma (UNSW College) → UNSW
- 예: UTS Insearch → UTS
- 예: Monash College → Monash
- **자동 1년 인정** (Bachelor 2학년 입학)
- Diploma 평균 70%+ 시 인정

**2. TAFE Diploma → 일반 대학:**
- TAFE NSW Diploma → UTS / UNSW / Western Sydney 등
- 같은 학과 (예: 간호 → Bachelor of Nursing) = 1년 인정 (UTS)
- 다른 학과 (예: 요리 → Business) = 6개월 또는 인정 없음
- 학교 + 학과 평가 별도

**3. 사립 RTO Diploma → 대학:**
- 사립 → 공립대 = 인정 적음 (보통 6개월 이하)
- 사립 → 사립대 (Torrens 등) = 인정 큼
- 학교 평가 + Articulation Agreement 확인

**4. Diploma → Master (편입 X, 직접 X):**
- Master = Bachelor 학위 필수
- Diploma → Bachelor → Master 단계 필수
- 단, Graduate Certificate / Graduate Diploma → Master 가능

**Articulation Agreement (학점 인정 협정):**
- 학교 간 공식 협정
- 자동 인정 (서류만)
- 협정 학교 사이트 확인

**RPL (Recognition of Prior Learning):**
- 사전 학습 인정
- 한국 대학 학점 + 호주 Diploma = RPL 평가
- 학교마다 인정 다름

**예시 (간호):**
- TAFE NSW Diploma of Nursing → UTS Bachelor of Nursing
- 1년 학점 자동 인정 (Articulation Agreement)
- TAFE 18개월 + UTS 2년 = RN 자격 + 4-5년에 PR 가능

**예시 (회계):**
- TAFE Diploma of Accounting → Macquarie University
- 협정 따라 다름 (보통 6개월~1년 인정)
- 직접 학교 학과 사무실 문의

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Pathway College**
대학 부속 Diploma 학교. UTS Insearch, UNSW College, Monash College 등. 자동 1년 인정.

**2. Articulation Agreement**
학교 간 학점 인정 공식 협정. 자동 인정. 학교 사이트 확인.

**3. RPL (Recognition of Prior Learning)**
이전 학습 + 경력 인정. 한국 대학 학점 평가 가능.

**4. AQF Pathway**
Diploma (5) → Bachelor (7) → Master (9) → PhD (10). 단계별 진학.

**5. Credit Transfer 신청**
학교 학과 사무실 + 성적증명서 + 학과 시라버스 제출.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **현재 Diploma 상태 + 학과 확인** - 학교 + 코스 + 평균 학점
**2단계**: **대학 + 학과 결정** - 대학 사이트 Credit Transfer 정책 확인
**3단계**: **Articulation Agreement 검색** - 학교 간 공식 협정 있는지
**4단계**: **Credit Transfer 신청** - 입학 신청 시 또는 입학 후 학과 사무실
**5단계**: **비자 영향 검토** - 새 학교 = 새 CoE / 6개월 이내 변경 = Release Letter

---

## 💡 직원이 학생한테 말할 멘트

> "Diploma → Bachelor 편입은 1) Pathway College (대학 부속) → 부속 대학 = 자동 1년 인정 / 2) TAFE → 일반 대학 = 같은 학과 1년, 다른 학과 6개월 일반 / 3) 사립 RTO → 공립대 = 인정 적음 패턴입니다. 학교 + 학과별 매우 다르고, Articulation Agreement (공식 협정)이 있으면 자동 인정됩니다. 본인 Diploma 학교 + 진학 희망 대학 직접 확인이 필수입니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Diploma = 무조건 Bachelor 1년 인정**
   → Pathway College만 자동. 그 외 = 학교 평가 별도.

2. **같은 학과 = 100% 인정**
   → 같은 학과여도 학교 평가. 보통 1년 인정 한도.

3. **Diploma → Master 직접 가능**
   → Master = Bachelor 학위 필수. Diploma → Bachelor → Master.

4. **사립 RTO Diploma = 공립대 인정 X**
   → 일부 협정 있음. 학교별 다름. 직접 확인.

5. **Credit Transfer = 자동**
   → 신청 + 서류 (성적/시라버스) 제출. 자동 X.

6. **Pathway College = 사립**
   → Pathway College = 대학 부속 (UTS Insearch 등). 사립 단어 혼동 X.

7. **학점 인정 = 비자 자동 단축**
   → 학점 인정 = 학습 기간 단축. 비자는 학교 새 CoE 따라.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 Diploma 학교 (TAFE/Pathway College/사립 RTO)
2. 학과 + 평균 학점
3. 진학 희망 대학 + 학과
4. 현재 학생비자 기간

---

## 🔍 직원이 직접 확인 가능한 사이트

- UTS Credit Transfer: www.uts.edu.au
- USyd Pathway: www.sydney.edu.au
- UNSW College: www.unswcollege.edu.au
- Monash College: www.monashcollege.edu.au
- AQF Levels: www.aqf.edu.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Diploma → Bachelor 진학 일반 안내
- Pathway College vs TAFE 일반 정보
- 윌슨 950명 동문 편입 사례

**MARA / 변호사 영역**
- 복잡한 학점 인정 분쟁 = 학교 + 변호사
- 비자 변경 (Diploma → Bachelor) = MARA
- RPL 거절 항소 = 학교 + 변호사
- 한국 학점 인정 = 학교 + RPL

---

## ✅ 완벽 응대 체크리스트

- [ ] Pathway College vs TAFE vs 사립 RTO 차이 설명함
- [ ] 같은 학과 vs 다른 학과 인정 차이 설명함
- [ ] Articulation Agreement 직접 확인 안내함
- [ ] RPL (사전 학습 인정) 안내함
- [ ] Credit Transfer 신청 절차 설명함
- [ ] 비자 변경 영향 (새 CoE) 안내함
- [ ] 윌슨 1:1 상담 + 학교 사무실 확인 권장함
