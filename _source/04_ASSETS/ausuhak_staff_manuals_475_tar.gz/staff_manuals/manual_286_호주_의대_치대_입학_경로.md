# #286 호주_의대_치대_입학_경로

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 한국에서 자연계 고3이에요. 호주 의대 가고 싶은데 어떻게 가나요? 시드니대 의대?"

**직원 멘붕 포인트:**
- Undergraduate 의대 (학사) vs Graduate 의대 (석사) 구분
- UCAT/GAMSAT 시험 한국에서 응시 가능 여부
- 의대 비자 = Bonded Place (지방 의무 근무)
- 한국 의사 면허 호주 인정 절차
- 비용 $80,000~$100,000/년 + 5~6년 = $500,000+

---

## ❌ 절대 하지 말아야 할 답

> "한국 자연계면 누구나 호주 의대 갈 수 있음"

→ ❌ UCAT/GAMSAT + 면접 + 학점 = 경쟁률 매우 높음. 단정 X.

---

## ✅ 정답

"호주 의대는 Undergraduate (학사 6년) 또는 Graduate (학사+석사 7년) 경로가 있고, UCAT (학사) 또는 GAMSAT (석사) 시험 + 면접 + 학점이 필요합니다. 비용 $80,000~$100,000/년 + 한국 의사 면허 별도 절차입니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Undergraduate vs Graduate 의대**
Undergraduate (Bachelor of Medicine) = 고졸 직접 입학 6년. UNSW/Adelaide/UWA/JCU/Monash 등. UCAT 응시. Graduate (Doctor of Medicine) = 학사 졸업 후 석사 4년. Sydney/Melbourne/Queensland/ANU 등. GAMSAT 응시. 둘 다 의사 면허 동일.

**2. UCAT/GAMSAT 시험**
UCAT (UK Clinical Aptitude Test) = Undergraduate 의대용. 한국에서 Pearson VUE 응시 ($350). 5개 섹션. 6월 응시. GAMSAT (Graduate Medical School Admissions Test) = Graduate 의대용. 한국 응시 X (호주/싱가포르/영국). 3월/9월. $585. 합격선 매우 높음.

**3. 의대 입학 조건**
UCAT 90 percentile + ATAR 99+ (Undergraduate). 또는 GAMSAT 60+ + GPA 6.5/7.0 (Graduate). 면접 (MMI = Multiple Mini Interview) 통과. 영어 IELTS 7.0 (각 영역 7.0). 국제학생 쿼터 = 5~10% (호주 학생 우선).

**4. Bonded Place (지방 의무 근무)**
호주 정부 지원금 받는 의대생 = 졸업 후 지방 근무 의무 (1~5년). 국제학생 = Bonded Place 신청 가능 (학비 일부 감면). 한국 학생 의대 합격은 매우 드뭄 (국제학생 쿼터 5~10%, 본인 영어/시험/면접/학점 조건 모두 매우 까다로움). 현실적 어려움.

**5. 호주 의사 면허**
AMC (Australian Medical Council) 인증. 호주 의대 졸업 = AMC 자동 인증. 한국 의대 졸업자 = AMC Examination 응시 (1차 MCQ + 2차 Clinical) + 영어 IELTS 7.0 + Internship 1년. 한국 면허 직접 인정 X.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 호주 의대 진학 결심 = 한국 자연계 + 영어 우수 + 시험/면접 준비 가능 시 도전
**2단계**: UCAT (Undergraduate) 또는 GAMSAT (Graduate) 응시 준비 (1~2년)
**3단계**: ATAR 99+ 또는 GPA 6.5+ + IELTS 7.0 동시 확보
**4단계**: MMI 면접 준비 + 의대 지원 (UAC NSW/VTAC VIC)
**5단계**: 합격 시 학비 + Bonded Place 결정 + 비자 신청

---

## 💡 직원이 학생한테 말할 멘트

> "학생, 호주 의대는 한국 학생에게 매우 어려운 경로입니다. UCAT (학사 의대) 또는 GAMSAT (석사 의대) 시험 + ATAR 99+ + IELTS 7.0 + MMI 면접 + 비용 5~6년 $500,000 정도 들어요. 국제학생 쿼터가 5~10%로 매우 좁아서 한국 학생 합격은 드문 편입니다. 대안 경로로 약대/치대 또는 한국 의대 졸업 후 호주 AMC 인증 경로도 검토하실 수 있어요. 학생 ATAR/내신/영어/예산 상황 알려주시면 객관적 비교 안내해 드립니다. 카톡 ID studywilson 으로 연락 부탁드려요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"한국 자연계 = 호주 의대 OK"**
   → ATAR 99+ + UCAT 90 percentile 필요. 한국 학생 합격률 매우 낮음.

2. **"한국 의대 졸업하면 호주 면허"**
   → AMC Examination + Internship 1년 추가.

3. **"학비 일부만 내면 됨"**
   → $80,000~$100,000/년 자비. 장학금 거의 X (국제학생).

4. **"Sydney 의대 = 학사"**
   → Sydney = Graduate (석사). UNSW = Undergraduate (학사).

5. **"GAMSAT 한국 응시"**
   → 한국 X. 호주/싱가포르 출장.

6. **"의대 졸업하면 즉시 PR"**
   → Bonded Place 의무 근무 + RMO 1년 후 PR 신청.

7. **"의사 부족이라 쉬움"**
   → 지방 의사 부족이지 도시는 매우 경쟁.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 고등학교 학년 + 내신 (ATAR 환산)
2. 영어 IELTS 점수 (7.0 필요)
3. 예산 ($500,000+ 5년)
4. 지방 근무 의향 (Bonded Place)

---

## 🔍 직원이 직접 확인 가능한 사이트

- UCAT 시험: https://www.ucat.edu.au
- GAMSAT: https://gamsat.acer.org
- UAC NSW (의대 지원): https://www.uac.edu.au
- AMC: https://www.amc.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 일반 정보 안내, 대안 경로 안내
- UCAT/GAMSAT 학원 안내
- 약대/치대 대안 경로 안내
- 한국 의대 졸업 후 AMC 경로 안내
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- AMC = 한국 의사 면허 인증 평가
- AHPRA = 의사 면허 등록
- MARA Lawyer = 의대 졸업 후 PR 비자
- 각 의대 = 입학 평가 (UCAT/GAMSAT)
- Bonded Place = 호주 정부 (Department of Health)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 학년/내신 확인했다
- [ ] 영어 점수 확인했다 (IELTS 7.0)
- [ ] 예산 확인했다 ($500,000+)
- [ ] Undergraduate vs Graduate 차이 안내했다
- [ ] UCAT vs GAMSAT 안내했다
- [ ] 한국 학생 합격률 낮음 정직하게 전달했다
- [ ] 대안 경로 (약대/치대) 제안했다
- [ ] 윌슨 직접 카카오 ID 안내했다
