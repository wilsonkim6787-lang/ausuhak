# #256 NAATI 통번역 PR 가산점

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 NAATI 통번역 자격증 따면 PR 가산점 있다고 들었어요. 한국어로 가능한가요?"

**직원 멘붕 포인트:**
- NAATI = National Accreditation for Translators and Interpreters
- PR Skilled 가산점 5점
- 한국어 = 가능 (Credentialed Community Language)
- CCL Test = 약 $800

---

## ❌ 절대 하지 말아야 할 답

> "NAATI 자격증 따면 PR 100% 보장됩니다."

→ ❌ **가산점 5점만 / PR 보장 X**. EOI 점수 상승 효과.

---

## ✅ 정답

NAATI CCL: ① **Credentialed Community Language Test** ② **PR Skilled Visa 5점 가산** ③ **한국어 OK** (호주 영어 ↔ 한국어) ④ **응시료 약 $800** ⑤ **유효 = 영구** (재시험 없음 / 합격 시) ⑥ **언어 + 직업 무관** (간호사 / 회계사 모두 가능) ⑦ **시험 = 5개 대화 통역 + 30점 만점**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. NAATI 정의**
National Accreditation Authority for Translators and Interpreters / 호주 정부 인증 기관 / 통번역 자격증

**2. CCL 시험 구조**
Credentialed Community Language Test / 약 30분 / 5개 대화 (영어 ↔ 한국어 양방향) / 30점 만점 / 합격선 29점 (Communication 80%)

**3. PR 가산점**
Skilled Visa 189 / 190 / 491 / EOI Points Test / Credentialed Community Language = 5점 / 영주권 점수 합산

**4. 응시 자격**
특별 자격 없음 / 영어 + 한국어 일정 수준 / 학력 무관 / 호주/한국 어디서나 응시 가능

**5. 응시료 + 일정**
약 $800 AUD (2025 기준) / 연 6~8회 / 시드니/멜번/브리즈번/온라인 가능 / 결과 약 8~10주

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: NAATI 공식 사이트 등록 (naati.com.au)
**2단계**: CCL 응시료 납부 + 시험 일정 선택
**3단계**: 한국어-영어 양방향 통역 연습 (의료 / 비즈니스 / 일상)
**4단계**: 시험 응시 (온라인 또는 오프라인)
**5단계**: 결과 8~10주 → 합격증 → EOI 점수 추가

---

## 💡 직원이 학생한테 말할 멘트

> "NAATI CCL은 한국어 통역 시험인데 PR Skilled Visa에서 5점 가산점을 줘요. 응시료 약 $800이고 한국어로 응시 가능합니다. 합격하면 영구 유효이고, 학력/직업 무관해서 누구나 응시 가능해요. 다만 PR 보장은 아니고 EOI 점수 5점 추가 효과만 있어요. PR 본 신청은 직업 + 영어 + 학력 + 경력 따로 봐야 합니다. 윌슨님이 1:1로 PR 전체 점수 계산 + NAATI 시점 전략 드려요. 카카오 (studywilson)으로 직업 + 현 영어 + PR 계획 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **NAATI = PR 보장 ❌**
   → 5점 가산점만 / PR = 종합 점수 + 직업

2. **NAATI = 한국 응시 불가 ❌**
   → 한국 응시 가능 / 온라인 응시 가능

3. **NAATI = 영어 시험 ❌**
   → 한국어 ↔ 영어 양방향 통역

4. **NAATI = 학력 필요 ❌**
   → 학력 무관 / 누구나 응시

5. **NAATI = 1년 유효 ❌**
   → 영구 유효 (합격 시)

6. **NAATI = 통역사만 ❌**
   → PR 가산점 = 모든 직업 적용

7. **CCL 합격선 = 50% ❌**
   → 약 80% (Communication 영역)

---

## 📞 카카오 응대 시 필수 4가지 확인

1. NAATI 응시 일정 + 응시료 가능 여부
2. 한국어-영어 통역 연습 수준
3. PR 본 신청 직업 + 영어 점수
4. EOI 본 신청 시점

---

## 🔍 직원이 직접 확인 가능한 사이트

- NAATI 공식: https://www.naati.com.au
- DHA Skilled Visa Points: https://immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- PR 종합 점수 1:1 계산
- NAATI + 영어 + 직업 시점 전략
- EOI 신청 + Invitation 분석

**MARA / 변호사 영역**
- NAATI 거절 + 재응시
- PR 신청 거절 + ART 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] NAATI CCL = PR 가산점 5점 명확
- [ ] 한국어 응시 가능 안내
- [ ] 응시료 약 $800 + 영구 유효
- [ ] PR 보장 아님 강조
- [ ] 직업 무관 = 모든 PR 신청자 OK
- [ ] EOI 점수 종합 = 윌슨 영역
- [ ] 윌슨 카카오 자연 유도
