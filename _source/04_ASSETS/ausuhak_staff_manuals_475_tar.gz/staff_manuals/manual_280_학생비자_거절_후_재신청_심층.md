# #280 학생비자_거절_후_재신청_심층

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 학생비자 거절됐어요. GS (Genuine Student) 부족이래요. 한국 가서 다시 신청해야 하나요? 호주에서 재신청 되나요?"

**직원 멘붕 포인트:**
- 거절 사유별 재신청 전략 (GS/재정/PIC 4020) 직원 모름
- Bridging Visa 만료일 + 강제 출국 위험
- Section 48 Bar (호주 내 재신청 금지)
- ART 항소 vs Federal Court 항소 차이
- 한국 재신청 시 PIC 4020 평생 차단 위험

---

## ❌ 절대 하지 말아야 할 답

> ""호주에서 다시 신청하면 됨""

→ ❌ Section 48 Bar = 호주 내 거절 후 대부분 재신청 불가. MARA Lawyer 영역.

---

## ✅ 정답

"학생비자 거절 후 재신청은 거절 사유 + 현재 비자 상태에 따라 전략이 완전히 다릅니다. ART 항소 vs 한국 재신청 vs Section 48 Bar 회피 등 MARA Lawyer 즉시 상담 필수입니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 거절 사유 종류**
GS 부족 (가장 흔함) = Statement of Purpose 부실. 재정 증명 부족 = $29,710/년 미달. PIC 4020 (허위 서류) = 3년~10년 차단. 영어 점수 미달 = ELICOS 추가 필요. 보험 (OSHC) 미가입. 건강검진 (HAP) 거절.

**2. Section 48 Bar**
Migration Act Section 48 = 호주 내 비자 거절 또는 취소 후 동일/다른 비자 재신청 금지. 예외 = Partner/Protection/Student (특정 조건). 학생비자 거절 후 호주 내 재신청 = 거의 불가능. 한국 출국 후 재신청 필수.

**3. ART 항소 (Tribunal)**
거절 통지 받은 날로부터 21일 내 신청. 비용 $3,374 (2025 기준). 처리 기간 12~18개월. 항소 중 = Bridging Visa 자동 (학습/일 가능). 승소율 = 평균 30%. MARA Lawyer 비용 $5,000~$15,000.

**4. PIC 4020 (허위 서류)**
비자 신청 시 거짓 정보 또는 위조 서류 제공 = 3년 차단 (Public Interest Criterion 4020). 신원 사칭 = 10년. PR 신청 시 평생 차단. Wilson은 절대 PIC 4020 케이스 안 받음 (MARA Lawyer만).

**5. 재신청 전략**
GS 부족 = 한국 출국 + Statement 보강 + 영어/재정 추가. Section 48 Bar 적용 = ART 항소 또는 한국 재신청. PIC 4020 = MARA Lawyer 항변 필수. 다른 비자 (Visitor/Working Holiday) = MARA Lawyer 평가.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 거절 통지서 (Refusal Letter) 사진 받기 + 거절 사유 정확히 확인
**2단계**: Bridging Visa 종료일 확인 (만료 후 불법 체류)
**3단계**: MARA Lawyer 즉시 상담 (21일 시한)
**4단계**: ART 항소 vs 한국 재신청 결정
**5단계**: 한국 재신청 시 GS 보강 + Wilson 신청 대행

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 비자 거절은 거절 사유 + 현재 Bridging Visa 만료일에 따라 전략이 완전히 달라요. 호주 내 재신청은 Section 48 Bar 때문에 거의 불가능해요. ART 항소 (21일 시한) vs 한국 출국 후 재신청 결정해야 하는데, MARA Lawyer 1차 상담 필수예요. 거절 통지서 사진 보내주시고, Bridging Visa 만료일 알려주세요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"호주 내 재신청 가능"**
   → Section 48 Bar 적용. MARA Lawyer 평가 없이 단정 X.

2. **"GS 거절 = 자기소개서만 다시 쓰면 됨"**
   → 거절 이유 분석 + 영어/재정/계획 종합 보강 필요.

3. **"ART 항소하면 무조건 이김"**
   → 승소율 30%. 항소 비용 + 변호사비 + 12~18개월 대기.

4. **"PIC 4020 무시하고 다시 신청"**
   → PIC 4020 = 3년 차단. 무시 X. MARA Lawyer 항변 필수.

5. **"한국 가서 다른 유학원으로 신청"**
   → 거절 기록 호주 시스템에 영구 남음. 동일 신청 = 자동 거절.

6. **"Working Holiday로 호주 다시 옴"**
   → WHV 신청 시 학생비자 거절 신고 의무. 신고 안 하면 PIC 4020.

7. **"Bridging Visa 만료해도 괜찮음"**
   → 만료 = 즉시 불법 체류. 28일 초과 = 3년 입국 금지 (PIC 4013).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 거절 통지서 받은 날짜 (21일 카운트)
2. 거절 사유 (GS/재정/PIC 4020/영어 등)
3. Bridging Visa 만료일
4. 이전 비자 거절 횟수

---

## 🔍 직원이 직접 확인 가능한 사이트

- ART (Administrative Review Tribunal (2024.10.14 AAT 대체)): https://www.art.gov.au
- Department of Home Affairs: https://immi.homeaffairs.gov.au
- MARA Lawyer 검색: https://www.mara.gov.au
- 한국 영사관 + 통역 지원

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 한국 재신청 대행 (GS 보강)
- ART 항소는 MARA Lawyer 영역
- Section 48 Bar 평가는 MARA Lawyer
- PIC 4020 항변은 MARA Lawyer 전담
- 거절 사유 분석 + 재신청 전략 Wilson 가능

**MARA / 변호사 영역**
- ART 항소 신청 (21일 시한)
- Section 48 Bar 회피 전략
- PIC 4020 항변
- Federal Court 항소 (ART 패소 시)
- Ministerial Intervention (마지막 수단)

---

## ✅ 완벽 응대 체크리스트

- [ ] 거절 통지서 사진 받았다
- [ ] 거절 사유 정확히 확인했다
- [ ] Bridging Visa 만료일 확인했다
- [ ] 21일 시한 (ART 항소) 안내했다
- [ ] MARA Lawyer 상담 안내했다
- [ ] Section 48 Bar 위험 안내했다
- [ ] 한국 재신청 시 Wilson 대행 가능 안내했다
- [ ] PIC 4013 (28일 불법 체류) 경고했다
