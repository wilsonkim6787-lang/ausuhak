# #326 호주_학생_도박_카지노_중독_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 호주 와서 카지노 자주 갔다가 돈을 다 잃었어요. 어떡하죠?"

**직원 멘붕 포인트:**
- 호주 = 1인당 도박 손실 세계 1위 ($1,500/년 평균)
- Crown Casino (Melbourne) / The Star (Sydney) = 한국 학생 자주 방문
- 도박 중독 = 정신건강 + 재정 위기
- Gambler's Help 1800 858 858 (24시간 무료)
- 직원이 정확한 자원 안내 + 학교 Counselling 연결

---

## ❌ 절대 하지 말아야 할 답

> "다 본인 책임이니까 이제 안 가면 돼요."

→ ❌ 도박 중독 = 정신건강 질환. '의지'로만 X. 전문 치료 + 재정 도움 + 자기 배제 (Self-Exclusion) 시스템 필요. 정확한 자원 안내 필수.

---

## ✅ 정답

**호주 도박 환경:**

**주요 카지노:**
- Crown Casino Melbourne
- Crown Sydney (Barangaroo)
- The Star Sydney
- The Star Brisbane
- SkyCity Adelaide

**도박 종류:**
- Pokies (Poker Machines) = 가장 중독성 (편의점/펍 어디서나)
- 카지노 게임 (블랙잭/바카라/룰렛)
- Sports Betting (Sportsbet, Bet365)
- Online Poker

**한국 학생 위험:**
- Crown/The Star = 한국어 통역 + 한국식 음식 = 친근
- 24시간 운영
- 무료 음식 + 술 = 머무름
- 한국 학생 우대 (VIP) = 함정

**도박 중독 신호:**

**경미:**
- 도박 시간/돈 통제 어려움
- 도박 전 흥분 + 도박 후 후회

**중간:**
- 학비/생활비 사용
- 친구/가족에게 거짓말
- 도박 시간 점점 증가

**심각:**
- 모든 자금 도박
- 일/학업 중단
- 자해/자살 의도
- 가족/친구 단절

**자원 (24시간 무료):**

**1. Gambler's Help / Gambling Help Online:**
- 1800 858 858 (24시간)
- 무료 + 한국어 통역 일부
- 온라인 채팅: gamblinghelponline.org.au
- 면담 + 재정 + 정신 통합

**2. Lifeline 13 11 14:**
- 자살/위기 시
- 24시간 무료

**3. 학교 Counselling:**
- 무료 (4~8회)
- 도박 중독 전문 일부

**4. Self-Exclusion (자기 배제):**

**Crown / The Star Self-Exclusion:**
- 본인 신청 → 카지노 출입 금지
- 6개월 / 1년 / 평생 선택
- 위반 시 벌금 + 이익 환수
- 무료 + 비밀 보장

**Pokies Self-Exclusion (BetStop):**
- BetStop (정부 운영)
- 모든 온라인 도박 사이트 차단
- 3개월~평생 선택
- 1300 467 778

**한국어 자원:**
- 한국 영사관 1577-1366 (응급)
- Embrace Multicultural Mental Health 1300 22 4636
- 호주 한인 교회 일부 (지역 별)

**재정 도움:**

**National Debt Helpline:**
- 1800 007 007 (무료)
- 재정 상담 + 채권 협상
- 도박 부채 일부 협상 가능

**파산 신청:**
- AFSA (Australian Financial Security Authority)
- 부채 $20K+ = 일부 자격
- 학생비자 영향 (Character Test)

**비자 영향:**

**도박 자체 = 비자 영향 X (합법):**
- 단, 도박 부채 = 학비 미납 = 학교 등록 취소 = 비자 영향
- 도박 자금 = 마약/매춘 등 불법 활동 자금 = Character Test

**가족 지원 + 한국 귀국:**
- 가족 알림 (학생 동의 시)
- LOA (휴학) → 한국 귀국 → 회복
- 정신건강 회복 후 호주 복귀 가능

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Pokies Poker Machines**
가장 중독성. 편의점/펍 어디서나. 60% 학생 도박 = Pokies 시작.

**2. Self-Exclusion Crown/Star**
본인 신청 카지노 출입 금지. 6개월~평생. 무료 + 비밀.

**3. BetStop (정부)**
온라인 도박 차단. 3개월~평생. 1300 467 778.

**4. Gambler's Help 1800 858 858**
24시간 무료. 한국어 통역 일부. 온라인 채팅 가능.

**5. National Debt Helpline 1800 007 007**
재정 상담 무료. 도박 부채 협상 가능.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **위기 평가** - 자해/자살 의도 = Lifeline 13 11 14
**2단계**: **Gambler's Help 연결** - 1800 858 858, 무료 + 한국어
**3단계**: **Self-Exclusion 신청** - Crown/The Star + BetStop
**4단계**: **학교 Counselling 예약** - 무료, 4~8회
**5단계**: **재정 상담 + LOA 고려** - National Debt Helpline / 한국 귀국 옵션

---

## 💡 직원이 학생한테 말할 멘트

> "도박 중독은 의지의 문제가 아닌 정신건강 질환이고, 호주는 도박 손실 세계 1위라 한국 학생들 위험 노출이 큽니다. Gambler's Help 1800 858 858이 24시간 무료 (한국어 통역 일부)이고, Crown/The Star Self-Exclusion 신청하면 카지노 출입 자동 금지됩니다. 학교 Counselling도 무료고, National Debt Helpline 1800 007 007이 부채 협상 도와줍니다. 자해 의도까지 있으면 Lifeline 13 11 14 즉시 부탁드립니다. 학생님 상황 들려주시면 자세히 안내하고 회복 경로 같이 찾을 수 있습니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **도박 = 의지 부족**
   → 도박 중독 = 정신건강 질환. 전문 치료 필요. 의지만 X.

2. **Self-Exclusion = 영구 기록**
   → 비밀 보장. 학교/가족/비자 정보 X. 본인만.

3. **Gambler's Help = 영어만**
   → 한국어 통역 가능 (요청). 온라인 채팅 영어.

4. **도박 부채 = 학생비자 자동 영향**
   → 도박 자체 X. 단, 학비 미납 = 학교 등록 취소 = 비자.

5. **Crown 무료 음식 = 안전**
   → VIP 우대 = 함정. 머무름 + 더 도박 → 손실 증가.

6. **파산 = 비자 자동 취소**
   → 파산 자체 X. 단, Character Test 영향 + Visa 갱신 어려움.

7. **한국 가족 알림 의무**
   → 본인 동의 필요 (만 18세+). 자살 위험 = Duty of Care = 알림 가능.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 위기 평가 (자해/자살 위험)
2. 도박 종류 + 손실 규모
3. Self-Exclusion 의지
4. 한국 가족 알림 + LOA 의지

---

## 🔍 직원이 직접 확인 가능한 사이트

- Gambler's Help: www.gamblinghelponline.org.au (1800 858 858)
- BetStop (정부): www.betstop.gov.au (1300 467 778)
- Crown Self-Exclusion: www.crownresorts.com.au
- National Debt Helpline: www.ndh.org.au (1800 007 007)
- Lifeline: www.lifeline.org.au (13 11 14)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 도박 중독 자원 일반 안내
- Gambler's Help / Self-Exclusion 안내
- 학교 Counselling + LOA 옵션

**MARA / 변호사 영역**
- 도박 부채 + 비자 = MARA
- 파산 신청 = 회계사 + 변호사
- Character Test 영향 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] 위기 평가 + Lifeline 즉시 (위험 시)
- [ ] Gambler's Help 1800 858 858 안내
- [ ] Self-Exclusion (카지노 + 온라인) 안내
- [ ] 학교 Counselling 무료 강조
- [ ] 재정 도움 + LOA 옵션
- [ ] 정서적 공감 + 실용 정보
