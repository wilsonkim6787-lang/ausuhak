# #405 호주_학생_학회_발표_Academic_Conference_여행_Funding_논문

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 박사인데 호주에서 미국 학회 발표하러 가요. 학생비자로 미국 출국·재입국 가능해요? 학교 Funding은 어떻게 신청해요? 논문 발표 영어 부담돼요. 학회 후 호주 재입국 시 비자 문제없어요?"

**직원 멘붕 포인트:**
- BVB(Bridging Visa B) 여부 모름
- 학회 Funding = 학교 vs 정부 모름
- ATO 학회 비용 세금공제 모름
- 재입국 시 검역 + 비자 검토 모름
- 논문 발표 영어 지원 못 함

---

## ❌ 절대 하지 말아야 할 답

> "박사는 학회 출장 무제한이고 비자 영향 없어요!"

→ ❌ 학회 출국 = 출국 후 30일 이상 시 BVB 권장. 학교 LOA 통보. 재입국 시 면접 가능.

---

## ✅ 정답

**호주 박사 학회 출장 가이드 (2026.05 기준)**:

1. **출국 + 재입국**:
   - Subclass 500 = 다중 입출국 가능
   - 단, 학기 중 30일 이상 출국 = LOA 통보 권장
   - 재입국 시 = 면접 가능 (특히 학기 결석)
2. **학회 Funding**:
   - 학교 Postgraduate Travel Grant: $500~$3,000
   - 학과 funding (지도교수 grant)
   - 호주 정부: ARC Grant (research fund 일부)
   - 외부: ~~Endeavour Scholarship~~ (2019년 종료) / Research Training Program (RTP)
3. **ATO 세금공제**:
   - PhD 논문 발표 = 자기 교육 비용 (Self-Education) 공제 가능
   - 항공료 + 등록비 + 호텔 비용 공제 (학업 직접 관련)
4. **재입국 검역**:
   - 음식·식물 = 신고 의무
   - Visa 검토 = 학기 진행 증빙 (CoE + 학생 ID)
5. **영어 발표 지원**:
   - 학교 Postgraduate Writing Centre
   - PhD Workshop = 발표 연습
   - 지도교수 1:1 코칭

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. BVB(Bridging Visa B) vs Subclass 500**
Subclass 500 = 다중 입출국 가능. BVB 별도 X. 단, BVA(임시) 보유 시 BVB 신청. 학회 출국 = Subclass 500 그대로 + 학교 통보 권장. 재입국 시 = ETA 불필요 (학생비자 보유).

**2. 학교 Travel Grant 신청**
Postgraduate Travel Grant: 대학별 다름. USyd $1,500, UNSW $2,000, Monash $2,500. 신청 = 6주 전 + 발표 채택서 + 예산서. 학과 funding = 지도교수 결정. 외부 grant 병행 가능.

**3. ATO Self-Education 세금공제**
ATO 자기 교육 비용 공제: PhD 학회 = 학업 직접 관련 → 공제 가능. 항공료, 등록비, 호텔, 식비 (영수증 필수). 첫 $250 본인 부담 후 공제. 학기 중 출국 = 학생비자 유지 증빙.

**4. 재입국 검역 + 비자 검토**
Smartraveller + DAFF (검역) = 음식/식물 신고. Border Force 학생 비자 = CoE + 학생 ID 즉시 제출 가능 준비. 학기 결석 30일 이상 = 면접 가능. 학교 LOA 통보 권장.

**5. 영어 발표 지원**
Postgraduate Writing Centre = 모든 대학 무료. PhD Workshop = 발표 연습 + 피드백. Toastmasters Club = 비공식 발표 연습. NAATI 통역 = 학회 발표 X (직접 발표).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 학회 채택 후 = 학교 LOA 통보 (30일 이상 결석 시).
**2단계**: 2단계: Travel Grant 신청 = 6주 전, 발표 채택서 + 예산.
**3단계**: 3단계: 항공권 + 호텔 예약 (영수증 보관 = ATO 공제).
**4단계**: 4단계: 출국 = Smartraveller 등록 + 한국 영사관 정보.
**5단계**: 5단계: 재입국 = CoE + 학생 ID + 학회 증명서 휴대.

---

## 💡 직원이 학생한테 말할 멘트

> "박사 학생비자로 학회 출국·재입국 가능하시고요. 30일 이상 학기 결석 시 학교 LOA 통보 권장드려요. 학교 Postgraduate Travel Grant ($500~$3,000) 신청하시고 ATO 자기 교육 비용 공제도 가능해요. 영어 발표 지원은 학교 Postgraduate Writing Centre에서 무료로 받으실 수 있어요. 재입국 시 CoE + 학회 증명서 휴대하시면 자세한 행정 안내는 윌슨님 카톡 상담주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생비자 = 학회 출국 무제한이라고 단정**
   → 학기 중 30일 이상 결석 = LOA 통보 권장. CoE 영향 가능.

2. **Travel Grant = 자동 받는다고 안내**
   → 신청 + 심사. 6주 전 + 채택서 + 예산. 경쟁적.

3. **ATO 공제 = 모든 비용이라고 안내**
   → 학업 직접 관련만. 첫 $250 본인 부담. 영수증 필수.

4. **재입국 = 즉시 통과라고 안내**
   → 학기 결석 시 면접 가능. CoE + 학생 ID 휴대.

5. **BVB = PhD도 자동이라고 오해**
   → Subclass 500 = BVB 불필요. BVA만 BVB 신청.

6. **ARC Grant = 학생도 신청이라고 안내**
   → ARC = 연구원/지도교수. 학생은 지도교수 grant 일부 사용.

7. **Toastmasters = 학교 행사라고 단정**
   → 외부 동아리. 가입비 약 $80/6개월. 발표 연습 효과적.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 학회 일정 + 결석 기간 (30일 이상)
2. Travel Grant 신청 가능성
3. Self-Education 공제 자격
4. 지도교수 동의 + 학과 행정

---

## 🔍 직원이 직접 확인 가능한 사이트

- homeaffairs.gov.au/visa-500 - 학생비자 출국
- ato.gov.au/individuals/income-deductions/work-related-expenses/self-education-expenses
- smartraveller.gov.au - 출국 등록
- 각 대학 Postgraduate Travel Grant
- 각 대학 Postgraduate Writing Centre

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- (이 경우 윌슨 영역 거의 없음)
- 학교 Travel Grant 안내

**MARA / 변호사 영역**
- 재입국 면접 시 변호사 = 거절 위험 시
- (일반적으로 변호사 불필요)

---

## ✅ 완벽 응대 체크리스트

- [ ] Subclass 500 다중 입출국 안내
- [ ] 30일 이상 LOA 통보 권장
- [ ] Travel Grant 6주 전 신청
- [ ] ATO Self-Education 공제 안내
- [ ] Smartraveller 등록 권장
- [ ] 재입국 CoE + 학생 ID 휴대
- [ ] 영어 발표 지원 안내 (Writing Centre)
