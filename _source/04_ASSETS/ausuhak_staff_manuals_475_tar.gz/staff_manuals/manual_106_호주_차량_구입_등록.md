# 📚 직원 응대 매뉴얼 #106

**케이스: 30세 / 브리즈번 Master 2학년 / "차 사려고 하는데 학생도 살 수 있나요? 한국 면허 가능해요? 보험은요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 브리즈번에서 학교 다니는데 대중교통 너무 불편해서 차 사려고요. 학생인데 살 수 있나요? 한국 면허로 운전 가능해요? 등록은 어떻게 해요? 보험 꼭 들어야 해요?

**👉 직원이 멘붕하는 순간**
- "학생 차 살 수 있나?"
- "한국 면허로 가능?"
- "Rego가 뭐야?"
- "Greenslip / CTP / Comprehensive 차이?"
- "중고 vs 신차?"

**❌ 절대 하지 말아야 할 답**
- "한국 면허로 평생 가능" → **거짓**
- "보험 안 들어도 돼" → **거짓. CTP 의무**
- "그냥 사면 돼" → **거짓. 등록 필수**

**✅ 직원이 알아야 할 정답**
호주 자동차 = **소유 = 가능 / 등록 + 보험 의무**:

1. **학생 = 차 소유 가능** (제한 없음)
2. **한국 면허 = 일정 기간만** (주별 다름)
3. **Rego (Registration)** = 차 등록 의무
4. **CTP (Compulsory Third Party)** = 의무 보험
5. **Comprehensive** = 종합보험 (선택)
6. **중고차 = REVS Check** (저당/도난 확인)
7. **Roadworthy Certificate** = 일부 주 매매 필수

직원 = **시스템 안내**. 윌슨 = **차량 매매 전문가 X**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 학생 차량 구입 가능 여부

**답**: 호주 = **누구나 차 구매 가능**. 학생도 OK.

**구매 조건**:
- 호주 거주 (학생비자 OK)
- 호주 운전면허 또는 한국 면허 (운전 시)
- 보험 가입
- 등록 (Rego)
- 자금 (현금 또는 대출)

**대출**:
- 학생 = 대출 어려움
- PR 또는 시민권자 = 가능
- 대안: 한국 자금 송금 → 현금 구매

**구매 방법**:

**중고차 (Used Car)**:
- 딜러 (Dealer) - 안전 / 비쌈
- 개인 매매 (Private Sale) - 저렴 / 위험
- Carsales.com.au, Gumtree, Facebook Marketplace

**신차 (New Car)**:
- 딜러십 직접
- 학생 = 구매 가능 / 대출 어려움

**학생 추천**:
- 5,000~10,000 AUD 중고차
- Toyota Corolla, Honda Civic, Mazda 3
- 한인 커뮤니티에서 구매 (검증됨)
- 검증 안 된 개인 매매 = 위험

**출처**: carsales.com.au, fairtrading.nsw.gov.au

---

### 2️⃣ 한국 면허 운전 (주별 정책)

**답**: 한국 면허로 호주 운전 = **주별 + 비자 종류 따라 다름**.

**NSW**:
- 학생비자 = 한국 면허 + 영문 번역 무제한 (학생비자 동안)
- 임시 거주 = 3개월 후 NSW 면허 전환
- PR = 3개월 이내 NSW 면허 전환

**VIC**:
- 학생비자 = 한국 면허 + 영문 번역 (학생비자 동안)
- 임시 거주 = 6개월 후 VIC 면허 권장
- PR = 6개월 이내 VIC 면허 전환

**QLD (브리즈번)**:
- 학생비자 = 한국 면허 + 영문 번역 무제한 (학생비자 동안)
- 임시 거주 = 3개월 후 QLD 면허
- PR = 1년 이내 QLD 면허

**WA (퍼스)**:
- 학생비자 = 한국 면허 + 영문 번역 (학생비자 동안)
- 3개월 후 WA 면허 권장

**SA (애들레이드)**:
- 학생비자 = 한국 면허 + 영문 번역
- 90일 후 SA 면허

**TAS (호바트)**:
- 학생비자 = 한국 면허 + 영문 번역
- 3개월 후 TAS 면허

**영문 번역**:
- 한국 영사관 발급 (시드니 02 9210 0200, 멜번 03 9533 3800)
- 또는 NAATI 인증 번역 (호주 내)
- IDP (International Driving Permit) = 한국에서 발급, 1년 유효

**출처**: service.nsw.gov.au, vicroads.vic.gov.au, qld.gov.au

---

### 3️⃣ Rego (Registration) = 차 등록

**답**: 호주 자동차 = **등록 의무**. 미등록 = 운전 불법.

**Rego 구성 (NSW 예시)**:
- Vehicle Registration Fee
- Motor Vehicle Tax (가격 따라)
- CTP Insurance (의무)
- Plate Fee

**비용 (NSW)**:
- 소형차 (1.5L 이하): 연 $400~600
- 중형차 (2.0L): 연 $600~800
- 대형차 (3.0L+): 연 $800~1,200
- + CTP: $400~700

**Rego 갱신**:
- 매년 또는 6개월
- 우편/이메일 알림
- 온라인 갱신 (Service NSW 등)
- 갱신 전 = Pink Slip (차량 검사) 필요 (5년 이상 차)

**Pink Slip (차량 검사)**:
- 5년 이상 = 매년 검사
- 비용: $40~60
- 정비소 (Mechanic)에서

**번호판**:
- 일반 번호판: 무료 (Rego 포함)
- 개인 번호판 (Personalised): $300~5,000
- 변경 가능

**출처**: service.nsw.gov.au, vicroads.vic.gov.au

---

### 4️⃣ 자동차 보험 (CTP / Third Party / Comprehensive)

**답**: 호주 자동차 보험 = **3종류**. CTP만 의무.

**1. CTP (Compulsory Third Party) = 의무**:
- Rego와 함께 자동 가입 (NSW)
- 다른 사람 부상/사망 보상
- 본인 차/물건 X
- 가격: $400~700/년

**주별 차이**:
- NSW: Greenslip (CTP) 별도 가입
- VIC: TAC (Transport Accident Commission) Rego에 포함
- QLD: CTP Rego에 포함

**2. Third Party Property = 선택**:
- 다른 사람 차/물건 보상
- 본인 차 X
- 가격: 연 $300~500
- 학생 = 추천

**3. Third Party Fire & Theft = 선택**:
- Third Party + 화재/도난
- 본인 사고 X
- 가격: 연 $400~700

**4. Comprehensive = 종합**:
- 모든 사고 보상
- 본인 + 상대 + 도난 + 화재
- 가격: 연 $700~2,000
- 신차/비싼 차 = 필수

**보험 회사**:
- AAMI
- NRMA
- RACV (VIC)
- Allianz
- Budget Direct
- Youi
- Bingle (저렴)

**보험료 영향**:
- 나이 (25세 이하 비쌈)
- 운전 경력
- No Claim Bonus
- 차종
- 거주 지역

**출처**: aami.com.au, nrma.com.au, budgetdirect.com.au

---

### 5️⃣ 중고차 구매 시 확인 사항

**답**: 중고차 = **사기/문제 많음**. 검증 필수.

**REVS Check (PPSR)**:
- 저당, 도난, 사고 이력 확인
- ppsr.gov.au에서 $2 결제
- 차량 VIN 번호 입력
- **반드시 구매 전 확인**

**Roadworthy Certificate (RWC)**:
- VIC, QLD = 매매 시 의무
- NSW = Pink Slip
- 정비소 검사
- 안전 기준 충족 확인

**중고차 검사 (Pre-Purchase Inspection)**:
- $200~300
- RACV/NRMA/RAA 등 자동차 클럽
- 또는 일반 정비소
- 추천: 고가 차 + 개인 매매 시 필수

**Cooling-off 없음**:
- 중고차 = 환불/취소 불가
- 딜러도 동일
- 신중히 결정

**서류**:
- Transfer of Registration (양도)
- 매매 영수증
- VIN 확인
- Odometer (주행거리) 확인
- 정비 기록

**가격**:
- Toyota Corolla 5년: $10,000~15,000
- Honda Civic 5년: $10,000~14,000
- Mazda 3 5년: $9,000~13,000
- Hyundai i30 5년: $8,000~12,000
- 한국 차 (현대/기아) = 가성비 OK

**출처**: ppsr.gov.au, racv.com.au, nrma.com.au

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 면허 준비
- 한국 면허 + IDP (한국에서 발급) 또는 영문 번역
- QLD = 학생비자 동안 한국 면허 OK
- 3개월 이상 거주 시 QLD 면허 전환 권장

### Step 2: 예산 결정
- 5,000~10,000 AUD 중고차 (학생 일반)
- + Rego $600~800
- + CTP $400~600
- + Third Party $300~500
- 총 $7,000~12,000

### Step 3: 차 선택
- Carsales.com.au, Gumtree, Facebook Marketplace
- 한인 커뮤니티 (검증됨)
- Toyota Corolla, Honda Civic 추천 (학생용)

### Step 4: 검증
- PPSR/REVS Check ($2)
- Pre-Purchase Inspection ($200~300)
- 시승
- 정비 기록 확인

### Step 5: 구매
- 매매 계약서
- Transfer of Registration
- 결제 (현금 또는 송금)

### Step 6: 등록 + 보험
- Service QLD (브리즈번) 방문
- Rego 명의 변경
- CTP 자동 포함
- Third Party 별도 가입 (보험회사)

### Step 7: 운전
- 좌측 통행
- 라운드어바웃 주의
- 학교 영역 40km/h
- 음주 0.05% 이하

---

## 💡 직원이 학생한테 말할 멘트

```
브리즈번에서 차 구매 고민이시군요.
호주 = 차 없으면 불편한 도시 많아요.

[학생 = 차 소유 가능]
- 학생비자 = 차 소유/등록 가능
- 대출 X (PR 이상 가능)
- 현금 또는 한국 송금으로 구매

[한국 면허 (QLD)]
- 학생비자 동안 = 한국 면허 + 영문 번역 OK
- IDP (한국 발급) 또는 NAATI 영문 번역
- 3개월+ 거주 = QLD 면허 전환 권장

[QLD 면허 전환]
- TMR (Transport and Main Roads) 방문
- 한국 면허 5년+ = 시험 면제
- 비용 $80~150

[차 구매]
- 추천: Toyota Corolla, Honda Civic, Mazda 3
- 5,000~10,000 AUD 중고차 (학생 일반)
- Carsales.com.au, Gumtree, 한인 커뮤니티
- 신차 = 학생 대출 어려움

[중고차 검증 필수]
- PPSR Check $2 (도난/저당 확인)
- Pre-Purchase Inspection $200~300
- 정비 기록 확인
- 시승
- 절대 검증 없이 구매 X

[Rego (등록)]
- 매년 갱신 $400~800
- CTP (의무 보험) 포함 또는 별도
- 5년 이상 차 = Safety Certificate (RWC) 필요

[보험]
- CTP = 의무 (사람 부상)
- Third Party Property = 선택 (남의 차)
- Comprehensive = 종합 (모든 사고)
- 학생 = Third Party Property 권장 (저렴)

[총 비용 (브리즈번)]
- 차 $8,000
- Rego $700
- CTP 포함
- Third Party $400
- 검증/등록 $300
- 보험 $400~600/년
- 첫해 = $9,000~10,000

[운전 주의]
- 좌측 통행
- 라운드어바웃 양보
- 학교 영역 40km/h (오전 7-9, 오후 2-4)
- 음주 0.05% (학생/L면허 0.00%)
- 휴대폰 사용 = 큰 벌금

차 구매는 신중하게 하세요.
한인 커뮤니티 통한 매매가 가장 안전해요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "학생은 차 못 사"
- **거짓**. 학생도 차 소유 가능
- 다만 대출 어려움 (PR 이상)
- 현금 구매 일반

### 함정 2: "한국 면허 평생 가능"
- **거짓**. 학생비자 동안만
- PR/시민권 = 즉시 호주 면허 전환
- 임시 거주 = 3~6개월 후 전환

### 함정 3: "보험 안 들어도 돼"
- **거짓**. CTP = 의무
- CTP 없이 운전 = 큰 벌금 + 면허 정지

### 함정 4: "신차가 안전"
- **부분 사실**. 학생 = 중고차 일반
- 5년 이내 일제 차 = 안전
- 한국 차 = 가성비 OK

### 함정 5: "딜러가 안전"
- **부분 사실**. 딜러도 사기 있음
- 개인 매매 = 더 위험
- 검증 (PPSR + Inspection) = 필수

### 함정 6: "Rego만 내면 돼"
- **부분 사실**. CTP 자동 포함 (NSW/QLD)
- VIC = TAC 별도
- + Third Party Property 추천

### 함정 7: "학생 = 보험료 동일"
- **거짓**. 25세 이하 = 보험료 비쌈
- No Claim Bonus = 시간 누적
- 운전 경력 짧음 = 보험료 높음

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 위치 (시/주)
- NSW vs VIC vs QLD = 정책 다름
- 면허 전환 시점
- Rego/보험 회사

### 2. 한국 면허 보유 여부
- 5년+ = 시험 면제
- IDP 또는 영문 번역
- 미보유 = 호주에서 처음부터

### 3. 예산
- 5,000~30,000 AUD
- 신차 vs 중고
- 대출 가능 여부

### 4. 사용 목적
- 학교 출퇴근
- 알바
- 가족 동반 (어린이)
- 장거리 여행

---

## 🔍 직원이 직접 확인 가능한 사이트

- Carsales: carsales.com.au
- Gumtree: gumtree.com.au
- PPSR: ppsr.gov.au (REVS Check)
- Service NSW: service.nsw.gov.au
- VicRoads: vicroads.vic.gov.au
- QLD TMR: qld.gov.au/transport
- AAMI: aami.com.au
- NRMA: nrma.com.au
- RACV: racv.com.au
- RAA (SA): raa.com.au

---

## 🚨 직원 영역 vs 차량 매매 영역

### 직원이 할 수 있는 것
- ✅ 호주 자동차 시스템 설명
- ✅ Rego/보험 종류 설명
- ✅ 한국 면허 정책 설명
- ✅ 검증 방법 (PPSR) 안내

### 직원이 할 수 없는 것
- ❌ 특정 차 추천
- ❌ 매매 중개
- ❌ 가격 협상
- ❌ 사기 분쟁 해결

---

## ✅ 완벽 응대 체크리스트

- [ ] 위치 (시/주) 확인
- [ ] 한국 면허 보유 + 경력
- [ ] 예산 확인
- [ ] 차 소유 가능 설명
- [ ] 한국 면허 사용 기간 안내
- [ ] 호주 면허 전환 시점
- [ ] Rego 시스템 설명
- [ ] CTP/Third Party/Comprehensive 차이
- [ ] 중고차 검증 (PPSR) 필수 강조
- [ ] Pre-Purchase Inspection 권장
- [ ] 한국 차/일제 차 가성비 안내
- [ ] 운전 주의 사항 (좌측, 라운드어바웃)
- [ ] 음주 0.05% 안내
- [ ] 특정 차 추천 = 안 함

---

**작성**: ausuhak.com 직원 교육팀
**감수**: Wilson Kim (QEAC E240)
**기준**: 2026년 5월
**다음 업데이트**: 면허 정책 변경 시
