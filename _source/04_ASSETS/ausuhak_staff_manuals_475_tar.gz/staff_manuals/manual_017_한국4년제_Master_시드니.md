# 📚 직원 응대 매뉴얼 #017

**케이스: 26세 / 한국 4년제 학사 / 시드니 / Master / 8천만 예산 / 취업+이민**

---

## 🎬 상황 시뮬레이션

> 한국에서 경영학과 졸업했고요 26세입니다. 호주 시드니에서 Master 하고 호주 회사 취업 후에 영주권 받고 싶어요. IELTS 6.5 있어요. 1년 8천만 가능합니다.

**👉 정답**: **Master coursework 2년 → 485 졸업비자 → 영주권 (직업 코드 매칭)**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Master coursework = 1.5~2년 학사 보유자용

- 한국 4년제 학사 + IELTS 6.5+ 입학 가능
- coursework Master = 강의 중심 (논문 X)
- research Master = 논문 中心 (485 3년)

### 2️⃣ 시드니 Master 학교

| 학교 | Master Business 학비 (연간) | IELTS |
|---|---|---|
| USyd | $52K~$58K | 7.0 |
| UNSW | $50K~$55K | 7.0 |
| UTS | $45K~$50K | 6.5 |
| Macquarie | $42K~$48K | 6.5 |
| WSU | $35K~$42K | 6.5 |
| ACU Sydney | $34K~$40K | 6.5 |

### 3️⃣ Master 졸업 후 485 졸업비자

- Master coursework 졸업 = **485 Post-Higher Education Work, 2년**
- Master research 졸업 = 3년
- 35세 미만 (HK/BNO 50세)
- IELTS 6.0 (각 영역 5.0)

### 4️⃣ 시드니 (Non-regional) vs Regional 도시 (PR 가산점)

- 시드니/멜번/브리즈번 CBD = **Non-regional** (491 비적용)
- Adelaide/Perth/Hobart/Canberra 등 Regional 지역 = **491 nomination 시 +15점**
- 190 (주 정부 nomination) = 도시 무관 +5점
- 2019.11.16 이후 Cat 2/3 차등 폐지, Regional 지역 모두 동일하게 +15점

26세부터 시작해도 PR까지 4-5년 걸림. 시드니 고집 시 491 적용 X (190 +5점만 가능).

### 5️⃣ 한국 경영학 + 호주 Master 후 PR 매칭 직업

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Accountant General | 221111 | MLTSSL |
| Management Accountant | 221112 | MLTSSL |
| Marketing Specialist | 225113 | STSOL |
| HR Adviser | 223111 | STSOL |
| ICT Business Analyst | 261111 | MLTSSL |
| Software Engineer | 261313 | MLTSSL |

경영학 → 회계/IT 전환 = PR 비교적 빠름 (MLTSSL 직업).

---

## 🎯 정답 경로

### Master + 485 + PR

```
한국 학사 + IELTS 6.5
        ↓
Master coursework 2년 (UTS / Macquarie / WSU / ACU 등 학생 비교)
        ↓
485 졸업비자 2년
        ↓
호주 회사 취업 + Skills Assessment
        ↓
PR 신청 (189/190/491)
```

**총 4년 호주 / 학비 약 $90K~$120K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 경영학 + 26세 + 시드니 Master + PR, 매우 일반적인 경로입니다.
> 
> 1. **Master coursework 2년** = $90K~$120K (UTS/Macquarie/WSU/ACU 등 학생이 학비/입학조건 비교)
> 2. **485 졸업비자 2년** = 호주 회사 취업 가능
> 3. **PR 매칭 직업**: Accountant (CPA 추가 필요), ICT Business Analyst, Marketing 등
> 
> 다만 시드니는 Non-regional이라 491 비자 +15점 적용 안 됨. 190 nomination만 +5점 가능. **Adelaide/Perth/Canberra 등 Regional 지역 검토** 시 491 +15점 적용 가능.
> 
> 8천만 예산이면 1년 학비 + 생활비 커버 가능하고, 알바 주 24시간 추가 수입으로 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 정확한 IELTS (각 영역)  
> ② 시드니 vs Adelaide/Perth/Canberra 검토 의향  
> ③ 취업 분야 (회계/IT/마케팅 등)"

---

## ⚠️ 함정

1. **"한국 학사 = 호주 Master 자동"** → IELTS 6.5+ + 학점 충족 必
2. **"시드니가 취업 多"** → 사실이지만 PR 가산점 0
3. **"Master 졸업 = 485 자동"** → 92주 학업 + 16개월 요건
4. **"경영학으로 회계사 자동"** → CPA 자격증 별도 必

---

## 📞 카카오 응대 시 필수

1. 정확한 IELTS
2. 시드니 vs Regional 도시 검토
3. 취업 분야 (직업 코드 매칭)
4. 영주권 우선순위 vs 시드니 거주 우선

---

## 🔍 직원 확인 사이트

- USyd / UNSW / UTS / Macquarie 사이트
- Skilled Occupation List
- CPA Australia: cpaaustralia.com.au
