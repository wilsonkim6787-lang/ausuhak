# #517 호주_학생_시험_Special_Consideration_Defer_Compassionate_과제_연장

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시험 보러 가는 길에 교통사고 났어요. 응급실 다녀와서 시험 못 봤어요. F 받게 되는 거 아니죠? Special Consideration이 뭐예요?"

**직원 멘붕 포인트:**
- Special Consideration: 시험/과제 연기 또는 대체 평가
- Compassionate Grounds: 사고/사망/질병/재해
- GP/병원 의사 진단서 또는 Police Report 첨부
- 신청 기한 보통 시험 후 7일 안
- 비자 영향 X (학업 부담만)

---

## ❌ 절대 하지 말아야 할 답

> "시험 못 봤으면 F예요 다음 학기 재수강하세요"

→ ❌ Special Consideration 옵션 있음. 학생 권리. 즉시 신청 안내

---

## ✅ 정답

안심하세요. Special Consideration 신청하시면 시험 연기 또는 대체 평가 가능해요. 사고는 명백한 Compassionate Grounds입니다. 응급실 진단서 또는 의사 진단서 + Police Report(있으면) 챙기시고, 시험 후 7일 안 학교 사이트에서 신청하세요. 신청 후 학교가 (1) 보충 시험(Supplementary Exam), (2) 과제 연장, (3) Withdraw Without Penalty 결정합니다. 비자에는 영향 없으니 안심하세요(학업 출석률 80% 유지하면 OK). 학교별 절차는 학생 포털에서 확인 가능해요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Special Consideration 사유**
Compassionate Grounds (인정):
- 사고 (교통/스포츠 등)
- 질병 (당일 또는 진행)
- 가족 사망 (직계 또는 가까운)
- 재해 (화재/홍수)
- 정신 건강 (Counsellor 진단)
- 종교 행사 (Public Holiday X)

비인정:
- 단순 결석
- 여행/휴가
- 직장 (사전 통보 가능)

**2. 필요 증빙**
사고/질병:
- 의사 진단서 (GP/응급실)
- 병원 영수증
- 응급실 Discharge Summary

사망:
- Death Certificate
- 가족관계증명서

정신 건강:
- Counsellor/Psychologist 진단
- 학교 Counselling Service Letter

사고 (교통):
- Police Report
- 사진 + 보험 청구서

**3. 처리 옵션 (학교별)**
1. Supplementary Exam (보충 시험)
   - 보통 1~2주 후 재시험
   - 점수 100% 그대로

2. Defer Exam (시험 연기)
   - 다음 시험 기간
   - 학기 연장

3. Assignment Extension (과제 연장)
   - 1~14일 추가
   - 감점 없음

4. Withdraw Without Penalty
   - 학점/학비 환급 일부
   - 비자 영향 없음 (학교 통보)

**4. 신청 절차**
1. 시험 후 7일 안 (학교별 차이)
2. 학생 포털 접속:
   - USyd Sydney Student
   - UNSW myUNSW
   - UTS My Student Admin
   - Monash Student Web
3. Special Consideration Form 작성
4. 증빙 업로드 (PDF/Photo)
5. 학과 + Faculty 검토 (5~10일)
6. 결정 통보 (이메일)

**5. 비자 영향 (없음)**
학생비자 (500):
- 출석률 80% 유지
- 학업 진도 (Course Progress) 유지
- Special Consideration은 학교 절차 (비자 무관)

위험 신호:
- 출석률 80% 미달 → Section 19 PRISMS Report → DHA → Section 116 NOICC
- 학업 실패 (Fail) 반복
- Withdraw 반복

Special Consideration은 학업 보호 + 비자 보호
신청은 빠를수록 유리

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 응급실/GP 진단서 + Police Report 챙기기
**2단계**: 학생 포털 Special Consideration Form 작성
**3단계**: 증빙 업로드 (시험 후 7일 안)
**4단계**: 학과 + Faculty 결정 대기 (5~10일)
**5단계**: Supplementary Exam 또는 Defer 통보

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 안심하세요. Special Consideration 신청하면 시험 연기 또는 대체 평가 가능해요. 사고는 명백한 Compassionate Grounds입니다. 응급실 진단서 + Police Report 챙기시고 시험 후 7일 안 학생 포털에서 신청하세요. 비자 영향 없습니다. 학교가 보충 시험/과제 연장/Withdraw 결정합니다. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **F 자동 X**
   → Special Consideration 신청

2. **증빙 없음 X**
   → 진단서 + Police Report

3. **기한 무시 X**
   → 보통 7일 안

4. **비자 영향 X**
   → 학교 절차 (비자 무관)

5. **학교 자동 X**
   → 본인 신청 필수

6. **Compassionate 광범위 X**
   → 사고/질병/사망/재해만

7. **Withdraw=Fail X**
   → Without Penalty 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사건 후 며칠? (7일 미만/7일+)
2. 진단서 받았어요? (있다/없다)
3. Police Report? (있다/없다)
4. 학교? (USyd/UNSW/UTS/Monash/기타)

---

## 🔍 직원이 직접 확인 가능한 사이트

- USyd Special Consideration: sydney.edu.au
- UNSW Special Consideration: my.unsw.edu.au
- UTS Special Consideration: uts.edu.au
- Monash Special Consideration: monash.edu
- Tertiary Education Quality: teqsa.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Special Consideration 1차 안내
- 증빙 가이드
- 학교 포털 안내
- 비자 영향 X 안내

**MARA / 변호사 영역**
- 학교 결정 분쟁 (학교 Ombudsman)
- Withdraw 비자 영향 (MARA)
- 사고 손해배상 (Civil Lawyer)
- OSHC 보험 청구 (보험사)

---

## ✅ 완벽 응대 체크리스트

- [ ] 진단서 + Police Report
- [ ] 학생 포털 신청 7일 안
- [ ] 증빙 업로드
- [ ] 결정 대기
- [ ] Supplementary Exam 또는 Defer
