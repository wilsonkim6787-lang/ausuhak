# #345 호주_PhD_박사과정_지도교수_장학금_485

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 한국에서 Master 마치고 호주 PhD 지원하려고 해요. 지도교수 어떻게 찾고, 장학금이랑 비자 어떻게 되나요?"

**직원 멘붕 포인트:**
- PhD 지원 절차?
- 지도교수 매칭?
- 장학금 = 풀타임?
- PhD + 가족 동반?

---

## ❌ 절대 하지 말아야 할 답

> "PhD는 그냥 학교에 신청하면 돼요."

→ ❌ 지도교수 매칭 + RTP 장학금 + Confirmation of Candidature + 485 4년 자격 모름.

---

## ✅ 정답

**호주 PhD = 지도교수 매칭 → 연구 제안서 → 장학금 신청 → 입학 → Confirmation of Candidature(1년 후) → 3~4년 연구 → 학위.**

**핵심 사실:**
- **지도교수 매칭**: 학교 사이트 Faculty + Research Profile 검색 → 이메일 컨택 → 연구 주제 일치 + 지도 동의 → 학교 입학 신청.
- **연구 제안서(Research Proposal)**: 5,000~10,000자. 연구 질문 + 방법론 + 문헌 리뷰 + 일정.
- **장학금**: 
  - **RTP(Research Training Program)**: 호주 정부 + 학교 매칭. 학비 면제 + 연 $32,192(2025년) + 1년 가족 동반 보조. 합격률 10~20%.
  - **University Scholarship**: 학교 자체 장학금. RTP와 동일/유사 조건.
  - **Industry Scholarship**: 산업 협력 + 추가 $10,000~$20,000.
- **Confirmation of Candidature**: PhD 1년 후 정식 박사 후보자 인정. 미인정 시 Master 전환.
- **485 비자 (Post-Higher Education Work Stream, 구 PSW)**: PhD = 4년 (가족 동반 + 일 가능).
- **PR 경로**: PhD + 직업 평가 + 영어 = 189/190 PR. PhD = EOI 점수 가산점 +20.

**경로:**
지도교수 컨택 → 연구 제안서 → 학교 입학 신청 → 장학금 신청 → 비자 500 → PhD 시작 → 1년 후 Confirmation → 3~4년 연구 → 학위

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 지도교수 컨택**
학교 Faculty 사이트 → Research Interest 일치 교수 → 이메일(연구 관심 + CV + 제안서 초안). 답장률 10~30%.

**2. RTP 장학금**
호주 정부 매칭 + 학교 분배. 학비 면제 + 연 $32,192 + 가족 보조. 합격률 10~20%. 지원 마감 8월(다음 해 입학).

**3. Confirmation of Candidature**
PhD 시작 1년 후 평가. 연구 제안서 + 진도 + 위원회 발표. 통과 시 정식 박사 후보, 실패 시 Master로 전환.

**4. 485 PhD 4년**
PhD 졸업 = 485 비자 (Post-Higher Education Work Stream, 구 PSW) 4년 (Bachelor 2년/Master 2년보다 길음). 가족 동반 + 일 가능.

**5. PR 우대 +20**
PR 189/190 EOI 점수 = PhD +20점 (Master +15점, Bachelor +15점). PhD 학위 PR 강력 유리.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 Master + 영어 IELTS 6.5+ + 연구 분야 결정
**2단계**: 지도교수 사이트 검색 + 이메일 컨택 (3~5명)
**3단계**: 지도 동의 → 연구 제안서 작성 → 학교 입학 신청
**4단계**: RTP/University Scholarship 신청 (마감 8월)
**5단계**: 비자 500 (가족 동반 가능) → PhD 시작 → 1년 후 Confirmation

---

## 💡 직원이 학생한테 말할 멘트

> "PhD는 지도교수 매칭이 핵심이고, RTP 장학금 받으면 학비 면제 + 생활비 지원받습니다. 가족 동반도 가능하고 졸업 후 485 4년 + PR 가산점도 큽니다.

한국 Master 학과 + 영어 점수 + 연구 관심 분야 + 가족 상황 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **PhD = 그냥 신청**
   → ❌ 지도교수 매칭 + 연구 제안서 + 인터뷰 필수. 일반 입학과 다름.

2. **장학금 = 자동**
   → ❌ RTP 합격률 10~20%. 매년 8월 신청 + 다음 해 1월/7월 입학.

3. **Confirmation = 형식**
   → ❌ 미통과 시 Master 전환 + PhD 박탈. 1년 진도 위원회 발표 + 평가.

4. **PhD 학비 = 자동 면제**
   → ❌ 장학금 받아야 면제. 자비 PhD = 학비 $30K~$40K/년.

5. **485 4년 = 무조건**
   → ❌ PhD 호주 졸업만 485 4년. PhD 학위 한국이면 X.

6. **지도교수 = 한 번 매칭 후 변경 불가**
   → ❌ 변경 가능. 지도교수와 갈등 시 학교에 다른 교수 매칭 요청 가능.

7. **PhD = PR 자동**
   → ❌ 직업 평가 + 영어 + 직업군 매칭 + EOI 70+. PR 별개 절차. 단, PhD = +20 가산점.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 Master 학과 + 평균 + 영어 점수
2. 연구 관심 분야 + 지도교수 후보
3. 장학금 신청 의향 (RTP/University)
4. 가족 동반 + PR 목표

---

## 🔍 직원이 직접 확인 가능한 사이트

- 각 학교 Research Profile + Faculty 사이트
- RTP Scholarship (education.gov.au/research-training-program)
- Find a Supervisor (각 학교 Find an Expert)
- DHA Student Visa 500 + 485 (Post-Higher Education)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 지도교수 컨택 + 연구 제안서 가이드
- RTP 장학금 신청 + 학교 입학 신청
- 비자 500 + 가족 동반 + 485 가이드

**MARA / 변호사 영역**
- 비자 500 거절 + ART (MARA)
- PhD 학과 변경 + Confirmation 실패 + 학교 항소 (학교 + 변호사)
- PR 189/190 신청 + 직업 평가 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 Master + 영어 IELTS 6.5+ 준비
- [ ] 지도교수 사이트 검색 + 3~5명 컨택
- [ ] 연구 제안서 5,000~10,000자 작성
- [ ] RTP/University Scholarship 신청 (8월 마감)
- [ ] 비자 500 + 가족 동반 + OSHC
- [ ] PhD 시작 1년 후 Confirmation 통과 준비
- [ ] 졸업 후 485 (Post-Higher Education) 4년 + PR 직업 평가
