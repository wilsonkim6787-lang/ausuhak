# #329 호주_학생_종교_문화_적응_식단_기도_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주에서 무슬림인데 학교에 기도실이 있는지 + 할랄 음식 어떻게 구하는지 모르겠어요."

**직원 멘붕 포인트:**
- 호주 = 다문화 사회 (인구 30%+ 외국 출생)
- 학교 = 기도실 / 종교 클럽 / 다양한 식단 지원
- 한국 학생 = 무슬림 / 채식 / 유대교 등 일부
- 종교 차별 = 호주 차별금지법 보호
- 직원이 정확한 자원 안내 = 학생 적응

---

## ❌ 절대 하지 말아야 할 답

> "호주에서 그런 거 잘 안 통해요. 그냥 적응하세요."

→ ❌ 호주 = 다문화 사회 + 종교 자유 보호. 학교 + 도시 = 다양한 종교 자원 풍부. 정확한 안내 필수.

---

## ✅ 정답

**호주 다문화 환경:**

**인구 다양성:**
- 외국 출생 = 30%+ (호주 인구)
- 무슬림 = 3.2% (80만 명)
- 힌두 = 2.7%
- 불교 = 2.4%
- 유대교 = 0.4%
- 무종교 = 38%

**시드니 / 멜번 = 가장 다양:**
- Lakemba (Sydney) = 무슬림 중심
- Cabramatta = 베트남
- Springvale (Melbourne) = 베트남 / 캄보디아

**학교 종교 시설:**

**1. 기도실 (Prayer Rooms):**
- 모든 G8 학교 = 무슬림 기도실
- 남/여 분리
- 24시간 또는 학교 시간
- USyd / UNSW / UMelb / UQ / ANU 모두 운영

**2. 종교 클럽:**
- Muslim Students Society
- Catholic Society
- Jewish Society
- Christian Union
- Buddhist Society
- Hindu Society

**3. 다종교 채플 (Multifaith Chapel):**
- 모든 종교 사용 가능
- 명상 / 기도 / 조용한 공간

**식단 지원:**

**1. 할랄 (Halal):**

**시드니:**
- Lakemba 거리 (Haldon St) = 할랄 메카
- Auburn = 터키 / 중동
- Bankstown = 다양한 할랄

**멜번:**
- Brunswick = 할랄
- Dandenong = 다양한 할랄

**대학 캠퍼스:**
- USyd / UNSW / UMelb = 할랄 카페 1~2개
- Halal-certified Food Trucks (학교 행사)

**할랄 인증:**
- AFIC (Australian Federation of Islamic Councils)
- 마트 = Halal-certified 라벨

**2. 채식 (Vegetarian / Vegan):**

**호주 채식 친화:**
- 모든 카페 / 식당 = 채식 메뉴
- Vegan 마트 (Vegie Bag, Vegan Express)
- 학교 카페테리아 = 채식 옵션 표준

**3. 유대교 (Kosher):**

**시드니:**
- Bondi / Rose Bay = 유대인 커뮤니티
- Kosher Markets / 식당

**멜번:**
- Caulfield / St Kilda = 유대인 중심
- Kosher 마트 다수

**4. 한국 식단:**
- 한인 마트 (Bing Bao, K-Mart)
- 한국 식당 / 카페
- 한국 BBQ

**기도 시간 (Prayer Times):**
- 무슬림 = Jumu'ah (금요일 정오)
- 학교 = 기도실 시간 조정 가능
- Ramadan (라마단) = 학교 / 직장 인정

**종교 휴일:**
- Eid al-Fitr / Eid al-Adha (무슬림)
- Diwali (힌두)
- Hanukkah / Yom Kippur (유대교)
- 학교 = 일부 휴일 인정 (시험 조정 가능)

**종교 차별 보호:**

**Australian Human Rights Commission:**
- 종교 차별 = 차별금지법
- 학교 / 직장 = 종교 차별 금지
- 신고 = AHRC (1300 656 419)

**기숙사 종교 배려:**
- 룸메이트 종교 다른 경우 = 학교에 신청
- 기도실 / 식단 = 기숙사 신청 시 명시

**한국 학생 무슬림 (드물지만 일부):**
- 시드니 Lakemba 근처 = 한인 + 무슬림 커뮤니티 일부
- 학교 Muslim Students Society 가입
- AFIC 연결

**한국 기독교 (다수):**
- 호주 한국 교회 = 시드니/멜번/브리즈번 100+
- 한국어 예배
- 학생 모임

**한국 불교 (일부):**
- 한국 불교 사찰 = 시드니 / 멜번 일부
- 호주 불교 사회 = 학교 클럽

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 학교 기도실 (Prayer Rooms)**
모든 G8 학교 = 무슬림 기도실 운영. 남/여 분리. 24시간.

**2. AFIC 할랄 인증**
Australian Federation of Islamic Councils. 마트 라벨. 식당 인증.

**3. Multifaith Chapel**
모든 종교 사용 가능. 명상 / 기도 / 조용한 공간. 학교 운영.

**4. Australian Human Rights Commission**
AHRC = 종교 차별 신고. 1300 656 419. 무료.

**5. Lakemba (Sydney) / Brunswick (Melbourne)**
할랄 메카 거리. 다양한 식당 + 마트.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **학생 종교 + 식단 확인** - 무슬림 / 채식 / 유대교 등
**2단계**: **학교 종교 시설 확인** - 기도실 / 클럽 / 채플
**3단계**: **식당 + 마트 위치 확인** - 시드니 / 멜번 위치별
**4단계**: **종교 클럽 가입** - Muslim/Catholic/Jewish Society
**5단계**: **차별 발생 시** - AHRC 1300 656 419 신고

---

## 💡 직원이 학생한테 말할 멘트

> "호주는 다문화 사회로 외국 출생 인구가 30%+이고 학교마다 기도실 + 종교 클럽 + 다양한 식단을 지원합니다. 무슬림은 G8 학교 모두 기도실 운영하고 시드니 Lakemba/멜번 Brunswick은 할랄 메카입니다. 채식은 모든 카페 메뉴 표준이고, 유대교는 Bondi/Caulfield에 Kosher 마트가 있습니다. 종교 차별은 AHRC (1300 656 419)에 신고할 수 있고 학교에서도 절대 허용 X입니다. 학생님 종교 + 학교 알려주시면 자세히 안내드립니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **호주 = 종교 차별 심함**
   → 호주 = 다문화 사회. 차별금지법 보호. 학교 + 도시 다양.

2. **학교 기도실 X**
   → G8 학교 모두 기도실 운영. 남/여 분리. 24시간 일부.

3. **할랄 = 비싸다**
   → Lakemba / Brunswick = 다양한 가격. 마트 라벨 일반.

4. **채식 = 호주에서 어려움**
   → 채식 = 매우 친화. 모든 카페 메뉴. Vegan 마트 다수.

5. **종교 휴일 = 인정 X**
   → 학교 = 일부 인정. 시험 조정 가능. 직장 = 협의.

6. **Ramadan = 학업 어려움**
   → 학교 = Ramadan 인정. 시험 일정 조정 가능. 교수 협의.

7. **종교 클럽 = 강제**
   → 선택. 학생 본인 의지. 가입 X 허용.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 학생 종교 + 식단 종류
2. 거주 도시 (시드니/멜번/브리즈번)
3. 학교 종교 시설 활용 의지
4. 차별 경험 + AHRC 신고 의지

---

## 🔍 직원이 직접 확인 가능한 사이트

- AFIC (할랄): www.afic.com.au
- AHRC (차별): www.humanrights.gov.au (1300 656 419)
- USyd Multifaith: www.sydney.edu.au/students/multifaith
- Halal Certified Australia: www.muslimaustralia.com.au
- 한국 영사관: aus-melbourne.mofa.go.kr

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 다문화 자원 일반 안내
- 학교 종교 시설 안내
- 식단 지원 (할랄/채식/Kosher) 안내

**MARA / 변호사 영역**
- 종교 차별 = AHRC + 변호사
- 비자 + 종교 = MARA
- 직장 종교 휴일 = Fair Work

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생 종교 + 식단 확인
- [ ] 학교 기도실 + 클럽 안내
- [ ] 할랄/채식/Kosher 식당 안내
- [ ] AHRC 차별 신고 안내
- [ ] Ramadan / 종교 휴일 학업 조정
- [ ] 다문화 사회 정보 강조
