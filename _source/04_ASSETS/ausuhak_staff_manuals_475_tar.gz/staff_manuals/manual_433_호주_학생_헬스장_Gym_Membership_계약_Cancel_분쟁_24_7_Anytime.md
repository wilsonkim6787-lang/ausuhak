# #433 호주_학생_헬스장_Gym_Membership_계약_Cancel_분쟁_24_7_Anytime

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "Anytime Fitness 1년 계약했는데 6개월 만에 한국 가야 해요. 환불 안 된다고 하고 위약금 $300 내라는데 너무해요. 그냥 카드 정지하면 안 되나요? Direct Debit 어떻게 끊어요?"

**직원 멘붕 포인트:**
- Australian Consumer Law (ACL) Cancel 권리
- Direct Debit 강제 정지
- Cooling-off Period (10일)
- Hardship 사유 Cancel
- ACCC Gym 분쟁 가이드

---

## ❌ 절대 하지 말아야 할 답

> "계약은 끝까지 가야 해요"

→ ❌ ❌ ACL상 Hardship 사유 (출국/실직/의료) Cancel 가능. 강제 위약금 = ACCC 신고 가능.

---

## ✅ 정답

헬스장 분쟁: ① ACL = 약관 불공정 시 무효 / Hardship 사유 (출국/의료/실직) Cancel 권리, ② Cooling-off Period (계약 후 10일 - VIC) - 전액 환불, ③ Direct Debit 정지: 은행에 'Direct Debit Stop' 요청 (법적 권리 / Westpac/CBA 모두 가능) - but 헬스장이 빚 청구 가능, ④ 위약금 $300 = 잔여 회비의 일부면 합법 / 잔여 전액 청구는 불공정 가능, ⑤ ACCC 분쟁 신고 - accc.gov.au, ⑥ Fair Trading 주별 - $100 미만 분쟁, ⑦ Anytime Fitness/Fitness First/Plus Fitness = 12개월 lock-in 일반적, ⑧ Hardship Cancel 시 의사 진단서/항공권 사본 필요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ACL Cancel**
Hardship 사유 가능

**2. Cooling-off**
10일 / VIC 표준

**3. Direct Debit Stop**
은행 권리 / 헬스장 빚 별개

**4. ACCC 분쟁**
accc.gov.au

**5. Fair Trading**
주별 무료 분쟁 해결

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 계약서 약관 확인 (Cancel 조건)
**2단계**: 2단계: Hardship 사유 서면 통보 (출국 = 항공권)
**3단계**: 3단계: Direct Debit 은행 정지 요청
**4단계**: 4단계: Fair Trading 또는 ACCC 신고
**5단계**: 5단계: 위약금 협상 (정당한 잔여만)

---

## 💡 직원이 학생한테 말할 멘트

> "ACL상 출국/Hardship 사유 Cancel 권리 있습니다. 항공권 사본 + 서면 통보하세요. Direct Debit은 은행에서 정지 가능합니다. 분쟁 시 Fair Trading (주별) 무료 신고하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **계약 강제 끝까지**
   → Hardship Cancel 가능

2. **Direct Debit 못 끊음**
   → 은행 권리

3. **위약금 전액 합법**
   → 잔여 일부만 정당

4. **Cooling-off X**
   → 10일 (VIC) 적용

5. **ACCC 헬스장 무관**
   → ACL 적용 분쟁 가능

6. **Anytime은 Cancel X 회원제**
   → ACL 우선 적용

7. **환불 협상 X**
   → Hardship 사유 환불 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 계약 시작/종료일
2. Hardship 사유 (출국/의료/실직)
3. Direct Debit 은행
4. Cooling-off 기간 내 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('ACCC', 'accc.gov.au')
- ('Fair Trading NSW', 'fairtrading.nsw.gov.au')
- ('Consumer Affairs VIC', 'consumer.vic.gov.au')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- ACL 일반 안내, 분쟁 절차

**MARA / 변호사 영역**
- 비자 영향 X / 소액 변호사 LawAccess

---

## ✅ 완벽 응대 체크리스트

- [ ] Hardship Cancel 권리 강조함
- [ ] Direct Debit 은행 정지 안내함
- [ ] Cooling-off 10일 안내함
- [ ] Fair Trading 무료 안내함
- [ ] 위약금 협상 가능 안내함
- [ ] ACCC 신고 옵션 안내함
