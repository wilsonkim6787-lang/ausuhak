# #394 호주_학생_장애_Disability_Support_NDIS_학교_지원_비자

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 청각 장애 있어요(보청기 사용). 호주 학교 다니면 강의 자막 지원돼요? 비자에 영향 가나요? NDIS는 학생도 받을 수 있나요?"

**직원 멘붕 포인트:**
- NDIS 학생비자 자격 모름
- 학교 장애 지원 범위 모름
- Health Requirement 영향 모름
- 수화/자막 서비스 호주 표준 모름
- 장애 등급별 비자 처리 차이 모름

---

## ❌ 절대 하지 말아야 할 답

> "장애 있으면 호주 비자 신청 안 되시고 NDIS도 못 받으세요."

→ ❌ 단정적 차별 발언. 장애 자체 = 비자 거절 사유 X. NDIS는 학생비자 비대상이지만 학교 자체 지원은 가능.

---

## ✅ 정답

**호주 장애 학생 지원 시스템 (2026.05 기준)**:

1. **NDIS (National Disability Insurance Scheme)**:
   - 학생비자 = 비대상 (시민/PR/특정 비자만)
   - 단, 학교 자체 지원 = 가능
2. **학교 장애 지원 (Disability Support Services)**:
   - DDA (Disability Discrimination Act 1992) = 의무
   - Reasonable Adjustment 의무 (자막, 수화 통역, 시험 시간 연장, 노트테이커)
3. **Health Requirement**:
   - 평생 의료 비용 $51,000 초과 시 = 면제 신청 필요
   - 청각/시각/지체 장애 = 일반적으로 통과
   - 중증 정신장애/지적장애 = 케이스별
4. **수화 통역**:
   - Auslan (Australian Sign Language) = 호주 수화 (한국 수화와 다름)
   - 학교 사전 요청 시 통역사 배정
5. **OSHC + 보청기/휠체어**:
   - 보청기 배터리/유지비 = 본인 부담
   - 휠체어 = 학교 캠퍼스 접근성 의무

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. NDIS 자격 + 학생비자 비대상**
NDIS Act 2013 = 호주 시민, PR, Protected SCV 일부만. 학생비자 = 비대상. 단, 학교 자체 Disability Support는 받을 수 있음.

**2. DDA 1992 학교 의무**
Disability Discrimination Act 1992 = 학교가 Reasonable Adjustment 제공 의무. 자막, 수화, 노트테이커, 시험 시간 연장(보통 25%), 별도 시험실, Assistive Tech.

**3. Health Requirement 면제**
Subclass 500 신청 시 Health Examination → BOMOS Threshold ($51,000/평생). 초과 시 Health Waiver 신청 가능. 학생비자 = Health Waiver 가능 (PR보다 관대).

**4. Auslan 한국 수화와 다름**
Auslan = 호주 수화, BSL(영국 수화) 기반. 한국 수화(KSL)와 완전히 다름. 학교 통역사 사전 요청 (3주 전). NAATI 인증 통역사 = 시간당 $80~$120.

**5. 캠퍼스 접근성**
DDA = 모든 신축 건물 휠체어 접근. 구건물도 Reasonable Adjustment. 강의실 자막(Live Captioning) = 사전 요청 시 가능. AI 자막 = 일부 학교 표준 (Otter, Microsoft Stream).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 출국 전 = 한국 장애 진단서 영문 번역 + Health Examination 준비.
**2단계**: 2단계: 비자 신청 시 = Health Waiver 필요 여부 변호사 상담.
**3단계**: 3단계: 학교 합격 후 = Disability Support Services 등록 (입학 전 4~6주).
**4단계**: 4단계: Reasonable Adjustment 요청 (자막, 수화, 시험 연장).
**5단계**: 5단계: 도착 후 = OSHC 등록 + 의료기 유지비 본인 부담 준비.

---

## 💡 직원이 학생한테 말할 멘트

> "청각 장애 = 학생비자 거절 사유 아니시고요, 호주 모든 학교는 DDA(장애차별금지법)에 따라 자막·수화·시험 연장 같은 지원 의무예요. NDIS는 학생비자 비대상이지만 학교 자체 지원 받으실 수 있어요. Auslan 통역도 사전 요청 가능해요. 비자 Health Waiver는 변호사 검토 필요한데 자세한 학교 선택은 윌슨님 카톡 상담주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **장애 = 비자 거절이라고 단정**
   → Health Requirement 통과 시 OK. 청각/시각/지체 장애 = 일반 통과. 중증만 Health Waiver.

2. **NDIS = 학생도 받는다고 안내**
   → NDIS = 시민/PR/Protected SCV만. 학생비자 비대상. 학교 자체 지원만 가능.

3. **Auslan = 한국 수화와 같다고 오해**
   → 완전히 다름. Auslan(호주) ≠ KSL(한국) ≠ ASL(미국). 사전 학습 또는 한국어-영어 자막 활용.

4. **Reasonable Adjustment = 자동 적용이라고 안내**
   → 사전 요청 필수. 입학 4~6주 전 Disability Support 등록 + 진단서 제출.

5. **OSHC = 보청기/휠체어 보장이라고 안내**
   → OSHC = 의료비만 보장. 보조기기 = 본인 부담. 한국에서 가져가는 것 권장.

6. **Health Examination = 한국 의사 진단서로 대체 가능이라고 오해**
   → Bupa Medical Visa Services 지정 의사 검진 의무. 한국 진단서는 참고용.

7. **장애 학생 = SOP에 강조해야 한다고 오해**
   → SOP는 학업 동기 + 진정성 위주. 장애 언급 = 강조 X, 사실 기재 OK.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 장애 종류 + 등급 (Health Waiver 필요 여부)
2. 한국 장애인 등록 + 영문 진단서
3. 필요 지원 종류 (자막/수화/시간 연장)
4. 보조기기 한국에서 지참 vs 호주 구입

---

## 🔍 직원이 직접 확인 가능한 사이트

- ndis.gov.au - NDIS 자격 (학생비자 비대상)
- humanrights.gov.au/disability_rights - DDA 1992
- homeaffairs.gov.au - Health Requirement
- 각 대학 Disability Support Services
- auslan.org.au - 호주 수화 정보

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학교 선택 (Disability Support 강한 학교)
- 도시 선택 (의료 인프라)
- ELICOS 강의실 자막 지원 확인

**MARA / 변호사 영역**
- Health Waiver 신청 = 변호사 필수
- Health Examination 결과 검토 = 변호사
- 비자 신청서 장애 기재 = 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 장애 진단서 영문 번역 안내
- [ ] Health Waiver 변호사 검토 권장
- [ ] 학교 Disability Support 입학 4주 전 등록
- [ ] Reasonable Adjustment 요청 항목 정리
- [ ] Auslan ≠ KSL 안내
- [ ] 보조기기 본인 부담 안내
- [ ] 윌슨 카톡 상담 유도
