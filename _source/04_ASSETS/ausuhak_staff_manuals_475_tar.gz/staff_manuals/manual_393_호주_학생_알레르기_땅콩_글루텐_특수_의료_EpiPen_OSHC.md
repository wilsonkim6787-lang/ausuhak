# #393 호주_학생_알레르기_땅콩_글루텐_특수_의료_EpiPen_OSHC

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 땅콩 알레르기 심한데 호주 음식 위험할까요? EpiPen 호주에서 살 수 있어요? OSHC로 응급실 가면 보장돼요? 학교에 알레르기 신고해야 해요?"

**직원 멘붕 포인트:**
- EpiPen 호주 처방 절차 모름
- OSHC 응급실 보장 범위 모름
- 학교 알레르기 신고 의무 모름
- 글루텐 무첨가 식품 인프라 모름
- 알레르기로 비자 거절될까 걱정 응답 못 함

---

## ❌ 절대 하지 말아야 할 답

> "알레르기는 한국에서 미리 약 가져가시면 호주에선 따로 안 해도 돼요!"

→ ❌ 응급 상황 시 호주 의료 시스템 이용 필요. EpiPen은 처방전 필요하고, OSHC 사전 등록·학교 신고 의무 있음.

---

## ✅ 정답

**호주 알레르기 의료 시스템 (2026.05 기준)**:

1. **EpiPen**:
   - 호주 처방전 필요 (GP 방문)
   - 가격: PBS 적용 시 $7.70/개 (학생비자 = PBS 적용 X), 일반 $50~$80
   - OSHC 보장: 일부 (사전 약 약가 보조)
2. **OSHC 응급실 보장**:
   - 100% 보장 (Bupa/Medibank/Allianz/NIB/AHM)
   - Out-of-pocket = 응급실 대기 X (PRN)
3. **학교 알레르기 신고**:
   - 등록 시 Medical Form 작성 = 의무 X (학생 자율)
   - 권장 = 학교 보건실에 EpiPen 보관, 응급 연락처 등록
4. **글루텐 무첨가 (Gluten-free)**:
   - Coles/Woolworths = Gluten-free 섹션 (호주 표기 의무)
   - 인증: Coeliac Australia 인증 마크
5. **비자 거절 위험**:
   - 알레르기 자체 = 비자 거절 사유 X (Health Requirement 통과)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. EpiPen 호주 처방**
GP(가정의) 방문 후 처방. PBS Authority 받으면 학생비자도 일부 보조. 일반 가격 $50~$80/개. 2년 유효기간. Anaphylaxis 진단서 = 학교/공항 제출 가능.

**2. OSHC 응급실 100% 보장**
Bupa/Medibank/Allianz/NIB/AHM = 응급실 ER 100% (Public Hospital). Ambulance = OSHC Standard 미포함, OSHC Premium 또는 Ambulance Cover 별도 가입 권장 ($60~$100/년).

**3. 학교 알레르기 신고 + EpiPen 보관**
ASCIA Action Plan (호주 알레르기 가이드) 작성 권장. 학교 보건실에 EpiPen 1개 보관. 응급 연락처 (호주 보호자, 한국 가족) 등록.

**4. Coeliac Australia 인증**
Gluten-free 표기 의무 = 호주 식품법 (Food Standards Code). Coeliac Australia 인증 마크 = 글루텐 < 20ppm. Coles/Woolworths 전용 섹션. 외식 = Gluten-free 메뉴 표시 식당 OK.

**5. 호주 응급실 절차**
Triage 5단계 (1=즉시, 5=2시간 이상). Anaphylaxis = 1단계 즉시 처치. 응급실 OSHC 카드 + 여권 제시. 비용 청구 안 됨 (Public Hospital). 사립병원 = 별도 청구 가능.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 출국 전 = 한국 알레르기 진단서 영문 번역 (NAATI 권장).
**2단계**: 2단계: 도착 후 = GP 방문 → EpiPen 처방 (1주 내).
**3단계**: 3단계: 학교 등록 시 = ASCIA Action Plan 제출 + 보건실 EpiPen 보관.
**4단계**: 4단계: OSHC = 응급실 보장 확인. Ambulance Cover 추가 가입 권장.
**5단계**: 5단계: 외식 시 = Allergen 메뉴 표시 식당 이용. 의심 시 직원에게 확인.

---

## 💡 직원이 학생한테 말할 멘트

> "알레르기 자체로 비자 거절 안 되시고요, 호주에선 GP 방문해서 EpiPen 처방받으시면 돼요. 학교에 ASCIA Action Plan 제출하고 보건실에 EpiPen 보관 권장드려요. OSHC는 응급실 100% 보장이고 Ambulance Cover만 추가 가입하시면 돼요. 자세한 학교/도시 안내는 윌슨님 카톡 상담받으세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **EpiPen 한국에서 가져가면 OK라고 안내**
   → 한국 EpiPen 유효기간 = 1~2년. 호주 처방 = 새 EpiPen 필수. 한국 약은 비상용.

2. **학교 신고 = 의무라고 단정**
   → 학교 신고 = 의무 X (학생 자율). 단, 강력 권장. 미신고 시 응급 상황 처치 지연 가능.

3. **OSHC = 모든 알레르기 약 보장이라고 안내**
   → OSHC 약가 보조 = 일부만. PBS 적용 X (학생비자). 일반 약가 본인 부담 비율 높음.

4. **Ambulance = OSHC 무료라고 안내**
   → OSHC Standard = Ambulance 미포함. NSW $407/이용, VIC $1,247/이용. 별도 가입 또는 OSHC Premium.

5. **Anaphylaxis 발생 시 = 911 안내**
   → 호주 응급 = 000 (Triple Zero). 911 X. 한국과 다름.

6. **Gluten-free = 어디든 있다고 안내**
   → Coles/Woolworths = OK. 외식 = 식당별 표시. 시골 = 제한적. 인증 마크 확인.

7. **알레르기 = 학생비자 거절이라고 오해**
   → DHA Health Requirement = 평생 비용 $51,000 초과 시 검토. 알레르기 자체 = 거절 사유 X.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 알레르기 종류 + 심각도 (Anaphylaxis 여부)
2. 한국 진단서 영문 번역 여부
3. OSHC 가입 여부 + 등급 (Standard vs Premium)
4. 외식 빈도 (자취 권장 정도)

---

## 🔍 직원이 직접 확인 가능한 사이트

- allergy.org.au - ASCIA 호주 알레르기 가이드
- coeliac.org.au - Coeliac Australia 인증
- homeaffairs.gov.au - Health Requirement
- pbs.gov.au - 약가 보조 시스템
- 각 OSHC 사이트 (Bupa/Medibank/Allianz/NIB/AHM)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학교 선택 (보건실 지원 좋은 학교)
- 도시 선택 (의료 인프라)
- OSHC 가입 안내

**MARA / 변호사 영역**
- Health Requirement 면제 신청 = 변호사 (심각한 경우)
- ASCIA Action Plan 작성 = GP/병원

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 알레르기 진단서 영문 번역 안내
- [ ] 도착 1주 내 GP 방문 → EpiPen 처방 안내
- [ ] 학교 ASCIA Action Plan 제출 안내
- [ ] OSHC 응급실 보장 확인
- [ ] Ambulance Cover 별도 가입 권장
- [ ] 응급번호 = 000 (911 X) 안내
- [ ] 윌슨 카톡 상담 유도
