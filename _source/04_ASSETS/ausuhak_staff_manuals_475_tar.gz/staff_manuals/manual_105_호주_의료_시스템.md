# 📚 직원 응대 매뉴얼 #105

**케이스: 28세 / 시드니 Master 1학년 / "감기 걸렸는데 병원 어떻게 가요? OSHC 있는데 병원비 무료인가요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니 도착 2주차인데 감기 심해졌어요. OSHC 가입했는데 병원 어디로 가요? 한국처럼 그냥 가면 되나요? 무료인가요? 약은 어디서 사요?

**👉 직원이 멘붕하는 순간**
- "OSHC = 무료?"
- "GP는 뭐야?"
- "한국처럼 가도 되나?"
- "약 = 처방전?"
- "응급실 = 어떻게?"

**❌ 절대 하지 말아야 할 답**
- "OSHC 있으니까 무료에요" → **거짓. 차액 발생**
- "그냥 병원 가면 돼요" → **거짓. GP 먼저**
- "한국 약국 가요" → **거짓. 처방전 필요**

**✅ 직원이 알아야 할 정답**
호주 의료 = **GP (General Practitioner) 시스템**. 한국과 완전 다름:

1. **GP = 1차 진료** (Family Doctor)
2. **GP 진료비 환급** = OSHC가 일부 환급
3. **Bulk Billing** = GP가 OSHC에 직접 청구 = **본인 부담 0**
4. **No Bulk Billing** = 본인 선납 → 영수증 → OSHC 환급
5. **응급실** = 000 또는 직접 방문 (큰 병원만)
6. **약국 (Pharmacy)** = GP 처방전 필수
7. **전문의 (Specialist)** = GP의 Referral (소개) 필수

직원 = **GP 시스템** 설명. 윌슨 = 학생 케어 안내.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ GP (General Practitioner) = 1차 진료의

**답**: 호주 의료의 기본. **모든 진료 = GP 먼저**.

**GP의 역할**:
- 감기, 몸살, 기본 질환 진료
- 처방전 (Script) 발급
- 전문의 Referral (소개장) 작성
- Medical Certificate (병결 증명서) 발급
- 백신 접종
- Mental Health Plan 작성

**예약 방법**:
- 전화 (대부분)
- HotDoc, HealthEngine 앱
- Walk-in (예약 없이) = 일부 클리닉만
- 평균 진료비: $80~120 (15분)
- Long Consultation: $150~200 (30분)

**한국 학생 자주 가는 GP**:
- 시드니: 한인 GP 다수 (Strathfield, Eastwood, Chatswood)
- 멜번: Glen Waverley, Box Hill 한인 GP
- 브리즈번: Sunnybank
- 한국어 가능 GP 검색: "Korean speaking GP" + 지역

**Bulk Billing**:
- GP가 OSHC/Medicare에 직접 청구
- 본인 부담 = 0
- 학생 = OSHC만 가능 (Medicare 없음)
- Bulk Billing GP = 미리 확인 필수

**출처**: health.gov.au, hotdoc.com.au

---

### 2️⃣ OSHC (Overseas Student Health Cover) 환급 시스템

**답**: OSHC = **부분 환급**. 무료 아님.

**OSHC 5개 회사**:
- Bupa (점유율 1위)
- Medibank
- Allianz Care
- NIB
- AHM

**환급 비율**:
- GP 진료: 100% (Bulk Billing 시) 또는 차액 본인
- 처방약: PBS 가격 일부
- 응급실: 100% (공립병원)
- 입원: 100% (공립병원 Shared Room)
- 전문의: GP Referral 필수, 일부 환급
- MRI/X-ray: 일부 환급

**환급 방법**:
1. **HiCAPS 카드** = 클리닉에서 즉시 처리
2. **앱 청구** = 영수증 사진 → 앱 업로드
3. **온라인 청구** = OSHC 사이트
4. **우편 청구** = 영수증 + 양식

**제외 항목**:
- 임신 (12개월 대기)
- 치과 (별도 가입)
- 안과 (별도 가입)
- 한방 (없음)
- 미용 (없음)

**출처**: bupa.com.au, medibank.com.au, allianzcare.com.au

---

### 3️⃣ Pharmacy (약국) 시스템

**답**: 한국 약국 ≠ 호주 Pharmacy. **처방전 필수**.

**약 종류**:

**OTC (Over the Counter)** = 처방전 없이 구매:
- 진통제 (Panadol, Nurofen)
- 감기약 (일부)
- 비타민
- 알레르기약 (일부)

**Prescription Only (처방전 필수)**:
- 항생제
- 강한 진통제
- 정신과 약
- 수면제
- 호르몬제

**처방전 (Script)**:
- GP 진료 후 발급
- E-Script (이메일/SMS) 또는 종이
- 약국에서 약사에게 제출
- PBS (Pharmaceutical Benefits Scheme) = 호주 시민/PR만
- 학생 = PBS 안 됨 = **풀 가격 지불**

**약국 체인**:
- Chemist Warehouse (가장 저렴)
- Priceline
- Terry White
- Amcal

**한약/한방**: 호주 = 거의 없음. 한국에서 가져오기 (반입 제한 확인)

**출처**: pbs.gov.au, chemistwarehouse.com.au

---

### 4️⃣ 응급실 (Emergency Department)

**답**: 호주 응급실 = **공립 병원만 OSHC 100%**.

**응급실 가는 법**:

**000 신고 (구급차)**:
- 의식 잃음
- 심한 출혈
- 호흡 곤란
- 가슴 통증
- 의심되는 골절
- 화상

**직접 방문**:
- 위 증상 외 응급 상황
- 운전 또는 택시
- 가족 동반

**응급실 비용**:
- 공립병원 (Public): OSHC 100% 환급
- 사립병원 (Private): 일부 환급
- **반드시 공립병원** 가야 함

**시드니 주요 공립 응급실**:
- Royal Prince Alfred Hospital (RPA, Camperdown)
- Westmead Hospital (Westmead)
- St Vincent's Hospital (Darlinghurst)
- Royal North Shore Hospital (St Leonards)

**멜번 주요 공립 응급실**:
- Royal Melbourne Hospital (Parkville)
- Alfred Hospital (Prahran)
- Monash Medical Centre (Clayton)

**브리즈번**:
- Royal Brisbane and Women's Hospital
- Princess Alexandra Hospital

**대기시간**:
- Triage 1 (위급): 즉시
- Triage 2: 10분 이내
- Triage 3: 30분 이내
- Triage 4: 1시간 이내
- Triage 5 (가벼움): 2시간+

**구급차 비용**:
- NSW: OSHC 환급 (일부)
- VIC: $1,200~2,000 (별도 보험 필요)
- QLD: 무료 (주정부 부담)
- 학생 = OSHC 가입 시 일부 환급

**출처**: health.nsw.gov.au, health.vic.gov.au

---

### 5️⃣ 전문의 (Specialist) 시스템

**답**: 호주 전문의 = **GP Referral 필수**.

**프로세스**:
1. GP 진료
2. GP가 전문의 필요 판단
3. Referral Letter 발급
4. 전문의 예약 (대기 길음)
5. 전문의 진료
6. 영수증 → OSHC 청구

**전문의 종류**:
- Cardiologist (심장)
- Dermatologist (피부)
- Gastroenterologist (소화기)
- Gynaecologist (산부인과)
- Neurologist (신경)
- Orthopaedist (정형외과)
- Psychiatrist (정신과)
- Urologist (비뇨기)

**비용**:
- 첫 진료: $200~500
- 재진료: $150~300
- OSHC 환급: 일부 (50~85%)
- 본인 부담 (Gap): $50~150

**대기 시간**:
- 일반 전문의: 2주~2개월
- 인기 전문의: 3~6개월
- 응급 = GP가 응급 표시 → 단축

**MRI/CT**:
- GP 또는 전문의 Referral 필수
- $300~800 (부위 따라)
- OSHC 환급 일부

**출처**: ahpra.gov.au, racgp.org.au

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: GP 찾기 (오늘)
- HotDoc 앱 다운로드 또는 google "Korean GP Sydney"
- 한국어 가능 GP = Strathfield, Eastwood
- Bulk Billing GP = OSHC 100% 환급
- 예약 또는 Walk-in

### Step 2: GP 진료 (당일~내일)
- OSHC 카드 지참
- 여권/학생증 지참
- 증상 설명
- 처방전 받음

### Step 3: 약국 가기
- Chemist Warehouse 등
- 처방전 제출
- 약 받기 (학생 = PBS 안 됨, 풀 가격)

### Step 4: OSHC 환급 (필요시)
- Bulk Billing이면 X
- 본인 선납했으면 영수증 → 앱 청구
- 환급 = 5일~2주

### Step 5: 심해지면
- 응급실 = 공립병원
- 또는 GP 재방문
- 전문의 = GP Referral

---

## 💡 직원이 학생한테 말할 멘트

```
시드니 도착 2주차 + 감기 심해졌다 하셨네요.

호주 의료는 한국과 완전 달라요.
한국 = 바로 큰 병원 / 호주 = GP (Family Doctor) 먼저예요.

[GP 시스템]
- GP = 1차 진료의 (감기, 몸살, 기본 진료)
- 모든 의료 = GP 먼저 → 필요시 전문의 소개
- 학생증/OSHC 카드 지참 필수

[GP 찾는 법]
- HotDoc 앱 또는 Google "Korean GP Sydney"
- 한국어 가능 GP 많음 (Strathfield, Eastwood)
- Bulk Billing GP = OSHC 100% 환급 = 본인 부담 0
- 예약 권장 (Walk-in 가능 클리닉도 있음)

[OSHC 환급]
- Bupa, Medibank, Allianz, NIB, AHM 5개 회사
- Bulk Billing = 즉시 처리 = 무료
- 본인 선납 = 영수증 → 앱 청구 → 5일~2주 환급

[처방약]
- GP 진료 후 처방전 발급
- 약국 (Pharmacy)에서 약 구매
- Chemist Warehouse 가장 저렴
- 학생 = PBS 안 되어 풀 가격
- 처방전 없는 약 (감기약, 진통제) = 약국 직접 구매

[응급 상황]
- 의식 잃음, 심한 출혈, 호흡 곤란 → 000 (구급차)
- 그 외 응급 → 공립병원 응급실 직접 방문
- 사립병원 응급실 = OSHC 환급 적음 = 비추

[지금 하실 것]
1. HotDoc 앱 다운로드
2. Bulk Billing + Korean speaking GP 검색
3. 가까운 곳 예약 또는 방문
4. OSHC 카드 + 여권 지참

호주 의료 시스템 적응에 시간 걸려요.
지금은 GP에 빨리 가시는 게 우선이에요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "OSHC = 무료"
- **거짓**. Bulk Billing GP만 100% 환급
- No Bulk Billing = 본인 선납 → 일부 환급
- 처방약, 전문의, 입원 = 차액 발생

### 함정 2: "Medicare = 학생도 가능"
- **거짓**. Medicare = 시민/PR만
- 학생 = OSHC만
- Bulk Billing은 Medicare 카드 환급 시스템이지만 OSHC도 일부 가능

### 함정 3: "한국 약 가져가도 돼"
- **부분 사실**. 처방약은 의사 처방전 영문 필수
- 마약류, 향정신성 = 신고 필수
- 한약 = 일부 식물 반입 금지
- TGA 사이트 확인

### 함정 4: "응급실 그냥 가면 돼"
- **부분 사실**. 공립병원만 가야 함
- 사립병원 응급실 = $1,000~3,000 청구
- 구급차 = 주별 다름 (VIC 유료, QLD 무료)

### 함정 5: "GP 진료 = 즉시"
- **거짓**. 예약 필수가 일반
- Walk-in 가능 GP도 있지만 대기 길음
- 인기 GP = 1주~2주 대기

### 함정 6: "전문의 바로 가도 돼"
- **거짓**. GP Referral 필수
- Referral 없이 가면 OSHC 환급 X
- Referral = 6개월~1년 유효

### 함정 7: "병원 = 24시간"
- **거짓**. GP는 영업시간만 (보통 9-5 또는 8-8)
- 야간 = After Hours GP 또는 응급실
- Nurse on Call (1300 60 60 24) = VIC 24시간 간호사 상담

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 현재 증상 + 정도
- 가벼움 (감기) → GP
- 중간 (고열, 통증) → GP 빨리 또는 응급
- 심함 (호흡곤란, 의식) → 000

### 2. OSHC 가입 여부 + 회사
- 미가입 = 즉시 가입 (학생비자 필수)
- 회사별 환급 비율 다름

### 3. 위치 (시/주)
- 가까운 GP 검색
- 한국어 가능 GP

### 4. 의료 이력
- 알레르기
- 현재 복용 약
- 과거 수술/입원
- 한국 진료 기록 영문 번역

---

## 🔍 직원이 직접 확인 가능한 사이트

- HotDoc: hotdoc.com.au (예약 앱)
- HealthEngine: healthengine.com.au
- Bupa: bupa.com.au/health-insurance/oshc
- Medibank: medibank.com.au/oshc
- Allianz Care: oshcallianzassistance.com.au
- NIB: nib.com.au/health-insurance/oshc
- AHM: ahm.com.au/oshc
- PBS: pbs.gov.au
- Healthdirect: healthdirect.gov.au (24시간 상담 1800 022 222)
- Nurse on Call (VIC): 1300 60 60 24

---

## 🚨 직원 영역 vs 의료진 영역

### 직원이 할 수 있는 것
- ✅ GP 시스템 설명
- ✅ OSHC 환급 안내
- ✅ 한국어 가능 GP 정보
- ✅ 응급실 가는 법
- ✅ 약국 시스템 설명

### 직원이 할 수 없는 것
- ❌ 의료 진단
- ❌ 약 추천
- ❌ 한국 약 호주 처방 변환
- ❌ 정신과 진료 권유
- ❌ 응급 상황 판단

---

## ✅ 완벽 응대 체크리스트

- [ ] 증상 정도 파악
- [ ] OSHC 가입 여부 확인
- [ ] 위치 (시/주) 확인
- [ ] GP 시스템 설명
- [ ] HotDoc 앱 안내
- [ ] 한국어 가능 GP 정보
- [ ] Bulk Billing 설명
- [ ] OSHC 환급 시스템 설명
- [ ] 약국 처방전 시스템 설명
- [ ] 응급 상황 000 안내
- [ ] 공립 vs 사립 병원 차이 설명
- [ ] 전문의 Referral 시스템 설명
- [ ] 진단/약 추천 = 안 함
- [ ] 응급 시 즉시 000

---

**작성**: ausuhak.com 직원 교육팀
**감수**: Wilson Kim (QEAC E240)
**기준**: 2026년 5월
**다음 업데이트**: OSHC 정책 변경 시
