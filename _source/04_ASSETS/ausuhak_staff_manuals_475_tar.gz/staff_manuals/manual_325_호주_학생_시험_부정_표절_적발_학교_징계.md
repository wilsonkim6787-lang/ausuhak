# #325 호주_학생_시험_부정_표절_적발_학교_징계

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 과제 표절로 학교에서 조사 받게 됐어요. 비자에 영향 있나요?"

**직원 멘붕 포인트:**
- 호주 학교 = Academic Misconduct (학업 부정) 매우 엄격
- 표절 = Turnitin 자동 검사
- 징계 = 0점 / 정학 / 퇴학
- 퇴학 = 학생비자 자동 취소 + PIC 4013
- 직원이 정확한 절차 + 변호사 안내 필요

---

## ❌ 절대 하지 말아야 할 답

> "표절은 별거 아니에요. 그냥 사과하면 돼요."

→ ❌ 호주 학교 = Academic Misconduct 매우 엄격. 0점/정학/퇴학 / 비자 영향 가능. 정식 절차 (Hearing) + 변호사 (학생 변론) 권장. 가볍게 안내 X.

---

## ✅ 정답

**Academic Misconduct (학업 부정) 종류:**

**1. Plagiarism (표절):**
- 인용 없이 출처 사용
- AI (ChatGPT) 활용 (선언 없이)
- Self-Plagiarism (본인 이전 과제 재사용)

**2. Collusion (공동 작업 부정):**
- 개별 과제를 공동으로 작성
- 시험 답안 공유

**3. Contract Cheating (대필):**
- 외부 대필 의뢰 (유료)
- Chegg / Course Hero 등 사용
- **가장 심각** = 자동 퇴학

**4. Exam Misconduct (시험 부정):**
- 시험 시간 외 자료 / 휴대폰
- 답안 베끼기
- 본인 외 응시 (대리)

**5. Data Fabrication (데이터 조작):**
- 연구 데이터 조작
- 가짜 출처

**Turnitin (자동 검사):**
- 모든 과제 자동 비교
- 5%~20% 일치 = 보통 정상 (인용)
- 30%+ = 경고
- 50%+ = 조사

**징계 단계:**

**1차 (경미):**
- 0점 (해당 과제만)
- 경고 + 교육
- 학생 기록

**2차 (중간):**
- 0점 (전체 과목)
- 정학 1학기
- 학생 기록

**3차 (심각):**
- 퇴학 (Expulsion)
- 학생비자 자동 취소
- 학력 취소

**Contract Cheating (자동 심각):**
- 첫 적발 = 퇴학 가능
- 형사 (NSW Education Standards Authority)

**조사 절차 (Academic Integrity Process):**

**1단계: 통지서 (Notification):**
- 교수 또는 학교 통지
- 부정 의혹 + 증거
- 학생 응답 기간 (10~14일)

**2단계: 응답 (Response):**
- 본인 의견 + 증거 + 변론
- 서면 + 면담 가능

**3단계: 청문회 (Hearing):**
- Academic Integrity Committee
- 본인 + 변호사/대리인 가능
- 증거 + 증인
- 결정

**4단계: 결정 (Decision):**
- 무혐의 / 경고 / 0점 / 정학 / 퇴학
- 항소 (Appeal) 가능 = 21일 이내

**비자 영향:**

**경미 (0점):**
- 비자 영향 X (학업 지속)
- 단, GPA 하락 가능

**중간 (정학):**
- 학업 중단 = 학생비자 영향 일부
- DHA Course Progress 보고
- 정학 후 복귀 = 비자 유지 가능

**심각 (퇴학):**
- 학생비자 자동 취소
- 28일 이내 출국 또는 다른 비자
- PIC 4013 (28일 초과 = 3년 입국 금지)
- ART 항소 가능

**변호사 / Student Advocacy:**

**Student Union Advocacy (무료):**
- 학생 조합 무료 변론
- 절차 안내 + 청문회 동행
- USyd / UNSW / UMelb 운영

**유료 변호사:**
- $200~$500/시간
- 청문회 변론
- ART 항소 (퇴학 시)

**한국 학생 ChatGPT 위험:**
- AI 사용 = 학교별 정책 다름
- 일부 학교 = 사용 가능 (선언 시)
- 일부 = 100% 금지
- AI 검사 도구 (GPTZero) 사용 증가
- 한국 학생 ChatGPT 의존 = 위험

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Turnitin 표절 검사**
자동 비교. 30%+ = 경고. 50%+ = 조사. 5%~20% = 정상 (인용).

**2. Contract Cheating**
외부 대필 의뢰. 첫 적발 = 퇴학 가능. 가장 심각.

**3. Academic Integrity Committee**
학교 학업 부정 위원회. 청문회 + 결정 + 항소.

**4. Course Progress (DHA)**
학생비자 = 학업 진행 의무. 정학/퇴학 = 영향.

**5. Student Union Advocacy**
학생 조합 무료 변론. 청문회 동행. USyd/UNSW/UMelb 등.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **통지서 정확히 분석** - 부정 의혹 + 증거 + 응답 기간
**2단계**: **Student Union 또는 변호사 상담** - 무료 또는 유료
**3단계**: **서면 응답 준비** - 본인 의견 + 증거 + 변론
**4단계**: **청문회 출석** - Academic Integrity Committee + 변론
**5단계**: **결정 + 항소 (필요 시)** - 21일 이내, 퇴학 = ART 추가

---

## 💡 직원이 학생한테 말할 멘트

> "호주 학교 학업 부정은 매우 엄격해서 표절/대필/시험 부정은 0점부터 퇴학까지 징계가 다양합니다. 청문회 절차가 있고 학생 본인 변론 + Student Union 무료 변론 또는 변호사 상담이 가능합니다. 퇴학 시 학생비자 자동 취소 + 28일 이내 출국 의무이고, ART 항소도 가능합니다. 통지서 받으셨다면 절대 무시하지 마시고, 응답 기간 10~14일 안에 변론 준비가 필수입니다. 통지서 + 상황 들려주시면 자세히 안내드립니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **표절 = 가벼운 일**
   → 호주 학교 = Academic Misconduct 매우 엄격. 0점/정학/퇴학.

2. **ChatGPT = 무조건 OK**
   → 학교별 정책 다름. AI 검사 도구 사용 증가. 선언 없이 사용 = 위험.

3. **Turnitin = 30% = 자동 부정**
   → 30% = 경고 단계. 50%+ = 조사. 인용 (Quotes/Citations) = 정상.

4. **청문회 = 변호사 의무**
   → 본인 변론 가능. Student Union = 무료. 단, 퇴학 위험 = 변호사 권장.

5. **Contract Cheating = 처음은 OK**
   → Contract Cheating = 첫 적발 = 퇴학 가능. NSW = 형사.

6. **퇴학 = 비자 영향 X**
   → 퇴학 = 학생비자 자동 취소. 28일 이내 출국 또는 다른 비자.

7. **학생 기록 = 사라짐**
   → Academic Misconduct = 학생 영구 기록. 다른 학교 이전 시 영향.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 통지서 + 부정 의혹 종류
2. 응답 기한 + 청문회 일정
3. Student Union / 변호사 상담
4. 변론 의지 + 학업 지속 의지

---

## 🔍 직원이 직접 확인 가능한 사이트

- USyd Academic Integrity: www.sydney.edu.au/students/academic-integrity
- UNSW Academic Misconduct: www.student.unsw.edu.au/academic-misconduct
- USyd Student Centre (SRC): www.src.usyd.edu.au
- ART Migration: www.art.gov.au
- TEQSA Academic Integrity: www.teqsa.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학업 부정 절차 일반 안내
- Student Union 무료 변론 안내
- 비자 영향 일반 정보

**MARA / 변호사 영역**
- 퇴학 + 비자 취소 = MARA + ART
- Contract Cheating 형사 = 변호사
- 비자 항소 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] 통지서 정확히 분석
- [ ] 응답 기한 + 청문회 안내
- [ ] Student Union 무료 변론 강조
- [ ] 변호사 권장 (퇴학 위험)
- [ ] 퇴학 = 비자 자동 취소 명시
- [ ] 주관적 평가 X (절차 정보만)
