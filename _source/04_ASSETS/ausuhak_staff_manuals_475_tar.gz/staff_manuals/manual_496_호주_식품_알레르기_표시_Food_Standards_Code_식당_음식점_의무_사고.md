# #496 호주_식품_알레르기_표시_Food_Standards_Code_식당_음식점_의무_사고

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한식당에서 음식 먹다가 심한 알레르기 반응 났어요. 식당이 알레르기 표시 안 했대요. 보상받을 수 있어요?"

**직원 멘붕 포인트:**
- Food Standards Code 1.2.3: 14개 알레르기 표시 의무
- 호주 모든 식당 (한식당 포함) 의무
- 표시 누락 + 알레르기 사고 = 식당 책임 (Civil/Criminal)
- Anaphylaxis 즉시 000 + EpiPen
- 한식당 표시 누락 흔함 → 직원이 사실 그대로 안내

---

## ❌ 절대 하지 말아야 할 답

> "한식당이라 알레르기 표시 안 해도 돼요"

→ ❌ Food Standards Code 모든 식당 의무. 한식당도 동일. 잘못 안내 시 학생 보상 기회 박탈

---

## ✅ 정답

호주 모든 식당은 Food Standards Code 1.2.3에 따라 14개 알레르기 표시 의무예요. 한식당도 예외 없습니다. 알레르기 사고 발생 시 응급실 영수증 + 진단서 + 식당 영수증/메뉴 사진 보관하세요. 식당 책임 청구 가능하고, 심각한 경우 변호사 자문 권장합니다. 식품 안전 신고는 NSW Food Authority 1300 552 406, 다른 주는 각 주 보건부예요. 동시에 ASCIA Action Plan 작성하시고 EpiPen 처방받으세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Food Standards Code 14개 의무 표시**
1. 글루텐 (밀/보리/호밀/귀리)
2. 갑각류 (새우/게/랍스터)
3. 계란
4. 생선
5. 우유 (유제품)
6. 견과류 (호두/아몬드/캐슈)
7. 땅콩
8. 참깨
9. 대두
10. 루핀
11. 황산염 (10mg/kg+)
12. 갑각류 (조개)
13. 셀러리
14. 머스타드

**2. 호주 식당 의무 (Food Act)**
메뉴/메뉴판/주문 시 알레르기 정보 제공
직원 교육 의무 (Allergen Aware)
교차 오염 방지 (별도 도구/팬)
고객 알레르기 문의 시 정확한 답변
위반 시:
- 식당 벌금 ($550~$110,000)
- 매장 폐쇄 가능
- 사고 시 형사 처벌

**3. 알레르기 사고 시 즉시 대응**
1. 000 (Triple Zero) 즉시
2. EpiPen (있으면)
3. 응급실 4시간 관찰
4. 식당 영수증 + 메뉴 사진 보관
5. 응급실 영수증 + 진단서 보관
6. 식품 신고 (NSW Food Authority)
7. 변호사 자문 (Civil Lawsuit)

**4. 식품 안전 신고 (각 주)**
NSW Food Authority: 1300 552 406
VIC: foodsafety.vic.gov.au
QLD: health.qld.gov.au
SA/WA/TAS/ACT/NT: 각 주 Health Department
신고 시 식당 조사 + 시정 명령
위반 확인 시 식당 벌금

**5. 보상 청구 (Civil Lawsuit)**
Negligence + Breach of Statutory Duty
보상 청구:
- 응급실 비용 (OSHC 미커버 부분)
- EpiPen 비용 ($120~$160/개)
- 통증/고통 (Pain and Suffering)
- Loss of Earnings
Limitation Act NSW: 시효 3년
Civil Lawyer 자문 ($300~$500/시간)
심각 사례는 Class Action 가능

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 응급실 + EpiPen 영수증 + 진단서 보관
**2단계**: 식당 영수증 + 메뉴 사진 + 위치 정보 보관
**3단계**: NSW Food Authority 또는 해당 주 신고
**4단계**: ASCIA Action Plan GP 발급
**5단계**: 심각 사례 시 Civil Lawyer 자문

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주 모든 식당은 Food Standards Code 1.2.3 따라 14개 알레르기 표시 의무라 한식당도 예외 없어요. 응급실/식당 영수증 + 진단서 보관하시고, NSW Food Authority 1300 552 406에 신고하세요. 식당 책임 청구 가능합니다. ASCIA Action Plan + EpiPen 처방도 받으세요. 자세한 보상 절차는 Civil Lawyer 자문 권장하고, 카카오 ID studywilson 으로 1차 안내 가능해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한식당 알레르기 표시 X**
   → Food Standards Code 모든 식당 의무

2. **응급실 영수증 안 보관 X**
   → 보상 청구 증거

3. **식품 신고 X**
   → 신고 안 하면 식당 시정 안 됨

4. **OSHC가 모든 비용 X**
   → OSHC 응급실 OK but EpiPen $120~$160 일부

5. **ASCIA Plan 안 만듦 X**
   → 재발 방지 + 학교 신고 필수

6. **변호사 비용 부담 X**
   → 심각 사례는 No Win No Fee 변호사

7. **한국 가족 법적 X**
   → 호주 사고 한국 가족 청구 권한 X

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 응급실 갔어요? (예/아니오)
2. EpiPen 사용했어요? (예/아니오)
3. 식당 영수증 + 메뉴 보관? (했다/안 했다)
4. 심각도? (경미/중증 응급)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Food Standards Code: foodstandards.gov.au
- NSW Food Authority: 1300 552 406
- VIC Food Safety: foodsafety.vic.gov.au
- ASCIA Plan: allergy.org.au
- Anaphylaxis Australia: 1300 728 000

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 알레르기 표시 의무 안내
- 신고 절차 안내
- ASCIA Plan 안내
- 1차 보상 절차 안내

**MARA / 변호사 영역**
- Civil Lawsuit (Civil Lawyer)
- Class Action 동참 (Class Action Lawyer)
- OSHC 보험금 분쟁 (PHIO)
- 비자 의료 신고 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 응급실 + EpiPen 영수증 보관
- [ ] 식당 영수증 + 메뉴 사진
- [ ] Food Authority 신고
- [ ] ASCIA Plan 발급
- [ ] Civil Lawyer 자문 (심각 사례)
