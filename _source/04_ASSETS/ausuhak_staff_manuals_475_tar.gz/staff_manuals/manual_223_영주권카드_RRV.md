# #223 영주권 카드 (대신 RRV)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 영주권 받았는데 영주권 카드 어디서 발급받나요? 한국 외국인등록증 같은 거요."

**직원 멘붕 포인트:**
- 호주 영주권 카드 X
- 여권에 라벨 (예전) / 디지털 (2015년 이후)
- VEVO로 확인

---

## ❌ 절대 하지 말아야 할 답

> "영주권 카드 가까운 동사무소에서 받으세요!"

→ ❌ **호주 = 영주권 카드 X**. 여권에 라벨 / VEVO 디지털 확인.

---

## ✅ 정답

호주 영주권 카드: ① **호주 영주권 카드 X** (한국 외국인등록증 같은 카드 없음) ② **여권 라벨 (Visa Label)** = 2015년 이전 / 여권 페이지에 도장 ③ **2015년 이후 = 디지털 (Visa Grant Notification)** = 이메일로 결정 통보 ④ **VEVO** (Visa Entitlement Verification Online) = 영주권 상태 디지털 확인 ⑤ **고용주 / 학교 / 은행** = VEVO Reference Number로 확인 ⑥ **5년 후 RRV (Resident Return Visa)** = 출입국 권리 갱신.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 영주권 시스템
- **물리적 카드 X**
- 여권 라벨 (2015년 이전) / 디지털 (이후)
- 결정 통보 = DHA 이메일 (Visa Grant Notification)

### 2. VEVO (Visa Entitlement Verification Online)
- 사이트: https://immi.homeaffairs.gov.au
- 비자 정보 디지털 확인
- 본인 확인 + 제3자 (고용주 / 학교) 확인 가능
- 무료

### 3. Visa Grant Notification 보관
- 영주권 결정 통보 이메일 = 영구 보관
- PDF 인쇄 / 클라우드 저장 권장
- 분실 시 = DHA 재발급 신청 ($65 AUD)

### 4. 신분증 (호주 거주 시)
- **운전면허** (각 주 발급)
- **여권** (한국 / 호주)
- **Medicare 카드** (영주권자 자동 가능)
- **NSW Photo ID Card** (운전면허 X 시) - 다른 주 비슷

### 5. 5년 후 RRV
- 영주권 라벨 5년 만료
- RRV 신청 (5년 갱신)
- 5년 중 호주 거주 2년 시 자동

---

## 🎯 정답 경로

### Step 1: 영주권 결정 통보 확인
- DHA 이메일 / Visa Grant Notification
- PDF 보관

### Step 2: VEVO 등록
- 본인 비자 정보 확인
- VEVO Reference Number 받기

### Step 3: 신분증 발급
- 운전면허 (주별)
- Medicare 카드

### Step 4: 5년 후 RRV
- 영주권 라벨 만료 전 신청

---

## 💡 직원 멘트

> "안녕하세요! 호주 영주권 카드 안내드릴게요.
>
> ✅ 호주 영주권 카드 = X (한국과 다름)
> ✅ 여권 라벨 (2015년 이전) / 디지털 (이후)
> ✅ VEVO = 비자 디지털 확인
> ✅ 신분증 = 운전면허 / Medicare 카드
> ✅ 5년 후 RRV 갱신
>
> 영주권 결정 이메일 (Visa Grant Notification) PDF로 보관하세요!
>
> 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 5개

1. ❌ "영주권 카드 발급" → ✅ 호주 = 카드 X
2. ❌ "여권 라벨 = 매 5년 갱신" → ✅ 2015년 이후 = 디지털
3. ❌ "VEVO = 유료" → ✅ 무료
4. ❌ "Medicare 카드 = 영주권 카드" → ✅ Medicare = 의료 카드 (영주권 X)
5. ❌ "RRV = 카드 발급" → ✅ RRV = 디지털

---

## 📞 필수 3가지 확인

1. ✅ 영주권 결정 시점 / 종류
2. ✅ Visa Grant Notification PDF 보관 안내
3. ✅ VEVO / 신분증 안내

---

## 🔍 직원 사이트

- **VEVO**: https://immi.homeaffairs.gov.au
- **Medicare**: https://www.servicesaustralia.gov.au/medicare
- **각 주 운전면허**: 주별

---

## 🚨 직원 vs 윌슨

**직원**: 영주권 카드 X / VEVO 안내
**윌슨**: 영주권 후 진로 (시민권 / 가족 / 학교)

---

## ✅ 체크리스트

- [ ] 영주권 카드 X 명시
- [ ] Visa Grant Notification PDF 보관
- [ ] VEVO 등록 안내
- [ ] Medicare / 운전면허 안내
- [ ] 5년 RRV 안내
