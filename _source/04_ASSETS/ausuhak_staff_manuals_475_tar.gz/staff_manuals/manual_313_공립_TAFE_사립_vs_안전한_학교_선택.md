# #313 공립_TAFE_사립_vs_안전한_학교_선택

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "유학원 추천 사립 학교 학비 싸고 IELTS 5.5만 요구해요. 공립 TAFE랑 어떻게 다른가요?"

**직원 멘붕 포인트:**
- 사립 학교 = 일부 불인증 / 영주권 어려움 / 부도 위험
- 공립 TAFE = 정부 운영 (NSW/VIC/QLD/SA/WA/TAS) 안전
- 사립 = 학비 저렴 + 입학 쉬움 BUT 인증 X 위험
- 학과별 인증 (ANMAC/CRICOS/TEQSA/ASQA) 차이 큼
- 직원이 잘못 안내 시 학생 큰 손해

---

## ❌ 절대 하지 말아야 할 답

> "사립이든 공립이든 CRICOS 등록만 되어 있으면 다 같아요."

→ ❌ CRICOS = 학생비자 발급 등록만. 사립 일부 = 인증 부족 (ANMAC 미인증, 학력 인정 어려움). 공립 TAFE = 정부 운영 안전. 사립 일부 = 부도 + 학비 환불 분쟁 위험. 인증 + 평판 + 학과별 차이 명확히 안내 필요.

---

## ✅ 정답

**호주 학교 분류 (한국 학생 자주 혼동)**

**공립 (Government):**
1. **University (Go8 + 일반 공립대)** - 38개 (Group of Eight + 그 외)
2. **TAFE (Technical and Further Education)** - 정부 직영
   - TAFE NSW, TAFE QLD, TAFE SA, TAFE WA, TasTAFE
   - VIC = Holmesglen, Chisholm, Gordon, William Angliss (정부)
3. **Foundation Colleges** - 대학 부속 (USyd Foundation 등)

**사립 (Private):**
1. **Private Universities** - 6개만 (ACU, Notre Dame, Bond, Torrens, Avondale, ICMS)
2. **Private RTO (Registered Training Organisation)** - 수천 개
   - 호주 정부 ASQA 등록
   - 학과별 인증 다름 (ANMAC/Engineers Aus 등)
3. **English Language Schools (ELICOS)** - 수백 개

**한국 학생 자주 혼동 (Important):**
- **Holmesglen, Chisholm, Gordon, William Angliss** = **정부 TAFE** (사립 X)
- **BROWNS English Language School** = ELICOS (사립)
- **Charlton Brown** = 사립 (BROWNS와 별개)
- 학생 안전 = 정부 TAFE > 공립대 > 인증 사립대 > 사립 RTO

**위험 신호 (사립 RTO 일부):**
1. IELTS 매우 낮음 (5.5 미만)
2. 학비 매우 저렴 ($10K 이하 = 의심)
3. 입학 시험/면접 X
4. 학교 졸업 = PR 보장 (허위)
5. ASQA 등록 검색 X
6. 인증 (ANMAC 등) X

**학교 안전성 검증:**
- ASQA: training.gov.au (RTO 등록 확인)
- TEQSA: www.teqsa.gov.au (대학 등록)
- CRICOS: cricos.education.gov.au (학생비자 발급)
- ANMAC: www.anmac.org.au (간호)
- ASIC: asic.gov.au (회사 등록 + 부도 정보)

**부도 위험 (사립 일부):**
- ESOS Act + TPS (Tuition Protection Service) 환불 보호
- 학비 환불 / 다른 학교 전학
- 단, 신청 + 시간 + 학습 시간 손실

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ASQA (Australian Skills Quality Authority)**
정부 RTO 등록 기관. training.gov.au에서 RTO 검색 가능.

**2. TEQSA (Tertiary Education Quality Standards Agency)**
대학/사립대 등록 기관. www.teqsa.gov.au.

**3. TPS (Tuition Protection Service)**
학교 부도 시 학생 보호. 학비 환불 또는 다른 학교 전학 보장.

**4. Group of Eight (Go8)**
Go8 (Group of Eight, 호주 8개 연구중심대학). UMelb, USyd, ANU, UQ, UWA, Adelaide, Monash, UNSW.

**5. 정부 TAFE 5개 + 멜번 4개**
TAFE NSW/QLD/SA/WA/TAS + Holmesglen/Chisholm/Gordon/William Angliss = 모두 정부.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **관심 학교 등록 확인** - ASQA (RTO) 또는 TEQSA (대학) 직접 확인
**2단계**: **학과별 인증 확인** - ANMAC (간호) / Engineers Aus (공학) / 직종별
**3단계**: **평판 검토** - 학교 졸업생 후기 / 한국 학생 커뮤니티 / 윌슨 950명 동문
**4단계**: **위험 신호 점검** - IELTS 매우 낮음 / 학비 매우 저렴 / PR 보장 광고
**5단계**: **최종 선택** - 정부 TAFE > 공립대 > 인증 사립대 > 사립 RTO 순

---

## 💡 직원이 학생한테 말할 멘트

> "공립 TAFE (정부) vs 사립 RTO 차이는 매우 큽니다. 공립 TAFE = NSW/QLD/SA/WA/TAS + Holmesglen/Chisholm/Gordon/William Angliss (멜번)이고, 안전합니다. 사립 RTO = 일부만 인증 (ANMAC/Engineers Aus 등)이고, IELTS 5.5 미만 + 학비 매우 저렴 + PR 보장 광고는 위험 신호입니다. 학교 선택 시 ASQA/TEQSA 등록 + 학과 인증 직접 확인이 필수입니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **CRICOS 등록 = 다 안전**
   → CRICOS = 학생비자만. 학과 인증 + 졸업장 인정 별개.

2. **Holmesglen = 사립**
   → Holmesglen = 정부 TAFE Victoria. 사립 X.

3. **사립 RTO = 졸업 후 PR 보장**
   → PR 보장 = 호주 정부만 결정. 학교 보장 = 허위 광고.

4. **학비 싼 학교 = 좋은 선택**
   → 학비 매우 저렴 = 인증 X 의심 신호.

5. **IELTS 5.5 학교 = 영어 쉬워서 좋다**
   → 간호 등 = IELTS 7.0 절대. 5.5 학교 = 졸업 후 면허/취업 어려움.

6. **학교 부도 시 학비 다 잃음**
   → TPS 보호. 학비 환불 또는 전학 보장. 단, 시간 손실.

7. **BROWNS = 사립 RTO**
   → BROWNS = ELICOS (영어 학교). Charlton Brown과 별개. 혼동 주의.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 관심 학교 정확한 영문명
2. 학과 (간호/IT/요리/Trade 등)
3. 현재 영어 점수 (IELTS 등)
4. 학비 + 기간 (학교 안내 자료)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ASQA RTO 검색: training.gov.au
- TEQSA 대학 검색: www.teqsa.gov.au
- CRICOS 검색: cricos.education.gov.au
- ANMAC (간호): www.anmac.org.au
- ASIC (회사 등록): asic.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 공립 TAFE 정부 학교 일반 안내
- 정부 vs 사립 차이 일반 정보
- 윌슨 950명 동문 학교 평판 정보

**MARA / 변호사 영역**
- 사립 학교 부도 분쟁 = ESOS Act + 변호사
- TPS 환불 거절 항소 = 변호사
- 사립 학교 졸업 후 PR 거절 = MARA
- 학교 사기 의심 = 호주 변호사 + 신고

---

## ✅ 완벽 응대 체크리스트

- [ ] 공립 vs 사립 차이 명확히 설명함
- [ ] Holmesglen/Chisholm/Gordon/William Angliss = 정부 TAFE 정정함
- [ ] 정부 TAFE > 공립대 > 인증 사립대 > 사립 RTO 순서 안내함
- [ ] ASQA/TEQSA/ANMAC 직접 검색 안내함
- [ ] 위험 신호 6가지 설명함
- [ ] TPS 부도 보호 안내함
- [ ] 윌슨 1:1 상담 권장함
