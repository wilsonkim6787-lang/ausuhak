# #472 호주_학생_시험_부정행위_Cheating_적발_Examination_Misconduct_퇴학

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "기말고사 보다가 휴대폰 화장실에서 봤어요. 시험감독관이 적발했어요. 학교에서 조사 들어간대요. 어떻게 해야 해요?"

**직원 멘붕 포인트:**
- 시험 부정행위 = Examination Misconduct = Plagiarism보다 더 무거운 처벌
- 휴대폰 = Unauthorized Material 적발 = Tier 3~4 (정학~퇴학) 가능성 높음
- 학생비자 즉시 위험. Course Fail → Section 19 → 비자 취소 28일 응답
- 한국식 '한 번 봐달라' 통하지 않음. 호주 대학 시험 부정행위 Zero Tolerance
- 직원이 '벌금이나 경고 정도일 거예요' 위로하면 안 됨

---

## ❌ 절대 하지 말아야 할 답

> "아 그 정도는 경고만 받고 끝날 거예요 휴대폰 본 정도는 별거 아니에요"

→ ❌ 휴대폰 시험장 반입+사용은 호주 대학 가장 무거운 위반. 1차 위반도 바로 Tier 4 (퇴학) 가능. 위로 X

---

## ✅ 정답

학교에서 정식 조사 들어가는 사안이라 가장 먼저 Student Advocacy Service에 연락해서 Hearing 동행 요청하세요. 응답 기한 놓치면 자동 유죄 처분이라 기한 확인 필수입니다. 동시에 윌슨샘과 카카오 1:1 상담 잡아서 비자 영향 점검합니다. 학교 응답서 제출 전에 절대 단독으로 답변하지 마세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Examination Misconduct 종류**
1. Unauthorized Material: 휴대폰/스마트워치/노트 반입
2. Communication: 다른 학생과 답 공유
3. Impersonation: 대리 시험 (가장 중죄, 즉시 퇴학+법적 처벌)
4. Disruptive Behaviour: 시험장 소란
5. Failure to Follow Instructions: 시험관 지시 거부
휴대폰 화장실에서 봤다 = #1 + 정황상 Cheating 추정

**2. 처벌 수위 (시험 부정행위)**
Plagiarism보다 한 단계 무거움
Tier 1 (경고): 거의 없음
Tier 2 (시험 0점): 가벼운 경우
Tier 3 (Course Fail + 정학 1~2학기): 표준
Tier 4 (Exclusion 퇴학): Communication/Impersonation
Impersonation은 Federal Court 형사 처벌 가능

**3. Hearing 절차 (호주 대학 표준)**
1. Notice of Allegation 메일 (5~10일 응답)
2. Written Statement 제출 (학생 진술)
3. Academic Integrity Hearing (대면 또는 Zoom)
4. Decision Letter (Tier 1~4 처분)
5. Appeal (14~21일, Final Internal Decision)
6. Ombudsman (NSW: NSW Ombudsman, VIC: VICO)

**4. 학생비자 Section 19 Report**
Course Fail = Unsatisfactory Course Progress
Course Exclusion = Cancellation of Enrolment
둘 다 PRISMS Section 19 Report 대상
→ Department 통보
→ Section 116 NOICC 28일 응답
응답 안 하면 비자 자동 취소 + 출국 명령

**5. Mitigating Factors (감경 사유)**
Hearing에서 주장 가능한 감경 사유:
1. First Offence (1차 위반)
2. Mental Health 진단서 (시험 당시)
3. Family Emergency 증빙
4. Genuine Misunderstanding (영어 부족 증명)
5. Voluntary Disclosure (적발 전 자수)
휴대폰 화장실 케이스는 #2~#3이 유일한 활로

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Notice of Allegation 메일 응답 기한 확인 → 캘린더 알람
**2단계**: Student Advocacy Service 즉시 연락 → Hearing 동행 + 진술서 작성 자문
**3단계**: Mitigating Factors 증빙 수집 (의료 진단서/가족 위급 증빙)
**4단계**: Hearing 출석 → Tier 협상 (Tier 4 → Tier 3 격하 목표)
**5단계**: 결과에 따라 윌슨샘 카카오 1:1 상담 → Appeal/비자 대응 결정

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요 학생님. 시험 중 휴대폰 적발은 매우 무거운 사안이에요. 학교 Student Advocacy Service에 즉시 연락해서 Hearing 동행 요청부터 해주세요. 응답 기한 놓치면 자동 유죄 처분됩니다. 비자 영향 부분은 윌슨샘과 1:1 상담 잡아드릴게요. 카카오 ID studywilson 입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'화장실에서 봤다' = 의도적 Cheating 자백**
   → 단순 반입(시험장 책상 위)보다 화장실 사용이 더 무거움. 의도적 부정행위로 해석. 진술서에서 단어 선택 신중

2. **'한국에서는 휴대폰 시험장 반입 OK' 변명 X**
   → 호주 대학은 시험 시작 전 모든 휴대폰/스마트워치 별도 보관 안내. 무지가 변명 안 됨

3. **'다른 학생도 했다' 변명 X**
   → 호주 대학은 'Other Students Did It Too' 변명 무시. 본인 책임만 다룸

4. **진술서 단독 제출 X**
   → Student Advocacy 검토 없이 단독 제출하면 본인 자백서가 됨. 반드시 자문 받고 제출

5. **Appeal 기한 놓침 = 끝**
   → Decision Letter 받고 14~21일 Appeal 기한. 놓치면 Final 처분 확정. 비자 취소 절차 진입

6. **부모 동행 무의미**
   → 호주 대학 18세 이상 본인만 응대. 부모 카카오 X. Student Advocacy가 정답

7. **'급한 카톡 확인'은 변명 안 됨**
   → 시험 중 휴대폰 사용은 이유 불문 부정행위. 가족 위급도 시험 후 확인 원칙

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Notice of Allegation 메일 받았어요? (받음 / 아직)
2. 응답 기한 며칠 남았어요? (5일 이상 / 5일 미만)
3. 휴대폰에서 시험 관련 검색/연락 한 흔적 있어요? (있다 / 없다)
4. 시험 당시 의료/가족 위급 같은 사유 있어요? (있다 / 없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Sydney Misconduct: sydney.edu.au/students/misconduct
- UNSW Examination: student.unsw.edu.au/exams
- Monash Examination: monash.edu/exams
- NSW Ombudsman: ombo.nsw.gov.au
- VIC Ombudsman: ombudsman.vic.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 응답 기한 안내
- Student Advocacy 연결
- Mitigating Factors 증빙 코칭
- Tier 협상 전략 자문

**MARA / 변호사 영역**
- Section 116 NOICC 응답서 (MARA)
- ART 비자 취소 이의 신청 (Lawyer)
- Federal Court Judicial Review (Lawyer)
- 재학 중 비자 변경 옵션 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 응답 기한 캘린더 알람 설정
- [ ] Student Advocacy Service 연락 완료
- [ ] Mitigating Factors 증빙 수집 완료
- [ ] 진술서 Student Advocacy 검토 후 제출
- [ ] 윌슨샘 비자 영향 1:1 상담 예약
