# #463 호주_학생_응급_의료_알레르기_EpiPen_Anaphylaxis_OSHC_처방전

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 땅콩 알레르기 심해서 한국에서 EpiPen 가지고 왔어요. 그런데 1년 후에 유효기간 끝나면 호주에서 어떻게 받나요? OSHC 처방전 가능한가요? 가격이 한국과 다른가요? 그리고 식당에서 실수로 땅콩 들어간 음식 먹어서 응급실 가면 OSHC 커버 되나요?"

**직원 멘붕 포인트:**
- EpiPen = 호주 처방전 의약품 (Schedule 4)
- OSHC PBS Schedule 1 일부 커버 ($31.60 처방전 환자 부담금)
- 응급실(ER) = Medicare X / OSHC 100% 커버 (Direct Billing)
- Anaphylaxis = 즉시 EpiPen + 000 호출 (생명 위급)
- ASCIA Action Plan(호주 알레르기 학회) 영문 작성 권장
- 학교 보건실 EpiPen 공동 사용 가능

---

## ❌ 절대 하지 말아야 할 답

> "알레르기 심하면 호주 살기 어려워요"

→ ❌ 호주 알레르기 의료 시스템 발달 / EpiPen 처방전 + OSHC + ASCIA Action Plan / 응급 시 OSHC 100% 커버 / 정확한 안내 시 안심

---

## ✅ 정답

(1) GP 방문 → EpiPen 처방전 (2) Pharmacy에서 EpiPen 2개 구입 - $31.60 PBS / OSHC 처방전 환자 부담금 (3) ASCIA Action Plan 영문 작성 - allergy.org.au 무료 (4) 학교 보건실 등록 - EpiPen 보관 (5) 응급 시 EpiPen → 000 → 응급실 / OSHC Direct Billing 100%

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. EpiPen 호주 처방 (PBS Schedule 1)**
Schedule 4 처방전 의약품 / GP 처방 / Pharmacy 구매 / PBS(Pharmaceutical Benefits Scheme) Concession Card $7.70 / General $31.60 / 학생비자 OSHC 일부 환급 / 유효기간 12~18개월 / 만료 시 재처방 무료(GP).

**2. Anaphylaxis 응급 대응 (5분)**
(1) EpiPen 허벅지 외측 주사(옷 위로 OK) (2) 누워서 다리 올림(쇼크 방지) (3) 000 즉시 / 'Anaphylaxis' 명시 (4) 5분 후 호전 X = EpiPen 2번째 (5) 호흡 정지 시 CPR / 학교/직장 EpiPen 위치 사전 파악.

**3. OSHC 응급실 커버**
Bupa/Medibank/Allianz/NIB/AHM 5개사 / 응급실 100% 커버(Direct Billing 호주 공립) / 사립 병원 일부 본인부담 / Ambulance NSW $400~$1,000 (학생 OSHC 일부) / VIC/QLD/SA/WA 무료(주민 한정) / 학생비자는 일부 본인부담.

**4. ASCIA Action Plan**
Australasian Society of Clinical Immunology and Allergy / allergy.org.au / 영문 무료 다운로드 / 알레르기 환자 응급 계획 / EpiPen 사용법 + 응급 연락처 / 학교/직장 제출 / 사진 부착 / 의사 서명 필요.

**5. 학교 보건실 EpiPen 등록**
초중고 = 학교 EpiPen 1~2개 비축(Anaphylaxis Action Plan 정책) / 대학 = 학생 본인 휴대 / 학교 보건실 등록 시 위급 시 학교 직원 사용 가능 / 본인 가방 항상 휴대 권장.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: GP 방문 (한국 EpiPen 보여주기) - 처방전 발급
**2단계**: 2차: Pharmacy(Chemist Warehouse 등) EpiPen 2개 구입 - $31.60 PBS
**3단계**: 3차: ASCIA Action Plan 영문 작성 - allergy.org.au + GP 서명
**4단계**: 4차: 학교 보건실 등록 + 응급 연락처 - 룸메이트/친구 알림
**5단계**: 5차: 응급 발생 시 EpiPen → 000 → 응급실 / OSHC Direct Billing

---

## 💡 직원이 학생한테 말할 멘트

> "호주 알레르기 의료 시스템 잘 되어있어서 안심하세요. EpiPen은 GP 처방전 → Pharmacy 구입($31.60 PBS, OSHC 일부 환급)입니다. ASCIA Action Plan(allergy.org.au) 영문 무료 다운로드 + GP 서명 후 학교/직장 제출하시고요. 응급 발생 시 EpiPen 즉시 + 000 호출 + 응급실 OSHC 100% 커버됩니다(Ambulance 본인부담 일부). 학교 보건실 등록 권장합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 EpiPen 직접 사용**
   → 한국 처방전 EpiPen = 호주 사용 OK / 단, 만료 후 재처방 = 호주 GP 필요 / 공항 신고 시 처방전 영문 동행.

2. **PBS Concession Card 학생비자 X**
   → Concession Card = PR/시민권만 / 학생비자 = General Patient $31.60 / OSHC 일부 환급.

3. **Ambulance NSW 학생 본인부담**
   → NSW $400~$1,000 / Membership 가입 $80/년 = 무료 / VIC/QLD 주민 무료 / 학생 = 본인부담 / OSHC 일부 환급.

4. **응급실 vs GP**
   → Anaphylaxis = 즉시 응급실 / GP X / EpiPen 사용 후 4~6시간 관찰 필수(Biphasic Reaction).

5. **학교 보건실 EpiPen 사용**
   → 학교 EpiPen = 학교 정책에 따라 학생 사용 가능 / 단, ASCIA Action Plan 등록 / 미등록 시 학교 직원 사용 못 할 수 있음.

6. **OSHC Pre-existing Condition**
   → 기존 알레르기 = Pre-existing 12개월 대기 가능 / 응급 처치는 첫날부터 / 일반 처방 12개월 대기 / Bupa/Medibank 정책 다름.

7. **EpiPen 휴대 의무 X (의무 X 강력 권장)**
   → 법적 의무 X / 학생 본인 책임 / 가방/허리 파우치 항상 / 친구/룸메이트 알림 / 비행기 휴대 가능(처방전 영문).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. (
2. 1
3. )
4.  
5. 알
6. 레
7. 르
8. 기
9.  
10. 종
11. 류
12. /
13. 심
14. 각
15. 도
16. ?
17.  
18. (
19. 2
20. )
21.  
22. 한
23. 국
24.  
25. E
26. p
27. i
28. P
29. e
30. n
31.  
32. 잔
33. 여
34.  
35. 갯
36. 수
37. /
38. 유
39. 효
40. 기
41. 간
42. ?
43.  
44. (
45. 3
46. )
47.  
48. O
49. S
50. H
51. C
52.  
53. 가
54. 입
55. 사
56. ?
57.  
58. (
59. 4
60. )
61.  
62. 학
63. 교
64. /
65. 직
66. 장
67.  
68. A
69. S
70. C
71. I
72. A
73.  
74. A
75. c
76. t
77. i
78. o
79. n
80.  
81. P
82. l
83. a
84. n
85.  
86. 제
87. 출
88.  
89. 여
90. 부
91. ?

---

## 🔍 직원이 직접 확인 가능한 사이트

- ASCIA(allergy.org.au), Anaphylaxis Australia(allergyfacts.org.au), HealthDirect(healthdirect.gov.au), PBS(pbs.gov.au), TGA(tga.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- EpiPen 호주 처방 / OSHC 응급 커버 / ASCIA Action Plan / 학교 보건실 등록 / Ambulance 비용 / 응급 시 000 안내

**MARA / 변호사 영역**
- 응급 후 비자 영향(거의 X) → 변호사 / 의료 사고 → 변호사 / OSHC 분쟁 → Private Health Insurance Ombudsman 1300 362 072

---

## ✅ 완벽 응대 체크리스트

- [ ] □
- [ ]  
- [ ] E
- [ ] p
- [ ] i
- [ ] P
- [ ] e
- [ ] n
- [ ]  
- [ ] G
- [ ] P
- [ ]  
- [ ] 처
- [ ] 방
- [ ]  
- [ ] 안
- [ ] 내
- [ ]  
- [ ] □
- [ ]  
- [ ] P
- [ ] B
- [ ] S
- [ ]  
- [ ] $
- [ ] 3
- [ ] 1
- [ ] .
- [ ] 6
- [ ] 0
- [ ]  
- [ ] 안
- [ ] 내
- [ ]  
- [ ] □
- [ ]  
- [ ] A
- [ ] S
- [ ] C
- [ ] I
- [ ] A
- [ ]  
- [ ] A
- [ ] c
- [ ] t
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] P
- [ ] l
- [ ] a
- [ ] n
- [ ]  
- [ ] 영
- [ ] 문
- [ ]  
- [ ] □
- [ ]  
- [ ] 학
- [ ] 교
- [ ]  
- [ ] 보
- [ ] 건
- [ ] 실
- [ ]  
- [ ] 등
- [ ] 록
- [ ]  
- [ ] □
- [ ]  
- [ ] 응
- [ ] 급
- [ ]  
- [ ] 시
- [ ]  
- [ ] 0
- [ ] 0
- [ ] 0
- [ ]  
- [ ] +
- [ ]  
- [ ] E
- [ ] p
- [ ] i
- [ ] P
- [ ] e
- [ ] n
- [ ]  
- [ ] □
- [ ]  
- [ ] O
- [ ] S
- [ ] H
- [ ] C
- [ ]  
- [ ] 응
- [ ] 급
- [ ] 실
- [ ]  
- [ ] 1
- [ ] 0
- [ ] 0
- [ ] %
- [ ]  
- [ ] □
- [ ]  
- [ ] A
- [ ] m
- [ ] b
- [ ] u
- [ ] l
- [ ] a
- [ ] n
- [ ] c
- [ ] e
- [ ]  
- [ ] 본
- [ ] 인
- [ ] 부
- [ ] 담
- [ ]  
- [ ] 일
- [ ] 부
