# 📚 직원 응대 매뉴얼 #042

**케이스: IT (Software / Cyber Security / Data) PR 종합**

---

## 🎬 상황 시뮬레이션

> 호주 IT 영주권 가능한 직업 다 알려주세요. 백엔드, 프론트, 클라우드, 사이버 시큐리티, 데이터 등 다양해서요.

**👉 정답**: **IT는 MLTSSL 직업군 (MLTSSL) - ACS Skills Assessment + Master 또는 학사 + 경력**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ IT 직업군 PR 매트릭스

| 직업 | ANZSCO | 평균 연봉 | PR 리스트 |
|---|---|---|---|
| Software Engineer | 261313 | $90K~$140K | MLTSSL |
| Software Tester | 261314 | $80K~$120K | MLTSSL |
| Developer Programmer | 261312 | $85K~$130K | MLTSSL |
| Systems Analyst | 261112 | $90K~$130K | MLTSSL |
| ICT Business Analyst | 261111 | $90K~$130K | MLTSSL |
| Cyber Security Analyst | 262112 | $100K~$150K | MLTSSL |
| Cyber Security Architect | 262113 | $120K~$180K | MLTSSL |
| Database Administrator | 262111 | $90K~$130K | MLTSSL |
| Data Scientist | 224711 | $100K~$150K | MLTSSL |
| Network Engineer | 263111 | $90K~$130K | MLTSSL |
| Computer Network and Systems Engineer | 263113 | $90K~$130K | MLTSSL |
| Web Developer | 261212 | $70K~$110K | STSOL |
| Multimedia Specialist | 261211 | $70K~$100K | STSOL |
| ICT Project Manager | 135112 | $110K~$160K | MLTSSL |

### 2️⃣ IT 표준 경로

```
한국 IT 학사 (또는 경력)
        ↓
[옵션 A: Master 추가] Master IT/Computing 1.5~2년
[옵션 B: 직접] 호주 IT 회사 취업 (스폰서)
        ↓
ACS (Australian Computer Society) Skills Assessment
        ↓
EOI 점수 90+ → 189/190/491 PR
```

### 3️⃣ ACS Skills Assessment

- **ACS** = IT 직업 평가 기관
- 한국 IT 학사 + 호주 Master + 한국 경력 평가
- Master 졸업자 = ACS 자동 인정 多
- 한국 경력 4년 미만은 일부만 인정

### 4️⃣ IT Master 학교 (시드니/멜번/Regional 도시)

| 학교 | 학비 (연간) | IELTS |
|---|---|---|
| USyd Master IT | $52K~$56K | 6.5 |
| UNSW Master IT | $50K~$55K | 6.5 |
| UTS Master IT | $44K~$48K | 6.5 |
| Macquarie Master IT | $42K~$46K | 6.5 |
| Adelaide Master IT (Regional, 491 +15점) | $40K~$44K | 6.5 |
| UQ Master IT (Non-regional) | $48K~$52K | 6.5 |
| RMIT Master IT (Melbourne) | $42K~$46K | 6.5 |

### 5️⃣ Cyber Security = IT 중 가장 강세

- Cyber Security Specialist 262112 = MLTSSL
- 호주 정부 + 국방 = Cyber 인력 부족
- Master of Cyber Security 신설 학교 多
- 연봉 강세 ($100K~$180K)

---

## 🎯 정답 경로

### IT Master + ACS + 485 + PR

```
한국 IT 학사 + 경력 + IELTS 6.5+
        ↓
Master IT (1.5~2년) - $80K~$110K
        ↓
ACS Skills Assessment
        ↓
485 졸업비자 2년 + 호주 IT 회사 취업
        ↓
호주 경력 1-2년 + EOI 90+ → 189/190 PR
```

**총 4-5년 / 학비 $80K~$110K**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 IT 영주권은 MLTSSL 직업군 + 연봉 강세입니다. 직업별:
> 
> - **Software Engineer** $90K~$140K (가장 흔한 PR)
> - **Cyber Security Specialist** $100K~$150K (수요 강세)
> - **Cyber Security Architect** $120K~$180K (전문가)
> - **Data Scientist** $100K~$150K
> - **DevOps / Cloud** $100K~$160K
> 
> 모두 MLTSSL 직업군.
> 
> **표준 경로**: 한국 IT 학사 → 호주 Master IT (1.5~2년) → ACS Skills Assessment → 호주 IT 회사 취업 → PR
> 
> Cyber Security가 가장 수요 강세입니다.
> 
> 카톡으로 알려주세요:
> ① 한국 IT 학사 + 경력  
> ② IT 분야 (백엔드/프론트/클라우드/Cyber/Data)  
> ③ Master 학교 우선 (Go8 vs 학비 합리적)  
> ④ 도시 (시드니 IT 강세 vs Regional 도시 491 PR 가산점)"

---

## ⚠️ 함정

1. **"한국 IT 경력 = 호주 자동 인정"** → ❌ ACS 평가 必
2. **"Web Developer = MLTSSL"** → ❌ STSOL = 491만 가능
3. **"Master = ACS 자동 통과"** → 학과/세부 매칭 必
4. **"한국 Master = 호주 인정"** → ACS 평가에서 일부 차감

---

## 📞 카카오 응대 시 필수

1. 한국 IT 학사 + 경력
2. IT 분야
3. Master vs 직접 취업
4. 도시 우선

---

## 🔍 직원 확인 사이트

- ACS: acs.org.au
- USyd Master IT: sydney.edu.au
- UNSW: unsw.edu.au
- UTS: uts.edu.au
- Cyber Security 학교들
