# #247 호주 자영업 (ABN) 등록

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 학생비자로 우버이츠 / 청소 / 프리랜서 일하려는데 ABN 필요하다는데 등록해도 되나요? 학생비자 위반인가요?"

**직원 멘붕 포인트:**
- ABN = 사업자 등록 (Australian Business Number)
- 학생비자 ABN 가능 (조건부 / Sole Trader)
- 단, "사업 운영" 시 비자 위반 (8101 / 8104)

---

## ❌ 절대 하지 말아야 할 답

> "학생비자라 ABN 절대 안 돼요!"

→ ❌ **Sole Trader 가능** (조건부). 단, 주 48시간 / 사업 운영 X.

---

## ✅ 정답

호주 학생비자 ABN: ① **Sole Trader (개인 사업자)** ABN 등록 가능 ② **조건**: 주 48시간 (학기 중) / 무제한 (방학) / 학업 우선 ③ **불가**: Company / Partnership / 직원 고용 = 사업 운영 = 비자 위반 ④ **신고 의무**: 매년 Tax Return / GST (연 $75,000+ 매출 시) ⑤ **주요 사용처**: 우버이츠 / Doordash / Airtasker / 프리랜서 (디자인 / IT) ⑥ **무료 등록**: ABR (Australian Business Register) ⑦ **TFN과 별개**: ABN = 사업 / TFN = 개인. ⑧ **윌슨 영역 X** (회계사 / 세무사 영역).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ABN vs TFN**
- **TFN (Tax File Number)**: 개인 세금 (모든 학생 의무)
- **ABN (Australian Business Number)**: 사업자 등록 (선택)
- 우버이츠 / 프리랜서 = ABN 필수 (Contractor)
- 일반 알바 (PAYG) = TFN만

**2. 학생비자 + ABN 조건**
- **Sole Trader만 가능** (개인 사업자)
- 주 48시간 (학기 중) / 무제한 (방학) 준수
- 학업 우선 (CoE 활성)
- "사업 운영 (Operating a Business)" = 비자 위반

**3. ABN 사용 사례 (학생 일반)**
- **우버이츠 / Doordash**: 배달 (ABN 필수)
- **Airtasker**: 청소 / 잡일 (ABN 권장)
- **프리랜서**: 디자인 / IT / 번역 (ABN 필수)
- **Uber / Ola**: 택시 (학생 거의 X)

**4. GST (Goods and Services Tax) 10%**
- 연 매출 $75,000+ = GST 등록 의무
- $75,000 미만 = GST X (선택)
- 우버이츠 = $75,000 미만 거의 = GST X

**5. Tax Return (세금 신고)**
- 매년 7~10월 (myGov / Tax Agent)
- ABN 소득 = Business Income으로 신고
- 비용 공제 (차량 / 핸드폰 / 인터넷)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 일 종류 확인 (PAYG / Contractor)
**2단계**: ABN 필요 여부 확인
**3단계**: ABR 무료 등록 (https://www.abr.gov.au)
**4단계**: 주 48시간 준수 (학기 중)
**5단계**: 매년 Tax Return (myGov / Tax Agent $99~$200)
**6단계**: 사업 운영 X (Sole Trader 한정)

---

## 💡 직원이 학생한테 말할 멘트

> "윌슨님께 이렇게 전달드릴게요:
> 
> '학생비자로 ABN 등록 가능해요 (Sole Trader 한정). 우버이츠 / Doordash / Airtasker / 프리랜서 = ABN 필수예요. 단, 주 48시간 (학기 중) / 무제한 (방학) 준수해야 하고, Company / Partnership / 직원 고용 = 사업 운영 = 비자 위반이에요. ABN은 ABR (https://www.abr.gov.au)에서 무료 등록이에요. 매년 7~10월 Tax Return 의무이고, 연 매출 $75,000+면 GST 10% 등록 의무예요. 자세한 세금 처리는 회계사 / Tax Agent ($99~$200) 영역이에요. 윌슨 영역이 아니에요.'"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7개

1. **학생비자 ABN 불가**: ❌ Sole Trader 가능
2. **ABN = 사업 운영**: ❌ Sole Trader = 개인 사업자
3. **주 48시간 무관**: ❌ ABN도 적용
4. **Company 등록 가능**: ❌ 비자 위반
5. **GST 의무**: ❌ $75,000+만
6. **Tax Return 선택**: ❌ 매년 의무
7. **윌슨 처리**: ❌ 회계사 영역

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **일 종류**: PAYG / Contractor / 프리랜서
2. **현재 비자**: 학생 / 485
3. **TFN 보유**: Yes / No
4. **회계사 보유**: 매년 Tax Return 처리

---

## 🔍 직원이 직접 확인 가능한 사이트

- **ABR (ABN 등록 무료)**: https://www.abr.gov.au
- **ATO (세금)**: https://www.ato.gov.au
- **TFN 신청**: https://www.ato.gov.au/individuals/tax-file-number
- **myGov Tax Return**: https://my.gov.au

---

## 🚨 직원 영역 vs 회계사 / 세무사 영역

| 영역 | 직원 가능 | 회계사 영역 |
|------|----------|---------|
| 학생비자 ABN 가능 안내 | ✅ | - |
| Sole Trader 한정 안내 | ✅ | - |
| 주 48시간 적용 안내 | ✅ | - |
| ABN 등록 처리 | ❌ | ✅ ABR (본인) |
| Tax Return 신고 | ❌ | ✅ Tax Agent |
| GST 처리 | ❌ | ✅ 회계사 |

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생비자 ABN 가능 (Sole Trader) 안내
- [ ] 주 48시간 적용 강조
- [ ] Company / Partnership 불가 명확화
- [ ] 우버이츠 / 프리랜서 = ABN 필수 안내
- [ ] GST $75,000+ 의무 안내
- [ ] 매년 Tax Return 의무 안내
- [ ] 회계사 / Tax Agent 영역 분리
