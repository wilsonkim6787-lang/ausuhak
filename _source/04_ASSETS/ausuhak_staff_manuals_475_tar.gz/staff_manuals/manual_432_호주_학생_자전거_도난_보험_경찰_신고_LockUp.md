# #432 호주_학생_자전거_도난_보험_경찰_신고_LockUp

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "$1,500짜리 새 자전거 캠퍼스 앞에 잠가놨는데 30분 만에 도난당했어요. 자물쇠도 끊어놨어요. 경찰 신고했는데 찾을 수 있을까요? 보험은 안 들었는데 학교에서 보상 받을 수 있나요? 다음에는 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- 자전거 도난 신고 절차
- Police Report 발급
- Contents Insurance 청구
- Bike Vault / U-Lock 권장
- Bike Registration (BikeRoll/529)

---

## ❌ 절대 하지 말아야 할 답

> "자전거 도난은 못 찾아요"

→ ❌ ❌ Police Report 받으면 Contents Insurance 청구 가능. 등록 시 회수율 상승.

---

## ✅ 정답

자전거 도난 절차: ① 즉시 경찰 신고 (131 444 / 또는 온라인 Police Assistance Line), ② Police Report Number 발급 (보험 청구 필수), ③ Contents Insurance (가입 시) 청구 - $500~$2,000 자기부담 후 보상, ④ 학교/캠퍼스는 보상 X (대부분), ⑤ BikeRoll, 529 Garage, BikeVault - 무료 등록 / 회수율 상승, ⑥ 다음 자전거 권장: U-Lock + 체인 락 이중 잠금 / Sold Secure Gold 등급 ($80+), ⑦ 실내 보관 (셰어하우스 거실/방), ⑧ 도난 빈발 지역 (시드니 시티/멜번 CBD/캠퍼스).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Police Report**
131 444 / 온라인 / 무료

**2. Contents Insurance**
Budget Direct/NRMA/Allianz $200~$600/년

**3. BikeRoll/529**
무료 등록 / 도난 회수

**4. Sold Secure Gold**
U-Lock 표준 / $80+

**5. 자전거 등록**
VIN 사진 / Frame Number 보관

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 즉시 경찰 신고 (131 444)
**2단계**: 2단계: Police Report Number 받기
**3단계**: 3단계: 자전거 사진 + 영수증 보관 (이미 했으면)
**4단계**: 4단계: Contents Insurance 청구
**5단계**: 5단계: 다음 자전거 등록 + U-Lock 이중

---

## 💡 직원이 학생한테 말할 멘트

> "경찰 신고 (131 444) 하시고 Police Report Number 받으세요. Contents Insurance 가입했으면 청구 가능합니다. 다음에는 BikeRoll/529 등록 + U-Lock 이중 잠금 권장합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **자전거 도난 못 찾음 단정**
   → 등록 시 회수 사례 多

2. **학교 보상 가능**
   → 거의 X

3. **Police Report 유료**
   → 무료

4. **Contents Insurance = OSHC 같이**
   → 별개

5. **U-Lock만 충분**
   → 체인+U-Lock 이중

6. **저가 자물쇠 OK**
   → 도난 빈번한 대상

7. **실외 24시간 보관**
   → 도난 빈번

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 도난 시점/장소
2. 자전거 영수증/사진 보유
3. Contents Insurance 가입 여부
4. Police Report 발급 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('NSW Police', 'police.nsw.gov.au')
- ('BikeRoll', 'bikeroll.com.au')
- ('529 Garage', 'project529.com')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 신고 절차 일반 안내

**MARA / 변호사 영역**
- 비자 영향 X / 무관

---

## ✅ 완벽 응대 체크리스트

- [ ] Police 131 444 안내함
- [ ] Police Report Number 강조함
- [ ] Contents Insurance 청구 안내함
- [ ] BikeRoll/529 등록 권장함
- [ ] U-Lock 이중 권장함
- [ ] 실내 보관 권장함
