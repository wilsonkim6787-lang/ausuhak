# #473 호주_학생_알레르기_Anaphylaxis_EpiPen_응급실_OSHC_커버

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "땅콩 알레르기 있는데 카페에서 실수로 먹고 호흡 곤란 와서 응급실 갔어요. EpiPen 처방받았는데 가격이 미쳤어요. OSHC로 커버되나요?"

**직원 멘붕 포인트:**
- Anaphylaxis = 생명 위협 알레르기 반응. 5~15분 안에 EpiPen 안 쓰면 사망 가능
- EpiPen 호주 가격: PBS 비적용 시 $120~$160/개 (비PR 학생)
- OSHC = Hospital + Some Medical 커버. 처방약은 별도 Extras 가입 필요
- PBS(Pharmaceutical Benefits Scheme) = PR/시민권자만 $31.60/개 적용
- 직원이 'OSHC 다 커버돼요' 잘못 알려주면 학생 큰 실비 부담

---

## ❌ 절대 하지 말아야 할 답

> "OSHC 들으셨으니까 다 무료예요 처방약도 다 됩니다"

→ ❌ OSHC는 PBS Equivalent 처방약 일부만 커버. EpiPen 같은 고가 약은 학생 부담 큼. 잘못 안내 시 학생 신뢰 잃음

---

## ✅ 정답

응급실은 OSHC가 거의 다 커버돼서 큰 부담 없을 거예요. EpiPen 처방약은 OSHC가 일부 환급해주는데, 보험사마다 한도 다릅니다. Bupa는 PBS Equivalent 약 1년 한도 $300~$500 정도예요. 영수증 들고 보험사 앱에서 청구하시면 됩니다. 그리고 ASCIA 알레르기 액션 플랜 등록하시고 학교에 알리세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. OSHC가 커버하는 것 vs 안 하는 것**
✅ 커버: 응급실 입원, 수술, GP 100% Schedule Fee, 구급차
✅ 일부 커버: PBS Equivalent 처방약 (보험사 한도)
❌ 미커버: 치과, 안경, 물리치료, 한방, 임신(12개월 대기)
❌ 미커버: PBS 비적용 약품, 비처방 OTC
→ EpiPen은 PBS Equivalent라 일부 환급 가능

**2. EpiPen 호주 가격 (2026 기준)**
PBS 적용 (PR/시민권자): $31.60/개 (Concession $7.70)
PBS 비적용 (학생비자/관광객): $120~$160/개
유효기간: 12~18개월 (만료 후 폐기)
권장 보유: 2개 (학교/집 분산)
OSHC Bupa 환급: 1년 한도 $300~$500 내 일부

**3. Anaphylaxis 응급 처치 + 호주 응급 시스템**
증상: 호흡곤란/얼굴부종/혈압저하/의식저하
1. EpiPen 즉시 (허벅지 외측 근육)
2. 000 (Triple Zero) 응급 전화
3. 응급실 후 4시간 관찰 의무 (재발 방지)
응급실 OSHC 커버: 100% Public Hospital ER
Private Hospital ER은 Extras Cover 필요

**4. ASCIA Action Plan (호주 표준 알레르기 관리)**
ASCIA = Australasian Society of Clinical Immunology and Allergy
사이트: allergy.org.au
Action Plan 다운로드: 알레르기 종류별 응급 대응 지침
GP에서 작성 → 본인+학교+직장 보관
Anaphylaxis Australia 1300 728 000 (24시간 자문)
MedicAlert 팔찌: $90~$200 (응급 시 증상 식별)

**5. 학교/직장 신고 (호주 의무)**
호주 학교/대학: Disability Standards 2005 의거 알레르기 신고 의무
Student Disability Office에 ASCIA Plan 제출
→ 시험 중 EpiPen 휴대 허용
→ 카페테리아 알레르기 정보 제공
직장 (카페/식당): Food Standards Code 알레르기 14개 표시 의무
한식당도 의무 (밀/계란/우유/생선/갑각류/땅콩/호두/대두 등)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 응급실 영수증 + EpiPen 처방전 + 약국 영수증 보관
**2단계**: OSHC 보험사 앱에서 Claim 청구 (Bupa/Medibank/Allianz/NIB/AHM)
**3단계**: GP 방문 → ASCIA Action Plan 작성
**4단계**: 학교 Disability Office에 Plan 제출 + EpiPen 학교 보관 등록
**5단계**: MedicAlert 팔찌 주문 + Anaphylaxis Australia 회원 가입

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요 학생님. 응급실 다녀오신 건 OSHC가 거의 다 커버돼요. EpiPen 처방약은 보험사마다 환급 한도 달라서, 영수증 챙겨서 OSHC 앱에서 Claim 청구하시면 됩니다. 그리고 GP에서 ASCIA Action Plan 받아 학교에 제출하세요. 추가 궁금하시면 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **OSHC = 한국 건강보험 같은 줄 X**
   → 한국 건보는 처방약 거의 다 커버. OSHC는 응급/입원 위주. 약품은 보험사별 한도

2. **EpiPen 1개만 사면 됨 X**
   → ASCIA 권장: 2개 보유 (학교/집 분산). Anaphylaxis 재발 시 1개로 부족

3. **EpiPen 만료 후 사용 X**
   → 유효기간 지나면 효과 50% 이하. 12~18개월 후 새로 처방받아야 함

4. **응급실 가지 말고 GP X**
   → Anaphylaxis는 무조건 000 응급. GP는 처치 안 됨. 잘못된 안내 시 사망

5. **PBS 적용된다고 잘못 안내**
   → 학생비자는 PBS 비적용. PR/시민권자만 $31.60. 학생은 $120~$160

6. **학교 신고 안 해도 됨 X**
   → 신고 안 하면 시험장 EpiPen 휴대 거부될 수 있음. Disability Office 등록 필수

7. **음식점 알레르기 표시 의무 모름**
   → Food Standards Code 1.2.3 의거 14개 알레르기 표시 의무. 사고 시 식당 책임 추궁 가능 (Civil Lawyer)

---

## 📞 카카오 응대 시 필수 4가지 확인

1. OSHC 어느 보험사예요? (Bupa/Medibank/Allianz/NIB/AHM)
2. 응급실 + EpiPen 영수증 보관하셨어요? (했다 / 안 했다)
3. ASCIA Action Plan 작성하셨어요? (했다 / 아직)
4. EpiPen 몇 개 보유하세요? (1개 / 2개 이상)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ASCIA: allergy.org.au
- Anaphylaxis Australia: allergyfacts.org.au / 1300 728 000
- PBS: pbs.gov.au
- OSHC Bupa: bupa.com.au/health-insurance/oshc
- MedicAlert: medicalert.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- OSHC 환급 절차 안내
- ASCIA Plan 작성 안내
- 학교 Disability Office 등록 코칭
- MedicAlert 팔찌 안내

**MARA / 변호사 영역**
- OSHC 보험금 분쟁 (PHIO Ombudsman)
- 식당 알레르기 표시 위반 보상 (Civil Lawyer)
- 응급 의료 사고 보상 (Civil Lawyer)
- 장애 등록 비자 영향 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 응급실 + EpiPen 영수증 보관 완료
- [ ] OSHC Claim 청구 완료
- [ ] ASCIA Action Plan GP 발급 완료
- [ ] 학교 Disability Office 등록 완료
- [ ] EpiPen 2개 보유 + MedicAlert 팔찌 주문
