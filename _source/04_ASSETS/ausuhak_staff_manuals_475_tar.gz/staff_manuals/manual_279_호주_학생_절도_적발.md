# #279 호주_학생_절도_적발

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 코울즈 (Coles)에서 화장품 $80어치 가방에 넣고 나오다가 보안한테 잡혔어요. 경찰 와서 조서 썼어요. 비자 어떻게 되나요?"

**직원 멘붕 포인트:**
- Shoplifting = 형사 기록 vs Civil Recovery 차이
- 경찰 조서 = 기소 진행 / 비자 영향
- $80 정도 = Penalty Notice or Court 경계
- Police Check 평생 기록 가능성
- 한국 부모/학교 통보 여부

---

## ❌ 절대 하지 말아야 할 답

> ""$100 미만이라 그냥 벌금만 내면 됨""

→ ❌ 금액 무관 형사 기록 가능. Penalty Notice 받아도 Court 선택 가능. 직원 단정 X.

---

## ✅ 정답

"절도는 호주에서 형사 사건이며 금액과 무관하게 형사 기록 가능성이 있습니다. Penalty Notice 받았다면 변호사 상담 후 Court 출두 결정하세요. 비자/PR 영향 가능합니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Shoplifting (Larceny) 처벌**
NSW Crimes Act Section 117. $2,000 미만 = Local Court (최대 2년). $2,000 이상 = District Court. 첫 범죄 + $300 미만 = Penalty Notice $550 (벌금 only, 기록 X 가능). $300 이상 또는 재범 = Court.

**2. Penalty Notice vs Court**
Penalty Notice = 벌금만 내면 끝 (전과 X). Court 선택 = 변호사 동반 + Section 10 (유죄지만 처벌 면제) 가능 → 더 깨끗. 단, Court 패소 시 전과 + 벌금 더 큼. 변호사 상담 후 결정.

**3. Police Check 영향**
Shoplifting Penalty Notice = National Police Check에 안 나옴 (벌금만). Court 처분 (Section 10 포함) = 처분일로부터 10년 (NSW Spent Convictions Act). 단, 비자 신청 시 Form 80에 모든 기록 신고 의무.

**4. 비자 영향**
Shoplifting 단발 + Section 10 = 비자 안전. 재범 또는 12개월 이상 실형 = Section 501 위험. PR 신청 시 Character Test 평가 (Best Interest of Community).

**5. Civil Recovery (민사)**
Coles/Woolworths 등 = Civil Recovery 우편 발송 (보안 비용 $200~$500 청구). 형사와 별도. 무시하면 채권추심. 변호사 통해 협상 가능. 학생비자 영향 X (민사).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Penalty Notice 받았는지 / Court 통지 받았는지 확인
**2단계**: 한국어 가능 형사 변호사 1차 상담 ($200~$400)
**3단계**: 변호사 조언으로 Penalty Notice 납부 vs Court 출두 결정
**4단계**: Court 선택 시 Section 10 신청 + 봉사활동/사과편지 준비
**5단계**: Civil Recovery 우편 받으면 변호사 통해 협상

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 절도는 금액과 무관하게 형사 기록 가능성 있어요. 비자/PR 영향 가능하니까 변호사 상담 필수예요. Penalty Notice 받으셨는지 / 경찰서 조서만 쓰고 통지 기다리는지 확인해주세요. Penalty Notice = 벌금만 내면 끝 vs Court 출두해서 Section 10 받으면 더 깨끗할 수 있어요. 변호사가 케이스 보고 결정해야 해요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"$80이라 그냥 벌금"**
   → Penalty Notice $550 + Civil Recovery $300 = 총 $850. Court 갈지 변호사 결정.

2. **"전과 안 남음"**
   → Penalty Notice = 안 남음. Court = Section 10 받아야 안 남음.

3. **"비자 신청 시 안 적어도 됨"**
   → Form 80 모든 기록 신고 의무. 거짓말 = PIC 4020 평생 차단.

4. **"한국 가면 끝"**
   → Civil Recovery 우편 채권추심 → 한국 신용 영향. Interpol 등재 거의 X (민사).

5. **"학교에 안 알려도 됨"**
   → 비자 안 취소되면 통보 의무 X.

6. **"보안이 한국인이라 봐줄 것"**
   → 보안은 신고 의무 (절도 금액 무관).

7. **"한 번이니까 괜찮음"**
   → 재범 = 즉시 Court + Section 10 거부 가능.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Penalty Notice 받았는지 / Court 통지 받았는지
2. 절도 금액 정확히 ($300 기준)
3. 이전 전과 있는지 (재범 여부)
4. Civil Recovery 우편 받았는지

---

## 🔍 직원이 직접 확인 가능한 사이트

- LawAccess NSW: 1300 888 529
- Legal Aid NSW
- Revenue NSW (Penalty Notice 납부): 1300 138 118
- NSW Online Court Registry

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 변호사 연결
- 법률 단정 X
- 정서 안정 멘트
- 한국 부모 연락 중재
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- 형사 변호사 = Court 변론, Section 10 신청
- MARA Lawyer = 비자 영향 평가
- Civil Recovery 협상 = 형사 변호사
- Form 80 신고 = MARA Lawyer 가이드
- PR 신청 시 Character Test = MARA Lawyer

---

## ✅ 완벽 응대 체크리스트

- [ ] Penalty Notice / Court 통지 확인했다
- [ ] 절도 금액 정확히 확인했다
- [ ] 재범 여부 확인했다
- [ ] 한국어 가능 형사 변호사 연결했다
- [ ] Section 10 옵션 안내했다
- [ ] Civil Recovery 우편 가능성 안내했다
- [ ] Form 80 신고 의무 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
