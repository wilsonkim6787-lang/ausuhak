# #494 호주_명절_Easter_Christmas_부활절_학교_휴교_여행_계획_종교적_의미

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "Easter Holiday 4일 쉰다는데 호주에서 처음이에요. 뭐 하나요? 학교 휴교는 정확히 언제예요? 여행 가도 돼요?"

**직원 멘붕 포인트:**
- Easter Holiday: Good Friday + Easter Saturday + Easter Sunday + Easter Monday (4일)
- Public Holiday 4일 = 호텔/항공 가격 2~3배 상승
- 학생비자 학생 여행 OK (Multi Entry 자동)
- 호주 외부 여행 시 출입국 시 비자 카드 + 학생증 휴대
- 직원이 종교 의미 강요 X (다양성 존중)

---

## ❌ 절대 하지 말아야 할 답

> "Easter는 무조건 교회 가야 해요 한국 안 가요?"

→ ❌ 종교 강요 X. 학생 자유 결정. 직원 윤리 + 다양성 존중

---

## ✅ 정답

Easter Holiday는 Good Friday부터 Easter Monday까지 4일 연휴예요. Public Holiday이라 학교/대부분 직장 휴무입니다. 호주에서는 가족과 시간 보내거나 단기 여행, BBQ 등 다양해요. 호주 내 인기 여행지(시드니→블루마운틴/사우스코스트, 멜번→그레이트오션로드)는 미리 예약 권장하고, 항공권/호텔은 2~3배 비싸요. 학생비자는 Multi Entry라 호주 외부 여행도 OK입니다. 출입국 시 비자 카드 + 학생증 휴대하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Easter Holiday 일정 (2026)**
Good Friday: 2026.04.03 (금)
Easter Saturday: 04.04 (토)
Easter Sunday: 04.05 (일)
Easter Monday: 04.06 (월)
Public Holiday 4일 연휴
학교: 보통 2주 Term Break + Easter
ANZAC Day: 04.25 (금) 별도 Public Holiday

**2. Easter 의미 + 호주 문화**
기독교: 예수 부활 기념
호주: 종교 + 가족/친구 시간
전통:
- Easter Egg Hunt (어린이)
- Hot Cross Buns (Good Friday)
- BBQ + 캠핑
- 부활절 미사 (선택)
비종교 호주인도 휴일 즐김

**3. 호주 인기 여행지 (Easter)**
시드니에서 출발:
- 블루마운틴: 2시간
- Hunter Valley 와이너리: 2시간
- South Coast (Jervis Bay): 3시간
멜번에서 출발:
- 그레이트 오션 로드: 1.5시간
- Phillip Island (펭귄 퍼레이드): 2시간
브리즈번에서 출발:
- Gold Coast: 1시간
- Sunshine Coast: 1.5시간

**4. Easter 항공/호텔 가격**
Public Holiday 4일 = Peak Season
항공권: 평소 2~3배
호텔: 2~3배
Airbnb: 2~3배
예약 권장 시점: 3~6개월 전
Easter 직전 예약 어려움
한국 명절(설/추석) 비슷한 패턴

**5. 학생비자 여행 (Easter)**
호주 내 여행: 비자 영향 X
호주 외 여행 (한국/일본 등):
- 학생비자 Multi Entry 자동
- 출국 + 입국 자유
- 출입국 시 비자 카드 + 학생증 휴대 권장
- 호주 학교 출석률 (80%) 영향 검토
- 한국 출국 시 한국 병역 미필 25~37세 신고

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Easter Holiday 일정 확인 (Good Friday~Easter Monday)
**2단계**: 여행 vs 호주 체류 결정
**3단계**: 호주 외 여행 시 학생비자 Multi Entry 확인
**4단계**: 항공권/호텔 미리 예약 (3~6개월 전)
**5단계**: 출입국 시 비자 카드 + 학생증 휴대

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. Easter Holiday는 Good Friday부터 Easter Monday까지 4일 연휴예요. 호주에서는 가족 시간, BBQ, 단기 여행 다양해요. 인기 여행지는 미리 예약하시고, 항공/호텔은 2~3배 비싸니 예산 잡으세요. 호주 외부 여행도 학생비자 Multi Entry로 OK입니다. 출입국 시 비자 카드 + 학생증 휴대하세요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Easter=교회 강요 X**
   → 종교 자유. 다양성 존중

2. **Public Holiday 무관 X**
   → Good Friday~Monday 4일

3. **항공/호텔 평소 가격 X**
   → 2~3배 상승

4. **호주 외 여행 비자 영향 X**
   → Multi Entry. 출국 자유

5. **출입국 시 비자 카드 안 가져옴 X**
   → 휴대 권장

6. **학교 자동 출석 X**
   → 출석률 80% 영향

7. **Easter Bunny 한국 X**
   → 호주 어린이 문화. 한국 자녀도 즐길 수 있음

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Easter 첫 호주 경험? (예/아니오)
2. 여행 계획? (호주 내/한국/타국/체류)
3. 예산 얼마? ($500/$500~$2,000/$2,000+)
4. 동행자? (혼자/친구/가족)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Public Holidays AU: australia.gov.au/public-holidays
- Tourism Australia: australia.com
- Skyscanner: skyscanner.com.au
- Booking.com: booking.com
- Airbnb: airbnb.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Easter 일정 안내
- 호주 인기 여행지 안내
- 학생비자 Multi Entry 1차 안내
- 항공/호텔 예약 시점 안내

**MARA / 변호사 영역**
- 비자 출입국 영향 (MARA)
- 한국 출국 병역 미필 (한국 병무청)
- 여행 사고 보험 (Travel Insurance)
- OSHC 해외 커버 (보험사)

---

## ✅ 완벽 응대 체크리스트

- [ ] Easter 일정 캘린더
- [ ] 여행 vs 체류 결정
- [ ] Multi Entry 비자 확인
- [ ] 항공/호텔 미리 예약
- [ ] 비자 카드 + 학생증 휴대
