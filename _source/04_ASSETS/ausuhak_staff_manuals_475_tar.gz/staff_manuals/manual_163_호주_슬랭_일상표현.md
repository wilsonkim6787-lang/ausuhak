# #163 호주 슬랭 / 일상 표현

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 친구가 'How ya going mate?'라고 했는데 어디 가냐는 거예요? 'Arvo', 'Brekkie' 무슨 뜻이에요? 호주 영어 너무 어려워요."

**직원 멘붕 포인트:**
- 호주 슬랭 모름
- 한국에서 배운 미국식 영어와 다름
- 학생이 호주 영어 적응 어려워함

---

## ❌ 절대 하지 말아야 할 답

> "호주 영어는 미국 영어와 똑같아요!"

→ 매우 다름. 학생이 호주 도착 후 충격 받음.

---

## ✅ 정답

호주 영어 (Aussie English)는 미국/영국과 다른 독특한 슬랭과 발음이 있어요. "How ya going?"은 "안녕"이고, "Arvo"는 오후, "Brekkie"는 아침. 핵심 슬랭 30개 알려드릴게요.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 영어 vs 미국 영어 차이
| 미국 | 호주 |
|------|------|
| Hi / Hello | **G'day** / Hi mate |
| How are you? | **How ya going?** |
| Thank you | Cheers / Ta |
| Friend | **Mate** |
| Restroom | Toilet / Loo |
| Apartment | **Unit** / Flat |
| Vacation | Holiday |
| Soda | Soft drink |
| Cookie | **Biscuit** |
| Gas | Petrol |
| Truck | Ute (Utility) |
| Sweater | Jumper |
| Pants | Trousers |

### 2. 핵심 호주 슬랭 30선
**인사:**
- **G'day** = 안녕 (Good day 줄임)
- **How ya going?** = 안녕? 어떻게 지내?
- **No worries** = 괜찮아 / 천만에 (호주 국민 표현)
- **Cheers** = 고마워 (Thank you)
- **Ta** = 고마워 (짧은 인사)

**시간/일과:**
- **Arvo** = 오후 (Afternoon)
- **Brekkie** = 아침식사 (Breakfast)
- **Mozzies** = 모기 (Mosquitoes)
- **Servo** = 주유소 (Service Station)
- **Bottle-O** = 술집 매장 (Bottle Shop)

**음식:**
- **Bickie** = 비스킷 (Biscuit)
- **Snag** = 소시지 (Sausage)
- **Sanga** = 샌드위치 (Sandwich)
- **Cuppa** = 차 한잔 (Cup of tea)
- **Maccas** = 맥도날드 (McDonald's)

**사람:**
- **Mate** = 친구
- **Bloke** = 남자
- **Sheila** = 여자 (옛 표현, 잘 안 씀)
- **Aussie** = 호주 사람
- **Pommy** = 영국 사람 (가벼운 농담)

**감정:**
- **Heaps** = 많이 (a lot)
- **Reckon** = 생각하다 (I think)
- **Stoked** = 신나다, 기쁘다
- **Ripper** = 멋지다 (= Awesome)
- **Bloody** = 매우 (강조, 살짝 거친 표현)

**기타:**
- **Fair dinkum** = 진짜야 (Really, true)
- **She'll be right** = 괜찮을 거야
- **Yeah, nah** = 아니 (Yeah가 들어가도 결국 No)
- **Nah, yeah** = 응 (반대로 결국 Yes)
- **Esky** = 아이스박스

### 3. 호주 발음 특징
- **A 발음:** 미국 [æ] → 호주 [aɪ] ("Today" = "Tody")
- **R 발음 약함:** "Car" = "카" (미국 "카르")
- **EI → AI:** "Mate" = "마이트"
- **NO → NOW:** "No" = "나우" 비슷
- **줄임말 多:** Afternoon → Arvo, Breakfast → Brekkie

### 4. 호주 영어 학습 자료
- **유튜브:** "Aussie English with Pete", "How To Speak Australian"
- **팟캐스트:** "Aussie English Podcast"
- **앱:** Babbel, Speak Like a Local
- **TV:** ABC, SBS (호주 방송)
- **영화:** Crocodile Dundee, The Castle, Strictly Ballroom

### 5. 학생 호주 영어 적응 가이드
- **첫 1개월:** 슬랭 50% 이해 (정상)
- **첫 3개월:** 슬랭 80% 이해
- **첫 6개월:** 본인도 자연스럽게 사용
- **첫 1년:** 거의 완벽 적응
- **친구 만들기:** 호주 친구 1명 = 한인 5명 가치

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. 호주 영어 = 다르다 인정
- 미국 영어 ≠ 호주 영어
- 한국에서 배운 발음과 다름
- 적응 시간 필요 (3~6개월)

### Step 2. 핵심 슬랭 30개 학습
- 일상에서 매일 듣는 표현 우선
- "G'day, mate", "No worries", "How ya going?"

### Step 3. 듣기 훈련
- 호주 유튜브 / 팟캐스트
- 호주 TV / 영화
- 매일 30분 이상

### Step 4. 호주 친구 만들기
- 학교 동아리 / 알바
- 한인 의존 X
- 호주인과 대화 = 진짜 학습

### Step 5. 자신감
- 처음 못 알아들어도 OK
- "Sorry, can you say that again?" 자유롭게
- 호주인은 친절함

---

## 💡 직원이 학생한테 말할 멘트

> "호주 영어는 미국 영어와 많이 달라요. 핵심 슬랭 알려드릴게요.
>
> **인사:**
> - 'G'day mate' = 안녕
> - 'How ya going?' = 어떻게 지내?
> - 'No worries' = 괜찮아 (호주 국민 표현)
>
> **줄임말:**
> - Arvo = 오후 / Brekkie = 아침 / Cuppa = 차 한잔
> - Maccas = 맥도날드 / Servo = 주유소
> - Mozzies = 모기 / Bickie = 비스킷
>
> **친근한 표현:**
> - Mate = 친구 (남녀 모두)
> - Cheers = Thank you
> - Heaps = 많이
> - Reckon = 생각하다
>
> **헷갈리는 표현:**
> - 'Yeah, nah' = 아니
> - 'Nah, yeah' = 응
> (Yes/No 마지막 단어가 정답)
>
> **학습 자료:**
> - 유튜브 'Aussie English with Pete'
> - 팟캐스트 'Aussie English Podcast'
>
> **적응 기간:** 3~6개월이면 80% 이해해요. 처음엔 'Sorry, can you say that again?' 자유롭게 쓰세요. 호주인은 친절해요.
>
> 어느 도시로 가시나요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. 미국 영어 = 호주 영어
- 매우 다름 (특히 발음, 슬랭)
- 학교에서 배운 영어 = 절반만 통함

### 함정 2. "How ya going?" = "어디 가?"
- ❌ 행선지 묻는 게 아님
- ✅ "안녕?" = "How are you?"

### 함정 3. "Mate" = 친구만
- 모르는 사람한테도 사용 OK
- 카페 점원, 택시 기사 등 모두 "mate"

### 함정 4. "Cheers" = 건배만
- 호주에서는 "Thank you" 의미가 더 흔함
- 매장에서 점원이 "Cheers" = "감사합니다"

### 함정 5. "Bloody" = 욕
- 살짝 거친 표현이지만 일상에서 강조용
- "It's bloody cold" = "엄청 추워"
- 어린이 앞에서는 자제

### 함정 6. 한국식 발음 고집
- "Today"를 "투데이" → 호주식 "투다이"
- 호주 발음 따라하면 더 잘 통함

### 함정 7. 영국 영어로 착각
- 호주 영어 ≠ 영국 영어
- 슬랭, 발음, 표현 모두 다름

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **현재 영어 수준?** (IELTS, TOEIC) → 적응 난이도
2. **호주 영어 들어본 적?** → 충격 완화
3. **목표 도시?** → 도시별 액센트 차이 (멜번/시드니/브리즈번)
4. **호주 친구 만들 계획?** → 적응 속도

---

## 🔍 직원이 직접 확인 가능한 사이트

- **Aussie English with Pete:** youtube.com/aussieenglish
- **Aussie English Podcast:** aussieenglish.com.au
- **호주 슬랭 사전:** dictionary.com (Australian Slang)
- **ABC Education:** education.abc.net.au

---

## 🚨 직원 영역 vs 윌슨 영역

| 직원 가능 | 윌슨 영역 |
|-----------|-----------|
| 호주 슬랭 일반 안내 | 학생 1:1 영어 코칭 |
| 학습 자료 추천 | - |
| 호주 vs 미국 영어 차이 | - |
| 적응 기간 안내 | - |

---

## ✅ 완벽 응대 체크리스트

- [ ] 호주 영어 ≠ 미국 영어 안내
- [ ] 핵심 슬랭 30개
- [ ] 인사 표현 (G'day, How ya going)
- [ ] 줄임말 (Arvo, Brekkie 등)
- [ ] 호주 발음 특징
- [ ] 학습 자료 추천
- [ ] 적응 기간 (3~6개월)
- [ ] 호주 친구 만들기 강조
- [ ] 자신감 (Sorry, can you say that again?)
- [ ] 학생 영어 수준 확인

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 영어/문화
