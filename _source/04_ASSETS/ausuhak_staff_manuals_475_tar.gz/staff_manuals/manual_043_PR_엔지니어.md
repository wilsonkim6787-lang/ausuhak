# 📚 직원 응대 매뉴얼 #043

**케이스: 엔지니어 (Mechanical / Civil / Electrical / Chemical) PR 종합**

---

## 🎬 상황 시뮬레이션

> 호주 엔지니어 영주권 가능한 분야 다 알려주세요. 기계, 토목, 전기, 화공 등이요.

**👉 정답**: **모두 MLTSSL 직업군 - Engineers Australia + 학사 또는 경력 + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 엔지니어 직업군 PR 매트릭스

| 직업 | ANZSCO | 평균 연봉 | PR 리스트 |
|---|---|---|---|
| Mechanical Engineer | 233512 | $85K~$130K | MLTSSL |
| Civil Engineer | 233211 | $85K~$130K | MLTSSL |
| Structural Engineer | 233214 | $90K~$140K | MLTSSL |
| Electrical Engineer | 233311 | $90K~$140K | MLTSSL |
| Electronics Engineer | 233411 | $85K~$130K | MLTSSL |
| Chemical Engineer | 233111 | $90K~$140K | MLTSSL |
| Industrial Engineer | 233511 | $85K~$120K | MLTSSL |
| Materials Engineer | 233112 | $85K~$130K | MLTSSL |
| Mining Engineer | 233611 | $100K~$180K | MLTSSL |
| Petroleum Engineer | 233612 | $120K~$200K | MLTSSL |
| Aeronautical Engineer | 233911 | $90K~$140K | MLTSSL |
| Naval Architect | 233916 | $90K~$140K | MLTSSL |
| Software Engineer | 261313 | $90K~$140K | MLTSSL |
| Telecommunications Engineer | 263311 | $90K~$130K | MLTSSL |
| Engineering Technologist | 233914 | $80K~$120K | MLTSSL |

광산/석유 엔지니어 = 연봉 매우 高 (호주 광산업 강세)

### 2️⃣ 엔지니어 표준 경로

```
한국 공대 학사 + 경력
        ↓
Engineers Australia 평가 (Skills Assessment)
        ↓
[옵션 A] 한국 학위 자동 인정 (ABEEK / Washington Accord) → Direct PR
[옵션 B] CDR 보고서 작성 → 평가 → PR
[옵션 C] 호주 Master Engineering 추가 → ACS/EA → PR
```

### 3️⃣ Washington Accord = 학위 상호 인정

- 한국 ABEEK 인증 학위 = 호주 자동 인정
- 한국 SKY/포항공대/카이스트/UNIST 일부 학과 ABEEK
- ABEEK 인증 X = CDR (Competency Demonstration Report) 必
  - 엔지니어 사례 3개 작성 + 영문
  - 평가 시간 + 비용 多

### 4️⃣ 호주 Master Engineering 학교

| 학교 | Master Engineering 학비 (연간) | IELTS |
|---|---|---|
| UMelb | $52K~$58K | 6.5 |
| USyd | $52K~$56K | 6.5 |
| UNSW | $50K~$55K | 6.5 |
| Monash | $48K~$54K | 6.5 |
| UQ | $46K~$52K | 6.5 |
| Adelaide (Regional, 491 +15점) | $44K~$48K | 6.5 |
| UWA | $44K~$50K | 6.5 |
| RMIT | $40K~$46K | 6.5 |

### 5️⃣ 호주 광산업 = Engineer 매우 강세

- WA Perth + QLD = 광산업 중심
- 광산 + 석유 엔지니어 연봉 $120K~$200K
- FIFO (Fly In Fly Out) = 14일 일 + 7일 휴가 패턴

---

## 🎯 정답 경로 (3가지 케이스)

### 케이스 1. 한국 ABEEK + 경력 (가장 빠름)

```
한국 공대 학사 (ABEEK) + 4년 경력
        ↓
Engineers Australia 평가 (Direct)
        ↓
호주 회사 직접 취업 (스폰서 482) 또는 EOI
        ↓
189/190/491 PR
```

**총 1-2년 / 학비 0**

### 케이스 2. CDR (ABEEK X)

```
한국 학사 + 경력 → CDR 작성 (3개월)
        ↓
EA 평가 + 호주 회사 취업
        ↓
PR
```

**총 2-3년 / CDR 비용 약 $1K-$2K**

### 케이스 3. Master Engineering 추가

```
한국 학사 + IELTS 6.5
        ↓
Master Engineering (1.5-2년)
        ↓
EA 평가 + 485 + 호주 회사 취업
        ↓
PR (호주 학위 가산점 +5)
```

**총 3-4년 / 학비 $70K~$100K**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 엔지니어 영주권은 MLTSSL 직업군 + 연봉 강세입니다. 분야별:
> 
> - **기계/토목/전기/화공** $85K~$140K
> - **광산** $100K~$180K (강세)
> - **석유** $120K~$200K (최강)
> 
> 모두 MLTSSL 직업군.
> 
> **한국 ABEEK 인증 학위면 Master 없이 Direct PR 가능** = 가장 빠름.
> 
> ABEEK 미인증이면 CDR 보고서 작성 또는 호주 Master 추가.
> 
> 광산/석유 엔지니어는 WA Perth + QLD 거주 시 강세 + Regional 491+15 가산점.
> 
> 카톡으로 알려주세요:
> ① 한국 학교 ABEEK 인증?  
> ② 분야 (기계/토목/전기/화공/광산)  
> ③ 한국 경력 연수  
> ④ Direct vs Master 추가  
> ⑤ 도시 우선"

---

## ⚠️ 함정

1. **"한국 공대 = 자동 인정"** → ABEEK만 자동 / 그 외 CDR
2. **"4년 경력 다 인정"** → 일부만 (직무 매칭)
3. **"Master 必須"** → ABEEK + 경력이면 불필요
4. **"Engineering Technologist = 엔지니어 동등"** → 연봉/PR은 동등 / 학위 다름

---

## 📞 카카오 응대 시 필수

1. 한국 학교 ABEEK
2. 분야 + 경력
3. Master 추가 의향
4. 도시 우선

---

## 🔍 직원 확인 사이트

- Engineers Australia: engineersaustralia.org.au
- Washington Accord: washingtonaccord.org
- ABEEK 한국: abeek.or.kr
