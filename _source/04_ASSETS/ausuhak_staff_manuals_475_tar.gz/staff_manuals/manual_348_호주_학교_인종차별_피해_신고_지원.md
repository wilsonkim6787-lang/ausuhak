# #348 호주_학교_인종차별_피해_신고_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 학교에서 호주 학생들한테 'go back to your country' 같은 말 듣고 따돌림 당해요. 신고하면 학교가 처리하나요?"

**직원 멘붕 포인트:**
- 인종차별 = 학교 처리 의무?
- 신고 = 보복 두려움
- 학업 영향?
- 법적 보호?

---

## ❌ 절대 하지 말아야 할 답

> "신경 쓰지 마세요. 어쩔 수 없어요."

→ ❌ Racial Discrimination Act + 학교 Anti-Racism Policy + AHRC 신고 가능. 학생 보호 + 학업 영향 차단 가능.

---

## ✅ 정답

**호주 학교 인종차별 = ① 학교 Anti-Racism Policy 신고 ② AHRC(Human Rights Commission) 신고 ③ Racial Discrimination Act 1975 법적 보호.**

**핵심 사실:**
- **Racial Discrimination Act 1975 (RDA)**: 인종/피부색/국적/민족 차별 금지. Section 18C = 인종 모욕(verbal/written) 형사/민사 처벌.
- **학교 Anti-Racism Policy**: 모든 호주 대학/TAFE 의무 보유. Student Conduct Code 위반. 학교 신고 → 조사 → 가해 학생 정학/제명.
- **AHRC(Australian Human Rights Commission)**: 무료 + 익명 신고 가능. 조사 + 조정. 미해결 시 Federal Court.
- **증거 수집**: 통신 기록(문자/이메일/SNS) + 목격자 진술 + 일자/장소 + 음성 녹음(NSW/VIC = 본인 동의 시 합법).
- **학교 보호 의무**: 학교는 ESOS Act + 학교 자체 정책에 따라 학생 보호 의무. 미이행 시 학생 = 학교 항소 + ASQA/TEQSA 신고.
- **익명 보호**: AHRC + 학교 신고 = 익명 보호 가능. 보복 = 추가 처벌 사유.

**경로:**
학교 Anti-Racism Office 신고 → 조사 + 가해 처벌 → 미해결 시 AHRC → Federal Court (마지막 수단)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. RDA Section 18C**
인종 모욕(verbal/written) = 형사/민사 처벌. 'Go back to your country' = 18C 위반 가능.

**2. 학교 Anti-Racism Policy**
Sydney Uni/UNSW/Melbourne 등 모든 학교 보유. Student Conduct + Discrimination 정책. 위반 = 가해 학생 정학/제명.

**3. AHRC 신고**
humanrights.gov.au → 온라인 신고 (익명/실명 선택). 조사 + 조정. 평균 6~12개월. 무료.

**4. 증거 수집**
통신 기록 + 목격자 + 일자/장소 + 음성 녹음(주별 합법성). 일기 + 메모도 증거.

**5. 학생 보호**
신고 후 보복 시 ESOS + 학교 정책 위반. 학생 = 학교 옮김 (Release Letter) + 비자 보호.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 증거 수집 (통신/목격자/일자/장소)
**2단계**: 학교 Anti-Racism Office 또는 Student Services 신고
**3단계**: 학교 조사 + 가해 처벌 (보통 4~8주)
**4단계**: 학교 미해결 시 AHRC 신고 (humanrights.gov.au)
**5단계**: 심각 시 Federal Court 또는 형사 신고 (RDA 18C)

---

## 💡 직원이 학생한테 말할 멘트

> "호주 학교 인종차별은 RDA(Racial Discrimination Act) 위반이고, 학교가 Anti-Racism Policy로 처리할 의무가 있어요. 신고하면 학교가 가해 학생 처벌해야 합니다.

학교 + 학과 + 가해 상황 + 증거 보유 여부 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **인종차별 = 어쩔 수 없음**
   → ❌ RDA 1975 위반 + 학교 처벌 의무. 무시하면 안 됨.

2. **학교 신고 = 보복**
   → ❌ 보복 = 추가 위반 사유. 익명 신고 가능.

3. **AHRC = 비싸고 오래**
   → ❌ AHRC 무료 + 6~12개월. Federal Court만 비쌈.

4. **'농담이었어' = 면책**
   → ❌ 의도 무관 = RDA 18C 위반 평가. 객관적 모욕성 기준.

5. **호주 학생만 보호**
   → ❌ 외국인 학생도 RDA 보호 + 학교 정책 적용.

6. **증거 없으면 신고 X**
   → ❌ 통신 기록 1개라도 있으면 가능. 증거 부족 시 학교 도움.

7. **학교 옮기면 끝**
   → ❌ 학교 옮기면 가해자 처벌 X. 신고 + 후속 조치 권장.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 학교 + 학과 + 인종차별 발생 일자/장소
2. 가해자 (학생/교수/직원) + 빈도
3. 증거 보유 (통신/목격자/녹음)
4. 심리 영향 + 학업 영향 + 학교 옮김 의향

---

## 🔍 직원이 직접 확인 가능한 사이트

- AHRC (humanrights.gov.au) - 신고
- RDA 1975 (legislation.gov.au)
- 각 학교 Anti-Racism / Student Conduct Policy
- ESOS National Code (esos.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학교 Anti-Racism 신고 가이드
- AHRC 신고 + 증거 정리 가이드
- 심리 지원 + 학교 옮김 (Release Letter) 결정

**MARA / 변호사 영역**
- Federal Court 인종차별 소송 (변호사)
- RDA 18C 형사 신고 (NSW Police + 변호사)
- 비자 보호 + 학교 옮김 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 증거 수집 (통신/목격자/일자/녹음)
- [ ] 학교 Anti-Racism Office 신고
- [ ] 심리 지원 (Lifeline/Beyond Blue)
- [ ] 학교 미해결 시 AHRC 신고 (무료)
- [ ] 보복 발생 시 추가 신고 + 학교 옮김 (Release Letter)
- [ ] 심각 시 Federal Court 또는 형사 신고
- [ ] 학업 영향 차단 + LOA 또는 학교 옮김 평가
