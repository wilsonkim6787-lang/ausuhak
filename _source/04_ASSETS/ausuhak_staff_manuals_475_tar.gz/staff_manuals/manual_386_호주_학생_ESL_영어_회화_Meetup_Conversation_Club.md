# #386 호주_학생_ESL_영어_회화_Meetup_Conversation_Club

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 학교만 다니니까 한국 친구만 생기고 영어가 안 늘어요. 영어 회화 모임 어디 있어요?"

**직원 멘붕 포인트:**
- Meetup.com 영어 회화 모임
- Language Exchange (Korean → English 교환)
- 교회/봉사 단체 영어 노출
- 도서관 무료 ESL 클래스
- 학교 Buddy Program

---

## ❌ 절대 하지 말아야 할 답

> "한국 친구만 만나면서 학교 다니면 자연히 영어 늘어요."

→ ❌ 한국 친구 의존 = 영어 정체. 강제로 영어 환경 만들어야 향상. 하루 30분 이상 영어 노출 + 주 2회 회화 모임 = 6개월 후 일상 회화 OK.

---

## ✅ 정답

**호주 영어 회화 모임 + ESL 가이드** (2026):

**1. Meetup.com (가장 활성화)**:
- meetup.com 회원 가입 (무료)
- "English Conversation Sydney/Melbourne" 검색
- 주 1~3회 모임 (카페/공원/도서관)
- 무료 또는 $5~$10/회 (음료 비용)
- 추천 모임:
  - Sydney: International Friends Sydney, Sydney Language Exchange
  - Melbourne: Melbourne English Conversation Club
  - 인원: 10~30명 (다국적)

**2. Language Exchange (1:1 교환)**:
- 본인 한국어 가르침 + 상대 영어 가르침
- 1시간씩 교대 (Korean 30분 + English 30분)
- 앱: Tandem, HelloTalk, Speaky
- 카페에서 직접 만남
- 한국어 배우는 호주인 다수 (K-pop/K-drama 영향)

**3. 교회/봉사 단체**:
- 호주 교회 = 영어 회화 환경 100%
- Hillsong, ANGLICAN, CATHOLIC 등
- 한인 교회 = 영어 노출 X (지양)
- 봉사: Foodbank, Salvation Army, Red Cross
- 무료 + 영어 + 호주 친구

**4. 도서관 무료 ESL**:
- 시드니 City Library, NSW State Library
- 멜번 City Library
- 매주 1~2회 90분 무료 클래스
- 강사 자원봉사 (호주 시민)
- 등록 무료, 학생증 X

**5. 학교 Buddy Program**:
- 대학교 = 호주 학생 1:1 매칭
- USyd Buddy Program, UNSW Mentor
- 학교 International Office 신청 (무료)
- 1학기 매칭 + 자유 만남

**6. 카페 알바**:
- 카페/레스토랑 알바 = 영어 + 수입 + 친구
- 한인 식당 알바 = 영어 효과 X (지양)
- Westfield 푸드코트 = 다국적 + 영어

**7. 호주 셰어 (한국인 X)**:
- 호주/외국인 셰어메이트 거주
- 매일 영어 환경
- 한국인 셰어 = 영어 효과 X
- 추천: Flatmates.com.au "No Korean" 필터

**8. 호주 운동 모임**:
- 시드니 Bondi Beach 서핑 클럽
- 멜번 Yarra River 조깅 클럽
- Park Run (주 1회 5km 무료 마라톤, parkrun.com.au)
- Football/Cricket 클럽 (Casual)

**9. 영화관 + 자막 끄기**:
- 호주 영화관 = 영어 자막 X (자동)
- 한국 영화관 = 영어 자막 ON 인식
- Hoyts, Event Cinemas, Village
- 1주일 1편 권장

**10. 영어 책/팟캐스트**:
- 학생용: Penguin Readers Level 3~4
- 팟캐스트: ABC Radio National, BBC 6 Minute English
- 매일 30분 + 받아쓰기
- 6개월 = TOEFL Listening 향상

**ESL 향상 6개월 표준 패턴**:
- Week 1~4: Meetup 영어 모임 + 도서관 ESL
- Week 5~12: Language Exchange + 호주 셰어
- Week 13~24: 카페 알바 + 봉사 활동
- 매일 30분 영어 노출 (영화/팟캐스트)
- 6개월 후 = 일상 회화 OK

**한인 의존 위험**:
- 한인 셰어 + 한식당 알바 + 한인 교회 = 영어 정체
- 6개월 후 IELTS 점수 동일 또는 하락
- 졸업 후 영어 못 하는 호주 거주자 = 실패

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Meetup.com**
meetup.com - 영어 모임

**2. Tandem App**
tandem.net - Language Exchange

**3. HelloTalk App**
hellotalk.com - 한국어 학습 호주인

**4. ParkRun Australia**
parkrun.com.au - 주말 5km

**5. ABC Radio National**
abc.net.au/radionational - 영어 팟캐스트

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. Meetup.com 가입 → 영어 회화 모임 1개 등록
**2단계**: 2. Tandem 앱 → Language Exchange 파트너 1명
**3단계**: 3. 호주/외국인 셰어 이사 (한인 셰어 탈출)
**4단계**: 4. 카페/레스토랑 알바 (한인 X) 시작
**5단계**: 5. 매일 30분 영어 영화/팟캐스트

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주 영어 회화 모임 답변드립니다.

학교만 다니면서 한국 친구만 만나면 영어 정체됩니다. 강제로 영어 환경 만들어야 합니다.

추천 5가지: ① **Meetup.com** "English Conversation Sydney/Melbourne" 검색, 무료~$10/회, 주 1~3회 모임. ② **Tandem 앱** Language Exchange로 한국어 배우는 호주인 1:1 매칭. ③ **호주 셰어** Flatmates.com.au에서 한국인 X 셰어메이트 (한인 셰어는 영어 효과 X). ④ **카페/레스토랑 알바** 한식당이 아닌 호주 가게로. ⑤ **도서관 무료 ESL** 시드니 City Library, NSW State Library 매주 90분 무료 클래스.

학교에 Buddy Program도 신청하세요. 호주 학생과 1:1 매칭됩니다. International Student Office에서 무료로 신청 가능합니다.

매일 30분 이상 영어 노출(영화/팟캐스트) + 주 2회 회화 모임 + 호주 셰어 = 6개월 후 일상 회화 가능합니다. 한인 교회/한식당/한인 셰어는 영어 학습 측면에서 지양하세요.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **자연히 영어 늘 인식**
   → 한국 친구만 = 영어 정체. 강제 환경 필수.

2. **한인 교회 권유**
   → 영어 노출 X. 호주 교회 권장.

3. **한국 식당 알바 권유**
   → 한국어 100%. 호주 가게 권장.

4. **Meetup 비싸다 인식**
   → 무료 또는 $5~$10/회.

5. **영어 책만 권유**
   → 회화 X. Speaking 모임 필수.

6. **호주인 1:1 = 데이트 인식**
   → Language Exchange = 친구 학습.

7. **Buddy Program 무시**
   → 학교 무료 + 1학기 매칭. 활용 필수.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현 영어 회화 환경 (한인 의존도)?
2. 셰어메이트 한국인 비율?
3. 주 알바 시간 한국 식당?
4. Meetup 가입 의향?

---

## 🔍 직원이 직접 확인 가능한 사이트

- meetup.com (모임)
- tandem.net (교환)
- flatmates.com.au (셰어)
- parkrun.com.au (운동)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 한인 의존 탈출 가이드 + Meetup 안내 + 영어 환경 설계

**MARA / 변호사 영역**
- 영어 학습 = 비자 무관. MARA X.

---

## ✅ 완벽 응대 체크리스트

- [ ] Meetup 모임 추천
- [ ] Language Exchange 권장
- [ ] 호주 셰어 강조
- [ ] 한인 의존 탈출
- [ ] Buddy Program 안내
- [ ] 카카오 상담 신청 유도
