# 📚 직원 응대 매뉴얼 #036

**케이스: 25세 / 고졸 / 영주권 최우선 / Darwin / 3천만 예산**

---

## 🎬 상황 시뮬레이션

> 영주권이 가장 중요해요. 한국인 거의 없는 곳 + 영주권 빠른 곳을 찾고 있어요. Darwin 어떤가요? 25살 고졸 3천만 예산입니다.

**👉 정답**: **Charles Darwin University (CDU) / TAFE NT + 491 비자 +15점 (Regional) + Australian Study +5점**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Darwin = Regional 지역 = 491 +15점 + Australian Study +5점

- 인구 약 15만 (NT 주도, 호주 최북단 주요 도시)
- 491 비자 +15점 (Regional, 모든 Regional 동일)
- Regional 학업/거주 시 Australian Study Requirement +5점 추가
- NT 정부 nomination 적극적 (직업군별 차이)
- 한국인 매우 적음 (영어 환경 강함)

**중요**: 2019.11.16 이후 Cat 1/2/3 시스템 폐지. Darwin도 다른 Regional 지역 (Adelaide/Perth/Hobart 등)과 동일하게 491 +15점.

**485 비자 Second PHEW Regional Extension**:
- Darwin (Cat 3 Regional Centre) = +2년 추가

### 2️⃣ Darwin 주요 학교

| 학교 | 종류 | 학비 |
|---|---|---|
| Charles Darwin University (CDU) | 종합대 | $25K~$35K/년 |
| TAFE NT | TAFE | $14K~$20K/년 |
| Northern Territory Open Education Centre | 공립 고교 | $11K~$15K |

### 3️⃣ Darwin 환경

**장점**:
- 영주권 가장 빠름
- 학비 호주 최저
- 한국인 거의 없음
- NT 정부 PR 우대 多

**단점**:
- 인구 14만 (작음)
- 더위 (열대 기후 / 1년 내내 25-35도)
- 시드니/멜번 대비 인프라 적음
- 알바 자리 한정적

### 4️⃣ NT Migration = NT 정부 스폰서십

- NT Skilled Occupation List 별도 운영
- NT 1년 거주 + 학업 = 491/190 신청 우선
- NT 졸업생 우대 시스템

### 5️⃣ Darwin 영주권 강세 코스

| 코스 | 학비 | PR 직업 |
|---|---|---|
| CDU Bachelor of Nursing | $32K/년 | RN 254499 |
| CDU Bachelor of IT | $30K/년 | IT MLTSSL |
| TAFE NT Diploma Cookery | $20K (1.5년) | Chef 351311 |
| CDU Bachelor of Education | $32K/년 | Teacher MLTSSL |

---

## 🎯 정답 경로

### Darwin CDU / TAFE NT + 491 PR

```
ELICOS 6개월 ($5K~$7K) - Darwin 어학원 한정적, 시드니/멜번에서 ELICOS 가능
        ↓
CDU Bachelor 또는 TAFE NT Diploma 1-3년
        ↓ Darwin Regional 지역 거주
졸업 + 485 (Bachelor 2년 + Cat 3 Regional Extension +2년 = 4년)
        ↓ NT 정부 nomination + Regional 학업 +5
EOI 점수 강화 → 491 (5년) → 191 영주권
```

**총 3-5년 / 학비 약 $30K~$100K (코스 따라)**

---

## 💡 직원이 학생한테 말할 멘트

> "영주권 우선 + 한국인 적은 곳 = Darwin도 검토 가능합니다.
> 
> 1. **491 비자 +15점 (Regional) + Australian Study +5점 = 추가 20점** (Hobart와 동일)
> 2. **NT 정부 nomination** = Darwin 거주 + 학업 학생 우대
> 3. **485 Second PHEW Extension**: Darwin (Cat 3) +2년 추가
> 4. **학비 효율 좋은 편**: TAFE NT $14K~$20K
> 5. **한국인 매우 적음** = 영어 환경 강함
> 
> 단점:
> - 인구 15만 (호주 최북단 주요 도시 / 작은 편)
> - 1년 내내 25-35도 (열대 기후)
> - 알바 자리 한정적
> - 어학원 한정적
> 
> 3천만 예산이면 ELICOS + TAFE NT 1년차 가능합니다.
> 
> ⚠️ Darwin은 Hobart보다 인프라가 더 적어 적응 어려울 수 있어요. MLTSSL 직업군 + 적응력 있을 때 검토합니다.
> 
> 카톡으로 알려주세요:
> ① 영어 수준  
> ② 직업 흥미  
> ③ Darwin 더위 + 작은 도시 OK?  
> ④ Hobart vs Darwin 비교 원하는지"

---

## ⚠️ 함정

1. **"Darwin = 사막"** → 열대 우림 + 해변 / 사막 X
2. **"한국 식당 多"** → ❌ 매우 적음
3. **"Hobart = Darwin 비슷"** → Hobart 25만 (호주 최남단) / Darwin 15만 (호주 최북단) / 기후·환경 정반대
4. **"NT 1년이면 자동 PR"** → 1년 거주 + 일 + Skills Assessment + EOI + nomination 必
5. **"Darwin 가산점 +20"** → 정확히는 491 +15점 (Regional 모두 동일) + Australian Study +5점 = +20점

---

## 📞 카카오 응대 시 필수

1. 영어 수준
2. 직업 흥미
3. 기후 + 작은 도시 적응
4. Hobart vs Darwin 검토

---

## 🔍 직원 확인 사이트

- Charles Darwin University: cdu.edu.au
- TAFE NT: tafe.nt.gov.au
- NT Migration: theterritory.com.au/migrate
