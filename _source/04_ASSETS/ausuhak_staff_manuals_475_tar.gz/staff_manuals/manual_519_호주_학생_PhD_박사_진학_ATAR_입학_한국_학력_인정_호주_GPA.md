# #519 호주_학생_PhD_박사_진학_ATAR_입학_한국_학력_인정_호주_GPA

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국 학사로 호주 박사 진학하려는데 GPA 환산이랑 한국 학력 인정 어떻게 돼요? 영어 점수도 따로 필요해요?"

**직원 멘붕 포인트:**
- 호주 박사 입학 = 학사/석사 + 영어 + 연구 제안서
- 한국 학력 인정: 호주 대학별 GPA 환산표 적용
- 영어 IELTS 6.5 이상 (각 영역 6.0+) 일반
- Research Proposal + Supervisor 사전 컨택 필수
- 장학금 (RTP, RHD Scholarship) PhD 학비/생활비 커버 가능

---

## ❌ 절대 하지 말아야 할 답

> "한국 학사로는 호주 박사 못 가요 석사 먼저 따세요"

→ ❌ 석사 우선 권장이지만 학사로 PhD 직행 가능. 잘못 안내 시 기회 박탈

---

## ✅ 정답

한국 학사로 호주 박사 진학 가능해요. 보통 (1) Honours/Master 1년 추가 후 PhD 진학 또는 (2) 학사 + 우수 GPA로 직접 PhD입니다. 한국 GPA는 호주 대학별 환산표 적용(예: USyd는 7-point Scale 환산). 영어는 IELTS 6.5+(각 영역 6.0+) 일반 요구하고, 일부 학과는 7.0+ 요구해요. 가장 중요한 건 Research Proposal + Supervisor 사전 컨택입니다. 장학금(RTP Scholarship) 받으면 학비 + 생활비 $30,000~$45,000/년 커버 가능합니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 PhD 입학 경로**
1. 학사 + Honours (4년)
   - 우수 학생 PhD 직행
   - First Class Honours 권장

2. 학사 + Master (5~6년)
   - 일반 경로
   - Master by Research 우대

3. 학사 (한국) + Pre-PhD
   - Master Qualifying 1년
   - 또는 Honours 1년

4. 학사 + 경력 (드뭄)
   - 산업 박사 (Industry PhD)
   - 회사 후원 + 일부 경력 인정

**2. 한국 GPA 호주 환산**
한국 4.5 만점 → 호주 7-point Scale (예시):
- 4.0~4.5 → 6.5~7.0 (High Distinction)
- 3.5~3.9 → 6.0~6.4 (Distinction)
- 3.0~3.4 → 5.0~5.9 (Credit)
- 2.5~2.9 → 4.0~4.9 (Pass)
- 2.0~2.4 → 3.0~3.9 (Marginal)

한국 4.3 만점은 별도 환산
USyd, UNSW, UMelb 환산표 사이트 공개

**3. 영어 점수 (학과별)**
일반 PhD:
- IELTS 6.5 (각 영역 6.0+)
- TOEFL iBT 79~93
- PTE 58~64

고급 PhD (Education/Law/Health):
- IELTS 7.0~7.5 (각 영역 6.5+)
- 일부 학과는 8.0

면제 가능:
- 호주/영국/미국 학사/석사 (영어권)
- 일부 학교 + 학과

**4. Research Proposal + Supervisor**
Research Proposal:
- 5~10페이지
- Background + Research Question + Methodology + Timeline
- 논문 형식 (Harvard/APA)
- 학사/석사 논문 활용 가능

Supervisor 컨택:
- 사이트 검색 (학과별 Faculty Member)
- 이메일 (CV + Proposal Abstract)
- 회신 받으면 면담
- 사전 동의 = 합격 확률 높음
→ 6개월~1년 전부터 컨택

**5. PhD 장학금 (RTP + RHD)**
Research Training Program (RTP) Scholarship:
- 호주 정부 장학금
- 학비 면제 (전액)
- 생활비 $32,192/년 (2026)
- 3.5년 + 6개월 연장 가능
- 외국인 학생 일부 가능

RHD (Research Higher Degree) Scholarship:
- 학교별 장학금
- USyd, UNSW, UMelb 등
- 학비 + 생활비 일부
- 외국인 학생 가능

신청:
- 입학 신청 시 자동 평가
- 우수 학생 우대 (GPA + 출판물)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 GPA 호주 환산 (학교별 환산표)
**2단계**: IELTS 6.5+ (각 영역 6.0+) 점수 준비
**3단계**: Research Proposal 5~10페이지 작성
**4단계**: Supervisor 사전 컨택 (6개월~1년 전)
**5단계**: RTP/RHD 장학금 동시 신청

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 한국 학사로 호주 박사 진학 가능해요. (1) Honours/Master 1년 추가 후 PhD 또는 (2) 우수 학사 직접 PhD입니다. 한국 GPA는 호주 대학별 환산표 적용하고 영어 IELTS 6.5+(각 영역 6.0+) 일반 요구해요. Research Proposal + Supervisor 사전 컨택이 가장 중요합니다. RTP Scholarship 받으면 학비 + 생활비 $32,192/년 커버 가능해요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학사로 PhD X**
   → 직행 가능 (조건부)

2. **GPA 4.0 절대 X**
   → 한국 4.0 ≠ 호주 4.0

3. **영어 IELTS 6.0 X**
   → 6.5+ 일반

4. **Supervisor 컨택 무관 X**
   → 필수

5. **Research Proposal 무용 X**
   → 합격 핵심

6. **RTP 학생 자동 X**
   → 신청 + 평가

7. **PhD 학비 자비 X**
   → 장학금 다수

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학력? (학사/석사/박사 진행)
2. 영어 IELTS 점수? (6.5+/6.0/모름)
3. 관심 분야? (이공/사회/예술/기타)
4. 장학금 신청 의향? (있다/모름)

---

## 🔍 직원이 직접 확인 가능한 사이트

- USyd PhD: sydney.edu.au/study/research
- UNSW PhD: research.unsw.edu.au
- RTP Scholarship: education.gov.au
- GPA 환산: 학교별 사이트
- Research Whisperer: thesiswhisperer.com

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- PhD 입학 1차 안내
- GPA 환산 1차
- Supervisor 컨택 가이드
- 장학금 1차 안내

**MARA / 변호사 영역**
- PhD 비자 (MARA)
- Research Proposal 작성 (학교 Mentor)
- Supervisor 컨택 (학과)
- RTP 신청 (학교)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 GPA 호주 환산
- [ ] IELTS 점수 준비
- [ ] Research Proposal
- [ ] Supervisor 컨택
- [ ] RTP/RHD 신청
