# 매뉴얼 #116: 호주 신원조회 / 경찰증명서 (Police Check)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "안녕하세요. 시드니 학교에서 실습(Placement) 들어가야 하는데 Police Check 필요하다고 해요. 어디서 발급받아요? 비용은 얼마이고 며칠 걸리나요? 한국 무범죄증명서도 같이 필요한가요?"

**직원 멘붕 포인트:**
- 호주 Police Check = National Police Check 모름
- 한국 무범죄증명서 vs 호주 Police Check 구분 모름
- 발급 기관 (호주 연방경찰 vs 사설) 모름
- WWCC vs Police Check 차이 모름
- 학생비자라도 발급 가능한지 모름

---

## ❌ 절대 하지 말아야 할 답

> "한국 무범죄증명서만 있으면 돼요"

→ **틀림**. 호주 학교 실습은 호주 Police Check 필수 多.

> "윌슨님이 발급해 주세요"

→ **윌슨 영역 아님**. 본인 신청만 가능.

> "온라인으로 5분이면 나와요"

→ **부정확**. 보통 1~2주 소요. 케이스에 따라 더 오래.

---

## ✅ 정답

> "호주 신원조회는 National Police Check이고, 호주 연방경찰(AFP) 또는 인증된 사설 기관에서 발급받으실 수 있어요. 
> 비용은 $42~$60 정도이고, 보통 1~10영업일 걸려요. 학생비자도 신청 가능해요. 
> 학교 실습이라면 Police Check + WWCC(Working with Children Check)가 같이 필요할 수도 있어요. 
> 한국 무범죄증명서는 학교에서 별도 요구하면 한국 경찰청 홈페이지에서 발급받으세요. 
> 자세한 절차 + 학교 요구사항 확인은 카카오 ID studywilson로 윌슨님께 1:1 상담 요청 드릴게요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 Police Check 종류

**(1) National Police Check (NPC)**
- 호주 전역 범죄 기록 조회
- 발급: 호주 연방경찰(AFP) + 인증 사설 기관
- 용도: 취업, 실습, 자원봉사, 비자
- 비용: $42~$60
- 처리: 1~10영업일

**(2) Working with Children Check (WWCC)**
- 18세 미만 대상 일/실습 시 필수
- 주별 발급 (NSW: WWCC / VIC: WWC Check / QLD: Blue Card)
- 비용: 학생/자원봉사 무료, 일반 $80~$120
- 처리: 즉시~4주

**(3) International Police Certificate**
- 호주 시민권/영주권 신청 시
- 16세 이후 12개월 이상 거주한 모든 국가에서 발급
- 한국 무범죄증명서 = 이 카테고리

**(4) Spent Convictions**
- 일정 기간 경과한 경범죄
- 자동 삭제 / 비공개

### 2. National Police Check 발급 방법

**Option A: AFP (호주 연방경찰) 직접**
- https://www.afp.gov.au
- 비용: $42 (개인) / $59 (사업자)
- 처리: 평균 15영업일
- 결과: 디지털 PDF + 우편

**Option B: 인증 사설 기관**
- CrimCheck, National Crime Check, InterCheck 등
- 비용: $50~$60
- 처리: 1~5영업일 (더 빠름)
- 24시간 응급 서비스 (추가 비용)

**Option C: 주별 경찰청**
- NSW Police: https://www.police.nsw.gov.au
- 비용: $50~$80
- 처리: 1~4주
- 본인 직접 방문 가능

**필요 서류:**
- 여권 (Primary ID)
- 운전면허/Medicare/은행카드 (Secondary ID)
- 100점 ID 시스템

### 3. 100점 ID 시스템

**Primary ID (70점):**
- 여권 (호주/한국)
- 호주 시민권 증서

**Secondary ID (40점):**
- 호주 운전면허증
- Medicare 카드
- 학생증
- 호주 은행카드 (사진 포함)

**Tertiary ID (25점):**
- 호주 은행 명세서
- 공과금 명세서 (전기/가스)
- 임대 계약서
- 보험 카드

**합계 100점 이상 필요:**
- 여권(70) + 학생증(40) = 110점 ✅
- 여권(70) + 은행 명세서(25) = 95점 ❌
- 한국 여권만(70) = 부족 ❌

### 4. 한국 무범죄증명서

**용도:**
- 호주 영주권 신청 (12개월+ 한국 거주자)
- 일부 호주 학교 실습 (이중 요구)
- 호주 시민권 신청

**발급 방법:**

**한국 거주 시:**
- 경찰청 민원포털 (https://minwon.police.go.kr)
- 정부24
- 본인 인증 후 신청
- 비용: 무료~3,000원
- 처리: 1~7영업일

**호주 거주 시 (해외):**
- 한국 영사관 방문 (시드니/멜번/캔버라)
- 위임장 + 한국 가족 대리 신청
- 영문 발급 가능 (Apostille 인증 필요할 수 있음)

**유효기간:**
- 발급 후 6개월 (호주 비자/실습용)
- 영문 + 한글 발급

### 5. 학교 실습 요구 서류 일반

**Bachelor of Nursing 실습:**
- ✅ National Police Check (1년 유효)
- ✅ WWCC (5년 유효)
- ✅ NDIS Worker Screening Check
- ✅ First Aid Certificate
- ✅ Working with Vulnerable People (WWVP)
- ✅ Immunisation Records (예방접종)
- ✅ Manual Handling Course

**Bachelor of Education 실습:**
- ✅ Police Check
- ✅ WWCC (필수)
- ✅ Anaphylaxis Training
- ✅ Mandatory Reporting Training

**Social Work 실습:**
- ✅ Police Check
- ✅ WWCC
- ✅ NDIS Worker Screening

**호텔/요리/IT 실습:**
- 일반적으로 Police Check만
- 학생 자격증 요구 (RSA / White Card 등)

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 학교 요구사항 정확히 확인
- Police Check만? WWCC도?
- 한국 무범죄증명서 별도 요구?
- 발급 후 유효기간

### Step 2: National Police Check 신청
- AFP 또는 사설 기관 (시간 우선이면 사설)
- 비용 $42~$60
- 100점 ID 준비

### Step 3: WWCC 신청 (필요 시)
- NSW: Service NSW
- 학생은 무료 또는 할인
- 즉시~4주

### Step 4: 한국 무범죄증명서 (필요 시)
- 한국 가족 대리 발급 OR
- 호주 영사관 방문
- Apostille 인증

### Step 5: 학교 제출
- 모든 증명서 일괄 제출
- 디지털 사본 보관

---

## 💡 직원이 학생한테 말할 멘트

**(1) 종류 안내:**
> "호주 신원조회는 National Police Check이에요. 호주 연방경찰 또는 사설 인증 기관에서 발급받을 수 있어요. 
> 학교 실습이시면 WWCC도 같이 필요할 수 있어요. 학교에 정확한 요구사항 확인하셨나요?"

**(2) 발급 방법:**
> "Police Check는 비용 $42~$60이고, AFP 직접은 약 15영업일, 사설 기관은 1~5영업일 정도 걸려요. 
> 시간 급하시면 사설 기관이 더 빨라요."

**(3) ID 준비:**
> "100점 ID 시스템이라 여권(70점) + 학생증(40점) 정도면 충분해요. 
> 호주 운전면허/Medicare/은행카드 있으시면 더 좋고요."

**(4) 한국 무범죄증명서:**
> "한국 무범죄증명서는 경찰청 민원포털에서 발급받으세요. 영문 발급 가능하고 비용 무료에요. 
> 호주에 계시면 한국 가족이 대리 발급하거나 영사관 방문하셔야 해요."

**(5) 윌슨 상담 유도:**
> "정확한 학교 요구사항과 발급 일정 조율은 카카오 ID studywilson로 윌슨님께 1:1 상담 요청 드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "Police Check = 한국 무범죄증명서"
- ❌ 별개 서류
- ✅ 호주 = AFP / 한국 = 경찰청

### 함정 2: "WWCC는 의무"
- ⚠️ 18세 미만 대상 일만
- ✅ IT/호텔/요리 실습은 불필요 多

### 함정 3: "학생비자는 발급 안 된다"
- ❌ 학생도 발급 가능
- ✅ 100점 ID만 있으면 OK

### 함정 4: "온라인 신청 = 즉시 발급"
- ❌ 보통 1~10영업일
- ✅ 사설 기관도 최소 24시간

### 함정 5: "한 번 받으면 평생 사용"
- ❌ 보통 1년 유효 (실습용)
- ✅ WWCC는 5년

### 함정 6: "여권만 있으면 100점 ID 충족"
- ❌ 여권 = 70점
- ✅ Secondary ID 추가 필요

### 함정 7: "한국 무범죄증명서 영사관에서 즉시 발급"
- ⚠️ 영사관은 신청 접수 (한국 본청에서 발급)
- ✅ 한국 가족 대리가 빠름

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 학교/실습 종류
- Bachelor of Nursing? Education? IT?
- Police Check만? WWCC도?
- 한국 무범죄 별도?

### 2. 시간 여유
- 며칠 내 필요?
- AFP(느림) vs 사설(빠름)

### 3. ID 보유 상태
- 여권 + 학생증?
- Medicare/운전면허?
- 100점 충족?

### 4. 한국 거주 가족
- 한국 가족 대리 발급 가능?
- 호주 영사관 거리?

---

## 🔍 직원이 직접 확인 가능한 사이트

### 1. AFP National Police Check
- https://www.afp.gov.au/what-we-do/services/criminal-records
- 호주 전역 발급

### 2. NSW Police Check
- https://www.police.nsw.gov.au/online_services/criminal_history_check

### 3. Service NSW (WWCC)
- https://www.service.nsw.gov.au
- 검색: Working with Children Check

### 4. 한국 경찰청 민원포털
- https://minwon.police.go.kr
- 무범죄증명서 발급

### 5. 정부24
- https://www.gov.kr
- 한국 본인 인증

### 6. 호주 시드니 한국총영사관
- https://overseas.mofa.go.kr/au-sydney-ko
- 영사 업무

### 7. 사설 인증 기관
- https://www.crimcheck.org.au
- https://www.nationalcrimecheck.com.au
- https://www.intercheck.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

### 직원 가능 (즉시 응대)
- ✅ 호주 Police Check 종류 안내
- ✅ AFP / 사설 기관 차이
- ✅ 100점 ID 시스템
- ✅ WWCC vs Police Check 구분
- ✅ 한국 무범죄증명서 발급 안내
- ✅ 학교 실습 요구사항 일반

### 학생 본인 영역
- ⚠️ 본인 신청 (대리 불가)
- ⚠️ ID 준비 (여권/면허 등)

### 변호사 영역
- 형사 기록 있는 학생 비자 영향
- Spent Convictions 자문
- 영주권 신청 시 범죄 기록

### 윌슨 1:1 상담 영역
- 학교별 요구사항 확인
- 발급 일정 + 학기 시작 일정 조율
- 형사 기록 있는 경우 비자/실습 영향

---

## ✅ 완벽 응대 체크리스트

- [ ] National Police Check (NPC) 안내
- [ ] AFP vs 사설 기관 차이 (시간/비용)
- [ ] 비용 $42~$60 안내
- [ ] 처리 기간 (AFP 15영업일 / 사설 1~5영업일)
- [ ] WWCC 별도 안내 (18세 미만 대상 시)
- [ ] 100점 ID 시스템 안내
- [ ] 여권(70) + 학생증(40) 조합 권장
- [ ] 한국 무범죄증명서 발급처 (한국 경찰청)
- [ ] 한국 영문 발급 가능 + 가족 대리
- [ ] 호주 영사관 영사 업무
- [ ] 학교별 요구사항 (Nursing/Education 등)
- [ ] 유효기간 (Police Check 1년 / WWCC 5년)
- [ ] AFP / 한국 경찰청 / 영사관 사이트 공유
- [ ] 형사 기록 있는 경우 변호사 영역
- [ ] 윌슨 카카오 ID 안내

---

**작성: ausuhak.com / ausuhak.com**
**카카오 ID: studywilson**
