# #167 학생 LGBT / 커밍아웃 / 성소수자 지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 게이인데 한국에서는 숨기고 살았어요. 호주 가면 커밍아웃해도 될까요? 부모님이 모르시는데... 호주 게이 친구 만날 수 있나요?"

**직원 멘붕 포인트:**
- LGBT 관련 매우 민감한 사안
- 호주 LGBT 환경 모름
- 학생 정체성 보호 + 안전 정보 동시 필요

---

## ❌ 절대 하지 말아야 할 답

> "호주는 자유로운 나라니까 마음대로 하세요!"

→ 학생 안전 + 가족 관계 + 비자 문제 등 복합 사안. 신중한 안내 필요.

→ 또한:
> "유학원에서 그런 거 답변 못 해드려요."
→ 학생 외면 = 신뢰 잃음. 정보는 안내하되 결정은 학생.

---

## ✅ 정답

호주는 LGBT에 매우 친화적인 국가입니다 (동성결혼 합법화 2017년). 시드니 Mardi Gras, 멜번 Midsumma 등 LGBT 축제 큰 규모로 열려요. 학교에 LGBT Support 그룹 (Queer Society) 있어 친구도 만들 수 있습니다. 단, 한국 가족과의 관계는 학생이 신중하게 결정할 일이에요.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주 LGBT 법적 보호
- **동성결혼 합법:** 2017년 12월 (Marriage Amendment Act 2017)
- **반차별법:** Sex Discrimination Act 1984
- **고용 차별 금지:** Fair Work Act
- **호주 학교 LGBT 보호:** 모든 주에서 차별 금지
- **혐오 발언:** 일부 주 형사 처벌 (NSW, ACT, QLD)

### 2. 호주 LGBT 도시 환경
**시드니:**
- **Mardi Gras** (2~3월): 세계 최대 LGBT 축제 1주일
- **Oxford Street, Newtown:** LGBT 친화 동네
- ACON: 시드니 LGBT 지원 단체

**멜번:**
- **Midsumma Festival** (1~2월): 큰 LGBT 축제
- **Fitzroy, Collingwood:** LGBT 친화
- Switchboard Victoria

**브리즈번:**
- **Brisbane Pride** (9월)
- **New Farm, West End:** LGBT 친화

**기타 도시:**
- 시드니/멜번 외 도시는 LGBT 인구 적음
- 시골 지역 보수적 분위기 일부

### 3. 학교 LGBT 지원 시스템
**대학:**
- **Queer Society / Pride Society** (학생회 산하)
- 매주 모임, 친구 만들기
- 상담 서비스 (Counsellor)

**TAFE/사립:**
- Wellbeing 부서 LGBT 지원
- Anonymous 상담

**고등학교:**
- 학교마다 차이
- Public School은 보통 친화적

### 4. LGBT 지원 단체 / 핫라인
- **QLife (LGBT 핫라인):** 1800 184 527 (3pm~12am)
- **ACON (NSW):** acon.org.au
- **Switchboard (VIC):** switchboard.org.au
- **Beyond Blue (정신건강):** 1300 22 4636
- **Lifeline:** 13 11 14
- **Headspace (청년 정신건강):** headspace.org.au
- **Twenty10 (LGBT 청년):** twenty10.org.au

### 5. 한국 가족과 관계 (민감 사안)
**현실:**
- 한국 가족 관계는 학생이 신중하게 결정
- 호주 자유 = 한국 가족 자유로워지지 X
- 부모님 모르시면 호주에서만 자유로울 수도

**비자 영향:**
- LGBT 정체성 = 비자 거절 사유 X
- 동성 파트너 = Partner Visa (820/801) 가능
- 호주 시민/영주권자 동성 파트너 = 일반 파트너 비자와 동일

**고려사항:**
- 가족 관계 → 학생 본인 결정
- 호주에서 비밀 유지 가능
- 정신 건강 (우울증, 불안) 관리 중요
- 학교 상담 + LGBT 지원 단체 활용

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1. 학생 정체성 존중 + 정보 제공
- 판단/조언 X
- 객관적 정보만

### Step 2. 호주 LGBT 환경 안내
- 동성결혼 합법
- 시드니 Mardi Gras, 멜번 Midsumma
- LGBT 친화 동네

### Step 3. 학교 지원 시스템
- Queer Society
- 상담 서비스
- 친구 만들기

### Step 4. 지원 단체 / 핫라인
- QLife 1800 184 527
- ACON, Switchboard
- 위기 시 Lifeline 13 11 14

### Step 5. 한국 가족 관계 = 학생 영역
- 직원이 결정 권유 X
- 정보만 제공

---

## 💡 직원이 학생한테 말할 멘트

> "호주는 LGBT에 매우 친화적이에요. 안심하시고 정보 알려드릴게요.
>
> **법적 보호:**
> - 동성결혼 합법 (2017년부터)
> - 차별금지법 (Sex Discrimination Act)
> - 모든 주에서 LGBT 차별 금지
>
> **도시별 환경:**
> - 시드니: Mardi Gras (2~3월, 세계 최대 LGBT 축제), Oxford Street/Newtown
> - 멜번: Midsumma Festival (1~2월), Fitzroy/Collingwood
> - 브리즈번: Brisbane Pride (9월), New Farm/West End
>
> **학교 지원:**
> - Queer Society / Pride Society (대학 학생회)
> - 매주 모임, 친구 만들기
> - 학교 상담 서비스 (Counsellor)
>
> **지원 단체 / 핫라인:**
> - QLife (LGBT 핫라인): 1800 184 527 (3pm~12am)
> - ACON (NSW): acon.org.au
> - Switchboard (VIC): switchboard.org.au
> - Twenty10 (청년 LGBT): twenty10.org.au
>
> **위기 상황:**
> - Lifeline: 13 11 14
> - Beyond Blue: 1300 22 4636
> - Headspace (청년): headspace.org.au
>
> **비자 측면:**
> - LGBT 정체성 = 비자 거절 사유 X
> - 동성 파트너 = Partner Visa 일반 파트너와 동일
>
> **가족 관계는 학생 본인이 신중히 결정하실 일이에요.** 호주에서는 자유롭게 지내실 수 있고, 한국 가족에게 알릴지 말지는 본인 선택이에요.
>
> 정신건강 관리도 중요해요. 학교 상담 + LGBT 지원 단체 적극 활용하세요. 어느 도시 가시나요?"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 5~7개

### 함정 1. 판단/조언
- ❌ "커밍아웃 하세요" / "하지 마세요"
- ✅ 정보만 제공, 결정은 학생

### 함정 2. 한국 가족 영역 침범
- ❌ 부모님께 알려드릴까요?
- ✅ 가족 관계 = 학생 영역

### 함정 3. 호주 = 무조건 안전
- 도시 안전 (시드니/멜번)
- 시골 일부 보수적
- 차별 신고 가능

### 함정 4. 비자 영향
- LGBT = 비자 거절 사유 X
- 동성 파트너 비자 = 일반과 동일
- 정확히 안내

### 함정 5. 정체성 노출 강요
- 학생이 직원한테 말한 것 ≠ 학원 공유 동의
- 비밀 유지

### 함정 6. 종교/문화 가치 강요
- 직원 개인 의견 X
- 객관적 정보만

### 함정 7. 정신건강 무시
- LGBT 청년 우울증 통계 高
- 한국 가족 갈등 + 외국 생활 = 스트레스
- 핫라인 안내 필수

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **어느 도시? 학교?** → 환경 안내
2. **현재 정신상태?** → 위기 시 Lifeline
3. **친구/지원 시스템?** → Queer Society 안내
4. **비자 단계?** → 동성 파트너 비자 정보

---

## 🔍 직원이 직접 확인 가능한 사이트

- **QLife:** qlife.org.au
- **ACON (NSW):** acon.org.au
- **Switchboard (VIC):** switchboard.org.au
- **Twenty10 (청년):** twenty10.org.au
- **Headspace:** headspace.org.au
- **Sydney Mardi Gras:** mardigras.org.au
- **Midsumma Festival:** midsumma.org.au

---

## 🚨 직원 영역 vs 윌슨/전문가 영역

| 직원 가능 | 윌슨 영역 | 전문가 영역 |
|-----------|-----------|-------------|
| 호주 LGBT 환경 안내 | 1:1 학생 케어 | 정신건강 (Counsellor) |
| 지원 단체 정보 | - | 가족 갈등 (Family Therapist) |
| 학교 시스템 | - | LGBT 변호사 (차별 사건) |
| 비자 일반 안내 | - | 이민변호사 (Partner Visa) |

---

## ✅ 완벽 응대 체크리스트

- [ ] 호주 LGBT 법적 보호 안내
- [ ] 도시별 환경 (시드니/멜번/브리즈번)
- [ ] 학교 Queer Society 안내
- [ ] QLife 1800 184 527
- [ ] ACON, Switchboard 등 단체
- [ ] Lifeline, Beyond Blue 위기 핫라인
- [ ] 비자 영향 (LGBT 거절 사유 X)
- [ ] 동성 파트너 비자 가능
- [ ] 가족 관계 = 학생 영역 존중
- [ ] 정신건강 관리 강조
- [ ] 판단/조언 자제

---

**작성일:** 2026-05-04
**버전:** v1.0
**카테고리:** 학생 지원/민감
