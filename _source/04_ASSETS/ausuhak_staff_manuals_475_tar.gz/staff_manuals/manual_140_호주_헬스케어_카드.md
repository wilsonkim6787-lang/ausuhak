# 매뉴얼 #140: 호주 헬스케어 카드 (Healthcare Card, Concession)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "쌤 학교 친구가 호주 헬스케어 카드 있으면 의료비 싸진다는데 학생도 받을 수 있어요? 어디서 받아요?"

**직원 멘붕 포인트:**
- Healthcare Card = 영주권/시민권 한정
- 학생 = 받을 수 없음
- 학생 OSHC가 대안
- Concession Card 종류 헷갈림

---

## ❌ 절대 하지 말아야 할 답
> "학생도 받을 수 있어요" (틀림)
> "Centrelink 가면 줘요" (틀림 - 학생 자격 없음)
> "OSHC = Healthcare Card" (틀림 - 별개)

## ✅ 정답
> "Healthcare Card는 영주권/시민권자 저소득층 대상입니다. 학생비자 자격 없음. 학생은 OSHC가 의료비 보장 역할. 영주권 취득 후 저소득 시 신청 가능. Pensioner Concession은 노령 영주권자, Low Income Healthcare Card는 영주권 저소득자. 자세한 절차는 윌슨 카카오 상담 시 안내드려요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. Healthcare Card 종류
- **Low Income Healthcare Card (LIHCC)**: 저소득자
- **Pensioner Concession Card (PCC)**: 노령 연금 수령자
- **Health Care Card (HCC)**: 정부 보조금 수령자
- **Commonwealth Seniors Health Card (CSHC)**: 고령 (Pension 제외)
- **Ex-Carer Allowance Card**: 보호자 출신

### 2. 학생비자 자격 여부
- ❌ Healthcare Card: 학생 자격 없음
- ❌ Medicare: 학생 자격 없음 (영주권 대기자 제외)
- ✅ OSHC: 학생비자 의무 가입
- ✅ Student Concession (교통): 학생증

### 3. Healthcare Card 혜택 (영주권자 한정)
- PBS 처방약 할인 ($7.70 → $30 절약)
- GP Bulk Bill 우선
- 응급실 무료 (Public)
- 치과 일부 무료
- 안경 보조금

### 4. 학생용 대안 (Student Concession)
- **NSW**: Opal Card 학생 50% 할인
- **VIC**: Myki 학생 할인 (조건부, 풀타임 학생)
- **QLD**: Translink Concession
- **SA**: Adelaide Metro 학생
- **WA**: SmartRider 학생
- **TAS**: Greencard 학생
- 영문 학생증 + Concession 신청

### 5. 영주권 취득 후 신청
- Centrelink 방문 또는 myGov
- 소득 증명
- 가족 구성 증빙
- 5분 발급 (자격 충족 시)

---

## 🎯 이 학생에게 안내할 정답 경로

### 1단계: 자격 확인
- 학생비자 = 자격 없음
- 영주권 취득 후 가능

### 2단계: 학생용 대안
- OSHC 보험 활용
- Student Concession 교통 카드

### 3단계: 영주권 취득 후
- 소득 확인 (LIHCC 한도)
- Centrelink 신청

### 4단계: 활용
- 약국 PBS 카드 제시
- GP 진료 시 제시
- 정기 갱신

### 5단계: 갱신
- 매년 자동 갱신
- 소득 변경 시 신고

---

## 💡 직원이 학생한테 말할 멘트

```
Healthcare Card는 영주권자/시민권자 대상이에요.
학생은 자격 없어요.

학생비자라면:
1. OSHC가 의료비 보장 역할
   - 학생비자 의무 가입
   - GP, 병원, 처방약 일부 커버

2. Student Concession (교통)
   - 영문 학생증 제출
   - Opal/Myki/Translink 50% 할인
   - 학생 한정 혜택

3. 약국 처방약
   - PBS 할인 안 됨 (영주권자만)
   - OSHC 일부 커버

영주권 취득 후 (저소득 시):
- Low Income Healthcare Card (LIHCC)
  - 약 $7.70 처방약 (정상 $30+)
  - GP Bulk Bill 우선
  - Public 치과 일부 무료

자세한 안내는 윌슨한테 카카오 (studywilson) 주세요.
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: OSHC = Healthcare Card
- 별개 시스템
- OSHC = 사보험 (학생 의무)
- Healthcare Card = 정부 (영주권자)

### 함정 2: 학생도 Bulk Bill 가능?
- OSHC Direct Bill = 가능
- Medicare Bulk Bill = 영주권자만
- GP에 사전 확인

### 함정 3: 친구 카드 사용
- Healthcare Card 명의자 한정
- 가족 부양 가능 (부부·자녀)
- 친구 = 불가, 사기 처벌

### 함정 4: 영주권 취득 즉시 신청
- 자격 확인 (소득 한도)
- Pensioner = 노령연금 수령
- 일반 영주권 = 저소득 자동

### 함정 5: 임시 비자 Medicare 가입
- 영주권 신청 중 = Medicare 가능 (특정 케이스)
- BVA (Bridging Visa A) = Medicare 가능
- 학생비자 = 불가

### 함정 6: 학생비자 자녀 Medicare
- 호주 출생 = 시민권 (조건부)
- 시민권 자녀 = Medicare 가능
- 학생 자녀 = 자동 X

### 함정 7: 영주권 취득 후 이중 보험
- OSHC 자동 무효
- Medicare로 전환
- Private Health Insurance 추가 권장

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **현재 비자** (학생/485/영주권)
2. **나이** (Pensioner 자격)
3. **가족 부양 여부**
4. **목적** (의료비/교통비 절약)

---

## 🔍 직원이 직접 확인 가능한 사이트

- **Services Australia (Healthcare Card)**: servicesaustralia.gov.au
- **Centrelink**: my.gov.au
- **PBS**: pbs.gov.au
- **NSW Opal (학생)**: opal.com.au
- **VIC Myki**: ptv.vic.gov.au

---

## 🚨 직원 영역 vs 전문가 영역

| 항목 | 직원 처리 | 전문가 |
|------|---------|-----|
| 자격 안내 | ✅ | |
| OSHC 대안 안내 | ✅ | |
| Student Concession 안내 | ✅ | |
| 신청 자세 처리 | ❌ | ✅ Centrelink |
| 보험 분쟁 | ❌ | ✅ OSHC 콜센터 |

---

## ✅ 완벽 응대 체크리스트

- [ ] Healthcare Card = 영주권자 한정 안내
- [ ] OSHC 학생 의무 안내
- [ ] Student Concession 교통 카드 안내
- [ ] 영주권 취득 후 신청 가능 안내
- [ ] LIHCC 처방약 할인 효과 설명
- [ ] 친구 카드 사용 금지 강조
- [ ] 윌슨 카카오 상담 유도
