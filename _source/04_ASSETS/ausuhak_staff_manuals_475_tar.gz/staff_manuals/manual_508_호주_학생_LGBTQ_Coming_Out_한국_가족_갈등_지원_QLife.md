# #508 호주_학생_LGBTQ_Coming_Out_한국_가족_갈등_지원_QLife

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "제가 동성애자라는 거 한국 부모님이 알게 됐어요. 절연한대요. 등록금도 끊는다고요. 어떻게 해요?"

**직원 멘붕 포인트:**
- 한국 가족 갈등 + 등록금 중단 = 비자/학업 위기
- Section 8202 학생비자 재정 증명 의무 (자비 가능 범위 평가)
- QLife 1800 184 527 (LGBTI+ 한국어 통역 가능)
- Beyond Blue 1300 22 4636 24시간
- 직원이 가치관 강요 X. 정보만 제공 + 자원 연결

---

## ❌ 절대 하지 말아야 할 답

> "부모님 말씀 따르세요 한국 돌아가세요"

→ ❌ 가치관 강요 X. 학생 자결권. 호주 LGBTI+ 자원 + 비자 옵션 안내

---

## ✅ 정답

힘드시겠어요. 호주는 LGBTI+ 차별금지법(Sex Discrimination Act 2013) 보호하고 동성결혼도 합법(2017)이라 안전하게 살 수 있어요. 한국 가족 갈등은 QLife 1800 184 527에서 24시간 LGBTI+ 전문 상담 받으세요. Beyond Blue 1300 22 4636도 한국어 통역 가능합니다. 등록금 중단 위기는 학교 Welfare Officer + Emergency Grant + Casual Job 활용 가능해요. 학생비자 재정 부족 시 Defer/Course Transfer 옵션도 있습니다. 본인 결정 우선이고, 시간 갖고 자원 활용하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 LGBTI+ 보호 (법적)**
Sex Discrimination Act 2013:
- 성적지향/성별 정체성 차별 금지
- 직장/교육/주거/의료
- AHRC 신고 1300 656 419

Marriage Amendment Act 2017:
- 동성결혼 합법
- Partner Visa 동등

Anti-Discrimination Act (각 주):
- 추가 보호
- 종교 제외 일부 (학교/단체)
외국인 학생도 동일 보호

**2. LGBTI+ 자원 (호주 24시간)**
QLife: 1800 184 527 (24시간)
- LGBTI+ 전문 상담
- 한국어 통역 가능 TIS 13 14 50

Acon NSW: acon.org.au
- LGBTI+ 건강/지원
- 시드니

Switchboard VIC: switchboard.org.au / 1800 184 527
Twenty10 시드니: twenty10.org.au

온라인 자원:
- Minus18 (청소년)
- Australians Together

**3. 한국 가족 갈등 + 심리**
Beyond Blue: 1300 22 4636 (24시간)
Lifeline: 13 11 14 (24시간)
Headspace: 12~25세 무료
한국어 통역: 13 14 50

갈등 회복:
- 시간 갖기
- 가족 상담 (선택)
- 한국 LGBTI+ 단체 (한국행복연대 등)
절연 가능성:
- 본인 자결권 우선
- 시간 후 회복 사례 많음
- 강요 X

**4. 재정 위기 (등록금 중단)**
학생비자 재정 증명:
- 학비 + 생활비 ($29,710/년)
- 자비 또는 후원자
- 부모 후원 중단 시 본인 자비 증명 필요

긴급 옵션:
- 학교 Emergency Grant $200~$500
- Casual Job (Fair Work 보호)
- Course Transfer (저렴한 학교)
- Course Defer (1학기 휴학)
- 학비 분할 (학교 협의)
- Section 8503 6개월 룰 검토

**5. Course Transfer/Defer 옵션**
Course Transfer:
- 6개월 안 첫 학기 (Standard 7 of National Code)
- 6개월 후 자유
- 저렴한 학교 (Pathway College, TAFE)

Course Defer (휴학):
- Compassionate Grounds (가족 갈등 인정 가능)
- 1학기 휴학 (LOA)
- 비자 유지 일부 가능
- Census Date 전 결정

Withdraw + 재신청:
- 비자 종료
- 새 비자 (재정 안정 후)
- MARA 자문 권장

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: QLife 1800 184 527 즉시 LGBTI+ 상담
**2단계**: 학교 Welfare Officer + Emergency Grant 신청
**3단계**: Casual Job (Fair Work 보호) 알아보기
**4단계**: Course Transfer 또는 Defer 검토 (MARA 자문)
**5단계**: 한국어 심리 상담 1800 RESPECT/Beyond Blue

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 힘드시겠어요. 호주는 LGBTI+ 차별금지법 보호하고 동성결혼 합법이라 안전합니다. QLife 1800 184 527 (24시간 LGBTI+ 상담), Beyond Blue 1300 22 4636 (한국어 통역 13 14 50) 활용하세요. 등록금 위기는 학교 Welfare Officer + Casual Job + Course Transfer 옵션 있어요. 학생비자 재정 영향은 MARA 자문 권장합니다. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **가치관 강요 X**
   → 본인 자결권 + 직업 윤리

2. **호주 LGBTI+ 위험 X**
   → 법적 보호 + 동성결혼 합법

3. **등록금 끊김 = 비자 즉시 X**
   → 학교 + 본인 자비 증명 가능

4. **Casual Job 못 함 X**
   → Fair Work 보호

5. **Defer 자동 X**
   → Compassionate + 학교 협의

6. **한국 가족 자동 회복 X**
   → 시간 + 갈등 관리

7. **Coming Out 강요 X**
   → 본인 시점 결정

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 안전해요? (안전/위협)
2. 등록금 잔액 얼마? (한 학기/없음)
3. Casual Job 가능? (가능/모름)
4. 한국 돌아갈 옵션? (있다/없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- QLife: qlife.org.au / 1800 184 527
- Acon NSW: acon.org.au
- Beyond Blue: 1300 22 4636
- Sex Discrimination Act: humanrights.gov.au
- TIS Korean: 13 14 50

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- LGBTI+ 자원 1차 안내
- 학교 Welfare Officer 연결
- Casual Job + Fair Work 안내
- Course Transfer/Defer 1차 안내

**MARA / 변호사 영역**
- Course Transfer (MARA)
- Course Defer (MARA + 학교)
- 재정 증명 변경 (MARA)
- 한국 가족 분쟁 (한국 변호사 - 절연 결정)

---

## ✅ 완벽 응대 체크리스트

- [ ] QLife 24시간 상담
- [ ] 학교 Welfare + Emergency Grant
- [ ] Casual Job
- [ ] Course 옵션 MARA 자문
- [ ] 심리 상담 한국어
