# #292 호주_학생_LGBT_차별_지원

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 게이인데 호주에서 차별받을까봐 걱정돼요. 학교/직장 어떤가요? 결혼하면 비자 받나요?"

**직원 멘붕 포인트:**
- 호주 LGBT 권리 (2017 동성결혼 합법)
- 학교 LGBT Support Group (Sydney/Melbourne)
- Partner Visa 동성 동등 인정
- 한국 가족 통보 vs 학생 프라이버시
- Hate Crime 신고 절차

---

## ❌ 절대 하지 말아야 할 답

> ""호주는 LGBT 차별 없음""

→ ❌ 법적 보호 vs 사회적 차별 별개. 단정 X. 정확한 정보만.

---

## ✅ 정답

"호주는 2017년 동성결혼 합법화 + LGBT 차별 금지법 (Sex Discrimination Act 1984) 시행 중입니다. Partner Visa 동성 동등 인정 (820/801, 309/100). 학교/직장 LGBT Support Group 활성화 (Sydney/Melbourne). 차별 신고 = Australian Human Rights Commission."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 LGBT 법적 권리**
Sex Discrimination Act 1984 = 성적 지향/성별 정체성 차별 금지. Marriage Act 2017 = 동성결혼 합법. State별 차별 금지법 (NSW Anti-Discrimination Act). 직장 차별 = Fair Work Act 보호. 학교 차별 = Education Act 보호.

**2. LGBT Friendly 학교/도시**
Sydney = 가장 LGBT Friendly (Mardi Gras 매년 2월). Melbourne 2위. Brisbane/Adelaide/Perth = 보수적이지만 법적 보호. 학교 = USyd Queer Collective / UNSW Queer Collective / Melbourne University Queer Department 등 모든 대학 운영.

**3. Partner Visa 동성 동등**
Partner Visa 820/801 (호주 내), 309/100 (해외) = 동성 동등 인정. 사실혼 12개월 동거 입증. 결혼 = NSW Births/Marriages 등록. 동성 결혼 합법 후 Partner Visa 신청 정상 처리.

**4. 차별 신고 절차**
Australian Human Rights Commission: 1300 656 419. State별 = NSW Anti-Discrimination Board (1800 670 812). 직장 = Fair Work Commission. 학교 = Wellbeing Office. Hate Crime = 경찰 (000 또는 131 444).

**5. 한국 학생 LGBT 지원**
한국 영사관 = LGBT 정보 제공 X. ACON (AIDS Council of NSW) = 한국어 지원 일부. Asian Marriage Alliance = 한국/아시아 LGBT 커뮤니티. Wilson = 정서 지원 + 학교 Wellbeing Office 연결.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 학교 LGBT Support Group 가입 (모든 대학)
**2단계**: 한국 가족 커밍아웃 vs 비밀 본인 결정 (Wilson 강요 X)
**3단계**: 차별 발생 시 학교 Wellbeing Office 신고
**4단계**: Partner 만남 → 사실혼 12개월 또는 결혼 → Partner Visa
**5단계**: Hate Crime 발생 시 경찰 + ACON 연락

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 호주는 2017년 동성결혼 합법 + LGBT 차별 금지법 시행 중이에요. Sydney가 가장 LGBT Friendly이고 모든 대학에 Queer Collective (LGBT Support Group) 있어요. Partner Visa도 동성 동등 인정해서 결혼하면 영주권 가능해요. 차별 발생 시 학교 Wellbeing Office 또는 Australian Human Rights Commission (1300 656 419) 신고할 수 있고요. 한국 가족 커밍아웃은 학생 본인 결정이에요. 더 자세한 정보 필요하시면 카카오로 편하게 말씀하세요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"호주 = 차별 전혀 없음"**
   → 법적 보호 O. 사회적 차별 일부 존재.

2. **"동성결혼 = 즉시 PR"**
   → Partner Visa 4~5년 (820 → 801).

3. **"LGBT = 학생비자 거절"**
   → 성적 지향 = 비자 거절 사유 X.

4. **"한국 가족 무조건 알려야"**
   → 학생 본인 결정. Wilson 강요 X.

5. **"호주 = HIV 자유"**
   → PrEP 가능 (Medicare 적용 PR/시민권).

6. **"교회/모스크 차별 보호 X"**
   → 종교 단체 일부 차별 가능 (Religious Discrimination Bill).

7. **"호주 LGBT = 전부 결혼"**
   → 결혼 vs 사실혼 vs 비혼 자유.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 비자 종류
2. Partner 유무 (사실혼/결혼)
3. 차별 경험 여부
4. 한국 가족 인지 여부 (학생 동의)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ACON (LGBT NSW): https://www.acon.org.au
- Australian Human Rights Commission: 1300 656 419
- Sydney Mardi Gras: https://www.mardigras.org.au
- 각 대학 Queer Collective

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 정서 지원, 정보 안내
- 학교 LGBT Support Group 연결
- Partner Visa MARA Lawyer 추천
- 차별 신고 절차 안내
- 윌슨 직접 카카오 (편안한 공간)

**MARA / 변호사 영역**
- Australian Human Rights Commission = 차별 신고
- ACON = LGBT 의료/정신건강
- Fair Work Commission = 직장 차별
- MARA Lawyer = Partner Visa
- 경찰 = Hate Crime

---

## ✅ 완벽 응대 체크리스트

- [ ] 현재 비자 + Partner 유무 확인했다
- [ ] 차별 경험 청취했다
- [ ] 호주 LGBT 법적 권리 안내했다
- [ ] Sydney/Melbourne 추천 안내했다
- [ ] 학교 Queer Collective 안내했다
- [ ] Partner Visa 동성 동등 안내했다
- [ ] 차별 신고 절차 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
