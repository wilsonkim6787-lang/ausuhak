# #284 호주_학생_우울증_학업_병행

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 호주 와서 외로워서 우울증 걸린 것 같아요. 학교 결석 자주 하고 시험도 망쳤어요. 비자 영향 있나요?"

**직원 멘붕 포인트:**
- 우울증 = 학업 영향 + Special Consideration 신청
- OSHC 정신과 보장 vs 자비
- 비자 8202 (출석률 80%) 위반 위험
- 한국 가족 통보 vs 학생 프라이버시
- 자살 사고 시 즉시 응급 (Lifeline 13 11 14)

---

## ❌ 절대 하지 말아야 할 답

> ""한국 가서 쉬다가 다시 오면 됨""

→ ❌ 휴학/조퇴 비자 절차 + 재입국 시 새 비자 필요. 의학적 도움이 우선.

---

## ✅ 정답

"우울증은 호주에서 정식 의학적 도움 받을 수 있고 학교에 Special Consideration 신청 가능합니다. 자살 사고 있으시면 즉시 Lifeline 13 11 14 연락하세요. Mental Health Care Plan으로 심리상담사 연결 가능합니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Mental Health Care Plan**
GP (가정의)에게 우울증 상담 → Mental Health Care Plan 작성 → Medicare/OSHC 적용 심리상담사 (Psychologist) 10회 무료 (연간). 한국어 가능 심리상담사 시드니/멜번/브리즈번에 30~50명. GP Referral 필수. 우울증 약 (항우울제) = PBS 적용 시 $30.

**2. 학교 Special Consideration**
시험 결석/낮은 점수 = Special Consideration 신청. 의사 진단서 + 학교 Wellbeing Office. 재시험 또는 점수 조정. UNSW/Sydney/Melbourne 등 모든 대학 제공. TAFE도 동일. 신청 기한 = 보통 시험 후 7일 내.

**3. 출석률 80% 비자 위반**
비자 8202 = ELICOS 80% 출석. 우울증으로 결석 누적 시 학교 → DHA 통보 → 비자 취소 가능. Compassionate Circumstance (의사 진단서) = 출석 면제. 학교 Wellbeing Office에 미리 통보 필수.

**4. 자살 사고 응급 대응**
Lifeline: 13 11 14 (24시간 무료, 한국어 가능 시간 제한). Beyond Blue: 1300 22 4636. Suicide Call Back Service: 1300 659 467. 한국 영사관: 02-9210-0200 (시드니, 24시간). 응급실 (Emergency) = 000 또는 가까운 병원 직접.

**5. OSHC 정신건강 보장**
Bupa/Medibank/Allianz/NIB/AHM = Mental Health 보장 (12개월 Waiting Period). 입원 = 무료. 외래 (심리상담) = $50~$100/회 (자비 일부). Mental Health Care Plan 적용 시 Bulk Bill 가능 → 무료. 한국어 심리상담사 약간 비싸 (시간당 $200).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: GP (가정의) 예약 → 우울증 상담
**2단계**: Mental Health Care Plan 작성 (Medicare/OSHC)
**3단계**: 한국어 가능 심리상담사 검색 + 예약 (10회 무료)
**4단계**: 학교 Wellbeing Office 연락 + Special Consideration 신청
**5단계**: 자살 사고 시 즉시 Lifeline 13 11 14 또는 응급실

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 호주 와서 외로움 많이 느끼시는 것 같아 마음이 아파요. 우울증은 호주에서 의학적으로 충분히 도움받을 수 있어요. GP (가정의) 예약하시면 Mental Health Care Plan 만들어줘서 한국어 가능 심리상담사 10회 무료로 받을 수 있어요. 학교에는 Special Consideration 신청해서 결석/시험 보호받을 수 있고요. 혹시 자살 생각 있으시면 즉시 Lifeline 13 11 14 (24시간) 또는 한국 영사관 02-9210-0200 연락하세요. Wilson도 카카오로 언제든 들어주실게요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"한국 가서 쉬면 됨"**
   → 휴학 절차 + 재입국 비자 필요. 호주에서 도움 가능.

2. **"OSHC 정신과 보장 X"**
   → 12개월 Waiting Period 후 보장. Mental Health Care Plan = 즉시.

3. **"학교에 알리면 비자 취소"**
   → Special Consideration 신청은 비자 보호. 미신청이 위험.

4. **"한국 부모한테 비밀"**
   → 심각한 우울증 = 부모 알리는 게 안전. 학생 프라이버시 존중하되 안전 우선.

5. **"항우울제 위험"**
   → PBS 적용 안전한 약 처방. 의사 지시 따르기.

6. **"한국어 상담사 없음"**
   → 시드니/멜번/브리즈번에 30~50명. GP가 추천.

7. **"자살 사고는 부끄러움"**
   → Lifeline 13 11 14 무료 + 익명 + 한국어 가능. 즉시 연락 권장.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 우울증 증상 시작 시점 + 자살 사고 여부
2. 출석률 현재 (80% 미달 위험)
3. 학교 Wellbeing Office 연락 여부
4. 한국 가족 인지 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- Lifeline: 13 11 14 (24시간 무료)
- Beyond Blue: 1300 22 4636
- Suicide Call Back: 1300 659 467
- 한국 영사관 시드니: 02-9210-0200 (24시간)
- Mental Health Care Plan (GP)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 정서 지원, 의사/상담사 연결
- Mental Health Care Plan 안내
- 학교 Wellbeing Office 연락 도움
- 한국 가족 연락 중재 (학생 동의 시)
- 윌슨 직접 카카오 (24시간 OK)

**MARA / 변호사 영역**
- GP = Mental Health Care Plan 작성
- Psychologist = 심리상담
- Psychiatrist = 약물 처방
- 학교 Wellbeing Office = Special Consideration
- Lifeline = 응급 무료 상담

---

## ✅ 완벽 응대 체크리스트

- [ ] 우울증 증상 청취했다
- [ ] 자살 사고 여부 확인했다 (있으면 즉시 Lifeline)
- [ ] GP 예약 안내했다
- [ ] Mental Health Care Plan 안내했다
- [ ] 한국어 심리상담사 연결 안내했다
- [ ] 학교 Special Consideration 안내했다
- [ ] 출석률 비자 영향 안내했다
- [ ] Wilson 24시간 카카오 안내했다 (studywilson)
