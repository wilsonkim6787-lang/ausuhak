# #464 호주_학생_시험_부정행위_Misconduct_커닝_AI_ChatGPT_제명

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시험 보다가 휴대폰 봤다고 시험 감독관한테 잡혀서 Academic Misconduct로 신고됐어요. 학교 측에서 청문회(Hearing) 한다는데 너무 무서워요. 변호사 필요한가요? 제명되면 비자도 끝나는 건가요? 그리고 ChatGPT로 과제 했다고 들켰을 때도 Misconduct인가요?"

**직원 멘붕 포인트:**
- Academic Misconduct = 학교별 정책 / 처벌 다름
- 경고 / Fail / 코스 제명 / 학위 박탈 단계별
- 제명 = 학생비자 28일 내 신규 비자 또는 출국
- ChatGPT 사용 = Misconduct 케이스 (일부 학교 = OK, 일부 = Fail)
- 청문회(Hearing) 권리 - 학생 항변 + Support Person
- 외부 변호사 동행 가능 (Student Union 무료 자문)

---

## ❌ 절대 하지 말아야 할 답

> "자수하시고 사정하시면 봐줄 거예요"

→ ❌ 자수 = 자백 인정 / 처벌 더 무거움 / 청문회 권리 활용 + Student Union 자문 + 항변 절차 / 정확한 안내 필요

---

## ✅ 정답

(1) 청문회(Hearing) 일정/장소/규정 확인 - 학교 정책 (2) Student Union 무료 자문 - 거의 모든 호주 대학 무료 (3) Academic Defender 동행 - 학생회 변호인 (4) 항변 준비 - 사실/맥락/반성/재발방지 (5) 결과 = 경고/Fail/제명 - 항소 가능

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Academic Misconduct 단계 (학교별)**
Cheating(부정행위)/Plagiarism(표절)/Collusion(공모)/Contract Cheating(대리시험)/AI Use(미허가) / 단계: Warning(경고) → Fail Subject → Suspended → Excluded(제명) → Degree Revoked / 학교별 정책 다름.

**2. 청문회 (Hearing) 절차**
Step 1: 신고서(Notice of Allegation) 학생 통지 / Step 2: 항변 서면(7~14일) / Step 3: 청문회 출석 / Step 4: 결정 통지 / Step 5: 항소(7~21일) / 학생 권리: 증인/Support Person/녹음(일부)/항변.

**3. 학생 권리 + Student Union**
Australian National University Student Union / Sydney University Student Representative Council(SRC) / UNSW Student Council / Monash Student Association / 무료 자문(Academic Defender) / 학생회비 일부 / 학교별 무료 변호인 등록 학생.

**4. ChatGPT/AI Use 정책 (2024~)**
학교마다 다름 / Sydney University: AI 사용 표시(인용) / UNSW: 일부 과제 OK / Melbourne: 시험 X 과제 일부 / Monash: 과제 표시 OK / RMIT: 시험 + 과제 모두 X / Turnitin AI Detector 사용(거짓 양성률 1~5%).

**5. 비자 영향 (제명 시)**
Excluded(제명) = CoE Cancel = 학생비자 자동 28일 단축 통보 / 28일 내 신규 학교 등록 + CoE 발급 + 비자 변경 OR 출국 / Suspension(정학) = 학생비자 유지 / Warning = 영향 X / 한 학교 제명 후 다른 학교 입학 = ESOS Standard 7 적용.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: Notice of Allegation 받은 즉시 - Student Union 무료 자문 (1주일 내)
**2단계**: 2차: 청문회 일정/장소 확인 + 항변 서면 작성 - Academic Defender 도움
**3단계**: 3차: 청문회 출석 - Support Person 동행 / 녹음 동의 시 가능
**4단계**: 4차: 결정 통지 (경고/Fail/제명) - 7~21일 항소 기한
**5단계**: 5차: 제명 시 = Wilson 카카오 즉시 - 28일 내 신규 학교 + CoE + 비자 변경

---

## 💡 직원이 학생한테 말할 멘트

> "Academic Misconduct는 학교 정책에 따라 처벌 다양합니다(경고~제명). 우선 Student Union(무료) 즉시 자문 받으세요 - 거의 모든 호주 대학 무료입니다. 청문회 = 학생 권리니 항변 서면 + Support Person 동행하시고요. ChatGPT 사용은 학교마다 다릅니다(과제 표시 OK or 전면 금지). 제명 = 학생비자 28일 단축이라 즉시 윌슨 직접 상담 권장합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **자수 = 더 무거운 처벌**
   → 자수 = 자백 인정 / 청문회 항변 권리 행사 = 처벌 가능성 낮춤 / Student Union 무료 자문 후 결정.

2. **Student Union 회비 학생비자 OK**
   → 학생비자 = 학교 등록 = 자동 학생회 회원 / 무료 자문 / 일부 변호사 동행 비용 별도.

3. **Turnitin AI Detector 거짓 양성**
   → 1~5% 거짓 양성률 / 학생 본인 작성도 AI 의심 / 청문회에서 작성 과정(History) 증명.

4. **청문회 통역 무료**
   → TIS National 13 14 50 / 한국어 무료 / 청문회 사전 신청 / 항변 정확히.

5. **제명 후 다른 학교 입학**
   → ESOS National Code Standard 7 / Release Letter 필요 / 새 학교 입학 시 Misconduct 기록 공유 가능 / 윌슨 직접 상담.

6. **Suspension vs Exclusion**
   → Suspension(정학) = 학기 1~2 정지 / 학생비자 유지 / Exclusion(제명) = 학교 영구 제명 / 학생비자 28일 단축.

7. **학위 박탈 (Degree Revoked)**
   → 졸업 후 부정행위 발견 시 학위 박탈 가능 / 매우 드물지만 가능 / 평생 기록.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. (
2. 1
3. )
4.  
5. M
6. i
7. s
8. c
9. o
10. n
11. d
12. u
13. c
14. t
15.  
16. 종
17. 류
18. (
19. 부
20. 정
21. /
22. 표
23. 절
24. /
25. A
26. I
27. )
28. ?
29.  
30. (
31. 2
32. )
33.  
34. N
35. o
36. t
37. i
38. c
39. e
40.  
41. o
42. f
43.  
44. A
45. l
46. l
47. e
48. g
49. a
50. t
51. i
52. o
53. n
54.  
55. 받
56. 은
57.  
58. 날
59. 짜
60. ?
61.  
62. (
63. 3
64. )
65.  
66. 청
67. 문
68. 회
69.  
70. 일
71. 정
72. ?
73.  
74. (
75. 4
76. )
77.  
78. S
79. t
80. u
81. d
82. e
83. n
84. t
85.  
86. U
87. n
88. i
89. o
90. n
91.  
92. 자
93. 문
94.  
95. 받
96. 은
97.  
98. 적
99. ?

---

## 🔍 직원이 직접 확인 가능한 사이트

- USyd SRC(srcusyd.net.au), UNSW Student Council(arc.unsw.edu.au), Monash MSA(msa.monash.edu), TEQSA(teqsa.gov.au), Overseas Students Ombudsman(ombudsman.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Misconduct 단계 / 청문회 절차 / Student Union 무료 자문 / ChatGPT 학교별 정책 / 제명 시 28일 룰 / 비자 영향 / TIS 통역

**MARA / 변호사 영역**
- 제명 후 비자 변경 → 이민 변호사 / 청문회 외부 변호사 → 변호사 / 학위 박탈 항소 → TEQSA / 형사 사기(대리시험 강요) → 경찰

---

## ✅ 완벽 응대 체크리스트

- [ ] □
- [ ]  
- [ ] N
- [ ] o
- [ ] t
- [ ] i
- [ ] c
- [ ] e
- [ ]  
- [ ] o
- [ ] f
- [ ]  
- [ ] A
- [ ] l
- [ ] l
- [ ] e
- [ ] g
- [ ] a
- [ ] t
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] 즉
- [ ] 시
- [ ]  
- [ ] S
- [ ] t
- [ ] u
- [ ] d
- [ ] e
- [ ] n
- [ ] t
- [ ]  
- [ ] U
- [ ] n
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] □
- [ ]  
- [ ] 청
- [ ] 문
- [ ] 회
- [ ]  
- [ ] 항
- [ ] 변
- [ ]  
- [ ] 권
- [ ] 리
- [ ]  
- [ ] □
- [ ]  
- [ ] S
- [ ] u
- [ ] p
- [ ] p
- [ ] o
- [ ] r
- [ ] t
- [ ]  
- [ ] P
- [ ] e
- [ ] r
- [ ] s
- [ ] o
- [ ] n
- [ ]  
- [ ] 동
- [ ] 행
- [ ]  
- [ ] □
- [ ]  
- [ ] T
- [ ] I
- [ ] S
- [ ]  
- [ ] 통
- [ ] 역
- [ ]  
- [ ] □
- [ ]  
- [ ] C
- [ ] h
- [ ] a
- [ ] t
- [ ] G
- [ ] P
- [ ] T
- [ ]  
- [ ] 학
- [ ] 교
- [ ] 별
- [ ]  
- [ ] 정
- [ ] 책
- [ ]  
- [ ] □
- [ ]  
- [ ] 제
- [ ] 명
- [ ]  
- [ ] 시
- [ ]  
- [ ] 2
- [ ] 8
- [ ] 일
- [ ]  
- [ ] 룰
- [ ]  
- [ ] □
- [ ]  
- [ ] W
- [ ] i
- [ ] l
- [ ] s
- [ ] o
- [ ] n
- [ ]  
- [ ] 직
- [ ] 접
- [ ]  
- [ ] 상
- [ ] 담
