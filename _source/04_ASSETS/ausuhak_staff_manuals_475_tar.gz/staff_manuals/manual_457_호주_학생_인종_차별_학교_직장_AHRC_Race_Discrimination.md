# #457 호주_학생_인종_차별_학교_직장_AHRC_Race_Discrimination

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "아르바이트하는 카페에서 매니저가 한국 학생들에게만 더 힘든 일 시키고 욕도 해요. 'Asian Pig' 등 인종차별 발언 했어요. 학교에서도 호주 학생들이 영어 못한다고 무시하고요. 어떻게 신고하나요? 비자 영향 있나요?"

**직원 멘붕 포인트:**
- Race Discrimination Act 1975 (호주 연방법)
- Australian Human Rights Commission (AHRC) 신고 가능
- Fair Work 차별 관련 직장 신고
- 학교 차별 = 학교 정책 + AHRC
- 신고자 비자 영향 X (피해자 보호)
- 한국 학생들 흔히 신고 안 함 - 권리 보호 필수

---

## ❌ 절대 하지 말아야 할 답

> "신고하면 일자리 잃어요"

→ ❌ 신고자 보복은 추가 위법 / Fair Work 보호 / 잘못된 두려움 = 차별 방치

---

## ✅ 정답

(1) AHRC 무료 신고 (2) Fair Work Ombudsman 직장 차별 (3) 학교 Equity Officer (4) 증거 수집 (녹음/SMS/목격자) (5) 비자 영향 X

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Racial Discrimination Act 1975**
호주 연방법 / 인종/피부색/혈통/국적/민족 차별 위법 / Section 18C 'Hate Speech' 형사 처벌 가능 / 신고처 = AHRC.

**2. Australian Human Rights Commission (AHRC)**
humanrights.gov.au / 1300 656 419 / 무료 / 차별 신고 + 조정 / 한국어 통역 가능 (TIS 131 450).

**3. Fair Work Discrimination**
fairwork.gov.au / 13 13 94 (한국어) / 직장 인종 차별 / 임금/시간 차별 / 보복 해고 위법 / Sham Contract 관련.

**4. 학교 Equity Officer**
각 대학/TAFE Equity & Diversity Office 운영 / 인종/성/장애 차별 신고 / 학내 조사 + 징계 / 학생 본인 또는 익명 신고.

**5. 증거 수집 (Evidence)**
녹음 = NSW/VIC/QLD 본인 참여 대화 합법 (One-Party Consent) / SMS/이메일 캡처 / 목격자 진술 / 차별 사건 일기 (날짜/시간/내용).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 증거 수집 (녹음/SMS/이메일/목격자 진술/일기)
**2단계**: 2차: 학교 차별 = 학교 Equity Officer / 직장 차별 = Fair Work
**3단계**: 3차: AHRC 무료 신고 (humanrights.gov.au)
**4단계**: 4차: 1800 RESPECT 1800 737 732 (한국어 통역, 차별로 인한 정신 피해 시)
**5단계**: 5차: 보복 해고 시 Fair Work Unfair Dismissal 신청

---

## 💡 직원이 학생한테 말할 멘트

> "정말 힘드셨을 거예요. 이건 본인 잘못 아니고 호주에 강력한 차별 금지 시스템 있어요.

**차별 = 호주 연방법 위법** (Racial Discrimination Act 1975)

**즉시 할 일:**

1. **증거 수집**:
   - 녹음 (NSW/VIC/QLD 본인 참여 대화 합법)
   - SMS/이메일 캡처
   - 목격자 진술
   - 차별 사건 일기 (날짜/시간/내용)

2. **신고 채널 (무료):**
   - **AHRC (인권위)**: humanrights.gov.au / 1300 656 419
   - **Fair Work** (직장): fairwork.gov.au / **13 13 94 (한국어 통역)**
   - **학교 Equity Officer**: 학내 차별

3. **보복 두렵다면:**
   - 신고자 보복 해고 = 추가 위법 (Fair Work)
   - Unfair Dismissal 신청 가능

**비자:**
신고자 비자 영향 **없습니다**. 오히려 차별 피해 입증 시 향후 비자 신청 시 도움 가능.

**정신 피해:**
1800 RESPECT (1800 737 732, 한국어 24시간) - 인종 차별로 인한 정신 피해도 지원.

**학교 차별:**
학교 Equity & Diversity Office에 신고 → 학내 조사. 익명 신고 가능.

**'Asian Pig' 등 발언:**
Section 18C Hate Speech = 형사 처벌 가능. 녹음 있으면 강력한 증거.

학교/지역/직장 알려주시면 한국어 가능 신고 채널 안내드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **외국인 학생이 신고하면 비자 영향**
   → 피해자 비자 영향 X / 가해자만 영향

2. **증거 없으면 못 한다**
   → 녹음 + 일기만으로 충분 / 호주 NSW/VIC/QLD One-Party Consent

3. **녹음은 불법이다**
   → NSW/VIC/QLD = 본인 참여 대화 녹음 합법 / 동의 X 녹음 불법

4. **신고하면 보복 해고**
   → 보복 해고 = 추가 위법 / Fair Work Unfair Dismissal 신청 가능

5. **AHRC는 호주인만**
   → 거주자/학생 모두 무료 / 비자 무관

6. **학교 차별은 못 신고**
   → 학교 Equity Officer + AHRC 가능

7. **'Asian Pig' 발언 = 농담일 수 있다**
   → 농담 아닌 명백한 인종차별 / Section 18C Hate Speech / 형사 처벌

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 차별 발생 장소 (학교 / 직장 / 공공)
2. 증거 보유 여부 (녹음/SMS/목격자)
3. 본인 비자 종류 (학생/485/PR)
4. 정신 피해 정도 (Counselling 필요 여부)

---

## 🔍 직원이 직접 확인 가능한 사이트

- humanrights.gov.au / 1300 656 419 (AHRC)
- fairwork.gov.au / 13 13 94 (한국어)
- 1800 RESPECT 1800 737 732 (24시간 한국어)
- TIS National 131 450 (한국어 통역)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- AHRC 일반 안내
- Fair Work 차별 신고 안내
- 학교 Equity Officer 안내
- 증거 수집 일반 가이드

**MARA / 변호사 영역**
- 보복 해고 시 비자 영향 평가
- 심각한 차별 폭력 시 형사 절차
- Compassionate Circumstances 비자 신청

---

## ✅ 완벽 응대 체크리스트

- [ ] 차별 = 위법 명확히
- [ ] 비자 영향 X 강조 (피해자)
- [ ] AHRC 무료 안내
- [ ] Fair Work 한국어 13 13 94
- [ ] 녹음 합법 (NSW/VIC/QLD)
- [ ] 보복 해고 추가 위법 안내
- [ ] 학교 Equity Officer 안내
- [ ] 한국어 통역 자원 안내
