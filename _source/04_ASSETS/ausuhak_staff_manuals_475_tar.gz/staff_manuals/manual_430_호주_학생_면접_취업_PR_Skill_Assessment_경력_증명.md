# #430 호주_학생_면접_취업_PR_Skill_Assessment_경력_증명

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "졸업 후 485 비자로 일하고 있는데 PR 신청 위해 ACS Skill Assessment 받아야 한대요. 한국 경력 + 호주 경력 둘 다 인정받으려고 하는데 한국 회사 영문 경력증명서 어떻게 받나요? 영문 안 해주면 어떡하죠? 면접 봐야 한다는 사람도 있던데 진짜인가요?"

**직원 멘붕 포인트:**
- Skill Assessment 영문 서류
- 한국 회사 영문 경력증명
- ACS 면접 vs 서류 평가
- VETASSESS Technical Interview
- Statutory Declaration 대체

---

## ❌ 절대 하지 말아야 할 답

> "한국 회사가 영문 안 해주면 그냥 호주 경력만 쓰세요"

→ ❌ ❌ 한국 경력 포기 시 PR 점수 큰 손실. Statutory Declaration + 영문 번역공증 대체 가능.

---

## ✅ 정답

Skill Assessment 한국 경력 입증: ① 한국 회사 영문 경력증명서 요청 (인사팀 직접) - 안 해주면 한글본+영문 번역공증 (NAATI 또는 한국 영사관 인증), ② 통장 입출금 내역 (월급) + 4대보험 가입증명서 (국민연금공단 영문 발급 가능), ③ 동료 Statutory Declaration (호주 JP 또는 변호사 인증) 보조 증빙, ④ ACS 면접 = 일부 케이스만 (의심 사례 / 일반 X), ⑤ VETASSESS Technical Interview = 일부 직군 (요리사/용접 등 실기 직군), ⑥ Engineers Australia CDR = 실무 사례 3개 영문 서술 / 면접 X, ⑦ 한국 NPS 영문증명서 nps.or.kr 무료 / 영문 발급, ⑧ 한국 4대보험 통합 - 4insure.or.kr.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ACS Skill Assessment**
$530 / 서류 / 면접 드물게

**2. VETASSESS**
$1,055 / Technical Interview 일부

**3. Engineers CDR**
$760 / 사례 3개 / 면접 X

**4. Statutory Declaration**
호주 JP 인증 / 동료 진술

**5. 국민연금 영문**
nps.or.kr 무료

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: Skill Assessment 기관 결정 (직군별)
**2단계**: 2단계: 한국 회사 영문 경력증명 요청
**3단계**: 3단계: NPS 영문증명서 + 통장 내역 보조
**4단계**: 4단계: 안 되면 Statutory Declaration 대체
**5단계**: 5단계: 호주 NAATI 번역공증 마무리

---

## 💡 직원이 학생한테 말할 멘트

> "한국 회사 영문 경력증명서 1차 요청하세요. 안 해주면 NAATI 번역공증 + NPS 영문증명서 + Stat Dec로 대체 가능합니다. ACS는 면접 거의 없고, VETASSESS만 일부 직군 Technical Interview 있습니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 경력 포기**
   → PR 점수 손실 큼

2. **ACS 면접 필수**
   → 드뭄 / 서류 위주

3. **VETASSESS 면접 모든 직군**
   → 요리/용접 등 일부

4. **Stat Dec 효력 X**
   → JP 인증 시 법적 효력

5. **한국 영사관 인증 안 됨**
   → 공증 가능

6. **국민연금 영문 X**
   → 무료 영문 발급

7. **NAATI 번역 비공식**
   → 법적 인정 (등록 번역사)

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Skill Assessment 기관 (직군별)
2. 한국 경력 연수
3. 한국 회사 인사팀 협조도
4. 현재 비자 (485 만료일)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('ACS', 'acs.org.au')
- ('VETASSESS', 'vetassess.com.au')
- ('국민연금 영문', 'nps.or.kr')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Skill Assessment 일반 안내, 서류 종류

**MARA / 변호사 영역**
- 복잡한 케이스 / Stat Dec 작성 / EOI 시점

---

## ✅ 완벽 응대 체크리스트

- [ ] 1차 회사 영문 요청 강조함
- [ ] Stat Dec 대체 안내함
- [ ] NPS 영문 무료 안내함
- [ ] ACS 면접 드물다 안내함
- [ ] VETASSESS 일부 직군 면접 명시함
- [ ] NAATI 번역공증 안내함
