# #491 호주_거주_한국_친구_호주_방문_Subclass_600_601_관광_비자_초청장

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한국 친구가 호주 놀러 오고 싶대요. 비자 어떻게 받아요? 제가 초청장 써야 해요?"

**직원 멘붕 포인트:**
- 한국 여권 호주 방문: ETA(601) 또는 Visitor(600)
- ETA 601: 온라인 $20, 12개월 Multi Entry, 1회 3개월
- Visitor 600: $200 (Offshore) / $500 (Onshore), 3~12개월, 사정 시 12개월 단일 체류
- 초청장: 본인이 호주 거주 학생이면 초청장 작성 가능
- 초청장 = Genuine Visitor 증명 자료 (필수 X but 도움)

---

## ❌ 절대 하지 말아야 할 답

> "한국 친구는 비자 없이 그냥 와도 돼요"

→ ❌ 모든 외국인 입국 비자 필요. ETA 또는 Visitor 600. 무비자 입국 X

---

## ✅ 정답

한국 여권은 호주 방문 시 ETA(Subclass 601) 또는 Visitor 600 비자 필요해요. ETA는 온라인 $20, 12개월 동안 여러 번 입국 가능, 1회 최대 3개월 체류. 관광/단기 방문이면 ETA 추천합니다. Visitor 600은 $200 (Offshore) / $500 (Onshore), 더 긴 체류(최대 12개월). 본인이 호주 거주 학생이면 초청장 작성 가능하지만 필수는 아니에요. 친구분 본인이 ETA 신청하시면 됩니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ETA Subclass 601 (가장 일반)**
온라인 신청: $20
유효: 12개월 Multi Entry
1회 체류: 최대 3개월
신청처: ETA App 또는 등록 여행사
한국 여권 자격: O
처리: 즉시~며칠

**2. Visitor 600 (긴 체류)**
신청: $190
Tourist Stream / Sponsored Family
1회 체류: 3개월/6개월/12개월
신청처: ImmiAccount 온라인
처리: 14일~30일
Genuine Visitor 증명 필요

**3. 초청장 (Letter of Invitation)**
본인이 호주 거주 학생/PR/시민권자
내용: 친구 이름 + 관계 + 방문 목적 + 체류 기간 + 숙소 + 재정 보증
필수 X but Sponsored Family Stream에는 도움
본인 비자 카드 + 학생증 + 임대 계약서 첨부

**4. Genuine Visitor 증명 (비자 거절 방지)**
한국 직장 재직증명서 + 한국 부동산/통장
왕복 항공권 예약
호주 숙소 (호텔/Airbnb 또는 친구 집)
여행 일정
한국 가족 (자녀/배우자) 증빙
한국에 돌아갈 이유 강한 증명

**5. 입국 시 주의**
Incoming Passenger Card 정확히 작성
체류 기간 + 호주 친구 주소 명시
현금 신고 AUD $10,000 초과
검역 (음식/식물) 신고 의무
체류 기간 초과 시 Overstay (재입국 거부)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 친구분 한국에서 ETA 601 신청 (온라인 $20)
**2단계**: 본인 호주 거주 증명 + 임대 계약서 사진 친구에게 보내기 (선택)
**3단계**: 왕복 항공권 + 호주 숙소 예약
**4단계**: 입국 시 Passenger Card 정확히 작성
**5단계**: 체류 기간 (3개월) 안 출국

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 한국 친구분은 ETA(Subclass 601) $20 온라인 신청하시면 돼요. 12개월 Multi Entry, 1회 최대 3개월 체류 가능합니다. 관광 목적이면 ETA로 충분해요. 본인이 초청장 쓰는 건 필수 아니지만 도움될 수 있어요. 더 긴 체류(6~12개월)는 Visitor 600 ($200 offshore / $500 onshore) 신청하셔야 합니다. 자세한 절차는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **무비자 입국 X**
   → ETA 또는 Visitor 600 필수

2. **ETA 1년 체류 가능 X**
   → 1회 3개월. 12개월은 비자 유효 기간

3. **초청장 필수 X**
   → 선택. Genuine Visitor 자료

4. **Visitor 600 자동 승인 X**
   → Genuine Visitor 증명 필요

5. **Overstay 무관 X**
   → 재입국 거부 + 학생 본인 비자 영향 없음

6. **호주 도착 후 비자 변경 X**
   → ETA → 학생/Partner 변경 어려움

7. **친구 일 가능 X**
   → ETA/Visitor 600은 Work 금지

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 친구분 체류 기간? (3개월 미만/6개월/12개월)
2. 방문 목적? (관광/가족/결혼식)
3. 친구분 한국 직장 있어요? (있다/없다)
4. 본인 호주 거주 증명 가능? (가능/모름)

---

## 🔍 직원이 직접 확인 가능한 사이트

- ETA Subclass 601: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/electronic-travel-authority-601
- Visitor 600: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/visitor-600
- ETA App: Australian ETA App
- ImmiAccount: online.immi.gov.au
- Korean Embassy AU: aus.mofa.go.kr

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- ETA vs Visitor 600 1차 안내
- 초청장 작성 가이드
- Genuine Visitor 증명 안내
- 한국 여권 자격 확인

**MARA / 변호사 영역**
- Visitor 600 신청 (MARA)
- 비자 거절 항변 (MARA)
- Sponsored Family 신청 (MARA)
- Overstay 후 처리 (MARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 친구분 ETA 601 온라인 신청
- [ ] 본인 호주 거주 증명 준비 (선택)
- [ ] 친구 왕복 항공권 + 숙소
- [ ] Passenger Card 정확히
- [ ] 체류 기간 안 출국 확인
