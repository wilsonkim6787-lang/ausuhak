# #381 호주_ELICOS_Direct_Entry_조건부_입학_IELTS_면제

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 IELTS 5.5인데 호주 디플로마 가려면 6.0 필요해요. ELICOS 다니면 IELTS 안 봐도 된다는데 사실이에요?"

**직원 멘붕 포인트:**
- ELICOS Direct Entry = 부속 어학원만 인정
- 어학원→코스 자동 진입 (Conditional Offer)
- IELTS 면제 가능 코스 vs 면제 불가 코스 (간호)
- 주차 계산 (10주~20주 부족 시 추가)
- ELICOS 학비 ($350~$500/주)

---

## ❌ 절대 하지 말아야 할 답

> "ELICOS 다니면 모든 코스 IELTS 면제 가능합니다."

→ ❌ 간호(Nursing) IELTS 7.0은 ELICOS Direct Entry로 면제 불가 (NMBA 면허 기준 + ANMAC 인증). 다른 코스(Business/IT/Cookery 등)는 ELICOS Direct Entry로 IELTS 면제 가능.

---

## ✅ 정답

**ELICOS Direct Entry 가이드** (2026):

**Direct Entry란?**:
- 학교 부속 어학원(ELICOS) 일정 주차 수료
- IELTS/PTE 시험 면제
- 본 코스 자동 진입 (Pathway Guarantee)

**조건**:
- 본 코스 학교의 부속 ELICOS만 인정 (외부 어학원 X)
- 출석 80%+ 의무
- Final Exam 통과 (Pass)
- Course Progress Maintained

**주차 계산 (IELTS 부족분 → ELICOS 주차)**:
- IELTS 0.5 점 부족 = 10주 ELICOS
- IELTS 1.0 점 부족 = 20주
- IELTS 1.5 점 부족 = 30주

**예시**:
- IELTS 5.5 → 본 코스 IELTS 6.0 필요 = 10주
- IELTS 5.0 → 본 코스 IELTS 6.0 필요 = 20주
- IELTS 5.0 → 본 코스 IELTS 6.5 필요 = 30주
- IELTS 4.5 → 본 코스 IELTS 6.0 필요 = 30주

**IELTS 면제 가능 코스 (대부분)**:
- ELICOS (영어)
- Foundation
- Diploma (Business/IT/Hospitality/Cookery 등)
- Bachelor (대부분)
- Master (대부분)

**IELTS 면제 불가 코스 (전문직)**:
- **Nursing (간호) - 절대 불가 (IELTS 7.0 의무, NMBA 기준)**
- 의학/치의학/약학(호주 졸업) - 7.0 의무
- 사회복지/PT/OT - 7.0 의무
- 교직 (AITSL) - R/W 7.0 + S/L 8.0 의무
- 위 분야 = ELICOS Direct Entry로 면제 X, IELTS 시험 의무

**ELICOS 학비**:
- $350~$500/주 (학교별)
- 10주 = $3,500~$5,000
- 20주 = $7,000~$10,000

**비자 신청 (조건부 입학)**:
- Packaged Course = ELICOS + Main Course COE 함께
- 1개 학생비자로 둘 다 커버
- 비자 기간 = ELICOS + Main Course 합계

**부속 어학원 vs 외부 어학원**:
- 부속 어학원 (UTS Insearch, Monash College, USyd CET): Direct Entry 가능
- 외부 어학원 (Navitas, Kaplan, ELS, Embassy): IELTS 시험 의무
- 비용 차이: 외부 어학원 $300~$400/주 (저렴)

**한국 학생 표준 패턴**:
- IELTS 5.5 + 부속 ELICOS 10주 + Diploma 1년
- IELTS 5.0 + 부속 ELICOS 20주 + Bachelor
- 간호 = IELTS 7.0 시험 의무 (ELICOS X)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. UTS Insearch**
uts.edu.au/insearch - 부속 어학원

**2. Monash College**
monashcollege.edu.au

**3. USyd CET**
sydney.edu.au/study/cet

**4. NMBA Nursing English**
nursingmidwiferyboard.gov.au

**5. ELICOS Provider 검색**
cricos.education.gov.au

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 본 코스 학교 + 영어 점수 요건 확인
**2단계**: 2. 본인 IELTS 점수 vs 요건 = 부족분 계산
**3단계**: 3. 학교 부속 ELICOS Pathway 확인 (외부 어학원 X)
**4단계**: 4. ELICOS 주차 등록 + Packaged Course COE 발급
**5단계**: 5. 비자 신청 (ELICOS + Main Course 동시)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. ELICOS Direct Entry 답변드립니다.

IELTS 5.5에서 디플로마 입학 IELTS 6.0이 필요하면 학교 부속 ELICOS(어학원)에서 10주 수료하면 IELTS 시험 면제로 자동 입학 가능합니다. 출석 80% + Final Exam 통과 조건입니다.

학비는 ELICOS 1주당 $350~$500이라 10주 = $3,500~$5,000 정도입니다. 비자는 Packaged Course(ELICOS + Main Course)로 1개 학생비자로 둘 다 커버됩니다.

⚠️ 주의: 간호(Nursing)는 IELTS 7.0이 NMBA 면허 기준이라 ELICOS Direct Entry로 면제 불가능합니다. 간호는 IELTS 시험을 봐서 7.0(각 영역 7.0)을 받아야 합니다.

또 부속 어학원만 Direct Entry가 됩니다. 외부 어학원(Navitas, Kaplan 등)은 IELTS 시험을 다시 봐야 합니다. 본 코스 학교 부속 어학원(UTS Insearch, Monash College, USyd CET 등)을 선택하셔야 합니다.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **간호 ELICOS 면제 권유**
   → NMBA 7.0 의무. ELICOS X. IELTS 시험 필수.

2. **외부 어학원 Direct Entry 권유**
   → 부속 어학원만 가능.

3. **ELICOS 출석 무시 권유**
   → 80% 미만 = Direct Entry 자격 박탈.

4. **Packaged Course 비자 분리**
   → 1개 비자로 동시. 분리 비자 X.

5. **주차 임의 계산**
   → 0.5점 = 10주 / 1.0점 = 20주 정확히.

6. **의학/약학 면제 권유**
   → 전문직 모두 IELTS 시험 의무.

7. **ELICOS 학비 무시**
   → 10주 $5,000~$10,000. 예산 포함 필수.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 본 코스 학교 + IELTS 요건?
2. 본인 IELTS 점수 (각 영역)?
3. 본 코스 = 간호/의학? (면제 불가)
4. 부속 어학원 vs 외부 어학원?

---

## 🔍 직원이 직접 확인 가능한 사이트

- cricos.education.gov.au (코스 검색)
- 각 학교 부속 ELICOS
- nursingmidwiferyboard.gov.au (간호)
- homeaffairs.gov.au (비자)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- ELICOS Pathway 안내 + 부속 어학원 매칭 + Packaged COE

**MARA / 변호사 영역**
- ELICOS 출석 미달 → 비자 취소 = MARA Agent.

---

## ✅ 완벽 응대 체크리스트

- [ ] Direct Entry 부속 어학원만
- [ ] 주차 계산 정확
- [ ] 간호 IELTS 7.0 면제 X 강조
- [ ] Packaged Course 비자
- [ ] 출석 80% 의무
- [ ] 카카오 상담 신청 유도
