# #406 호주_학생_출판_저작권_논문_책_ISBN_NLA_Copyright

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "박사 논문 출판 준비 중인데 호주에서 책 내려면 ISBN 어디서 받나요? 한국 출판사랑 호주 출판사 차이도 모르겠고, 저작권은 호주랑 한국 둘 다 등록해야 하나요? 학생비자인데 출판해도 되나요?"

**직원 멘붕 포인트:**
- ISBN 발급처 호주/한국 차이 모름
- 학생비자로 출판 인세 받으면 알바 시간 카운트?
- 저작권 등록 호주는 자동/한국은 등록제 차이
- Self-publishing vs Traditional publishing 절차
- 박사 논문 NLA 의무 납본 모름

---

## ❌ 절대 하지 말아야 할 답

> "학생비자는 출판 못 해요"

→ ❌ ❌ 완전 거짓. 학생비자도 저작 활동 가능. 인세는 알바 시간에 포함 안 됨 (수동 소득). Royalty는 Tax Return에 신고만 하면 됨.

---

## ✅ 정답

ISBN은 호주 NLA(National Library of Australia) 무료 발급, Thorpe-Bowker가 유료 대행. 한국은 국립중앙도서관 ISBN센터(seoji.nl.go.kr) 무료. 저작권은 호주(자동 발생, 등록 없음) / 한국(저작권위원회 등록 가능, copyright.or.kr). 박사 논문은 NLA 의무 납본(Legal Deposit). 인세는 수동 소득이라 학생비자 알바 40시간 카운트 X. 다만 Tax Return 신고 의무.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 ISBN 발급 (Thorpe-Bowker)**
공식 발급기관: Thorpe-Bowker (myidentifiers.com.au). 1개 ISBN $44, 10개 $88, 100개 $440. 책 1권당 ISBN 1개. e-book과 종이책은 별도 ISBN. 신청 시 출판사 정보 (개인 출판도 가능) + ISBN 사용처 입력. 보통 1-2일 내 이메일로 받음. NLA 자체는 무료지만 ISBN 발급은 Thorpe-Bowker가 독점.

**2. 저작권 자동 발생 원칙 (Berne Convention)**
호주는 저작권 자동 발생. 등록 절차 없음. 작품을 만든 순간 저작권 발생 (Copyright Act 1968). © 표시 의무 X (있어도 무방). 한국도 자동 발생이지만 등록하면 분쟁 시 입증 쉬움 (한국저작권위원회 cros.or.kr, 1건 1만원). 호주는 등록 제도 자체가 없음. 분쟁 시 초안/메모/이메일 등 작성 증거로 입증.

**3. Legal Deposit (NLA 의무 납본)**
Copyright Act 1968 Section 195CD. 호주에서 출판된 모든 인쇄물 + 디지털 출판물 → NLA에 의무 납본. 무료. nla.gov.au/legal-deposit. 박사/석사 논문은 ADT(Australasian Digital Theses) 또는 학교 Repository에 자동 등록. 책 출판 시 NLA에 1부 우송 의무. 미준수 시 벌금 가능 (실제 적용은 드뭄).

**4. 학생비자 인세 처리 (Royalty Income)**
인세는 Passive Income (수동 소득). 학생비자 40시간/2주 알바 제한 = Active Work에만 적용. 인세는 Tax Return Item 13 (Royalties)에 신고. 세율 본인 한계세율 적용 (보통 19~32.5%). 한국 출판사에서 받는 인세는 한국에서 원천세 22% 떼고 송금 → 호주에서 외국세 공제(Foreign Income Tax Offset) 신청 가능. ATO Section 6-5 Ordinary Income.

**5. Self-publishing vs Traditional**
Self-publishing: Amazon KDP (Kindle Direct), Lulu, IngramSpark. ISBN 본인 구매 또는 플랫폼 무료 제공 (단, 플랫폼 ISBN은 그 플랫폼만 사용 가능). 인세 50~70%. Traditional: 호주 출판사 Allen & Unwin, UQP, Black Inc. 등에 원고 제안서 (Submission). 수락률 1~2%. 인세 8~15%. 한국 출판사 거치면 한국 시장 + 한국 ISBN.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 박사 논문이면: 학교 Repository(예: UQ eSpace, USyd Library) 자동 납본 확인. 책으로 출판하려면 별도 ISBN 필요
**2단계**: Thorpe-Bowker(myidentifiers.com.au) 가입 → ISBN 1개 $44 구매 → 책 정보 등록
**3단계**: 저작권: 별도 등록 불필요. 원고 작성 일자 + 초안 백업으로 충분
**4단계**: 출판 후 NLA Legal Deposit: nla.gov.au/legal-deposit → 책 1부 우편 발송
**5단계**: Tax Return: myGov ATO → Item 13 Royalties → 인세 + 한국 원천세 영수증 (Foreign Income Tax Offset)

---

## 💡 직원이 학생한테 말할 멘트

> "박사 논문 출판 준비 중이시군요. 호주 출판은 ISBN을 Thorpe-Bowker(myidentifiers.com.au)에서 1개 $44에 발급받으시면 되고, 박사 논문이면 학교 Repository에 이미 자동 납본됐을 거예요. 별도 책으로 출판하실 때만 ISBN 필요합니다.

저작권은 호주는 만들면 자동 발생이라 등록 안 해도 됩니다. 한국은 한국저작권위원회에 등록할 수 있긴 한데 의무는 아니에요.

학생비자로 출판 가능하시고요, 인세는 수동 소득이라 40시간 알바 제한에 안 들어갑니다. 다만 Tax Return에 Royalty 신고는 필수예요.

박사 졸업 후 진로 + 출판 활용 + 비자 전환(485 또는 학자 비자) 등 종합 전략은 윌슨 카톡(studywilson)에서 상담 도와드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **ISBN을 NLA에서 직접 발급한다고 안내**
   → ❌ 거짓. NLA는 Legal Deposit(납본) 기관. ISBN 발급은 Thorpe-Bowker(상업 회사)가 독점.

2. **저작권 © 표시 안 하면 보호 안 된다고 안내**
   → ❌ 거짓. Berne Convention 가입국은 자동 보호. © 표시는 의무 아님.

3. **학생비자로 인세 받으면 비자 위반이라 안내**
   → ❌ 거짓. 인세는 Passive Income. 알바 40시간 제한 적용 안 됨.

4. **Amazon KDP로 출판하면 ISBN 필요 없다고 안내**
   → ❌ 부분 거짓. KDP는 무료 ASIN 제공 (Kindle용). 종이책 ISBN은 본인 구매 또는 KDP 무료 ISBN(KDP 전용). 호주 ISBN은 별도 구매 권장.

5. **한국 출판사 인세는 호주에 신고 안 해도 된다고 안내**
   → ❌ 위험. 호주 세법상 Worldwide Income 신고. 미신고 시 ATO 가산세. 한국 원천세 22% 공제 받으려면 신고해야 함.

6. **저작권 등록 호주에서 할 수 있다고 안내**
   → ❌ 거짓. 호주는 저작권 등록 제도 자체가 없음. 자동 발생만 있음.

7. **박사 논문 NLA 납본 안 해도 된다고 안내**
   → ❌ 위험. Copyright Act Section 195CD 의무. 학교 Repository로 갈음되는 경우 많지만 책으로 출판 시 별도 납본.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 출판 형태 (박사 논문 / 일반 책 / e-book / 학술서)
2. 출판 시장 (호주 / 한국 / 양쪽)
3. 출판 방식 (Self-publishing / Traditional)
4. 현재 비자 (학생 / 485 / PR)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Thorpe-Bowker (호주 ISBN): myidentifiers.com.au
- 한국 ISBN: seoji.nl.go.kr
- NLA Legal Deposit: nla.gov.au/legal-deposit
- 한국저작권위원회: cros.or.kr
- ATO Royalty: ato.gov.au (검색: royalty income)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 박사 졸업 후 비자 전환 전략 (485 / 학자 비자 / Skilled)
- 출판 경력을 활용한 비자 점수 향상 방안 안내
- 한국/호주 출판 시장 커리어 연계 컨설팅

**MARA / 변호사 영역**
- Distinguished Talent (Subclass 858) 비자 신청 - MARA 변호사
- 한국 원천세 ↔ 호주 세금 이중과세 - 회계사 (CPA / Tax Agent)
- 출판 계약서 법률 검토 - 변호사 (Solicitor)
- 저작권 침해 분쟁 - IP 전문 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] ISBN 호주(Thorpe-Bowker)/한국(seoji) 차이 안내
- [ ] 저작권 자동 발생 원칙 설명 (등록 불필요)
- [ ] 박사 논문 NLA Legal Deposit 의무 안내
- [ ] 인세 = Passive Income (알바 40시간 제한 X) 설명
- [ ] Tax Return Item 13 Royalty 신고 의무 안내
- [ ] 학생비자로 출판 가능함을 명확히 전달
- [ ] MARA/세무사 영역 분리 안내
- [ ] 윌슨 카톡(studywilson) 종합 상담 유도
