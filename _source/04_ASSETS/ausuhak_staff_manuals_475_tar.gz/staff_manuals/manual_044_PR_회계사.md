# 📚 직원 응대 매뉴얼 #044

**케이스: 회계사 (Accountant) PR 종합**

---

## 🎬 상황 시뮬레이션

> 호주 회계사 영주권 어떻게 받나요? 한국 회계 전공도 있고 비전공도 있고요.

**👉 정답**: **Master of Accounting + CPA Australia/CA ANZ + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 회계사 직업군 PR 매트릭스

| 직업 | ANZSCO | 평균 연봉 | PR 리스트 |
|---|---|---|---|
| Accountant General | 221111 | $75K~$110K | MLTSSL |
| Management Accountant | 221112 | $80K~$120K | MLTSSL |
| Taxation Accountant | 221113 | $80K~$120K | MLTSSL |
| External Auditor | 221213 | $80K~$120K | MLTSSL |
| Internal Auditor | 221214 | $75K~$110K | MLTSSL |
| Finance Manager | 132211 | $100K~$150K | STSOL |

### 2️⃣ 호주 회계사 자격 = CPA 또는 CA

- **CPA Australia** (Certified Practising Accountant) = 가장 흔함
- **CA ANZ** (Chartered Accountants) = 전문성 高
- **IPA** (Institute of Public Accountants) = 작은 곳

### 3️⃣ 회계사 표준 경로 (한국 4년제 비회계 학사 + 호주 Master)

```
한국 학사 + IELTS 7.0
        ↓
Master of Accounting 2년 ($90K~$110K)
        ↓
CPA Foundation 면제 + Professional 시험
        ↓
485 졸업비자 + 호주 회계 회사 취업
        ↓
CPA Practical Experience 3년 + 시험
        ↓
PR (직업 + CPA)
```

### 4️⃣ Master of Accounting 학교

| 학교 | 위치 | 학비 (연간) | IELTS |
|---|---|---|---|
| USyd | Sydney | $54K | 7.0 |
| UNSW | Sydney | $52K | 7.0 |
| UMelb | Melbourne | $58K | 6.5 |
| Monash | Melbourne | $50K | 7.0 |
| UTS | Sydney | $44K | 6.5 |
| Macquarie | Sydney | $42K | 6.5 |
| WSU | Sydney (Non-regional) | $36K | 6.5 |
| Adelaide (Regional, 491 +15점) | Adelaide | $44K | 6.5 |
| Curtin (Regional, 491 +15점) | Perth | $42K | 6.5 |

### 5️⃣ 한국 KICPA + 호주 CPA 전환 (DB 별도 매뉴얼 #027)

- KICPA 자격 + 5년 경력 = CPA Foundation 일부 면제
- Master 1년 단축 가능
- 시험 일부만 응시

---

## 🎯 정답 경로 (3가지 케이스)

### 케이스 1. 한국 비회계 학사 → 호주 Master + PR

```
한국 학사 + IELTS 7.0 → Master Acc 2년 → CPA + 485 → PR
```

**총 4-5년 / 학비 $90K~$110K**

### 케이스 2. 한국 회계 전공 학사 (학점 인정)

```
한국 회계 학사 + IELTS 7.0 → Master Acc 1년 (단축) → CPA + PR
```

**총 3-4년 / 학비 $50K~$60K**

### 케이스 3. 한국 KICPA → CPA Australia (DB #027)

```
한국 KICPA + 경력 + IELTS 7.0 → CPA 가입 + 시험 → 호주 취업 → PR
```

**총 1.5-2년 / 비용 적음**

---

## 💡 직원이 학생한테 말할 멘트

> "호주 회계사 영주권은 한국에서 가장 많이 진행되는 PR 경로 중 하나입니다.
> 
> 1. **Accountant General 221111** = MLTSSL 직업군
> 2. **CPA Australia** 자격 = 호주 회계사 표준
> 3. **연봉**: $75K~$120K (회계 분야 따라)
> 
> 본인 케이스에 따라:
> - **한국 비회계 학사**: Master of Accounting 2년 = $90K~$110K
> - **한국 회계 전공**: Master 1년 단축 가능 = $50K~$60K
> - **한국 KICPA + 경력**: Direct CPA 전환 가능 = 1.5-2년
> 
> Big 4 (PwC, EY, Deloitte, KPMG) 한국 사무실 경력 있으면 호주 사무실 이직 가능합니다.
> 
> Regional 지역 (Adelaide/Perth 등)은 491 +15점 (Brisbane CBD는 Non-regional).
> 
> 카톡으로 알려주세요:
> ① 한국 학사 전공 + 경력  
> ② IELTS 점수  
> ③ KICPA 자격 여부  
> ④ 도시 우선"

---

## ⚠️ 함정

1. **"한국 회계사 = 호주 자동"** → ❌ KICPA + CPA 시험 必
2. **"Master = CPA 자동"** → Foundation 면제만 / Professional 시험 必
3. **"Big 4 = 자동 PR"** → 회사 + 직업 매칭 必
4. **"한국 경력 다 인정"** → Skills Assessment 평가

---

## 📞 카카오 응대 시 필수

1. 한국 학사 전공
2. 한국 경력
3. KICPA 여부
4. 도시 우선

---

## 🔍 직원 확인 사이트

- CPA Australia: cpaaustralia.com.au
- CA ANZ: charteredaccountantsanz.com
- Master Accounting 학교들
