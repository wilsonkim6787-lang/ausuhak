# #356 호주_학생_교통사고_부상_장애_발생_보상

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니에서 자전거 타다가 차에 치여서 다리 골절됐어요. 병원비 2만 불 나왔어요. OSHC로 다 커버되나요? 운전자한테 얼마 받을 수 있어요?"

**직원 멘붕 포인트:**
- OSHC 커버 범위 + 한도 모름
- Third Party Insurance (CTP) vs OSHC 차이
- 운전자 보험 청구 절차 모름
- 장애 등급 시 보상 금액
- 학기 중단 + 비자 영향

---

## ❌ 절대 하지 말아야 할 답

> "OSHC로 다 커버되니까 걱정마세요."

→ ❌ OSHC = 의료비만 일부 커버. 입원/수술 자기부담금 + 일부 항목 제외. 교통사고 = CTP (Compulsory Third Party) 보험 청구 별도.

---

## ✅ 정답

**OSHC 커버 범위**:
- 일반 의사 (GP): 100% (Bupa/Medibank 직접 결제)
- 입원/수술: 사립 병원 100%, 공립 병원 100% (단, MBS 기준)
- 응급실: 커버 (병원별)
- 처방약: 일부 제외 + $50/항목 한도
- 자기부담금: 사고별 $0~$500

**CTP (운전자 보험)**:
- 호주 자동차 = CTP 의무 가입
- 사고 피해자 = 운전자 CTP에서 의료비 + 휴업 보상 + 후유 장애 보상
- 신청: 사고 28일 이내 운전자 보험사
- 조정 기간: 6~24개월
- 보상액: 의료비 100% + 휴업비 + Pain & Suffering ($50K~$1M)

**장애 등급**:
- WPI (Whole Person Impairment) 평가
- 10% 이상 = Lump Sum 보상
- ART 항소 가능

**비자 영향**: Compelling Reasons LOA 가능. 비자 유지 + 학기 휴학 OK.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. OSHC 5사**
Bupa, Medibank, Allianz, NIB, AHM. 학생비자 의무. 보장 한도 + 자기부담금 보험사별 차이.

**2. CTP (Compulsory Third Party)**
호주 자동차 등록 = 의무 보험. 사고 피해자 인사 보상. NSW: SIRA 관할, VIC: TAC 관할.

**3. WPI 평가**
Whole Person Impairment = 장애 등급. AMA Guidelines 기준. 10% 이상 = Lump Sum 보상 자격.

**4. Compelling Reasons LOA**
본인 의료 사고 = ESOS 인정 사유. 학교 LOA 의무 승인. 비자 유지 + 학기 연기.

**5. Pain & Suffering**
정신적 고통 보상. 호주 일반 $50,000~$1,000,000. 변호사 No Win No Fee 일반적.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 사고 즉시: 경찰 신고 (000) + Police Report 발급
**2단계**: 병원: OSHC 카드 제시 → 사립 병원 100% 커버
**3단계**: 운전자 정보 확보: Rego 번호 + 보험사 + 면허증
**4단계**: CTP 청구: 28일 이내 운전자 보험사 클레임
**5단계**: 변호사 선임: No Win No Fee 인사 변호사

---

## 💡 직원이 학생한테 말할 멘트

> "다친 거 안타깝네요. OSHC로 병원비 대부분 커버되고, 추가로 운전자 CTP 보험에서 의료비 + 휴업비 + 후유 장애 보상을 별도로 받을 수 있어요. 사고 28일 이내 신고 필수입니다. 학기는 Compelling Reasons LOA로 휴학 가능하고 비자 유지됩니다. 자세한 절차는 윌슨 1:1 상담 + 인사 변호사 추천 필요해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **OSHC = 100% 커버**
   → 자기부담금 + 일부 항목 제외. CTP 별도 청구 필요.

2. **CTP 신고 시한 제한 없음**
   → 28일 이내 신고 의무. 장기 클레임 6년.

3. **운전자 잘못 = 자동 보상**
   → CTP = 무과실 보상. 단, 본인 100% 과실 시 일부 제한.

4. **사고 + LOA = 비자 위반**
   → Compelling Reasons LOA = 비자 유지.

5. **변호사 선임 비용 부담**
   → 인사 사건 = No Win No Fee 일반. 승소 시 30%~33%.

6. **Pain & Suffering 자동 포함**
   → 별도 청구. WPI 10% 이상 + 변호사 협상.

7. **OSHC 사고 자동 통보**
   → OSHC ≠ 변호사. 본인 청구 필수.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사고 일자 + 28일 이내 여부
2. OSHC 보험사 + 가입 상태
3. 운전자 Rego 번호 + 보험사 정보 확보
4. 현재 학기 + 비자 만료일 (LOA 검토)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW SIRA (CTP): sira.nsw.gov.au
- VIC TAC: tac.vic.gov.au
- OSHC Bupa: bupa.com.au/health-insurance/oshc
- Law Society NSW (변호사 검색): lawsociety.com.au
- ESOS Compelling Reasons: dese.gov.au/esos

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Compelling Reasons LOA 학교 안내
- 비자 만료 vs 회복 기간 충돌 검토
- OSHC 사용법 + CTP 차이 설명

**MARA / 변호사 영역**
- 인사 변호사 추천 (No Win No Fee)
- WPI 평가 + Lump Sum 협상
- 장기 장애 시 영주권 영향 검토

---

## ✅ 완벽 응대 체크리스트

- [ ] OSHC 커버 + 자기부담금 정확 안내
- [ ] CTP 28일 신고 시한 강조
- [ ] 운전자 정보 확보 우선 강조
- [ ] Compelling Reasons LOA 비자 유지 안심
- [ ] No Win No Fee 변호사 추천
- [ ] Pain & Suffering 별도 청구 안내
- [ ] 윌슨 1:1 상담 자연 유도
