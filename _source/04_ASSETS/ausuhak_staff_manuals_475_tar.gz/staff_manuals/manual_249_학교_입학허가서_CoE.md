# #249 학교 입학허가서 CoE / Offer Letter 차이

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 학교에서 Offer Letter 받았는데 비자 신청하려니 CoE가 필요하다고 하네요. 같은 거 아닌가요?"

**직원 멘붕 포인트:**
- Offer Letter ≠ CoE (전혀 다른 단계)
- Offer = 입학 제안 / CoE = 학비 납부 후 발급
- CoE = Confirmation of Enrolment (비자 필수)
- PRISMS 시스템 등록 = 정부 자동 통보

---

## ❌ 절대 하지 말아야 할 답

> "Offer Letter로 비자 신청하면 됩니다."

→ ❌ **비자 100% 거절**. CoE 필수. 학비 납부 후 학교가 발급.

---

## ✅ 정답

입학 단계: ① **Application** (지원서 + 서류) → ② **Offer Letter** (조건부/무조건부) → ③ **OSHC + 학비 납부** (Initial Fee) → ④ **CoE 발급** (PRISMS 등록) → ⑤ **GS 작성** → ⑥ **비자 신청 (CoE 첨부)**. **CoE = 비자 절대 필수**. Offer Letter만으로 비자 신청 = 거절.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Offer Letter (입학 제안)**
- **조건부 (Conditional)**: 영어점수 미달 / ELICOS 패키지
- **무조건부 (Unconditional)**: 모든 조건 충족
- **유효기간**: 보통 6개월
- **학비 미납부 상태** = 비자 신청 불가

**2. CoE (Confirmation of Enrolment)**
- 학비 납부 후 학교 발급
- **PRISMS 시스템 등록** (정부 자동 통보)
- CoE 번호 = 비자 신청 필수
- 코스별 별개 CoE (ELICOS + Diploma = 2개)

**3. CoE 발급 절차**
- ① Offer 수락 (Acceptance Form 서명)
- ② OSHC 가입 (학생보험)
- ③ 학비 납부 (Initial Fee = 보통 1학기 분)
- ④ 학교가 PRISMS 등록 → CoE 발급 (1~3일)

**4. 비자 신청 시 CoE 역할**
- DHA가 PRISMS 자동 조회
- CoE 번호 → 학교 + 코스 + 기간 자동 인식
- CoE 없음 = 비자 신청 자체 불가

**5. CoE 취소 / 변경**
- 학교 변경 시 = 새 CoE 발급
- 6개월 룰 (PRISMS 8202 조건)
- 학비 환불 = 학교 정책 + ESOS Act

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Offer Letter 수락 (Acceptance Form 서명, 학교 이메일)
**2단계**: OSHC 가입 (Bupa/Medibank/Allianz/NIB/AHM 5개 중 1)
**3단계**: 학비 납부 (Initial Fee = 학교 청구서 기준)
**4단계**: 학교가 PRISMS 등록 → CoE 이메일 수신 (1~3일)
**5단계**: GS 에세이 작성 → 비자 신청 (CoE 번호 입력)

---

## 💡 직원이 학생한테 말할 멘트

> "Offer Letter는 입학 제안이고, CoE는 학비 납부 후 발급되는 정부 등록 서류입니다. 비자 신청에는 CoE가 필수예요. 학비 납부 → 학교가 PRISMS 등록 → CoE 이메일 발송 (1~3일)이고, 그 다음 비자 신청 가능합니다. 학비 납부 어느 정도 가능한지 윌슨님 카카오 (studywilson)으로 알려 주시면 환불 정책 등 자세히 안내드려요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **Offer Letter = 입학 확정 ❌**
   → 학비 납부 + CoE = 입학 확정

2. **CoE 1개로 5년 코스 패키지 ❌**
   → 코스별 별개 CoE (ELICOS + Diploma + Bachelor = 3개)

3. **학비 100% 납부 필수 ❌**
   → Initial Fee (1학기 또는 학교 정책) = OK

4. **CoE 받으면 무조건 비자 승인 ❌**
   → CoE = 입학 등록 / 비자 = GS + 재정 + 영어 별개 심사

5. **OSHC 가입 = 선택 ❌**
   → 학생비자 8501 조건 = OSHC 의무

6. **CoE 시작일 = 학기 시작일 동일 ❌**
   → CoE 시작일 = 코스 시작일 (Orientation 포함 가능)

7. **Offer Letter 거절 = 비자 거절 영향 ❌**
   → Offer 거절 = 학교 영역 / 비자 거절 = DHA 별개

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Offer Letter 종류 (Conditional / Unconditional / 유효기간)
2. 학비 납부 가능 여부 (Initial Fee 금액)
3. OSHC 가입 여부
4. 비자 신청 시점 (CoE 받은 후 즉시)

---

## 🔍 직원이 직접 확인 가능한 사이트

- PRISMS (정부): https://prisms.education.gov.au
- ESOS Act (학생 보호): https://internationaleducation.gov.au
- Department of Home Affairs: https://immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- Offer / CoE 차이 설명
- PRISMS 절차 안내
- OSHC 가입 안내

**윌슨 영역**
- 학비 환불 분쟁 (학교 vs 학생)
- 학교 변경 + CoE 재발급
- ESOS Act / TPS 관련

**MARA 영역**
- 비자 거절 + CoE 취소
- PRISMS 분쟁 + 비자 영향

---

## ✅ 완벽 응대 체크리스트

- [ ] Offer Letter ≠ CoE 차이 명확 설명
- [ ] CoE = 비자 절대 필수 강조
- [ ] PRISMS = 정부 자동 등록 시스템
- [ ] Initial Fee 납부 → CoE 발급 (1~3일)
- [ ] OSHC 의무 안내 (8501)
- [ ] 코스별 별개 CoE 안내
- [ ] 학비 환불 분쟁 = 윌슨 영역
- [ ] 윌슨 카카오 자연 유도
