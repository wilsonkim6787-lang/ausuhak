# #216 PR 신청 후 대기 (Bridging Visa)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 영주권 신청했는데 결과 나올 때까지 1~2년 걸린대요. 그 동안 어떤 비자로 있어야 해요? 일도 가능한가요?"

**직원 멘붕 포인트:**
- Bridging Visa A / B / C
- PR 대기 중 권리
- 출국 가능 여부

---

## ❌ 절대 하지 말아야 할 답

> "PR 신청하면 자동으로 영주권자 권리 다 줘요!"

→ ❌ **자동 X**. Bridging Visa A = 학생 비자와 비슷한 권리.

---

## ✅ 정답

PR 신청 후 대기: ① **Bridging Visa A (BVA)** = PR 신청 시 자동 발급 / 호주 체류 / 일 가능 (조건 있음) ② **Bridging Visa B (BVB)** = 출국 + 재입국 권리 ($150 AUD 신청) ③ **Bridging Visa C (BVC)** = 비자 만료 후 신청 시 ④ **권리**: 일 가능 (대부분) / 학교 가능 / Medicare X (영주권 결정 후) ⑤ **소요 기간**: 영주권 종류별 (189 = 11~16개월 / 482→186 = 6~12개월 / 482→191 = 변동) ⑥ 윌슨 + MARA 등록 이민변호사.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. Bridging Visa A (BVA)
- 호주 내 비자 신청 시 자동 발급
- 신청 비자 결정까지 유효
- 일 가능 (대부분 / 일부 제한)
- 학교 가능
- 출국 = X (재입국 X)

### 2. Bridging Visa B (BVB)
- BVA 보유자가 출국 시 신청
- $150 AUD
- 출국 + 재입국 가능
- 1회 출국 (3개월) 또는 다회

### 3. Bridging Visa C (BVC)
- 비자 만료 후 신청 시 발급
- 일 = X (Work Right 별도 신청)
- 출국 = X

### 4. PR 종류별 대기 시간
- **189** (Skilled Independent): 11~16개월
- **190** (Skilled Nominated): 6~12개월
- **491** (Skilled Regional): 7~12개월
- **186** (ENS - Employer Nomination): 6~12개월
- **482 → 186**: 변동

### 5. PR 대기 중 가능한 활동
- ✅ 일 (대부분)
- ✅ 학교
- ✅ 운전 (호주 면허)
- ❌ Medicare (영주권 결정 후 자동 가능)
- ❌ HECS-HELP 학자금 대출
- ⚠️ 출국 시 BVB 필수

---

## 🎯 정답 경로

### Step 1: 현재 비자 / PR 신청 상태 확인
- 학생비자 / 485 / Partner / 다른 비자
- PR 신청 종류 (189 / 190 / 491 / 186)

### Step 2: BVA 자동 발급 확인
- 신청 후 메일 / VEVO 확인
- 권리 (일 / 학교) 확인

### Step 3: 출국 필요 시 BVB 신청
- $150 AUD
- 출국 사유 (가족 / 휴가)
- 재입국 시 BVB 유효

### Step 4: PR 결과 대기
- DHA 통보 (이메일)
- 영주권 발급 → 모든 권리 자동

---

## 💡 직원 멘트

> "안녕하세요! PR 대기 안내드릴게요.
>
> ✅ Bridging Visa A = PR 신청 시 자동 발급 (일/학교 OK)
> ✅ 출국 시 = BVB 별도 신청 ($150)
> ✅ Medicare = 영주권 결정 후 자동
> ✅ 대기 시간 = 6~16개월 (PR 종류별)
>
> 자세한 권리 / 제한은 본인 PR 종류별로 다르고, 이민변호사 (MARA) 영역이에요.
>
> 윌슨님이 PR 진행 + 변호사 매칭 도와드려요. 카카오톡으로 1:1 상담받으시는 거 어떨까요?"

---

## ⚠️ 함정 7개

1. ❌ "PR 신청 = 영주권자" → ✅ BVA = 학생 비자 비슷
2. ❌ "BVA로 출국 가능" → ✅ BVB 별도 ($150)
3. ❌ "Medicare 즉시 가능" → ✅ 영주권 결정 후
4. ❌ "BVA 일 자유" → ✅ PR 종류별 일부 제한
5. ❌ "BVA 만료 = PR 거절" → ✅ BVA = PR 결정까지 유효
6. ❌ "PR 거절 = 즉시 출국" → ✅ ART 항소 가능 (28일 이내)
7. ❌ "BVA로 한국 단기 방문 OK" → ✅ BVB 없으면 재입국 X

---

## 📞 필수 4가지 확인

1. ✅ 현재 비자 / PR 신청 종류
2. ✅ BVA 발급 확인 (VEVO)
3. ✅ 출국 계획 → BVB 안내
4. ✅ 윌슨 + MARA 변호사 안내

---

## 🔍 직원 사이트

- **Bridging Visa**: https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/bridging-visa
- **VEVO**: https://immi.homeaffairs.gov.au
- **MARA (이민변호사)**: https://www.mara.gov.au

---

## 🚨 직원 vs 윌슨 vs 변호사

**직원**: Bridging Visa 일반 안내
**윌슨**: PR 진행 / 학교 / 코스 매칭
**변호사 (MARA)**: PR 신청 / ART 항소 (윌슨이 매칭)

---

## ✅ 체크리스트

- [ ] PR 신청 종류 / 현재 비자 확인
- [ ] BVA / BVB / BVC 차이 안내
- [ ] 출국 시 BVB 안내
- [ ] 윌슨 + 변호사 매칭 강조
