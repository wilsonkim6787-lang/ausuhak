# 📚 직원 응대 매뉴얼 #005

**케이스: 고1 학생 / 호주 Go8 (Group of Eight) 진학 / Foundation 준비**

---

## 🎬 상황 시뮬레이션

> 고1인데요 호주 시드니대학교나 멜번대학교 가고 싶어요. 한국 고등학교 다니고 있는데 어떻게 준비해야 하나요? 부모님이 1년 1억까지 지원해주신다고 하셨어요.

**👉 정답**: **Foundation 코스** → Go8 1학년

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Go8 = Group of Eight = Go8 (Group of Eight, 호주 8개 연구중심대학)

| 학교 | 위치 | QS 랭킹 |
|---|---|---|
| University of Melbourne (UMelb) | VIC | Top 13 |
| University of Sydney (USyd) | NSW | Top 19 |
| Australian National University (ANU) | ACT | Top 30 |
| University of Queensland (UQ) | QLD | Top 40 |
| Monash University | VIC | Top 37 |
| UNSW Sydney | NSW | Top 19 |
| University of Adelaide | SA | Top 89 |
| University of Western Australia (UWA) | WA | Top 77 |

### 2️⃣ Foundation = 호주 대학 1학년 입학 준비 코스

**답**: 한국 고졸로는 Go8 직접 입학 어려움. **Foundation 1년** 거치면 Go8 1학년 입학 가능.

- 기간: 9~15개월 (Standard / Extended / Comprehensive)
- 학비: $25,000~$45,000 (학교마다)
- 영어 조건: IELTS 5.5~6.0 (학교마다)
- 한국 고2 졸업 또는 검정고시 + 영어로 입학 가능

### 3️⃣ Go8 학교별 Foundation 컬리지

| Foundation | 진학 가능 대학 |
|---|---|
| Trinity College | UMelb |
| Monash College | Monash |
| UNSW Foundation | UNSW |
| USyd Taylors College | USyd |
| Eynesbury | Adelaide / 다른 SA |
| UQ Foundation | UQ |

### 4️⃣ Foundation vs Diploma Pathway 차이

| 구분 | Foundation | Diploma Pathway |
|---|---|---|
| 진학 | Bachelor 1학년 | Bachelor 2학년 (1년 학점 인정) |
| 기간 | 9~12개월 | 8~12개월 |
| 영어 | IELTS 5.5~6.0 | IELTS 5.5~6.5 |
| 학비 | $25K~$45K | $28K~$38K |
| 적합 | Go8 | 일반 대학 |

Go8 = Foundation / 일반 대학 = Diploma 일반적.

### 5️⃣ 한국 고1 학생의 표준 경로

**선택지 1**: 한국 고등학교 졸업 → Foundation 1년 → Go8 1학년
**선택지 2**: 한국 고1 마치고 → 호주 Year 11-12 (2년) → ATAR → Go8 직접
**선택지 3**: 한국 고2 → Foundation → Go8 (가장 빠름)

---

## 🎯 이 학생에게 안내할 정답 경로

### 한국 고졸 → Foundation → Go8

```
한국 고등학교 졸업 (Year 12 동등)
        ↓
Foundation 9~12개월 (Trinity / Monash College / Taylors 등)
        ↓
Go8 학사 1학년 입학
        ↓
3-4년 학사 졸업 → 485 또는 한국 귀국
```

**총 예상 학비 (4-5년)**: 약 $200K~$280K (UMelb/USyd 등)
**1년 1억 = 약 $70K** = Foundation $40K + Bachelor $50K~$60K = **빠듯하지만 가능**

---

## 💡 직원이 학생한테 말할 멘트

> "고1이시면 시간 충분합니다. 호주 Go8 (Group of Eight, 호주 8개 연구중심대학) 진학에는 여러 길이 있어요.
> 
> 1. **한국에서 정규 고등학교 졸업** (Year 12 동등 인정)
> 2. **Foundation 1년 코스** (Trinity/Monash College/Taylors 등) = Go8 1학년 보장 진학
> 3. Foundation 영어 조건 IELTS 5.5~6.0 = 한국 고등학교 다니면서 준비 가능
> 4. 학비: Foundation $40K + Bachelor 3년 $150K~$200K = 4-5년 약 $200K~$240K
> 
> 1억 예산이면 빠듯하긴 하지만 가능하고, 한국 고2 마치고 Foundation 시작하면 가장 빠릅니다.
> 
> 카톡으로 알려주세요:
> ① 현재 영어 수준 (모의고사 영어 등급)  
> ② 한국 고등학교 졸업 vs 고2 마치고 Foundation  
> ③ 희망 전공 (의대/공대/경영 등)"

---

## ⚠️ 함정

1. **"한국 고졸이면 Go8 직접 입학"** → ❌ Foundation 또는 Pathway 거의 필수
2. **"Foundation은 학교마다 비슷"** → ❌ 학교 평판 + 진학률 차이 큼
3. **"검정고시도 Foundation OK"** → ✅ 일부 학교는 검정고시 인정
4. **"의대도 Foundation으로?"** → ⚠️ 의대는 별도 (UMAT/GAMSAT)

---

## 📞 카카오 응대 시 필수

1. 현재 영어 수준
2. 한국 고등학교 졸업 vs 고2 마치고 가는지
3. 희망 전공 (의대/공대/경영 등 - 학교 다름)
4. Go8 어느 학교 우선 (UMelb? USyd? UNSW?)

---

## 🔍 직원 확인 사이트

- Trinity College (UMelb): trinity.unimelb.edu.au
- Monash College: monashcollege.edu.au
- UNSW Foundation: unsw.edu.au/study/global/unsw-foundation-studies
- Taylors College (USyd): taylorscollege.edu.au
