# #259 CPA 직업평가 회계 PR

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 한국 회계학과인데 호주 회계사 PR 받으려면 뭐 해야 하나요?"

**직원 멘붕 포인트:**
- CPA Australia / CA ANZ / IPA 3개 평가
- 한국 회계 학사 + 12개 코어 과목 인정
- 9개 코어 부족 = 호주 추가 학습 필수
- PY (Professional Year) = 5점 가산

---

## ❌ 절대 하지 말아야 할 답

> "한국 회계 학사면 호주 회계사 됩니다."

→ ❌ **12개 코어 과목 평가 + 부족 시 호주 추가 학습**.

---

## ✅ 정답

회계 직업평가: ① **CPA Australia / Chartered Accountants ANZ / IPA** (3개 기관) ② **12개 코어 과목 평가** (회계 / 감사 / 세무 / 재무 / 법) ③ **부족 시 호주 Bachelor / Master 추가** ④ **수수료 약 $560 AUD** ⑤ **심사 6~10주** ⑥ **PY 1년 = PR 5점 가산** ⑦ **ANZSCO 221111 / 221112**.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 3개 평가 기관**
CPA Australia (대중적) / Chartered Accountants ANZ (CA) / IPA (Institute of Public Accountants) / 3개 모두 PR 인정

**2. 12개 코어 과목**
Accounting Systems / Financial Accounting / Management Accounting / Finance / Audit / Commercial Law / Tax Law / Economics / Quantitative Methods / IT for Business 등

**3. 한국 학사 평가**
회계학과 학사 = 보통 8~10개 인정 / 부족 2~4개 = 호주 Master of Professional Accounting 추가 학습

**4. PY (Professional Year)**
Professional Year Program = 호주 코스 졸업 후 1년 / PR 5점 가산 / 비용 약 $15,000~$20,000 / 회계 + 인턴 12주

**5. CPA 본 자격 (PR 후)**
CPA 자격증 = PR 후 별도 / 호주 학사 + CPA 6과목 + 3년 경력 / PR 자격 평가와 별개

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 학위 + 성적표 영문 발급
**2단계**: CPA Australia 사이트 등록 (cpaaustralia.com.au)
**3단계**: Skills Assessment 신청 + 수수료 ($560)
**4단계**: 12개 코어 과목 매칭 → 부족 시 호주 추가 학습
**5단계**: PY 추가 (5점 가산 원하면)

---

## 💡 직원이 학생한테 말할 멘트

> "회계 PR은 12개 코어 과목 평가가 핵심이에요. 한국 회계 학사면 보통 8~10개 인정되고 부족 2~4개는 호주 Master of Professional Accounting으로 추가 학습합니다. 평가 기관은 CPA Australia / CA ANZ / IPA 3개인데 CPA가 가장 일반적이에요. 호주 Master + PY (Professional Year) 1년 + IELTS 7 + 직업 평가 = PR 표준 경로입니다. 윌슨님이 1:1로 한국 학과 분석 + 호주 Master 매칭 + PY 시점 전략 드려요. 카카오 (studywilson)으로 한국 학력 + 영어 점수 + PR 일정 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **회계 학사 = 자동 인정 ❌**
   → 12개 코어 평가 / 부족 = 추가 학습

2. **CPA = PR 자격 ❌**
   → 직업 평가 별개 / CPA = 호주 자격증

3. **PY = 의무 ❌**
   → 선택 / 5점 가산 효과만

4. **Master 1개 = 부족 메꾸기 ❌**
   → Master 코어 매칭 정확히 분석

5. **3개 기관 = 다른 결과 ❌**
   → 기관 선택 차이만 / PR 인정 동일

6. **회계사 = IELTS 6 ❌**
   → IELTS 7 (각 영역 7) / PR Skilled

7. **PY = 호주 학사도 OK ❌**
   → PY = 호주 Master 졸업자 우선

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 학력 + 회계 학사 학과
2. 12개 코어 과목 매칭 가능 여부
3. 호주 Master 결정 여부
4. 영어 IELTS 7 가능 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- CPA Australia: https://www.cpaaustralia.com.au
- CA ANZ: https://www.charteredaccountantsanz.com
- IPA: https://www.publicaccountants.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 12개 코어 매칭 1:1 분석
- 호주 Master 학교 + 코스 매칭
- PY 시점 + PR 전략

**MARA / 변호사 영역**
- CPA 거절 + Review
- PR 거절 + ART 항소

---

## ✅ 완벽 응대 체크리스트

- [ ] 12개 코어 과목 평가 핵심
- [ ] 3개 평가 기관 (CPA / CA / IPA)
- [ ] 한국 학사 = 부분 인정
- [ ] 호주 Master + PY = 표준
- [ ] IELTS 7 (각 영역 7) 의무
- [ ] PY = 선택 / 5점 가산
- [ ] 윌슨 1:1 = 코어 매칭 영역
- [ ] 윌슨 카카오 자연 유도
