# 📚 직원 응대 매뉴얼 #024

**케이스: 35세 / 한국 간호사 + 10년 경력 / Bridging Course / 호주 RN**

---

## 🎬 상황 시뮬레이션

> 한국 간호사 10년 경력이고 35세입니다. OBA 시험은 부담돼서 호주 가서 학교 다니면서 RN 자격 받고 싶어요. IELTS 7.0 있어요.

**👉 정답**: **Bachelor of Nursing (Bridging) 또는 Re-entry Course**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Bridging Course = 한국 간호사를 위한 호주 RN 전환 코스

- 호주 대학교에서 운영
- 1-1.5년 단축 코스 (한국 간호 경력 인정)
- 졸업 = 자동 RN 자격 (OBA 면제)
- 호주 적응 + 임상 실습 포함

### 2️⃣ Bridging 운영 학교

| 학교 | 코스명 | 기간 | 학비 | 위치 |
|---|---|---|---|---|
| Curtin University | Bachelor of Nursing (Re-entry) | 1.5년 | $40K~$45K | Perth |
| UTS Sydney | Re-Entry to Nursing | 1년 | $35K~$40K | Sydney |
| La Trobe | Bachelor of Nursing (Re-entry) | 1.5년 | $35K~$40K | Melbourne |
| Murdoch | Bridging Course | 1년 | $30K~$35K | Perth |
| ECU | Bridging Course | 1년 | $32K~$36K | Perth |
| Federation | Bridging | 1년 | $28K~$32K | Ballarat |
| UniSA | Bridging | 1년 | $32K~$36K | Adelaide |

### 3️⃣ Bridging 입학 조건

- 한국 간호 학사 + 면허
- 한국 간호 경력 (학교마다 1-3년 이상)
- IELTS 7.0 (각 영역 7.0)
- AHPRA 사전 평가 결과 (Bridging 권장 받은 경우)

### 4️⃣ Bridging vs OBA 선택 기준

| Bridging 선택 | OBA 선택 |
|---|---|
| 안정적 학습 선호 | 시험 자신 있음 |
| 호주 적응 + 인맥 우선 | 빠른 등록 우선 |
| 자녀 데려가기 (가족동반) | 단기 체류 OK |
| 학비 부담 가능 | 비용 절약 |
| 35세 이상 | 30대 초반 |

### 5️⃣ Bridging 졸업 후

- AHPRA RN 등록 자동
- 485 졸업비자 가능 (Master coursework 동등 = 2년)
- 호주 병원 즉시 취업
- 영주권: RN 254499 MLTSSL

---

## 🎯 정답 경로

### Bridging Course + 485 + PR

```
한국 간호사 + 10년 경력 + IELTS 7.0
        ↓
AHPRA 사전 평가 (Bridging 추천 받음)
        ↓
Bridging Course 1-1.5년 ($30K~$45K)
        ↓
졸업 = AHPRA RN 등록
        ↓
485 졸업비자 + 호주 병원 취업
        ↓
PR 신청 (RN 254499)
```

**총 3-4년 / 학비 $30K~$45K**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 간호사 10년 + 35세 + IELTS 7.0 = Bridging Course가 안정적인 선택입니다.
> 
> 1. **Bridging Course = 1-1.5년 단축 코스**
> 2. **호주 적응 + 영어 + 인맥** 모두 잡음
> 3. **졸업 = 자동 RN 자격** (OBA 면제)
> 4. **학교 옵션**: Federation $28-32K (가장 저렴) / UniSA $32-36K / Murdoch $30-35K
> 
> 35세시면 485 가능 (35세 미만 까지 신청 가능 / Bridging 시작 시 신청)이고, 졸업하면 호주 병원 바로 취업 + PR 신청 가능합니다.
> 
> 자녀 동반 / 배우자 동반도 학생비자로 가능합니다.
> 
> 카톡으로 알려주세요:
> ① 정확한 IELTS  
> ② 한국 경력 분야  
> ③ 가족 동반 여부  
> ④ 도시 우선 (Perth / Sydney / Melbourne / Adelaide / Ballarat)"

---

## ⚠️ 함정

1. **"OBA가 더 빠르니까 OBA"** → 35세+에게는 Bridging이 안전
2. **"한국 경력 인정 안 받아준다"** → 학교마다 1-3년 인정
3. **"Bridging은 학사 다시 처음부터"** → ❌ 1-1.5년 단축
4. **"IELTS 6.5도 OK"** → ❌ 7.0 必須

---

## 📞 카카오 응대 시 필수

1. 정확한 IELTS
2. 한국 간호 경력
3. 가족 동반 여부
4. 도시 우선

---

## 🔍 직원 확인 사이트

- Curtin Re-entry: curtin.edu.au
- UTS Re-Entry: uts.edu.au
- La Trobe Re-entry: latrobe.edu.au
- AHPRA: ahpra.gov.au
