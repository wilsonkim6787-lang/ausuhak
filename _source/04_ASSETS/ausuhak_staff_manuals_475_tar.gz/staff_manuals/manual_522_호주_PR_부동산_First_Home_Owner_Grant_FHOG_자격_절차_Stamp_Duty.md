# #522 호주_PR_부동산_First_Home_Owner_Grant_FHOG_자격_절차_Stamp_Duty

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "PR 받아서 호주 첫 집 사고 싶어요. First Home Owner Grant 받을 수 있어요? Stamp Duty 면제도 가능해요?"

**직원 멘붕 포인트:**
- First Home Owner Grant (FHOG): PR + 시민권자만, 학생비자/임시비자 X
- 각 주별 금액 차이 ($10,000~$30,000)
- Stamp Duty Exemption: PR + 시민권자 (조건부)
- First Home Buyer Assistance: 추가 보조금 + 대출 보증
- FIRB (Foreign Investment Review Board) 승인 의무 (외국인)

---

## ❌ 절대 하지 말아야 할 답

> "학생비자도 First Home Owner Grant 받을 수 있어요"

→ ❌ PR/시민권자만. 학생비자/임시비자 자격 X. 잘못 안내 시 큰 손실

---

## ✅ 정답

PR/호주 시민권자만 First Home Owner Grant(FHOG) 받을 수 있어요. NSW $10,000(신축), VIC $10,000~$20,000, QLD $30,000(신축), WA $10,000 등 주별 차이 있습니다. Stamp Duty Exemption도 PR/시민권자 조건부 면제 가능해요(NSW $800,000 이하 가격 면제). 학생비자/임시비자는 First Home Owner X이고 FIRB(외국인 투자 심의) 승인 + Foreign Investor Stamp Duty 추가 8%~21% 부담합니다. 첫 집 구매는 큰 결정이라 Mortgage Broker + Conveyancer 자문 권장해요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. First Home Owner Grant (주별)**
NSW: $10,000
- 신축 또는 첫 입주 (5년 미만)
- 가격 $750,000 이하
- 6개월 안 거주 + 6개월 이상

VIC: $10,000 (메트로) / $20,000 (지방)
QLD: $30,000 (신축, 2025~2026)
WA: $10,000 (신축)
ACT: $7,000 (조건부)
SA: $15,000
TAS: $30,000
NT: $10,000

신청: 각 주 Office of State Revenue

**2. Stamp Duty Exemption (PR)**
NSW (First Home Buyer):
- $800,000 이하: 100% 면제
- $800,000~$1,000,000: 비례 감면
- 그 이상: 일반 Stamp Duty

VIC:
- $600,000 이하: 면제
- $600,000~$750,000: 비례 감면

QLD/WA/ACT 등 주별 다름
조건: PR/시민권자 + 첫 집 + 거주

**3. FIRB (Foreign Investor)**
Foreign Investment Review Board:
- 학생비자 부동산 구매 의무 승인
- 신청료 $14,500~$580,000 (가격별)
- 보통 신축만 가능 (기존 X)

Foreign Investor Stamp Duty 추가:
- NSW 추가 8%
- VIC 추가 8%
- QLD 추가 8%
- 기본 Stamp Duty + 8%

→ 학생비자 부동산 구매 = 비용 큼

**4. First Home Buyer 추가 혜택**
First Home Loan Deposit Scheme (Federal):
- 정부 보증 5% Deposit (보통 20%)
- LMI(Lender Mortgage Insurance) 면제
- 연 35,000명 한도
- 가격 한도 (지역별)

First Home Super Saver Scheme:
- Super 자발적 기여 + 인출
- 최대 $50,000
- Tax Concession

Family Home Guarantee (Single Parent):
- 2% Deposit
- 한부모 우선

**5. 구매 절차 + 비용**
1. Pre-approval (대출 사전 승인)
   - Mortgage Broker 활용
2. 부동산 검색 (Domain/Realestate.com.au)
3. Building & Pest Inspection ($500~$800)
4. 가격 협상 + Contract
5. Cooling-off Period (NSW 5일)
6. Conveyancer ($1,500~$3,000)
7. Settlement (보통 6주)

추가 비용:
- Stamp Duty (또는 면제)
- Title Transfer $150~$200
- LMI (20% 미만 Deposit)
- Building Insurance

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: PR 자격 확인 + 첫 집 자격 확인
**2단계**: Mortgage Broker Pre-approval
**3단계**: 부동산 검색 + Building Inspection
**4단계**: Conveyancer 통한 Contract + Settlement
**5단계**: FHOG + Stamp Duty Exemption 신청

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. PR/시민권자만 First Home Owner Grant 받을 수 있어요. NSW $10,000(신축), QLD $30,000(신축) 등 주별 차이 있습니다. Stamp Duty도 PR 첫 집 면제 가능해요(NSW $800,000 이하). 학생비자는 First Home X이고 FIRB 승인 + 8% 추가 Stamp Duty 부담합니다. 첫 집 구매는 Mortgage Broker + Conveyancer 자문 권장해요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생비자 FHOG X**
   → PR/시민권자만

2. **FIRB 무관 X**
   → 외국인 의무

3. **Stamp Duty 자동 X**
   → PR 첫 집 조건

4. **Mortgage Broker 무관 X**
   → Pre-approval 핵심

5. **Building Inspection X**
   → Lemon Property 위험

6. **Conveyancer 안 받음 X**
   → 법률 + 절차 필수

7. **Foreign 8% 무관 X**
   → 외국인 추가 Stamp Duty

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 비자? (학생/PR/시민권)
2. 예산? ($500K 미만/$500K~$1M/$1M+)
3. 신축 vs 기존? (신축/기존)
4. Pre-approval 받았어요? (받음/안 받음)

---

## 🔍 직원이 직접 확인 가능한 사이트

- FHOG NSW: revenue.nsw.gov.au
- First Home Loan Deposit: housingaustralia.gov.au
- FIRB: firb.gov.au
- Domain: domain.com.au
- Realestate.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- FHOG 자격 1차 안내
- Stamp Duty 1차 안내
- FIRB 외국인 안내
- Mortgage Broker 1차 연결

**MARA / 변호사 영역**
- Mortgage Broker (Broker)
- Conveyancer (Solicitor)
- Building Inspector (Inspector)
- FIRB 신청 (변호사)

---

## ✅ 완벽 응대 체크리스트

- [ ] PR 자격 + 첫 집 확인
- [ ] Mortgage Broker Pre-approval
- [ ] Building & Pest Inspection
- [ ] Conveyancer Contract
- [ ] FHOG + Stamp Duty Exemption
