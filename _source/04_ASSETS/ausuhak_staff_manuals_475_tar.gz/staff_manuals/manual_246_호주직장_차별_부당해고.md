# #246 호주 직장 차별 / 부당해고 (Fair Work)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 카페 알바 하는데 사장이 한국인이라고 임금 적게 주고 무시해요. 이번 달엔 갑자기 해고됐어요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Fair Work Ombudsman = 임금 / 해고 분쟁 (무료)
- 한국인 사장 (Cash Job 빈번) = 위반 가장 많음
- 학생비자 = 신고 가능 (보복 X / 비자 보호)

---

## ❌ 절대 하지 말아야 할 답

> "학생비자라 신고하면 비자 취소되니까 참으세요."

→ ❌ **학생비자 신고 가능 + 비자 보호** (Assurance Protocol). Fair Work 무료 상담.

---

## ✅ 정답

호주 직장 차별 / 부당해고: ① **Fair Work Ombudsman**: 13 13 94 (무료 / 한국어 통역) ② **임금 위반**: 최저시급 (Award) 미만 = 위반 / 회수 가능 ③ **부당해고 (Unfair Dismissal)**: 21일 내 신청 / 6개월+ 근속 (소기업) ④ **학생비자 보호**: Assurance Protocol = 임금 신고 = 비자 취소 X (단, 주 48시간 위반은 별도) ⑤ **차별 (Anti-Discrimination)**: 인종 / 종교 / 성별 / 나이 → AHRC (Human Rights Commission) ⑥ **Cash Job (현금 지급)** = 세금 X / 슈퍼 X = 위반 (회수 가능). ⑦ **윌슨 영역 X** (Fair Work / 변호사 영역).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Fair Work Ombudsman**
- 호주 직장 분쟁 정부 기관 (무료)
- 13 13 94 / fairwork.gov.au
- 한국어 통역 가능 (TIS National 131 450)
- 임금 / 해고 / 휴가 / 슈퍼 등

**2. 최저시급 (Award)**
- 호주 최저시급 = $24.95/시 (2025.07~) / Casual = +25% Loading = $31.19/시 (Casual, 25% Loading)
- Award (산업별 최저) = 산업별 다름 (Hospitality / Retail / Construction)
- 최저 미만 = 위반 / Fair Work 신고 가능

**3. 부당해고 (Unfair Dismissal)**
- **신청 자격**: 6개월+ 근속 (대기업) / 12개월+ (소기업 = 15명 미만)
- **신청 시한**: 해고 후 21일 (매우 짧음)
- **신청료**: $87.20 (2025) / 면제 가능
- **Fair Work Commission** 결정

**4. 학생비자 보호 (Assurance Protocol)**
- 학생비자가 임금 / 해고 신고 = 비자 취소 X
- 단, 주 48시간 위반 = 별도 (Home Affairs)
- Cash Job 신고 = 본인 보호 (회수 가능)

**5. 차별 (Anti-Discrimination)**
- AHRC (Australian Human Rights Commission)
- 인종 / 종교 / 성별 / 나이 / 장애 / 성정체성
- 무료 신고 / 12개월 내

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 즉시 안전 확인 (협박 / 폭력 시 000)
**2단계**: 증거 수집 (급여 명세 / 근무 기록 / 메시지)
**3단계**: Fair Work Ombudsman 13 13 94 (한국어 통역)
**4단계**: 임금 회수 신청 (My Account / 온라인)
**5단계**: 부당해고 21일 내 신청 (Fair Work Commission)
**6단계**: 차별 = AHRC 신고

---

## 💡 직원이 학생한테 말할 멘트

> "윌슨님께 이렇게 전달드릴게요:
> 
> '먼저 학생비자라도 임금 / 해고 신고 가능해요. Assurance Protocol = 신고 시 비자 취소 X예요 (단, 주 48시간 위반은 별도). Fair Work Ombudsman 13 13 94 (한국어 통역 무료)에 연락하세요. 호주 최저시급 $24.95 (2025.07~)/시 (2025.07~), Casual = $31.19/시 (25% Loading)예요. Cash Job = 세금 X / 슈퍼 X = 위반이라 회수 가능해요. 부당해고는 21일 내 Fair Work Commission 신청이에요 (시한 매우 짧음). 차별은 AHRC (Human Rights Commission) 신고예요. 윌슨이 영역이 아니에요. Fair Work / 변호사 영역이에요.'"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7개

1. **학생비자 신고 = 취소**: ❌ Assurance Protocol = 보호
2. **Cash Job 안전**: ❌ 위반 / 회수 가능
3. **참으면 됨**: ❌ 임금 회수 가능
4. **부당해고 시한 자유**: ❌ 21일 (매우 짧음)
5. **최저시급 시간 무관**: ❌ Award = 산업별 / Casual Loading
6. **한국인 사장 = 한국 법**: ❌ 호주 거주 = 호주 법
7. **윌슨 처리**: ❌ Fair Work 영역

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **분쟁 종류**: 임금 / 해고 / 차별 / 협박
2. **근속 기간**: 6개월+ / 12개월+ (부당해고 자격)
3. **증거 보유**: 급여 명세 / 근무 기록 / 메시지
4. **즉시 위험**: 000 우선

---

## 🔍 직원이 직접 확인 가능한 사이트

- **Fair Work Ombudsman**: https://www.fairwork.gov.au / 13 13 94
- **TIS National (한국어 통역)**: 131 450
- **Fair Work Commission (부당해고)**: https://www.fwc.gov.au
- **AHRC (차별)**: https://humanrights.gov.au
- **Assurance Protocol (학생 비자)**: https://www.fairwork.gov.au/find-help-for/visa-holders-migrants

---

## 🚨 직원 영역 vs Fair Work / 변호사 영역

| 영역 | 직원 가능 | 외부 영역 |
|------|----------|--------|
| Fair Work 안내 | ✅ | - |
| 학생비자 보호 안내 | ✅ | - |
| 최저시급 일반 안내 | ✅ | - |
| 임금 회수 신청 | ❌ | ✅ Fair Work |
| 부당해고 신청 | ❌ | ✅ Fair Work Commission |
| 차별 신고 | ❌ | ✅ AHRC |

---

## ✅ 완벽 응대 체크리스트

- [ ] Assurance Protocol (학생 보호) 강조
- [ ] Fair Work 13 13 94 한국어 통역 안내
- [ ] 최저시급 $24.95 (2025.07~)/시 (2024) 안내
- [ ] Casual Loading 25% 안내
- [ ] Cash Job 위반 / 회수 가능 안내
- [ ] 부당해고 21일 시한 강조
- [ ] 윌슨 = 유학 영역 / Fair Work 영역 분리
