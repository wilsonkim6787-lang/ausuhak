# #362 호주_학생_중고차_사기_피해_민원_환불

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "중고차 5천 불 주고 샀는데 일주일 만에 엔진 고장났어요. 페이스북에서 한인이 팔았는데 환불해줄까요? 어떻게 신고해요?"

**직원 멘붕 포인트:**
- 사적 거래 vs 딜러 거래 환불 권리 차이
- Australian Consumer Law (ACL) 적용 여부
- 한인 사기범 추적 + 신고 절차
- Consumer Affairs vs 경찰 vs Tribunal 구분
- PPSR 미조회 + RWC 미확인 후속 조치

---

## ❌ 절대 하지 말아야 할 답

> "개인 거래는 환불 안 돼요. 그냥 손해 보세요."

→ ❌ ACL = 개인 거래도 일부 권리 (False Representation). NSW Civil Tribunal 무료 신고 가능. 한인 사기 = 경찰 신고 + Consumer Affairs 동시 진행 권장.

---

## ✅ 정답

**개인 거래 (Private Sale) 권리**:
- ACL Section 18 (False Representation): 거짓 진술로 판매 = 환불/배상 청구 가능
- 단, "As Is" 명시 + 사실 진술 = 환불 어려움
- NSW Civil and Administrative Tribunal (NCAT): 신고 $54

**딜러 거래 권리**:
- ACL Consumer Guarantees: 자동 적용
- 합리적 품질 (Acceptable Quality) 보장
- 환불/수리/교환 의무
- Statutory Warranty (NSW): 3개월/3,000km

**증거 확보**:
- 광고 캡처 (페이스북/Gumtree)
- 카카오톡 대화 캡처
- 결제 영수증 (송금/현금)
- 차량 점검 견적서

**신고 절차**:
1. NSW Fair Trading 민원 (무료): fairtrading.nsw.gov.au
2. NCAT 신청 ($54): 직접 변호 가능
3. 사기 의심: NSW Police 신고 (131 444)
4. 한국인 대상 사기 = 시드니 영사관 영사 보호 신청

**예외**:
- 개인 거래 + RWC/Pink Slip 위조 = 사기 형사 처벌 가능
- "As Is" 매매 + 사실 진술 = 권리 제한

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Australian Consumer Law (ACL)**
전국 통일 소비자법. Section 18 = 거짓 진술 금지 (개인/딜러 모두).

**2. NCAT (NSW Civil and Administrative Tribunal)**
ncat.nsw.gov.au. 소비자 분쟁 무료 신청 ($54). 변호사 없이 직접 변호. 결정 = 법적 강제력.

**3. Statutory Warranty (NSW)**
딜러 매매 차량 = 3개월/3,000km 의무 보증. 개인 매매 미적용.

**4. False Representation**
ACL Section 18: 거짓 진술. 주행거리 위조/사고 이력 은폐 = 위반. 형사 + 민사 책임.

**5. Consumer Affairs**
NSW Fair Trading, VIC Consumer Affairs. 무료 민원 + 조정. 강제력 X (조정만).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 즉시 증거 확보: 광고 + 대화 + 영수증 + 차량 점검 견적서
**2단계**: 판매자 연락: 환불/수리 요청 (서면)
**3단계**: 거부 시: NSW Fair Trading 민원 (무료)
**4단계**: 조정 실패: NCAT 신청 ($54)
**5단계**: 사기 의심: NSW Police + 시드니 영사관 영사 보호

---

## 💡 직원이 학생한테 말할 멘트

> "개인 거래라도 거짓 진술 (False Representation) 사기면 ACL로 환불 청구 가능해요. NSW Fair Trading 무료 민원 + NCAT $54 신청해서 받을 수 있습니다. 광고 캡처 + 카카오톡 대화 + 영수증 증거 모으세요. 한국인 대상 사기는 시드니 영사관 영사 보호도 신청 가능해요. 자세한 절차는 윌슨 + 변호사 추천 필요해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **개인 거래 = 환불 절대 X**
   → ACL 거짓 진술 시 가능.

2. **As Is = 모든 권리 포기**
   → 허위 진술은 ACL 위반.

3. **페이스북 거래 = 추적 불가**
   → Meta 협조 + 경찰 디지털 포렌식 가능.

4. **Tribunal = 변호사 의무**
   → 본인 직접 변호 가능.

5. **Statutory Warranty 모든 차량 적용**
   → 딜러 매매만. 개인 매매 미적용.

6. **Consumer Affairs = 강제력**
   → 조정만. 강제력 = NCAT 또는 법원.

7. **영사관 = 보상 처리**
   → 영사 보호 = 조언 + 안내. 보상 X.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 거래 형태 (개인 vs 딜러)
2. 증거 확보 (광고/대화/영수증/점검 견적)
3. 거짓 진술 여부 (주행거리/사고 이력)
4. 판매자 신원 (이름/주소/전화)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW Fair Trading: fairtrading.nsw.gov.au
- NCAT: ncat.nsw.gov.au
- VIC Consumer Affairs: consumer.vic.gov.au
- ACCC Scamwatch: scamwatch.gov.au
- 시드니 한국 영사관: overseas.mofa.go.kr/au-sydney-ko

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 민원 절차 + 증거 정리 안내
- 한인 사기 조심 + PPSR 사전 조회 강조
- Consumer Affairs vs NCAT 단계 안내

**MARA / 변호사 영역**
- 민사 변호사 (배상금 $5K 이상)
- 형사 변호사 (사기 형사 고발)
- 외국인 대상 사기 그룹 적발

---

## ✅ 완벽 응대 체크리스트

- [ ] ACL 개인 거래 권리 정확 안내
- [ ] NCAT $54 무료 변호 가능 안심
- [ ] 증거 확보 우선 강조
- [ ] Statutory Warranty 딜러만 명시
- [ ] 영사관 영사 보호 안내
- [ ] Scamwatch 신고 권장
- [ ] 윌슨 1:1 상담 자연 유도
