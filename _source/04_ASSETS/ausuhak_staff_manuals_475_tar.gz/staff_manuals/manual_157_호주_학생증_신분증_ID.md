# 매뉴얼 #157 - 호주 학생증 / 신분증 / 공식 ID

## 🎬 상황 시뮬레이션

**카카오 첫 메시지:**
> "호주에서 ID가 뭐 필요해요? 학생증 받았는데 신분증으로 쓸 수 있어요? Pub 가는데 여권 들고 다녀야 하나요?"

**직원 멘붕 포인트:**
- 호주 신분증 종류 다양
- 학생증 vs Photo ID 다름
- 여권 분실 위험

---

## ❌ 절대 하지 말아야 할 답
- "학생증으로 다 돼요" (Pub 거절 가능)
- "여권 항상 가지고 다니세요" (분실 위험)
- "한국 신분증 쓰세요" (호주 인정 X)

## ✅ 정답
"호주에서 일반적으로 쓰이는 ID는 운전면허증 또는 Proof of Age Card예요. 학생증은 학교 안에서만 유효해요. Pub/술집은 운전면허 또는 여권 필요해요. 여권 항상 들고 다니면 분실 위험이에요. Photo ID 발급법 윌슨 대표가 카톡으로 안내드려요. ID studywilson 이에요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 호주에서 인정되는 ID 종류

**1차 ID (Primary)**:
- **여권** (Passport)
- **호주 운전면허증** (Driver Licence)
- **Proof of Age Card** (NSW/VIC)
- **Australia Post Keypass**

**2차 ID (Secondary)**:
- 학생증
- Medicare 카드
- 은행 카드
- 신용카드

→ Pub/술집/은행은 1차 ID 요구

### 2. Photo ID 발급 (Proof of Age Card)

**NSW (시드니)**:
- **Photo Card** - Service NSW
- 18세+ $59 / 18세 미만 $40
- 발급 2~3주
- 운전면허 대신 사용 가능

**VIC (멜번)**:
- **Keypass ID** - Australia Post
- $51
- 18세+ 발급

**QLD (브리즈번)**:
- **Adult Proof of Age Card**
- $59

**SA/WA/TAS/NT**:
- 각 주 정부 사이트 확인

### 3. 학생증 (Student ID Card)

**용도**:
- 학교 출입 (도서관/체육관)
- 학생 할인 (대중교통/박물관/영화관)
- 시험 응시
- 학교 식당 결제 (일부)

**용도 X**:
- Pub/Bar/Club (Photo ID 요구)
- 은행 계좌 개설 (1차 ID 필요)
- 비자 신청
- 정부 서비스

→ **학생증 ≠ 신분증**

### 4. 한국 운전면허증 사용

**호주 도착 후**:
- IDP (국제운전면허증) + 한국 면허 → 호주 운전 가능 (3~6개월)
- IDP는 ID로 사용 X (Pub 등)

**호주 운전면허 전환**:
- NSW: 3개월 이내 의무
- VIC: 6개월 이내 의무
- 한국 5년+ 보유 → 시험 면제 (일부 주)

### 5. 여권 분실 시 처리

**즉시 조치**:
1. 한국 영사관 신고 (시드니/멜번)
2. 경찰 신고 (Police Report) → 사건번호
3. 임시 여행증명서 신청 ($30~$60)
4. 한국 정식 여권 재발급 ($53)

**여권 분실 시 비자 영향**:
- 학생비자 자체는 유지 (전자비자)
- 한국 출입국 시 신여권 + 비자 라벨 필요

**예방**:
- 호주 도착 후 Photo Card 신청
- 여권 = 집/은행 보관 (외출 시 X)
- 여권 사본 (스마트폰) 보관

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 학생 현재 상황 파악
- 막 도착? 학교 다니는 중?
- ID 분실? 신규 발급?

### Step 2: Photo ID 발급 권유
- 주별 절차 안내

### Step 3: 학생증 vs ID 차이 설명
- 학생증은 학교 한정

### Step 4: 여권 보관 권유
- 분실 위험 안내

### Step 5: 윌슨 상담 (필요시)
- 분실 사고 시 처리

---

## 💡 직원이 학생한테 말할 멘트

```
[ID 발급 안내]
호주 일상 ID 발급 추천드려요!

▪️ NSW: Photo Card (Service NSW $59)
▪️ VIC: Keypass (Australia Post $51)
▪️ QLD: Adult Proof of Age Card ($59)

학생증은 학교 안에서만 유효하고요,
Pub/은행/일상은 Photo ID가 편해요.

여권은 분실 위험이라 집에 보관 권유해요.

자세한 발급법 윌슨 대표가 카톡으로 안내드려요.
ID: studywilson
```

```
[여권 분실 시]
여권 분실하셨군요. 침착하게 처리해요.

1. 경찰 131 444 (Police Report)
2. 한국 영사관 (시드니/멜번)
3. 임시 여행증명서 → 정식 여권

학생비자 자체는 유지돼요 (전자비자).
긴급한 도움 필요하면 윌슨 대표 카톡 주세요.
ID: studywilson
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "학생증 = 신분증"
**아님** - 학교 안에서만. Pub/은행 거절 가능.

### 함정 2: "여권 항상 들고 다녀야"
**위험** - 분실 위험. Photo Card 발급 권유.

### 함정 3: "IDP = 한국 면허증 같음"
**아님** - 호주 운전 가능, 단 ID로 사용 X.

### 함정 4: "Photo Card = 운전면허"
**다름** - Photo Card는 ID만. 운전 X. 운전면허는 별도.

### 함정 5: "Australia Post Keypass = 모든 주"
**아님** - VIC 위주. NSW는 Service NSW Photo Card.

### 함정 6: "여권 분실 = 비자 끝"
**아님** - 비자 유지. 여권 재발급으로 회복.

### 함정 7: "한국 주민등록증 = 호주 ID"
**아님** - 호주 정부 인정 X.

---

## 📞 카카오 응대 시 필수 4가지 확인

```
[직원이 학생에게 물어볼 4가지]

1. 어느 주 거주?
   (NSW? VIC? 다른?)

2. 18세 이상? 미만?
   (Proof of Age 자격)

3. ID 발급 vs 분실 사고?

4. 운전 계획?
   (운전면허 별도 필요)

→ 윌슨 카톡 연결: studywilson
```

---

## 🔍 직원이 직접 확인 가능한 사이트

- [Service NSW Photo Card](https://www.service.nsw.gov.au/transaction/apply-photo-card)
- [Australia Post Keypass](https://auspost.com.au/id-and-document-services/keypass-identity-card)
- [QLD Proof of Age](https://www.qld.gov.au/transport/licensing/proof-of-age)
- [한국 영사관 시드니](http://overseas.mofa.go.kr/au-sydney-ko/)

---

## 🚨 직원 영역 vs 윌슨 영역

### 직원 영역
- ID 종류 일반 안내
- 발급 절차 안내
- 학생증 vs ID 차이

### 윌슨 영역 (1:1)
- 분실 사고 시 처리
- 영사관/경찰 연결

---

## ✅ 완벽 응대 체크리스트

- [ ] 호주 1차 vs 2차 ID 안내
- [ ] 주별 Photo Card 발급 안내
- [ ] 학생증 ≠ 신분증 명확히
- [ ] 여권 분실 위험 안내
- [ ] 한국 면허 + IDP 안내
- [ ] 분실 시 처리 절차
- [ ] 윌슨 카톡 연결 (사고 시)

---

**작성: 2026-05-04 **
**참조: Service NSW / Australia Post / 한국 영사관**
