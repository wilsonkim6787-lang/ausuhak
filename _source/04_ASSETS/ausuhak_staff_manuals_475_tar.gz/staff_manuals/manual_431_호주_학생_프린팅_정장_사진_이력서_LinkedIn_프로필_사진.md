# #431 호주_학생_프린팅_정장_사진_이력서_LinkedIn_프로필_사진

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "졸업 후 호주 회사 면접 봐야 하는데 정장이 없어요. 한국에서 사 갈까 호주에서 살까요? 그리고 LinkedIn 프로필 사진 어디서 찍나요? 이력서는 어떻게 작성해야 호주 스타일인지 모르겠어요."

**직원 멘붕 포인트:**
- Officeworks 프린팅
- Myer/David Jones 정장
- LinkedIn 사진 스튜디오
- Australian Resume Style (1-2 pages)
- Cover Letter 의무 여부

---

## ❌ 절대 하지 말아야 할 답

> "한국 양식 그대로 쓰세요"

→ ❌ ❌ 호주 이력서 = 사진 X / 나이 X / 결혼 X. 한국 양식 그대로 = 차별 우려 + 미스매치.

---

## ✅ 정답

호주 취업 준비: ① 정장 - Myer/David Jones $300~$800, M.J. Bale/Politix(남) / Cue/Country Road(여) 한국보다 비쌈, ② 프린팅 - Officeworks (24/7 일부 매장) A4 흑백 $0.10/장, 컬러 $0.50, ③ LinkedIn 사진 - $50~$150 사진관 (LookSmart, Snap Studio), ④ Australian Resume = 1-2장 / 사진 X / 생년월일 X / 결혼 상태 X / Reference 2명 끝, ⑤ Cover Letter = 1장 / 의무 (대부분), ⑥ 호주 이력서 핵심: STAR 방식 (Situation-Task-Action-Result), ⑦ Seek/LinkedIn/Indeed 가장 활용도 높음.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Officeworks**
프린팅 + 사무용품 + 24/7 일부

**2. 호주 정장**
Myer/DJ $300+ / Lowes 저가 $100~

**3. Australian Resume**
1-2장 / 사진/나이 X

**4. Cover Letter**
STAR 방식 / 의무

**5. Reference**
전 직장 상사 2명 표준

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 면접 일정 확인
**2단계**: 2단계: 정장 - 한국에서 사오는 게 가성비 (대부분)
**3단계**: 3단계: Officeworks 프린팅 위치 확인
**4단계**: 4단계: LinkedIn 사진 스튜디오 예약
**5단계**: 5단계: 이력서 호주식 변환 (사진/나이 삭제)

---

## 💡 직원이 학생한테 말할 멘트

> "정장은 한국에서 사오시는 게 저렴합니다. 이력서는 호주식 (1-2장 / 사진/나이/결혼 삭제) 으로 작성하세요. Officeworks에서 프린팅 가능합니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **호주 이력서 사진 필수**
   → 넣으면 차별 우려

2. **나이/생년월일 표기**
   → 호주 이력서 X

3. **3-4장 이력서**
   → 1-2장 표준

4. **Cover Letter 선택**
   → 대부분 의무

5. **Reference 4명+**
   → 2명 표준

6. **한국 사진관 LinkedIn**
   → 현지 톤 안 맞음

7. **Officeworks 무료**
   → 유료 / 셀프서비스

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 면접 일정 / 회사 업종
2. 정장 보유 여부
3. 현재 이력서 한국식 vs 호주식
4. LinkedIn 가입 상태

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('Officeworks', 'officeworks.com.au')
- ('Seek', 'seek.com.au')
- ('LinkedIn 호주', 'linkedin.com')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 이력서 일반 안내, 정장 정보

**MARA / 변호사 영역**
- 비자 영향 X / 무관

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 정장 가성비 안내함
- [ ] 호주 이력서 사진 X 강조함
- [ ] 1-2장 분량 안내함
- [ ] STAR Cover Letter 안내함
- [ ] Reference 2명 안내함
- [ ] Officeworks 프린팅 안내함
