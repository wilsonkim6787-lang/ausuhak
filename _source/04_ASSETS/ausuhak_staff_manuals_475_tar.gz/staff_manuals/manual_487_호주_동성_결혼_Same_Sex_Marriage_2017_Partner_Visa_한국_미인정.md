# #487 호주_동성_결혼_Same_Sex_Marriage_2017_Partner_Visa_한국_미인정

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주에서 한국인 동성 친구가 호주 시민권자 파트너랑 결혼해요. 한국 가족이 인정 안 하는데 비자/법적 효력 있어요?"

**직원 멘붕 포인트:**
- 호주 동성 결혼 합법: 2017.12.09
- 동성 부부 Partner Visa 820/801, 309/100 가능
- 한국 동성 결혼 미인정 (가족관계 등록 X)
- 호주 결혼증명서는 호주에서만 효력
- 직원 차별 발언은 AHRC 신고 가능 + 직업 윤리 문제

---

## ❌ 절대 하지 말아야 할 답

> "동성 결혼은 한국에서 의미 없어요"

→ ❌ 호주 합법. 학생 가치관 존중. 차별 발언 금지

---

## ✅ 정답

호주는 2017년부터 동성 결혼 합법화돼서 호주 법적 완전 유효해요. 시민권자 파트너와 결혼 시 Partner Visa(820/801) 신청 가능, PR + 시민권까지 갈 수 있습니다. 한국은 미인정이라 한국 가족관계 등록 안 되고 한국 측 효력 없어요. 한국 가족 인정 여부와 호주 비자는 별개입니다. 비자 절차는 윌슨샘과 1:1 상담하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 동성 결혼 (Marriage Act 2017)**
2017.12.09 Marriage Amendment Act
정의: 'Marriage between two people'
법적 효력: 모든 권리 동일
Marriage Celebrant + 1개월 Notice 의무

**2. Partner Visa (동성/이성 동일)**
820 Onshore Temporary: $9,365, 12~24개월
801 Permanent: 820 후 2년
309/100 Offshore: 12~24개월
동성/이성 차별 X

**3. 관계 진실성 4영역**
Financial: 공동 계좌/임대
Household: 공동 거주/가사
Social: 가족/친구 인지
Commitment: Marriage Certificate + 시간
동성 부부도 동일

**4. 한국 측 처리**
민법 812조: 결혼 = 남녀
한국 가족관계 등록 X
한국 거주 시 동거인 신분
한국 상속 시 배우자 권리 X (유언 필요)

**5. LGBTI+ 지원**
QLife: 1800 184 527
Acon NSW: acon.org.au
Beyond Blue: 1300 22 4636
AHRC Sex Discrimination: humanrights.gov.au

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: Notice of Intended Marriage 1개월 전 BDM 제출
**2단계**: Marriage Celebrant 통해 결혼식
**3단계**: Marriage Certificate 발급
**4단계**: Partner Visa 820/801 신청
**5단계**: 관계 진실성 4영역 증빙 수집

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 호주 동성 결혼은 2017년부터 합법이라 법적 완전 유효해요. Partner Visa(820/801) 신청 가능하고 PR도 됩니다. 한국 측은 미인정이라 별개 문제예요. 자세한 비자 절차는 카카오 ID studywilson 으로 1:1 상담하세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **동성 결혼 호주 효력 X**
   → 2017년부터 합법

2. **Partner Visa 동성 차별 X**
   → 동성/이성 동일 절차

3. **한국 인정 X = 호주 영향 X**
   → 별개 문제

4. **관계 진실성 동성이 어려움 X**
   → 동일. Social 영역 보강

5. **한국 자동 등록 X**
   → 한국 시스템 미반영

6. **한국 시민권 영향 X**
   → 한국 국적 영향 없음

7. **직원 차별 발언 X**
   → AHRC 신고 + 윤리 문제

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 친구분 비자? (학생/485/PR)
2. 파트너 만난 기간? (1년 미만/1~2년/2년+)
3. Notice 제출? (했다/안 했다)
4. 한국 가족 인지? (인지/미인지/갈등)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Marriage Equality: marriagequality.org.au
- BDM 각 주 등록
- Partner Visa: immi.homeaffairs.gov.au/visas/partner
- QLife: qlife.org.au
- AHRC: humanrights.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 동성 결혼 합법성 안내
- Partner Visa 1차 안내
- 관계 진실성 가이드
- 한국 측 한계 안내

**MARA / 변호사 영역**
- Partner Visa 820/801 (MARA)
- 관계 진실성 진술서 (MARA)
- 한국 가족 분쟁 (한국 법무사)
- 한국 측 처리 (영사관)

---

## ✅ 완벽 응대 체크리스트

- [ ] Notice 1개월 전 제출
- [ ] Marriage Celebrant 예약
- [ ] 관계 증빙 4영역 수집
- [ ] Partner Visa 신청 (MARA)
- [ ] QLife/Beyond Blue 활용
