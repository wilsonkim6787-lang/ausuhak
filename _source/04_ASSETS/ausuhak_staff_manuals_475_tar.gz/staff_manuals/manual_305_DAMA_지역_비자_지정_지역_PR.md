# #305 DAMA_지역_비자_지정_지역_PR

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니/멜번 외 작은 도시 가면 PR 더 쉽다는데 정확히 어떤 거에요?"

**직원 멘붕 포인트:**
- DAMA = Designated Area Migration Agreement
- 지역별 협정 다름 (NT, SA, WA, VIC, QLD)
- 직업 + 영어 + 자산 일반 PR보다 완화
- 지정 직업 다름 (지역별 IT/요리/보건/Trade 등)
- DAMA 지원 = 482 + 491 + 186 + 187 등 다양

---

## ❌ 절대 하지 말아야 할 답

> "시드니/멜번 외 가면 PR 자동으로 받아요."

→ ❌ DAMA = 지정 지역 + 지정 직업 + 호주 회사 후원 + 영어 등 조건. 자동 X. 또한 DAMA = 482 + 191 → PR 단계적. 거주 의무 + 직업 유지 의무.

---

## ✅ 정답

**DAMA = 지역별 호주 정부 협정 비자**

**현재 운영 DAMA 지역:**
1. **Northern Territory (NT)** - 다윈 + 전역
2. **South Australia (SA)** - Adelaide Tech + Regional SA
3. **Western Australia (WA)** - Goldfields, Pilbara, South West
4. **Victoria (VIC)** - Great South Coast (Warrnambool 등)
5. **Queensland (QLD)** - Far North QLD (Cairns), Townsville
6. **New South Wales (NSW)** - Orana (Dubbo), Far South Coast
7. **Tasmania (TAS)** - 전역

**DAMA 혜택:**
- 일반 PR보다 영어 점수 낮음 (IELTS 5.0~6.0)
- 직업 리스트 확대 (일반 MLTSSL/STSOL 외)
- 나이 우대 (45세 이상도 가능)
- 임금 요건 완화 (TSMIT 10% 감면)

**비자 종류:**
- 482 (Skilled Worker) - 4년 임시
- 491 (Skilled Work Regional) - 5년 임시 + 191 PR
- 494 (Skilled Employer Sponsored Regional) - 5년 임시 + 191 PR
- 186 (Employer Nomination Scheme) - 직접 PR

**조건:**
- 지정 지역 거주
- 지정 직업 + 호주 회사 후원
- 직업 평가 (TRA/VETASSESS)
- 영어 점수 (지역별 다름, IELTS 5.0~6.0)

**한국 학생 활용:**
- 시드니/멜번 졸업 + DAMA 지역 이주
- DAMA 지역 호주 회사 후원 = 4-5년 일하면서 PR
- 일반 EOI 점수 낮아도 가능

**예시 (Adelaide):**
- IT (Web Developer) = DAMA SA 지정 직업
- 영어 IELTS 5.5 (Functional)
- 한국 학생 ICT 4년 + Adelaide 취업 = DAMA 491 → 191 PR

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. DAMA 정의**
Designated Area Migration Agreement. 호주 정부와 지역별 협정. 지역 인력난 해결 목적.

**2. 일반 PR vs DAMA 차이**
일반 PR = MLTSSL + EOI 65점 + IELTS 6.0. DAMA = 지정 직업 + 영어 5.0~6.0 + 회사 후원.

**3. 491 → 191 PR 경로**
491 = 5년 지역 임시 비자. 3년 거주 + 일하면 191 영구 비자 신청.

**4. TSMIT 감면**
Temporary Skilled Migration Income Threshold. 일반 $73,150 → DAMA 10% 감면.

**5. 지역별 직업 리스트 다름**
NT = 다양한 직업 (요리/보건/IT). SA = Tech/제조/건설. 지역 산업에 따라 다름.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **DAMA 지역 + 직업 확인** - 본인 분야가 어느 지역 DAMA 해당 직업인지
**2단계**: **지역 학교/취업 결정** - 지역 학교 진학 후 졸업 / 또는 지역 직접 취업
**3단계**: **호주 회사 후원** - DAMA 지역 회사 후원 (DAMA Endorsed Employer)
**4단계**: **비자 종류 선택** - 482 (4년 임시) / 491 (5년 임시 + 191 PR) / 186 (직접 PR)
**5단계**: **거주 의무 + 일** - 지역 거주 + 지정 직업 일 = PR 자격

---

## 💡 직원이 학생한테 말할 멘트

> "DAMA = 호주 7개 지정 지역 + 지정 직업 협정으로, 일반 PR보다 영어 점수/나이/직업 조건이 완화된 비자입니다. 본인 분야 (IT/요리/보건 등)가 어느 지역 DAMA 해당인지 + 호주 회사 후원이 핵심입니다. 491 (5년) → 191 PR 경로가 일반적입니다. Adelaide DAMA가 한국 학생에게 인기입니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **DAMA 지역 가면 자동 PR**
   → DAMA = 호주 회사 후원 + 직업 + 영어 + 거주 모두 충족. 자동 X.

2. **DAMA = 영어 점수 0**
   → 지역별 IELTS 5.0~6.0 (Functional/Vocational). 0은 아님.

3. **Sydney/Melbourne도 DAMA 가능**
   → Sydney/Melbourne = 일반 도시. DAMA 적용 X. Regional NSW (Orana) = OK.

4. **DAMA = 1년이면 PR**
   → 491 → 3년 + 191 PR. 보통 4-6년.

5. **DAMA Endorsed Employer = 모든 회사**
   → DAMA Endorsed = 협정 등록 회사만. 일반 회사 X.

6. **Adelaide = DAMA 지역**
   → Adelaide Metropolitan = DAMA 일부 (DAMA SA). Adelaide 외 Regional SA = 더 광범위.

7. **DAMA 191 PR 후 시드니 이주 가능**
   → 191 PR 후 5년 거주 의무 (지정 지역). 5년 후 자유.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 본인 분야 (IT/요리/보건/Trade 등)
2. 관심 지역 (NT/SA/WA/VIC/QLD/NSW Regional/TAS)
3. 호주 회사 후원 가능 여부 (이미 회사 / 신규 구직)
4. 영어 점수 + 나이

---

## 🔍 직원이 직접 확인 가능한 사이트

- DAMA 종합: immi.homeaffairs.gov.au/visas/employing-and-sponsoring-someone/sponsoring-workers/learn-about-sponsoring/labour-agreements/designated-area-migration-agreements
- Adelaide DAMA: www.migration.sa.gov.au
- NT DAMA: theterritory.com.au
- Cairns DAMA: www.cairns.qld.gov.au
- Orana DAMA NSW: www.rdaorana.org.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- DAMA 지역 일반 정보 안내
- Adelaide DAMA = 한국 학생 인기 안내
- 윌슨 950명 동문 DAMA 지역 사례

**MARA / 변호사 영역**
- DAMA 비자 신청 = MARA 등록 변호사 권장
- DAMA Endorsed Employer 후원 협상 = 변호사
- DAMA 거절 항소 = MARA
- 지역별 다른 협정 = MARA 자문

---

## ✅ 완벽 응대 체크리스트

- [ ] DAMA = 지정 지역 + 지정 직업 협정 명확히 함
- [ ] 7개 운영 지역 안내함
- [ ] 일반 PR vs DAMA 차이 설명함
- [ ] 491 → 191 PR 경로 설명함
- [ ] 호주 회사 후원 필수 강조함
- [ ] 거주 의무 + 직업 유지 의무 설명함
- [ ] MARA 변호사 자문 권장함
