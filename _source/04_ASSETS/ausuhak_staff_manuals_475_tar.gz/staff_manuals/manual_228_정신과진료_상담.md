# #228 정신과 진료 / 상담 (Mental Health Plan)

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주에서 우울증 / 불안증으로 정신과 진료받고 싶은데... 한국이랑 어떻게 다르나요?"

**직원 멘붕 포인트:**
- Mental Health Care Plan
- GP → 심리상담사 (Psychologist)
- 정신과 의사 (Psychiatrist)
- OSHC 환급

---

## ❌ 절대 하지 말아야 할 답

> "정신과는 호주에서 비싸고 어려워요. 그냥 참으세요!"

→ ❌ **참는 것 위험**. Mental Health Care Plan = OSHC 환급 가능.

---

## ✅ 정답

호주 정신과 / 상담: ① **GP** = 1차 진료 / Mental Health Care Plan 작성 (10회 무료~할인 상담) ② **Psychologist (임상심리사)** = 상담 (CBT / DBT) ③ **Psychiatrist (정신과 의사)** = 약 처방 (항우울제 / 항불안제) ④ **OSHC 환급**: GP 진료 / Psychologist 일부 (보험사별) ⑤ **무료 상담 라인**: Lifeline (13 11 14) / Beyond Blue (1300 22 4636) / Headspace (학생) ⑥ **한국어 상담사** = 시드니 / 멜번 일부 / 윌슨 매칭. 부끄러움 X.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. Mental Health Care Plan (MHCP)
- GP 작성 (1차 진료)
- 10회 (연간) 심리상담 환급 (Medicare)
- OSHC도 일부 환급 (보험사별)

### 2. 의료진 종류
- **GP**: 1차 / MHCP 작성 / 약 처방 (간단)
- **Psychologist (임상심리사)**: 상담 (CBT / DBT 등) / 약 처방 X
- **Psychiatrist (정신과 의사)**: 약 처방 / 진단 / 입원

### 3. OSHC 정신과 환급
- 보험사별 다름
- Bupa / Medibank / Allianz / NIB / AHM
- GP 진료 = 100% 환급
- Psychologist = 부분 환급 (회당 $50~$100)
- Psychiatrist = 부분 환급

### 4. 무료 상담 라인 (24시간 / 한국어 X)
- **Lifeline**: 13 11 14 (자살 위기)
- **Beyond Blue**: 1300 22 4636 (우울 / 불안)
- **Headspace**: 학생 / 청소년
- **13YARN**: 13 92 76 (Aboriginal)
- **Kids Helpline**: 1800 55 1800 (만 25세 이하)

### 5. 한국어 상담사
- **시드니**: 일부 한인 심리상담사 (Strathfield / Eastwood)
- **멜번**: 일부 (Box Hill / Carnegie)
- **온라인**: 한국 화상 상담 (시차)
- 윌슨 = 학생 매칭 가능

---

## 🎯 정답 경로

### Step 1: 응급 vs 일반
- 자살 / 자해 위험 = 즉시 000 / Lifeline 13 11 14
- 일반 우울 / 불안 = GP 예약

### Step 2: GP 진료
- MHCP 작성 요청
- 10회 심리상담 처방
- 약 (항우울제 등) 필요 시 처방

### Step 3: Psychologist 매칭
- GP 추천 또는 Psychology Today 검색
- 한국어 가능 = 윌슨 매칭

### Step 4: Psychiatrist (필요 시)
- GP 의뢰서
- 약 처방 / 진단

### Step 5: OSHC 환급
- 영수증 보관
- 보험사 청구

---

## 💡 직원 멘트

> "안녕하세요! 호주 정신과 / 상담 안내드릴게요.
>
> ✅ GP → Mental Health Care Plan (10회 상담)
> ✅ Psychologist (상담) / Psychiatrist (약 처방)
> ✅ OSHC 환급 (보험사별)
> ✅ 무료 상담: Lifeline 13 11 14 / Beyond Blue 1300 22 4636
> ✅ 한국어 상담사 = 시드니 / 멜번 일부
>
> 정신 건강 = 부끄러운 거 절대 아니에요. 호주 학생 30%+가 상담받아요.
>
> 한국어 상담사 매칭 / 학교 카운슬러 연결 = 윌슨님이 도와드려요. 카카오톡으로 1:1 상담받으시는 거 어떨까요?
>
> ⚠️ 자살 / 자해 위험 시 즉시 000 또는 Lifeline 13 11 14!"

---

## ⚠️ 함정 6개

1. ❌ "정신과 = 부끄러움" → ✅ 호주 = 일반 진료
2. ❌ "Psychologist = 약 처방" → ✅ Psychologist 약 처방 X
3. ❌ "OSHC 정신과 100%" → ✅ 부분 환급
4. ❌ "한국어 상담 X" → ✅ 시드니 / 멜번 일부 가능
5. ❌ "응급 = 응급실 직접" → ✅ 자살 위험 = 000 / Lifeline 우선
6. ❌ "GP 정신과 약 모두" → ✅ 강한 약 = Psychiatrist

---

## 📞 필수 4가지 확인

1. ✅ 응급도 (자살 / 자해 위험 시 즉시)
2. ✅ MHCP / Psychologist / Psychiatrist 차이
3. ✅ OSHC 환급 안내
4. ✅ 한국어 상담사 / 학교 카운슬러 안내

---

## 🔍 직원 사이트

- **Beyond Blue**: https://www.beyondblue.org.au
- **Lifeline**: https://www.lifeline.org.au
- **Headspace**: https://headspace.org.au
- **Psychology Today**: https://www.psychologytoday.com/au

---

## 🚨 직원 vs 윌슨 vs 의사 vs 응급

**직원**: 정신과 시스템 일반 안내 / 응급 즉시 안내
**윌슨**: 한국어 상담사 매칭 / 학교 카운슬러
**GP / Psychologist / Psychiatrist**: 진료 / 처방
**응급**: 000 / Lifeline 13 11 14

---

## ✅ 체크리스트

- [ ] 응급도 (자살 / 자해) 즉시 확인
- [ ] MHCP / Psychologist / Psychiatrist 차이 설명
- [ ] OSHC 환급 안내
- [ ] Lifeline / Beyond Blue 안내
- [ ] 한국어 상담사 / 학교 카운슬러 매칭
- [ ] 카카오톡 1:1 상담 연결
