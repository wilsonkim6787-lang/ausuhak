# #383 호주_학생_학교_변경_Course_Transfer_6개월_Release_Letter

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니 디플로마 다니는데 학교가 너무 별로예요. 다른 학교로 옮길 수 있어요?"

**직원 멘붕 포인트:**
- 6개월 룰 (Standard 7 ESOS)
- Release Letter 학교 거부 가능
- AQF 동급 코스만 변경 가능
- 비자 동일 (Subclass 500 유지)
- Course Transfer vs Course Change 차이

---

## ❌ 절대 하지 말아야 할 답

> "언제든 자유롭게 학교 옮길 수 있어요."

→ ❌ ESOS Act Standard 7 = 본 코스 시작 후 6개월 내 = 학교 변경 시 Release Letter 의무. 6개월 후 = 자유롭게 변경. Release Letter는 학교 거부 가능.

---

## ✅ 정답

**학교 변경(Course Transfer) 가이드** (2026):

**6개월 룰 (Standard 7 ESOS)**:
- 본 코스 시작 후 6개월 내 = Release Letter 의무
- 본 코스 시작 후 6개월 후 = 자유롭게 변경 가능
- ELICOS/Foundation 기간은 6개월에 미포함
- 본 Course (Diploma/Bachelor 등) 시작일부터 카운트

**Release Letter란?**:
- 현 학교가 발급 (학생이 다른 학교로 옮김 허용 문서)
- 무료 (수수료 X 표준)
- 학교 거부 가능 (사유 명시 의무)

**Release Letter 발급 가능 사유**:
- 학생 본인 요청 + 적절한 이유
- 학교 코스 변경 (학과 폐지)
- 학교 도산/위기
- 학생 가정 사정 (가족 위급)

**Release Letter 거부 가능 사유**:
- 학비 미납 (전 학기 미지불)
- Academic Misconduct (표절/시험 부정)
- 학교 평판 손상 우려
- 학생 행동 부적절
- 단순 변덕 = 거부 가능

**Release Letter 거부 시 학생 옵션**:
1. Internal Appeal (학교 내부 항소)
2. Commonwealth Ombudsman 신고 (무료)
3. 6개월 완료 후 자유 변경

**Course Transfer 절차**:
1. 새 학교 입학 신청 + Conditional Offer 받음
2. 현 학교에 Release Letter 신청 (서면)
3. 학교 결정 (1~2주)
4. Release Letter 받음 → 새 학교에 제출
5. 새 학교 COE 발급 → PRISMS 통보 → 비자 자동 변경

**AQF 동급 또는 상위 코스만 변경 가능**:
- Diploma → Diploma OK
- Diploma → Advanced Diploma OK
- Diploma → Bachelor OK
- Bachelor → Diploma X (하향, GTE 위반)
- Master → Bachelor X

**Course Transfer vs Course Change**:
- **Transfer**: 학교 변경 (같은 또는 다른 코스)
- **Change**: 같은 학교 내 코스 변경

**학비 환불**:
- Refund Policy 학교별 (등록 시 약관)
- 6개월 내 변경 = 환불율 50~80%
- 6개월 후 변경 = 환불율 20~50%
- 일부 학교 = 환불 불가 (Non-Refundable)

**비자 영향**:
- AQF 동급/상위 + 적절한 Transfer = 비자 영향 X
- AQF 하향 = GTE 위반 → 비자 거절
- ELICOS만 변경 = 영향 X

**Release Letter 거부 우회 (6개월 룰)**:
- 6개월 완료 = Release Letter 불필요
- 새 학교 COE → 현 학교 자동 통보 → 비자 변경
- 현 학교 동의 X 합법

**한국 학생 자주 사례**:
- 사립 디플로마 → 정부 TAFE 변경 (학비/품질)
- ELICOS A → ELICOS B 변경 (자유)
- Bachelor 1년 차 → 다른 대학 Bachelor (Credit Transfer)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. ESOS Act Standard 7**
Course Transfer 룰

**2. Commonwealth Ombudsman**
ombudsman.gov.au - 학교 분쟁

**3. AQF Framework**
aqf.edu.au - 학위 등급

**4. PRISMS DOHA**
학교 → DOHA 통보

**5. 각 학교 Refund Policy**
등록 약관 확인

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1. 본 코스 시작 후 6개월 경과 여부 확인
**2단계**: 2. 새 학교 입학 신청 + Conditional Offer
**3단계**: 3. 6개월 내 = 현 학교 Release Letter 신청
**4단계**: 4. 6개월 후 = Release Letter 불필요, 새 COE만
**5단계**: 5. 새 학교 COE → 비자 자동 변경

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 학교 변경 답변드립니다.

본 코스(Diploma) 시작 후 6개월 경과했는지가 핵심입니다. 6개월 룰(ESOS Act Standard 7)이 적용됩니다.

**6개월 내 변경**: 현 학교 Release Letter 의무. 학교가 거부할 수 있고(학비 미납, 평판 등), 거부 시 Commonwealth Ombudsman 무료 신고 가능합니다.

**6개월 후 변경**: 자유롭게 변경 가능. Release Letter 불필요. 새 학교 COE 받으면 PRISMS 통해 자동 처리됩니다.

새 코스는 AQF 동급 또는 상위만 가능합니다. Diploma → Diploma/Advanced Diploma/Bachelor OK이지만, Bachelor → Diploma는 GTE 위반으로 비자 거절됩니다.

학비 환불은 학교별 Refund Policy에 따라 다릅니다. 6개월 내 = 50~80% 환불 가능, 6개월 후 = 20~50% 환불 표준입니다. 일부 학교는 환불 불가입니다.

추가 안내 필요하시면 카카오 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **언제든 자유 변경 권유**
   → 6개월 룰 의무. 미준수 = 비자 위험.

2. **Release Letter 자동 발급 인식**
   → 학교 거부 가능.

3. **AQF 하향 변경 권유**
   → GTE 위반. 비자 거절.

4. **학비 환불 100% 인식**
   → Refund Policy 학교별. 50~80% 표준.

5. **ELICOS 6개월 포함 인식**
   → 본 Course 시작일부터. ELICOS 미포함.

6. **Release Letter 수수료 권유**
   → 무료 표준. 수수료 = 부당.

7. **Ombudsman 한국어 가능 인식**
   → 영어만. 통역 별도.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 본 코스 시작 후 6개월 경과?
2. 현 학교 학비 미납 여부?
3. 새 학교 코스 = AQF 동급/상위?
4. Release Letter 거부 우려?

---

## 🔍 직원이 직접 확인 가능한 사이트

- esos.gov.au (학생비자법)
- ombudsman.gov.au (분쟁)
- aqf.edu.au (학위)
- 각 학교 Refund Policy

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Course Transfer 가이드 + Release Letter 작성 + 새 학교 매칭

**MARA / 변호사 영역**
- Release Letter 분쟁 + 비자 영향 = MARA Agent.

---

## ✅ 완벽 응대 체크리스트

- [ ] 6개월 룰 정확 안내
- [ ] Release Letter 거부 가능성
- [ ] AQF 동급/상위만
- [ ] 환불 정책 학교별
- [ ] Ombudsman 항소 옵션
- [ ] 카카오 상담 신청 유도
