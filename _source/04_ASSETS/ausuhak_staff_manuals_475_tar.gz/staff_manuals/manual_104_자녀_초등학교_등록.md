# 📚 직원 응대 매뉴얼 #104

**케이스: 35세 / 멜번 Master 1학년 / "남편이랑 같이 왔는데 7살, 9살 자녀 호주 초등학교 어떻게 등록해요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 멜번에서 Master of Public Health 1학년이에요. 가족 동반 비자로 남편이랑 7살, 9살 자녀랑 같이 왔어요. 자녀 학교 등록 어떻게 해요? 학비 무료인가요? 어디 학교 좋아요? 영어 못하는데 괜찮아요?

**👉 직원이 멘붕하는 순간**
- "부모 학생비자 = 자녀 학비 무료?"
- "공립 vs 사립?"
- "Catchment area?"
- "영어 못함 = 어떻게?"
- "학년 배정?"

**❌ 절대 하지 말아야 할 답**
- "공립 무료에요" → **부분 사실. 일부 주만**
- "어디든 되요" → **거짓**
- "사립 가야 안전" → **거짓**

**✅ 직원이 알아야 할 정답**
호주 자녀 학교 = **주별 정책 다름**. VIC = 학생비자 자녀 = **유료 일부**:

1. **VIC** = 부모 Master/PhD = **자녀 공립 무료** (특정 조건)
2. **VIC** = 부모 Bachelor/Diploma = 공립 **유료** ($16,000~22,000/년)
3. **NSW** = 일부 주 다른 정책
4. **공립 = Catchment Area** (학구)
5. **영어 못함 = EAL (English as Additional Language)** 지원
6. **학년 배정 = 나이 기준**
7. **사립 = $20,000~50,000/년** (자유)

직원 = **주/비자별 정책** 안내. 윌슨 = **학교 매칭**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ VIC 학생비자 자녀 학비 정책

**답**: VIC = 부모 학위 따라 자녀 학비 다름.

**VIC International Student Program (Government Schools)**:

**무료 (Fee-Exempt)**:
- 부모 = **Master / PhD** by **Coursework or Research**
- 부모 = 호주 정부 장학금 (DFAT, Australia Awards)
- 부모 = TAFE 교사 등 정부 후원

**유료 (Full Fee)**:
- 부모 = Bachelor 또는 Diploma
- 부모 = 일반 ELICOS / TAFE Diploma
- 학비:
  - Primary (Year 1~6): $16,000~18,000/년
  - Secondary (Year 7~12): $18,000~22,000/년

**학교 신청**:
- VIC International Student Program 사이트
- 또는 Department of Education 직접

**서류**:
- 부모 학생비자
- 부모 CoE (대학원 코스)
- 자녀 출생 증명 (영문)
- 자녀 백신 접종 (호주 기준)
- 영어 평가 (EAL)

**출처**: study.vic.gov.au, education.vic.gov.au

---

### 2️⃣ NSW 학생비자 자녀 학비 정책

**답**: NSW = VIC와 다름. **유료가 일반**.

**NSW Department of Education (Public Schools)**:

**유료 (Tuition Fees)**:
- 학생비자 부모의 자녀 = **유료**
- 학비:
  - Primary (K~6): $13,000~15,000/년
  - Secondary (7~12): $16,000~18,000/년

**예외 (무료 가능)**:
- 부모 = 호주 정부 장학금 (DFAT)
- 부모 = NSW TAFE 등 일부 정부 후원
- 일부 PhD = 무료 (학교/학과별)

**학교 신청**:
- DET International (NSW)
- nswisp.com.au

**서류**:
- 부모 학생비자 + CoE
- 자녀 출생 증명
- 자녀 백신 접종
- 영어 평가

**출처**: nswisp.com.au, education.nsw.gov.au

---

### 3️⃣ Catchment Area (학구) + 학교 선택

**답**: 호주 공립 = **Catchment Area** (집 주소 기준 학구). 사립 = 자유.

**Catchment Area**:
- 공립 학교 = 집 주소 = 학구 학교 우선
- 학구 외 = 자리 있을 시 가능
- 한국 = "8학군" 비슷
- 좋은 학교 = 좋은 동네 = 집값/렌트 비쌈

**Catchment 확인**:
- VIC: findmyschool.vic.gov.au
- NSW: schoolcatchments.com.au

**좋은 학교 동네 (예)**:

**멜번 (VIC)**:
- Glen Waverley = 한인 많음 + 좋은 학교
- Box Hill = 동양인 많음 + 좋은 학교
- Doncaster = 한인 + 좋은 학교
- Balwyn = 부유 + 좋은 학교
- Brighton = 비싸지만 우수

**시드니 (NSW)**:
- Chatswood = 한인 + 좋은 학교
- Eastwood = 한인 많음
- Epping = 한인 + 좋은 학교
- Hornsby = 우수 학교
- Strathfield = 한인 + 좋은 학교

**사립 학교**:
- 자유 입학 (Catchment X)
- 시험 + 인터뷰
- $20,000~50,000/년
- 예: Scotch College, MLC, Caulfield Grammar

**학년 배정**:
- 호주 = 1월~12월 학년
- 한국 = 3월~2월
- 자녀 나이 기준 배정 (한국 학년 X)
- 예: 만 7세 = Year 2, 만 9세 = Year 4

**출처**: findmyschool.vic.gov.au, education.nsw.gov.au

---

### 4️⃣ EAL (영어 부족 자녀 지원)

**답**: 영어 못 하는 자녀 = **EAL** (English as Additional Language) 지원.

**EAL 지원**:
- 호주 모든 공립/사립 학교 = EAL 프로그램
- 일반 수업 + 별도 영어 수업
- 무료 (공립 학생 = 무료, 학비 별도 X)

**EAL 단계**:
- Beginner (영어 0)
- Intermediate (기초)
- Advanced (일반 수업 가능)

**EAL 기간**:
- 평균 1~2년
- 어린 자녀 (5~7세) = 빠름 (6개월~1년)
- 큰 자녀 (10세+) = 더 오래

**English Language School (Intensive)**:
- VIC = English Language School (별도)
- NSW = Intensive English Centre (IEC)
- 6개월~1년 영어 집중 → 일반 학교 전학

**일반 학교 EAL Specialist**:
- 학교 내 EAL 교사
- 일반 수업 + 별도 영어 (주 3~5회)

**한국 학생 EAL 경험**:
- 호주 = 다민족 = EAL 일반적
- 7세 = 1년 후 또래 수준
- 9세 = 1.5~2년 후 또래 수준

**출처**: education.vic.gov.au, det.nsw.edu.au

---

### 5️⃣ 호주 학교 시스템 (학년/학기)

**답**: 호주 = **K~12** 시스템. 학년 = 나이 기준.

**호주 학교 시스템**:

**Primary School (Year K~6)**:
- Kindergarten (Prep, Foundation): 만 5세
- Year 1: 만 6세
- Year 2: 만 7세
- ... Year 6: 만 11세

**Secondary School (Year 7~12)**:
- Year 7: 만 12세
- Year 12: 만 17세 (졸업)

**한국 학년 → 호주 학년 환산**:
- 한국 초1 (만 7세) = 호주 Year 2
- 한국 초3 (만 9세) = 호주 Year 4
- 한국 중1 (만 13세) = 호주 Year 8
- 한국 고1 (만 16세) = 호주 Year 11

**학기**:
- Term 1: 1월~3월
- Term 2: 4월~6월 (3주 방학)
- Term 3: 7월~9월 (2주 방학)
- Term 4: 10월~12월 (6주 방학)

**한국 → 호주 도착 시점**:
- 1월 = Term 1 시작 (이상적)
- 7월 = Term 3 시작 (괜찮음)
- 학기 중 = OK (자리 있을 시)

**교복**:
- 공립 = 교복 ($100~300, 본인 구입)
- 사립 = 교복 ($300~800)
- 운동복 + 일반복 + 정복

**책/문구**:
- Booklist (학교 발급) = $300~600/년
- 한국식 무상 교과서 X

**점심**:
- 본인 가져옴 (도시락)
- 학교 매점 = 자비
- 일부 학교 = 학교 점심 ($5~10/일)

**출처**: 각 주 교육부

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 부모 학위 + 비자 확인
- Master of Public Health = **VIC 자녀 공립 무료** 자격
- 코스 = Coursework or Research?
- 둘 다 OK (VIC)

### Step 2: 거주지 결정
- 멜번 어디 살 예정?
- 좋은 학교 = Glen Waverley, Box Hill, Doncaster, Balwyn
- Catchment Area 확인 = findmyschool.vic.gov.au

### Step 3: 학년 배정
- 7세 → **Year 2**
- 9세 → **Year 4**
- 한국 학년 무관

### Step 4: 학교 신청
- VIC International Student Program 등록
- study.vic.gov.au
- Master 부모 = **무료** 적용 신청

### Step 5: 영어 평가 (EAL)
- 자녀 영어 평가
- 학교 EAL 또는 English Language School
- 멜번 = Noble Park English Language School 등

### Step 6: 서류 준비
- 부모 학생비자 (PDF)
- 부모 CoE (Master of Public Health)
- 자녀 출생 증명 (영문 NAATI 번역)
- 자녀 백신 접종 기록 (호주 기준 확인)
- 자녀 한국 학교 성적표 (영문 번역)

### Step 7: 학교 인터뷰
- 자녀 학교 방문
- 교복 / 책 / 점심 정보
- 첫 등교일 확인

### Step 8: 한국과 다른 점 안내
- 호주 = 한국식 학원 X (체육/예술 중심)
- After-school = 자율 (Day Care 별도)
- Term Holiday 관리

---

## 💡 직원이 학생한테 말할 멘트

**[카카오톡 답장 멘트]**

> 가족 동반 멜번 = 좋은 결정이세요! 자녀 학교 안내드릴게요.
>
> **🟢 학비 무료 자격**:
> - VIC + 부모 = **Master / PhD** = **공립 자녀 학비 무료**
> - Master of Public Health = **자격 있음**
> - Coursework / Research 둘 다 OK
>
> 만약 부모가 Bachelor/Diploma였으면 = 유료 ($16,000~22,000/년)였을 텐데, **Master = 무료**로 큰 혜택입니다.
>
> **🎂 학년 배정 (나이 기준)**:
> - 7세 → **Year 2**
> - 9세 → **Year 4**
> - 한국 학년 무관, 호주 1~12월 기준
>
> **🏠 거주지 결정 = 학교 결정**:
> 호주 공립 = **Catchment Area** (집 주소 학구)
>
> **멜번 한인 + 좋은 학교**:
> - **Glen Waverley** = 한인 많음 + 우수 학교
> - **Box Hill** = 아시안 많음 + 우수 학교
> - **Doncaster** = 한인 + 우수
> - **Balwyn** = 부유 + 우수 (집세 비쌈)
>
> 학교 검색: **findmyschool.vic.gov.au**
>
> **📝 학교 신청**:
> 1. **study.vic.gov.au** (VIC International Student Program)
> 2. **VIC Master 부모 = 무료 신청**
> 3. 서류 = 부모 비자 + CoE + 자녀 출생 증명 + 백신 + 한국 성적표
>
> **🌐 영어 못해도 OK = EAL 프로그램**:
> - 호주 모든 학교 = EAL 지원
> - 일반 수업 + 별도 영어 수업
> - 7세 = 1년 후 또래 수준
> - 9세 = 1.5~2년
>
> **English Language School** (별도, 6개월~1년):
> - 멜번: Noble Park, Blackburn 등
> - 영어 집중 → 일반 학교 전학
> - 처음 도착 = 권장
>
> **📚 한국과 다른 점**:
> - 교복 본인 구입 ($100~300)
> - Booklist (책) $300~600/년
> - 도시락 (학교 매점 X 권장)
> - 학원 X = 체육/예술 우선
> - 1~12월 학년 (한국 3~2월 X)
>
> **📋 서류 준비**:
> 1. 부모 학생비자 PDF
> 2. 부모 CoE (Master of Public Health)
> 3. 자녀 출생 증명 (영문 **NAATI** 번역)
> 4. 자녀 백신 접종 기록 (호주 기준 확인)
> 5. 자녀 한국 학교 성적표 (영문 번역)
> 6. 자녀 여권
>
> **📅 시점**:
> - 호주 학기 = 1월 / 4월 / 7월 / 10월
> - 1월 = Term 1 시작 (이상적)
> - 학기 중 = OK (자리 있을 시)
>
> 윌슨이 학교 매칭 + 신청 도와드릴 수 있어요. 거주 예정 동네 정해지면 카카오로 알려주세요.
>
> 카카오 ID: studywilson

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "VIC + Bachelor도 무료"
- **사실**: VIC + Bachelor/Diploma = **유료**. Master/PhD만 무료
- **올바른 안내**: "VIC = Master/PhD만 무료"

### 함정 2: "NSW도 똑같이 무료"
- **사실**: NSW = 거의 유료 (예외 = DFAT 장학금)
- **올바른 안내**: "NSW = 유료 일반"

### 함정 3: "한국 학년 그대로"
- **사실**: 호주 = 나이 기준 (7세 = Year 2)
- **올바른 안내**: "한국 학년 X. 나이 기준"

### 함정 4: "학교 어디든 등록"
- **사실**: 공립 = Catchment Area
- **올바른 안내**: "집 주소 = 학구. 좋은 학교 = 좋은 동네"

### 함정 5: "영어 못하면 못 가요"
- **사실**: EAL 지원 = 모든 학교
- **올바른 안내**: "EAL 프로그램. 1~2년 후 또래 수준"

### 함정 6: "사립 = 항상 좋아"
- **사실**: 좋은 공립 = 사립과 비슷. 동네 따라
- **올바른 안내**: "공립 학구 좋은 곳 = 사립과 비슷, 무료"

### 함정 7: "한국 학교 성적 = 자동 인정"
- **사실**: 영문 번역 + 학년 환산
- **올바른 안내**: "영문 번역 + 호주 학년 배정"

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 부모 학위
- Master / PhD? = VIC 무료
- Bachelor / Diploma? = 유료
- → 학비 정책 다름

### 2. 거주 주
- VIC / NSW / QLD?
- → 학비 정책 다름

### 3. 자녀 나이 / 영어
- 만 5세 미만 = 유아원
- 만 5~17세 = 학교
- 영어 수준?
- → EAL / 학년 배정

### 4. 거주 동네
- 정해졌나?
- 한인 동네 선호?
- → Catchment + 학교 매칭

**4가지 확인 후 → 본인의 영역(공식 정책 + 학년 배정) → 윌슨 영역(학교 매칭)**

---

## 🔍 직원이 직접 확인 가능한 사이트

### VIC
- study.vic.gov.au (International Student Program)
- education.vic.gov.au
- findmyschool.vic.gov.au (Catchment 확인)

### NSW
- nswisp.com.au (International Student Program)
- education.nsw.gov.au
- schoolcatchments.com.au

### QLD
- eqi.com.au (International)
- qed.qld.gov.au

### 백신 정보
- immunisationhandbook.health.gov.au

### 사립 학교
- isaa.com.au (Independent Schools)

**확인 사항**: 위 사이트 = 정부 공식.

---

## 🚨 직원 영역 vs 변호사/MARA 영역

### 직원 영역 (이 매뉴얼 활용)
- ✅ 주별 자녀 학비 정책
- ✅ 학년 배정 (나이 기준)
- ✅ Catchment Area 안내
- ✅ EAL 프로그램 안내
- ✅ 학교 신청 절차
- ✅ 서류 준비

### 윌슨 직접 처리 영역
- ⚠️ 거주지 + 학교 매칭
- ⚠️ 학교 직접 컨택
- ⚠️ NAATI 번역 연결
- ⚠️ 한국 학교 성적 번역 도움

### 학교 영역 (직원 X)
- ❌ 학교 입학 결정 (학교)
- ❌ EAL 단계 평가 (학교)

### MARA 영역 (직원 X)
- ❌ 가족 비자 변경
- ❌ 자녀 비자 별도 신청

**원칙**: 직원 = **공식 정책**. 매칭 = **윌슨**.

---

## ✅ 완벽 응대 체크리스트

응대 끝나기 전 이 체크리스트 확인:

- [ ] **부모 학위** (Master = VIC 무료) 확인했나?
- [ ] **VIC vs NSW** 학비 차이 안내했나?
- [ ] 자녀 **학년 배정** (나이 기준) 안내했나?
- [ ] **Catchment Area** (학구) 개념 설명했나?
- [ ] findmyschool.vic.gov.au 안내했나?
- [ ] 한인 동네 (Glen Waverley, Box Hill 등) 안내했나?
- [ ] **EAL 프로그램** 안내했나?
- [ ] English Language School (집중) 안내했나?
- [ ] 학교 신청 사이트 (study.vic.gov.au) 안내했나?
- [ ] 서류 (부모 비자/CoE/출생증명/백신/성적표) 안내했나?
- [ ] **NAATI 번역** 강조했나?
- [ ] 호주 학기 (1/4/7/10월) 안내했나?
- [ ] 한국 vs 호주 학교 차이 (교복/책/도시락) 안내했나?
- [ ] **윌슨 학교 매칭** 가능 안내했나?
- [ ] "어디든 OK" 같은 부정확 답변 안 했나?

**핵심**: VIC + Master = **자녀 공립 무료**. 학년 = 나이 기준. Catchment Area + 영어 EAL. 윌슨 = 학교 매칭.

---

**작성**: ausuhak.com 직원 교육 시스템 v1.0
**기준일**: 2026-05-04
**참고**: study.vic.gov.au, nswisp.com.au, findmyschool.vic.gov.au
**다음 매뉴얼**: #105 호주 의료 시스템 (Medicare / GP)
