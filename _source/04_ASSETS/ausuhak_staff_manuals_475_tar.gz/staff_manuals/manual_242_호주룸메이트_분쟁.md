# #242 호주 룸메이트 분쟁

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 셰어하우스 룸메이트가 청소 안 하고 시끄럽고 임대료도 안 내요. Bond 못 받을까봐 걱정돼요. 어떻게 해야 하나요?"

**직원 멘붕 포인트:**
- Head Tenant vs Sub-Tenant 권리 차이
- Bond 분담 = Property Manager 또는 Head Tenant
- 분쟁 = NCAT (NSW) / VCAT (VIC)

---

## ❌ 절대 하지 말아야 할 답

> "참으세요. 호주는 룸메이트 자유예요."

→ ❌ **본인 권리 보호 가능**. 계약 / 증거 / NCAT 활용.

---

## ✅ 정답

호주 룸메이트 분쟁: ① **계약 형태 확인**: Head Tenant (Lease 본인) vs Sub-Tenant (Head Tenant에게 임대) ② **Sub-Lease 합법성**: Property Manager 사전 승인 필수 (미승인 = Lease 위반) ③ **분담 합의서 (House Agreement)**: 임대료 / 청소 / 공과금 분담 서면 (분쟁 시 증거) ④ **Bond 분담**: 룸메이트별 Bond 분담 → 정부 보관 (단, Head Tenant 명의면 본인이 분담 청구) ⑤ **분쟁 해결**: NSW Fair Trading / NCAT (Tribunal) ⑥ **즉시 위험 (폭력/도난)**: 000 / 경찰. ⑦ **윌슨 영역 X** (Tenants' Union / NCAT 영역).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Head Tenant vs Sub-Tenant**
- **Head Tenant**: Lease에 본인 이름 = Property Manager와 직접 계약
- **Sub-Tenant**: Head Tenant에게 재임대 = Head Tenant가 임대인
- 본인이 Sub-Tenant면 Head Tenant가 분쟁 처리

**2. Sub-Lease 합법성**
- Property Manager 사전 승인 필수 (Lease 조항)
- 미승인 = Lease 위반 = Head Tenant 책임
- 한국 학생 = 무단 Sub-Lease 빈번 (위반 인지 X)

**3. House Agreement (분담 합의서)**
- 임대료 / 공과금 / 청소 / 손님 / Quiet Hours 서면
- 분쟁 시 증거
- 양식: NSW Fair Trading 무료 다운로드

**4. Bond 분담**
- Bond는 정부 보관 (Rental Bond Board)
- 룸메이트별 분담 = 명의 1명 또는 분할 등록
- 청소 / 손상 책임 = 분담 합의서에 따라

**5. 즉시 위험 vs 일반 분쟁**
- **즉시 위험 (폭력 / 도난 / 협박)**: 000
- **일반 분쟁 (임대료 / 청소)**: NCAT
- **중간 (괴롭힘 / 차별)**: NSW Anti-Discrimination Board

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 즉시 안전 확인 (위험 시 000)
**2단계**: 계약 형태 파악 (Head / Sub-Tenant)
**3단계**: 증거 수집 (메시지 / 사진 / 임대료 미납 영수증)
**4단계**: 직접 대화 시도 (서면 권장)
**5단계**: Property Manager 알림 (Head Tenant 권한)
**6단계**: NCAT 신청 ($55) 또는 Tenants' Union 무료 상담

---

## 💡 직원이 학생한테 말할 멘트

> "윌슨님께 이렇게 전달드릴게요:
> 
> '먼저 즉시 위험 (폭력/협박)이면 000 (경찰)이에요. 일반 분쟁은 본인이 Head Tenant (Lease 본인)인지 Sub-Tenant (Head Tenant에게 임대)인지 확인이 우선이에요. House Agreement (분담 합의서) 서면이 있으면 분쟁 해결에 결정적이에요. 임대료 미납은 메시지 / 영수증 / 은행 거래 내역 증거 수집이 중요해요. NSW = NCAT (Tribunal) 신청 $55, VIC = VCAT이에요. NSW Tenants\' Union 무료 상담 가능해요. 룸메이트 분쟁은 윌슨 영역이 아니에요. Tenants\' Union / NCAT 영역이에요.'"

---

## ⚠️ 직원이 헷갈리기 쉬운 함정 7개

1. **참아야 함**: ❌ 본인 권리 보호 가능
2. **Sub-Lease 자유**: ❌ Property Manager 승인 필수
3. **House Agreement 선택**: ❌ 분쟁 시 증거 결정적
4. **Bond Property Manager 임의 분배**: ❌ 정부 보관 / 합의 필수
5. **즉시 NCAT**: ❌ 직접 대화 → Tenants' Union → NCAT 순서
6. **NCAT 변호사**: ❌ 본인 가능 (변호사 X)
7. **윌슨 처리**: ❌ Tenants' Union 영역

---

## 📞 카카오 응대 시 필수 4가지 확인

1. **즉시 위험 여부**: 000 우선
2. **계약 형태**: Head / Sub-Tenant
3. **분쟁 종류**: 임대료 / 청소 / 소음 / 폭력
4. **증거 보유**: 서면 / 메시지 / 영수증

---

## 🔍 직원이 직접 확인 가능한 사이트

- **NSW Tenants' Union**: https://www.tenants.org.au
- **NCAT (NSW)**: https://www.ncat.nsw.gov.au
- **VIC Tenants Victoria**: https://tenantsvic.org.au
- **VCAT (VIC)**: https://www.vcat.vic.gov.au
- **NSW Fair Trading**: https://www.fairtrading.nsw.gov.au

---

## 🚨 직원 영역 vs Tenants' Union / NCAT / 경찰 영역

| 영역 | 직원 가능 | 외부 영역 |
|------|----------|--------|
| 즉시 위험 안내 (000) | ✅ | - |
| 계약 형태 차이 안내 | ✅ | - |
| House Agreement 권장 | ✅ | - |
| 분쟁 처리 | ❌ | ✅ Tenants' Union |
| NCAT 신청 | ❌ | ✅ 본인 또는 Tenants' Union |
| 폭력 / 협박 | ❌ | ✅ 경찰 (000) |

---

## ✅ 완벽 응대 체크리스트

- [ ] 즉시 위험 시 000 안내
- [ ] Head / Sub-Tenant 차이 안내
- [ ] House Agreement 권장
- [ ] 증거 수집 강조
- [ ] NSW Tenants' Union 무료 상담 안내
- [ ] NCAT $55 안내
- [ ] 윌슨 = 유학 / Tenants' Union 영역 분리
