# #309 호주_학교_학과_변경_Course_Change

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 호주 대학 IT 학과 다니는데 너무 어려워서 회계학과로 바꾸고 싶어요. 비자도 다시 받아야 하나요?"

**직원 멘붕 포인트:**
- 학과 변경 시 학교 내 (같은 AQF) vs 다른 학교 차이 큼
- ELICOS/Foundation/Diploma = AQF 변경 시 비자 새로 받기
- Bachelor 내 학과 변경 = 일반적으로 비자 OK
- 학과 변경 시 GTE (Genuine Temporary Entrant) 재평가
- 직원이 잘못 답하면 학생 비자 위반 + 학습 시간 낭비

---

## ❌ 절대 하지 말아야 할 답

> "학교만 그대로면 학과 자유롭게 바꿔도 비자에 영향 없어요."

→ ❌ 학교 내 학과 변경 = 같은 AQF Level (Bachelor → Bachelor) = 일반적으로 비자 OK. 단, AQF Level 변경 (Bachelor → Diploma 다운그레이드) = Section 8202 비자 조건 위반 가능 = DHA 신고 + 비자 새로 받기.

---

## ✅ 정답

**학과 변경 = 4가지 시나리오**

**시나리오 1: 같은 학교 + 같은 AQF Level**
- 예: Bachelor of IT → Bachelor of Accounting (같은 학교)
- 비자 영향: 일반적으로 OK
- 단, 학교 내 절차 (학과 신청 + 승인)
- 새 CoE 발급 → 학교가 PRISMS 통해 DHA 통보

**시나리오 2: 다른 학교 + 같은 AQF Level**
- 예: A 대학 Bachelor → B 대학 Bachelor
- 새 학교 입학 + 새 CoE
- 학생비자 6개월 규정: 학생비자 시작 후 6개월 이내 학교 변경 = 학교 동의 (Release Letter) 필요
- 6개월 이후 = 자유 (Release Letter 불필요)

**시나리오 3: AQF Level 변경 (다운그레이드)**
- 예: Bachelor → Diploma → Certificate
- Section 8202 비자 조건 위반 가능
- DHA 신고 + 새 비자 신청 (저학위)
- 비자 새로 받아야 가능

**시나리오 4: AQF Level 업그레이드**
- 예: Diploma → Bachelor → Master
- 일반적으로 OK (학습 의지 인정)
- 단, 새 CoE + 학생비자 기간 충분 확인

**Section 8202 (비자 조건):**
- 학생 = 학생비자에 등록된 코스/AQF 유지 의무
- 변경 시 새 비자 신청 또는 학교 신고 의무
- 위반 = 비자 취소 가능

**6개월 Release Letter Rule:**
- 학생비자 시작 후 6개월 이내 = 학교 변경 시 Release Letter 필수
- 6개월 이후 = Release Letter 불필요
- ELICOS 1:1 코스 등 일부 예외

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. AQF Level (Australian Qualifications Framework)**
Cert I~IV (Level 1-4), Diploma (5), Advanced Diploma (6), Bachelor (7), Master (9), PhD (10).

**2. 학생비자 Section 8202**
학생비자 등록된 코스 유지 의무. 변경 시 신고 + 새 비자.

**3. CoE (Confirmation of Enrolment)**
학교가 발급, PRISMS 등록, DHA 통보. 학과 변경 시 새 CoE.

**4. 6개월 Release Letter Rule**
학생비자 시작 후 6개월 이내 = 학교 변경 시 Release Letter 필요.

**5. GTE 재평가**
학과 변경 시 GTE (Genuine Temporary Entrant) 재평가. 변경 합리성 입증.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: **현재 학과 + 변경 학과 AQF Level 확인** - 같은 Level인지/업그레이드/다운그레이드
**2단계**: **학교 + 학과 결정** - 학교 내 변경 / 다른 학교 변경
**3단계**: **학교 신청** - 새 학과 입학 신청 + 학교 내 학점 인정 가능
**4단계**: **Release Letter 확인** - 6개월 이내 다른 학교 변경 시 = 현 학교 Release Letter
**5단계**: **비자 영향 확인** - 같은 AQF = 일반 OK / 다운그레이드 = 새 비자 신청

---

## 💡 직원이 학생한테 말할 멘트

> "학과 변경은 1) 같은 학교 같은 AQF (Bachelor → Bachelor) = 일반 OK / 2) 다른 학교 같은 AQF + 6개월 이내 = Release Letter 필요 / 3) AQF 다운그레이드 (Bachelor → Diploma) = 비자 새로 받기 / 4) 업그레이드 = 일반 OK 입니다. IT → 회계 (같은 Bachelor) = 같은 학교 내 학과 변경이면 비자 영향 적습니다. 정확한 절차는 학교 학과 사무실 + 윌슨 상담 권장합니다. 카톡 답장 부탁드립니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학과 변경 = 비자 새로**
   → 같은 AQF = 보통 비자 영향 X. 학교 내 학과 변경 = 가장 간단.

2. **6개월 Release Letter = 의미 없는 절차**
   → 위반 = 비자 취소 가능. 매우 중요한 규정.

3. **AQF 다운그레이드 = 학교만 신경**
   → 비자 조건 8202 위반. DHA 통보 + 새 비자 필수.

4. **학교 변경 = 학생비자 자동 종료**
   → 학생비자 = 학교 변경해도 유지. 단, 6개월 이내 = Release Letter.

5. **학과 변경 시 학점 인정 자동**
   → 학교마다 학점 인정 다름. 사무실 직접 확인. 자동 X.

6. **ELICOS → Bachelor 변경 = 비자 OK**
   → Package Visa (ELICOS + Bachelor) = OK. 별도 ELICOS만이면 = 새 비자 + 새 CoE.

7. **학과 변경 = OSHC 자동 연장**
   → OSHC = 본인이 갱신. 학과 변경과 무관. 기간 만료 시 새 가입.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 코스 + AQF Level (Bachelor / Diploma / Master 등)
2. 변경 희망 코스 + AQF Level
3. 현재 학교 + 변경 희망 학교 (같은/다른)
4. 학생비자 시작 시점 (6개월 이내/이후)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Section 8202 비자 조건: immi.homeaffairs.gov.au
- AQF: www.aqf.edu.au
- PRISMS: prisms.education.gov.au
- ESOS Act: www.education.gov.au
- Release Letter 안내: 각 학교 International Office

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 학과 변경 일반 절차 안내
- AQF Level별 비자 영향 설명
- 윌슨 950명 동문 학과 변경 사례

**MARA / 변호사 영역**
- AQF 다운그레이드 + 비자 새로 = MARA
- 학과 변경 후 비자 거절 = MARA 항소
- Release Letter 거부 분쟁 = ESOS Act 법적 절차
- GTE 재평가 어려움 = MARA

---

## ✅ 완벽 응대 체크리스트

- [ ] AQF Level 4가지 시나리오 정확히 설명함
- [ ] 같은 학교 vs 다른 학교 차이 설명함
- [ ] 6개월 Release Letter Rule 강조함
- [ ] 다운그레이드 = 새 비자 필수 정정함
- [ ] 학교 학과 사무실 직접 확인 안내함
- [ ] GTE 재평가 가능성 설명함
- [ ] 윌슨 1:1 상담 유도함
