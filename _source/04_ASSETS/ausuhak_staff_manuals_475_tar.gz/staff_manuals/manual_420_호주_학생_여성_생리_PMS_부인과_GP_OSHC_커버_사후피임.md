# #420 호주_학생_여성_생리_PMS_부인과_GP_OSHC_커버_사후피임

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 생리불순이 심해졌어요. 부인과 가야 할 거 같은데 OSHC 커버되나요? 어디로 가야 하나요? 사후피임약(Plan B) 처방전 필요한가요? 한국이랑 시스템 너무 다르네요."

**직원 멘붕 포인트:**
- 호주 부인과(Gynaecologist) 직접 가는지 GP 거치는지
- OSHC 부인과 커버 여부
- Plan B (사후피임약) 처방전 필요 여부
- 산부인과 vs 부인과 차이 (호주는 분리)
- 여성 의사 요청 가능 여부

---

## ❌ 절대 하지 말아야 할 답

> "한국이랑 똑같이 부인과 바로 가면 돼요"

→ ❌ ❌ 거짓. 호주는 GP(General Practitioner) 우선. Specialist (부인과/산부인과)는 GP Referral 필수.

---

## ✅ 정답

호주 의료 시스템 = GP(가정의) 우선. 부인과/산부인과 직접 못 감. GP 진료 → Referral → Specialist. OSHC 부인과 진료(GP+Specialist) 80% Public, 일부 Private 100% (등급별). Plan B (Levonorgestrel): 처방전 X (Pharmacy 직접 구매 가능, $20~$40). 단, 일부 약사가 Counselling. 여성 의사 요청 가능 (예약 시 'Female GP/Specialist' 명시). 한국어 통역 TIS 131 450 무료. 응급 시 ED(Emergency Department) 무료(Public Hospital).

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 GP → Specialist 시스템**
GP(General Practitioner) = 한국 가정의/내과. 모든 의료 진료 1차 관문. Specialist (부인과/산부인과/심장내과 등) = GP Referral 필수 (Pediatrician 일부 예외). Bulk Billing GP (무료) vs Mixed Billing GP (Gap Fee $50~$100). 학생비자 OSHC = Bulk Billing 무료, Mixed는 Gap만 본인 부담. GP 평균 대기 1~3일.

**2. 부인과 vs 산부인과 차이 (호주)**
호주는 Gynaecologist (부인과) + Obstetrician (산부인과)이 분리 또는 통합. O&G(Obstetrics and Gynaecology) Specialist가 둘 다. 생리불순/난소/자궁 = Gynaecologist. 임신/출산 = Obstetrician. GP가 적합한 Specialist 선택. 일반 Specialist 비용: GP Referral 후 $200~$500/회 (OSHC가 일부 환급). Public Hospital Specialist 무료 (대기 6개월~1년).

**3. OSHC 부인과 커버 (등급별)**
OSHC Standard (학생비자 의무): GP Bulk Billing 무료, Specialist 80% Public Hospital, Pathology 80% MBS Schedule. Pap Smear (자궁경부암 검사): 5년마다 무료 (HPV Test). 임신/출산: 12개월 Waiting Period (가입 12개월 후 커버). 사후피임약/응급피임: OTC라 OSHC 커버 X. IUD/Implant 피임: GP/Gynaecologist 처방, OSHC 일부 커버.

**4. Plan B (사후피임약) Pharmacy 직접 구매**
호주 Levonorgestrel(Postinor-2, Plan B) = Schedule 3 약 = 처방전 없이 약사 면담 후 구매. 비용 $20~$40. 24시간 약국(Chemist Warehouse, Priceline 등) 가능. 약사 질문: 1) 마지막 콘돔 사용/실패 시간 2) 마지막 생리 3) 임신 가능성. 72시간 내 효과 95%. 응급 IUD(Copper) 5일 내 효과 - GP/Gynaecologist.

**5. 여성 의사 + 한국어 통역**
예약 시 'Female GP' 또는 'Female Specialist' 명시 가능. HotDoc, HealthEngine 앱에서 의사 성별 필터. Public Hospital도 가능 (간호사에게 요청). 한국어 통역: TIS National 131 450 (24시간, 무료, 의료 우선). GP에게 'I need Korean interpreter' 말하면 GP가 TIS 연결. 한국 진료 시간 + 호주 의료 절차 차이로 통역 권장.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: GP 예약 (HotDoc 앱 또는 전화) - Female GP 명시 가능
**2단계**: 2단계: GP 진료 - 증상 설명 + Pathology 처방 (혈액검사 등)
**3단계**: 3단계: 필요 시 Gynaecologist Referral - 예약 1~6주 (Public 6개월+)
**4단계**: 4단계: 응급 시 사후피임 - Pharmacy 직접 (처방전 X, $20~$40)
**5단계**: 5단계: OSHC 청구 - Bupa/Medibank/Allianz 앱에서 Receipt 업로드

---

## 💡 직원이 학생한테 말할 멘트

> "호주 의료 시스템이 한국이랑 많이 달라서 헷갈리실 거예요. 정리해드릴게요.

호주는 GP(General Practitioner, 가정의) 우선이에요. 부인과 직접 못 가요. GP 보고 Referral 받아서 Specialist(부인과 = Gynaecologist) 가는 시스템이에요.

절차:
1) GP 예약 (HotDoc 앱이 편해요) - 'Female GP' 명시 가능
2) GP가 1차 진료 + 혈액검사 처방 + 필요 시 Specialist Referral
3) Gynaecologist 예약 (Public 6개월+ / Private 1~6주)

OSHC 커버:
- GP Bulk Billing 무료
- Specialist Public 80%, Private 일부
- Pap Smear 5년마다 무료
- 임신/출산 12개월 Waiting Period

사후피임약(Plan B / Postinor-2): 처방전 없이 약국에서 직접 구매 가능해요. Chemist Warehouse, Priceline 등에서 $20~$40. 약사가 몇 가지 질문 후 줘요. 72시간 내 효과 95%.

한국어 통역: TIS National 131 450 (24시간, 무료, 의료 우선). GP에게 'Korean interpreter' 말하면 연결해줘요.

여성 의사 요청도 가능합니다. 예약 시 명시하시면 돼요.

장기 케이스(피임/검진/난임 등)는 호주 GP/Gynaecologist 신뢰 관계 만드시는 게 좋아요. 윌슨 카톡(studywilson)에서 OSHC 등급별 커버 + 한국 vs 호주 의료 시스템 차이 안내드려요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **부인과 직접 가면 된다고 안내**
   → ❌ 거짓. GP Referral 필수.

2. **Plan B 처방전 필요하다고 안내**
   → ❌ 거짓. Schedule 3 - 약사 면담 후 OTC 구매.

3. **OSHC 사후피임약 커버한다고 안내**
   → ❌ 거짓. OTC는 OSHC 커버 X.

4. **여성 의사 요청 안 된다고 안내**
   → ❌ 거짓. 예약 시 명시 + 앱 필터 가능.

5. **Public Hospital 부인과 빨리 본다고 안내**
   → ❌ 거짓. 6개월~1년 대기 일반.

6. **응급 IUD도 약국에서 산다고 안내**
   → ❌ 거짓. Copper IUD = GP/Gynaecologist 시술 ($150~$300).

7. **한국어 통역 비용 든다고 안내**
   → ❌ 거짓. TIS 131 450 - 의료는 무료.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 증상 긴급도 (즉시 GP / 응급 ED)
2. OSHC 보험사 (Bupa/Medibank/Allianz/NIB/AHM)
3. 여성 의사 선호 여부
4. 한국어 통역 필요 여부

---

## 🔍 직원이 직접 확인 가능한 사이트

- HotDoc (GP 예약): hotdoc.com.au
- HealthEngine (의사 검색): healthengine.com.au
- TIS National (통역): 131 450 (24h)
- Family Planning NSW: fpnsw.org.au
- Chemist Warehouse: chemistwarehouse.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- OSHC 등급별 커버 + 한국 vs 호주 의료 시스템 차이 안내
- 장기 거주자 GP/Specialist 추천
- 한국어 의사 (시드니/멜번 한인 GP) 정보

**MARA / 변호사 영역**
- OSHC 청구 거부 - Insurance Lawyer / AFCA
- 의료 과실 - Personal Injury Lawyer (#411 매뉴얼)
- 비자 의료 검진 영향 - MARA 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] GP → Specialist 시스템 명확히
- [ ] OSHC GP/Specialist 커버 안내
- [ ] Plan B 처방전 없이 약국 구매 안내
- [ ] 여성 의사/한국어 통역 무료 안내
- [ ] Pap Smear 5년 무료 안내
- [ ] 응급 시 ED Public Hospital 무료 안내
- [ ] 한국 vs 호주 시스템 차이 비교
- [ ] 윌슨 카톡 OSHC 등급별 안내 유도
