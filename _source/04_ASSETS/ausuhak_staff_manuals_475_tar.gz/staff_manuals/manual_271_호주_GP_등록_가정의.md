# #271 호주 GP 등록 가정의

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 호주 도착했는데 감기 걸렸어요. 병원 어디 가야 하나요?"

**직원 멘붕 포인트:**
- GP = General Practitioner (가정의)
- Bulk Billing GP = OSHC 무료
- Medical Centre 등록 권장
- Walk-in 가능 / 예약 권장

---

## ❌ 절대 하지 말아야 할 답

> "한국처럼 종합병원 응급실 가세요."

→ ❌ **호주 = GP 우선 / 응급실 = 진짜 응급만**.

---

## ✅ 정답

GP 등록: ① **General Practitioner** = 호주 1차 의료 (한국 가정의학과) ② **Medical Centre** 등록 권장 ③ **Bulk Billing** = OSHC 직접 청구 (무료) ④ **Gap Fee** = 자비 $30~$80 (학생) ⑤ **예약 권장** (Walk-in 가능) ⑥ **전문의 = GP Referral 필수** ⑦ **Telehealth** = 전화 / 영상 진료.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. GP 정의**
General Practitioner / 호주 1차 의료 / 한국 가정의학과 + 내과 일부 / 모든 진료 출발점 / 처방전 + 의뢰서

**2. Bulk Billing 시스템**
OSHC 직접 청구 = 학생 자비 0 / Medicare Card (PR) = 무료 / 학생 = OSHC 카드 제시

**3. Gap Fee (자비)**
Bulk Billing 안 하는 GP = $80~$150 진찰 / OSHC 환급 약 $40~$80 / 차액 자비 / 학생 비용

**4. Walk-in vs 예약**
Medical Centre = Walk-in 가능 / 예약 = 빠름 (HotDoc 앱) / 예약 추천 / 응급 = Emergency Department 별개

**5. 전문의 (Specialist)**
GP Referral 필수 / 자비 $200~$500 / OSHC 부분 환급 / 영주권 = Medicare 부분 / Public Hospital = 무료 (대기 길음)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 도착 후 1주 내 Medical Centre 등록
**2단계**: OSHC 카드 + 여권 지참
**3단계**: HotDoc 앱 다운로드 (예약)
**4단계**: 감기 / 일반 진료 = GP
**5단계**: 응급 = Emergency Department 또는 000

---

## 💡 직원이 학생한테 말할 멘트

> "호주는 GP (가정의) 시스템이라 일반 진료는 종합병원이 아니라 동네 Medical Centre에서 GP 만나요. Bulk Billing GP는 OSHC 직접 청구해서 학생 자비 0이고, Bulk Billing 안 하는 곳은 자비 $30~$80 정도 듭니다. 예약은 HotDoc 앱이 편해요. 전문의는 GP가 의뢰서 (Referral) 써줘야 만날 수 있고 자비 $200~$500입니다. 진짜 응급 (의식 없음 / 큰 사고)은 000 또는 응급실 가세요. 윌슨님이 1:1로 한인 GP / Bulk Billing 매칭 드려요. 카카오 (studywilson)으로 거주 지역 알려주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **GP = 한국 응급실 ❌**
   → 응급 X / 일반 진료 / 가정의

2. **응급실 = 무료 ❌**
   → Public = 무료 / Private = $1K+

3. **GP = 무조건 자비 ❌**
   → Bulk Billing = OSHC 무료

4. **전문의 = 직접 ❌**
   → GP Referral 필수

5. **Walk-in = 빠름 ❌**
   → 예약이 빠름 (HotDoc)

6. **OSHC = 모든 비용 ❌**
   → Gap Fee 자비 / 한약 X

7. **처방전 = 약국 자유 ❌**
   → GP 처방전 의무

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 거주 지역 (Suburb)
2. OSHC 가입 + 카드
3. 한국어 가능 GP 필요 여부
4. 응급 vs 일반 진료

---

## 🔍 직원이 직접 확인 가능한 사이트

- HotDoc 예약: https://www.hotdoc.com.au
- HealthDirect: https://www.healthdirect.gov.au
- Bupa Find a Provider: https://www.bupa.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 한인 GP / Bulk Billing 매칭
- OSHC 사용 가이드
- 전문의 Referral 안내

**MARA / 변호사 영역**
- 의료 사고 + 변호사
- OSHC 청구 거절 + AFCA

---

## ✅ 완벽 응대 체크리스트

- [ ] GP = 1차 의료 / 한국 가정의
- [ ] Bulk Billing = OSHC 무료
- [ ] Gap Fee = 자비 $30~$80
- [ ] 예약 = HotDoc 앱
- [ ] 전문의 = GP Referral
- [ ] 응급 = 000 / Emergency
- [ ] 윌슨 1:1 = 한인 GP 매칭
- [ ] 윌슨 카카오 자연 유도
