# 📚 직원 응대 매뉴얼 #101

**케이스: 21세 / "Sydney University 컴퓨터공학 지원했는데 거절됐어요. 어떻게 해야 돼요?"**

---

## 🎬 상황 시뮬레이션

**[카카오톡 알림]** 띠리링~

> 시드니대 Bachelor of Computer Science 지원했는데 GPA 부족이라고 거절됐어요. 한국 4년제 졸업했고 GPA 3.2/4.5예요. 다른 학교 가능한가요? 아니면 Master로 가야 하나요? 1년 미루는 건 싫어요.

**👉 직원이 멘붕하는 순간**
- "거절 = 끝?"
- "다른 Go8 학교?"
- "Master vs Bachelor?"
- "Pathway 학교?"
- "GPA 3.2/4.5 = 호주 환산?"

**❌ 절대 하지 말아야 할 답**
- "1년 후 다시 지원하세요" → **무책임**
- "Sydney 포기하세요" → **부분 사실. 대안 X**
- "Master로 가세요" → **자격 미확인**

**✅ 직원이 알아야 할 정답**
거절 = **끝 X**. 호주 = **47개 대학** + Pathway 다양:

1. **다른 Go8** 시도 (UNSW, Monash, UQ, ANU, Adelaide, UWA, Melbourne)
2. **일반 대학** 시도 (UTS, RMIT, Macquarie, QUT 등)
3. **Pathway** 입학 (Foundation / Diploma → 학사 2학년 편입)
4. **Master 직행** (학사 + GPA 일정 시)
5. **TAFE → 학사 편입** (학점 인정)
6. **다음 학기** 재도전 (성적/포트폴리오 보강)

직원 = **6가지 대안** 안내. 윌슨 = **학생별 최적 매칭**.

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 호주 대학 = 47개 + 다양한 입학 기준

**답**: 호주 대학 = **47개 (Go8 + 일반)**. 학교마다 입학 기준 다름.

**Go8 (Group of Eight)**:
- University of Sydney
- UNSW (University of New South Wales)
- Monash University
- University of Queensland (UQ)
- Australian National University (ANU)
- University of Adelaide
- University of Western Australia (UWA)
- University of Melbourne

**Go8 입학 기준 (일반)**:
- 한국 4년제 GPA 3.5/4.5+ (대학별)
- IELTS 6.5 (각 6.0)
- 학과 따라 다름

**일반 대학 (입학 비교적 수월)**:
- UTS (University of Technology Sydney)
- Macquarie University
- RMIT University
- Deakin University
- La Trobe University
- QUT (Queensland University of Technology)
- Griffith University
- Curtin University

**일반 대학 입학 기준**:
- 한국 4년제 GPA 3.0/4.5+
- IELTS 6.5 (각 6.0)
- 더 관대

**출처**: 각 대학 공식 사이트, Universities Australia

---

### 2️⃣ Pathway 시스템 (거절 후 우회)

**답**: 거절 = **Pathway**로 우회 가능. 1년 추가 시간 또는 학점 인정.

**Pathway 종류**:

**Foundation (예비 과정)**:
- 고졸 직후 / 학력 부족 시
- 1년 = 학사 1학년 입학
- Sydney Foundation (Taylors), UNSW Foundation 등

**Diploma (전문대 수준)**:
- 1년 (FastTrack) ~ 2년
- 학사 **2학년 편입** = 1년 학점 인정
- TAFE NSW Diploma → UTS / 시드니대
- Sydney Foundation Diploma → 시드니대 2학년
- INSEARCH (UTS 자회사) → UTS 2학년

**대학별 Pathway 예**:
- Sydney Foundation/Diploma (Taylors)
- UTS:Insearch → UTS
- Monash College → Monash
- UNSW Global → UNSW
- UWA Foundation → UWA
- ANU College → ANU

**비용 (Pathway)**:
- $25,000~40,000 AUD/년
- 학사보다 약간 저렴

**출처**: 각 학교 Pathway 사이트

---

### 3️⃣ Master 직행 vs Bachelor

**답**: 한국 4년제 졸업 = **Master 직행** 가능 (자격).

**Master 직행 자격**:
- 한국 4년제 학사
- GPA 3.0/4.5+ (학교/학과별)
- 관련 학과 또는 IT/Business는 비전공 OK 일부
- IELTS 6.5 (각 6.0)

**Master 장점**:
- 1.5~2년 = 빨라짐
- 학사 = 호주 인정 학력
- 485 비자 = 2년~3년
- 호주 사회 = Master 우대

**Master 단점**:
- 학비 비쌈 ($30,000~50,000/년)
- IT/Business = 한국 학사 비전공 시 거절 가능
- 일부 학과 = 학사 학과 일치 필수

**Bachelor 신청 vs Master**:
- Bachelor = 처음부터 (3~4년)
- Master = 한국 학사 활용 (1.5~2년)
- 한국 4년제 졸업자 = **Master 추천**

**한국 GPA 환산**:
- 4.5 만점 → 호주 7.0 만점
- GPA 3.2/4.5 ≈ 호주 5.0~5.5/7.0
- 일반 Master = OK (UTS, Macquarie, RMIT)
- Go8 Master = 일부 가능 / 일부 의문

**출처**: 각 대학 Master Coursework 입학 기준

---

### 4️⃣ TAFE Diploma → 학사 편입

**답**: TAFE Diploma 1년 = 학사 **2학년 편입** (학점 인정).

**TAFE NSW Diploma of IT**:
- 1년 + Advanced Diploma 1년
- IELTS 5.5 (각 5.0)
- → UTS Bachelor of IT 2학년 편입
- 또는 Western Sydney 등

**TAFE 장점**:
- 입학 = 비교적 수월
- 학비 저렴 ($20,000/년)
- 실용 중심 + 학사 편입 가능
- IELTS 낮음

**TAFE → 학사 편입 시 학점 인정**:
- Diploma = 1년 학점 (학사 1학년 면제)
- Advanced Diploma = 2년 학점 (1+2학년 면제)
- 학교/학과 따라 다름

**TAFE 우회 = 거절 학생에게 추천**:
- 한국 4년제 졸업 + 한국 IT 학과 X
- → TAFE Diploma IT 1년
- → UTS Bachelor IT 2학년 편입 2~3년
- → 졸업 + 485

**출처**: TAFE NSW, UTS, 각 대학 Credit Transfer

---

### 5️⃣ 거절 사유 분석 + 보강

**답**: 거절 사유 = 분석 + 보강 시 **다음 학기 재도전** 가능.

**거절 사유**:
- GPA 부족
- IELTS 부족
- 학과 미스매치 (한국 학사 학과)
- 포트폴리오 부족 (디자인, 영화 등)
- Personal Statement 약함
- 추천서 약함

**보강 방법**:

**GPA 보강**:
- 추가 학점 (한국 대학원 / 학점 인정)
- 호주 Foundation/Diploma 1년 + 좋은 성적

**IELTS 보강**:
- IELTS 6.5 → 7.0 + 직접 입학
- ELICOS Direct Entry (학교 부설 어학원)
- → 학교 마다 IELTS 면제 가능

**포트폴리오**:
- 컴공 = 코딩 프로젝트 GitHub
- 디자인 = Behance / 작업물 PDF
- 영화 = Vimeo

**Personal Statement**:
- 학과 동기 명확
- 호주 학교 = "왜 이 학교"
- 미래 계획

**다음 학기 = 6개월~1년 후**:
- 호주 학기 = 2월 / 7월 (대학)
- 거절 후 → 6개월 보강 → 7월 인테이크 가능

**출처**: 각 대학 입학 사정 정책

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 거절 사유 확인
- Sydney = 거절 이유 = GPA?
- 거절 메일 / 이유 정확히
- 직원 = 사유 분석

### Step 2: GPA 환산
- 한국 GPA 3.2/4.5 = 호주 약 5.0~5.5/7.0
- Sydney = 5.5+ 요구 (학과별)
- → Sydney 직접 = 자격 미달

### Step 3: 6가지 대안 제시

**대안 1: 다른 Go8**:
- Adelaide / UWA = GPA 약간 관대
- 직접 신청

**대안 2: 일반 대학**:
- UTS / Macquarie / RMIT = GPA 3.0+ OK
- Bachelor of IT = 가능

**대안 3: Pathway**:
- INSEARCH → UTS 2학년
- Monash College → Monash 2학년
- 1년 + 학사 2년 = 3년 총

**대안 4: Master 직행**:
- 한국 4년제 졸업 = 자격
- Master of IT (UTS, RMIT 등) = GPA 3.0+ OK
- 1.5~2년 = 빠름
- → **추천**

**대안 5: TAFE → 학사 편입**:
- TAFE Diploma 1년 + UTS/RMIT 2~3년
- 학비 저렴

**대안 6: 다음 학기 재도전**:
- 7월 인테이크 가능
- IELTS 7.0 보강
- 추가 학점 / 포트폴리오

### Step 4: 윌슨 1:1 상담
- 6가지 중 학생 우선순위 / 자금 / 시점
- 윌슨 = 개별 매칭

---

## 💡 직원이 학생한테 말할 멘트

**[카카오톡 답장 멘트]**

> 거절 = 끝이 아니에요. 호주 47개 대학 + 다양한 길이 있습니다.
>
> **🟢 6가지 대안**:
>
> **대안 1: 다른 Go8**
> - Adelaide, UWA = GPA 약간 관대
> - 직접 Bachelor 지원
>
> **대안 2: 일반 대학 (입학 수월)**
> - **UTS**, **Macquarie**, **RMIT** Bachelor of IT
> - GPA 3.0+ = OK
> - IELTS 6.5
>
> **대안 3: Pathway**
> - **INSEARCH → UTS 2학년 편입** (1년 + 2년)
> - **Monash College → Monash 2학년**
> - **Sydney Foundation/Diploma (Taylors) → 시드니대 2학년 편입** = 시드니 가능
> - 시간 = 학사와 동일 (3년)
>
> **대안 4: Master 직행 (추천!)**
> - 한국 4년제 졸업 = **Master 자격**
> - Master of IT (UTS, RMIT, Macquarie)
> - GPA 3.2/4.5 = 일반 대학 OK
> - **1.5~2년 = 빠름**
> - 485 비자 = 2~3년
>
> **대안 5: TAFE → 학사 편입**
> - TAFE NSW Diploma of IT 1년
> - → UTS Bachelor 2학년 편입
> - 학비 저렴 ($20,000/년)
> - IELTS 5.5 OK
>
> **대안 6: 다음 학기 재도전**
> - 호주 7월 인테이크
> - IELTS 7.0 보강
> - 포트폴리오 GitHub
> - Sydney 다시 지원
>
> **🚨 추천**:
> 한국 4년제 졸업 = **Master 직행 추천**
> - UTS Master of IT / RMIT Master of IT
> - 1.5~2년 + 485 비자 + 영주권 가능
> - Sydney 못 가도 = UTS도 IT 강함 (호주 IT Top 5)
>
> **GPA 환산**:
> 한국 GPA 3.2/4.5 ≈ 호주 5.0~5.5/7.0
> - Sydney 학사 = 자격 미달
> - **UTS Master = 충분**
>
> **시점**:
> - 7월 인테이크 신청 = 4~5월 마감
> - 2월 인테이크 = 11월 마감
>
> 6가지 중 어떤 방향 선호하세요? 윌슨이 학생 상황 1:1 상담 + 학교 매칭해드릴게요.
>
> 카카오 ID: studywilson

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "Sydney 못 가면 다 끝"
- **사실**: 47개 대학 + Pathway 다양
- **올바른 안내**: "6가지 대안 + Master 추천"

### 함정 2: "1년 후 다시 도전"
- **사실**: 호주 = 7월 인테이크 = 6개월 후
- **올바른 안내**: "7월 인테이크 + 즉시 다른 학교"

### 함정 3: "한국 GPA 4.5 만점 = 호주 동일"
- **사실**: 호주 = 7점 만점. 환산 필수
- **올바른 안내**: "한국 3.2/4.5 ≈ 호주 5.0~5.5/7.0"

### 함정 4: "Master = Bachelor보다 어려움"
- **사실**: Master = 일부 일반 대학 = GPA 3.0+ OK
- 한국 4년제 졸업 자체가 자격
- **올바른 안내**: "Master 직행 = Bachelor 거절 시 추천"

### 함정 5: "Pathway = 가짜 학교"
- **사실**: Pathway = 정식 학사 편입. 졸업장 동일
- **올바른 안내**: "Pathway 졸업 = Sydney/UTS 학위. 동일 가치"

### 함정 6: "TAFE = 대학 아님"
- **사실**: TAFE Diploma → 학사 편입 = OK
- 호주 = TAFE → Bachelor 일반적 경로
- **올바른 안내**: "TAFE → 학사 편입 = 학비 저렴 + 입학 수월"

### 함정 7: "포트폴리오 컴공 안 필요"
- **사실**: 컴공 = GitHub / 프로젝트 가산점
- **올바른 안내**: "포트폴리오 = 거절 후 보강 핵심"

---

## 📞 카카오 응대 시 필수 4가지 확인

### 1. 거절 사유
- GPA / IELTS / 학과 / 포트폴리오?
- → 사유별 보강 방법

### 2. 한국 학력 정확히
- 4년제 / 전문대?
- 학과 = IT 관련?
- GPA?
- → Master 자격 / Bachelor 자격

### 3. IELTS 점수
- 6.5? 7.0?
- 각 영역?
- → 학교 매칭

### 4. 시점 / 예산
- 즉시 입학 (다른 학교)?
- 7월 인테이크 (재도전)?
- 학비 예산?
- → 옵션 우선순위

**4가지 확인 후 → 본인의 영역(6가지 대안 정보) → 윌슨 영역(학교 매칭)**

---

## 🔍 직원이 직접 확인 가능한 사이트

### 호주 대학 검색
- universitiesaustralia.edu.au

### Go8
- go8.edu.au

### 각 대학 입학 기준
- sydney.edu.au, unsw.edu.au, monash.edu, uq.edu.au
- uts.edu.au, mq.edu.au, rmit.edu.au

### Pathway
- taylorscollege.com (Sydney/UTS)
- insearch.edu.au (UTS)
- monashcollege.edu.au

### TAFE
- tafensw.edu.au

### CRICOS (학교 등록 확인)
- cricos.education.gov.au

**확인 사항**: 위 사이트 = 정부/대학 공식.

---

## 🚨 직원 영역 vs 변호사/MARA 영역

### 직원 영역 (이 매뉴얼 활용)
- ✅ 6가지 대안 정보
- ✅ Pathway 학교 안내
- ✅ Master 자격 1차 안내
- ✅ TAFE → 학사 편입 안내
- ✅ 다음 학기 재도전 시점

### 윌슨 직접 처리 영역
- ⚠️ 학생 GPA 환산 정확히
- ⚠️ 6가지 중 최적 매칭
- ⚠️ 학교 직접 컨택
- ⚠️ Personal Statement 검토

### 학교 영역 (직원 X)
- ❌ 학교 입학 사정 (학교 결정)
- ❌ Conditional Offer 협상 (학교 + 윌슨)

### MARA 영역 (직원 X)
- ❌ 학생비자 신청 (변경)
- ❌ 거절 후 비자 영향

**원칙**: 직원 = **6가지 대안**. 학교 매칭 = **윌슨 직접**.

---

## ✅ 완벽 응대 체크리스트

응대 끝나기 전 이 체크리스트 확인:

- [ ] **6가지 대안** 모두 안내했나?
  - [ ] 다른 Go8
  - [ ] 일반 대학
  - [ ] Pathway
  - [ ] Master 직행
  - [ ] TAFE → 편입
  - [ ] 다음 학기 재도전
- [ ] **Master 추천** (한국 4년제 졸업) 강조했나?
- [ ] GPA 환산 (한국 4.5 → 호주 7.0) 안내했나?
- [ ] Pathway = **정식 학사 졸업** 동일 가치 명시했나?
- [ ] TAFE → 학사 편입 = 학점 인정 안내했나?
- [ ] 호주 인테이크 (2월/7월) 안내했나?
- [ ] 거절 사유 = 보강 방법 매칭했나?
- [ ] IELTS 학교별 다름 안내했나?
- [ ] 학비 차이 (Go8 vs 일반 vs TAFE) 안내했나?
- [ ] **윌슨 1:1 상담** 권장했나?
- [ ] "Sydney 못 가면 끝" 같은 절망 답변 안 했나?

**핵심**: 거절 = **끝 X**. **6가지 대안**. 한국 4년제 졸업 = **Master 추천**. Pathway = 정식 학위 동일. 윌슨 = 학생별 매칭.

---

**작성**: ausuhak.com 직원 교육 시스템 v1.0
**기준일**: 2026-05-04
**참고**: 각 대학 공식 사이트, universitiesaustralia.edu.au, cricos.education.gov.au
**다음 매뉴얼**: #102 호주 직장 영어 / 인터뷰 준비
