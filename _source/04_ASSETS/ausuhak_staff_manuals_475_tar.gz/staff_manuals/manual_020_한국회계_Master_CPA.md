# 📚 직원 응대 매뉴얼 #020

**케이스: 28세 / 한국 경영/회계 학사 / 호주 회계사 / 영주권 / 9천만 예산**

---

## 🎬 상황 시뮬레이션

> 한국 경영학과 졸업하고 회계 쪽으로 일하다가 호주 회계사 자격 따고 영주권 받으려고 합니다. 28세이고 IELTS 7.0 있어요. 9천만 예산이에요.

**👉 정답**: **Master of Accounting + CPA Australia + 485 + PR**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ 회계사 = 호주 MLTSSL 직업군 (MLTSSL)

| 직업 | ANZSCO | PR 리스트 |
|---|---|---|
| Accountant General | 221111 | MLTSSL |
| Management Accountant | 221112 | MLTSSL |
| Taxation Accountant | 221113 | MLTSSL |
| External Auditor | 221213 | MLTSSL |

### 2️⃣ 호주 회계사 자격 = CPA 또는 CA (둘 중 하나)

- **CPA Australia** (Certified Practising Accountant)
- **CA ANZ** (Chartered Accountants)
- **IPA** (Institute of Public Accountants)

CPA = 가장 흔함 / CA = 전문성 高 / IPA = 작은 곳

### 3️⃣ Master of Accounting (Pre-CPA)

호주 Master of Accounting 졸업 = CPA Australia 인정 학위 (Foundation 면제)

| 학교 | 학비 (연간) | IELTS |
|---|---|---|
| USyd Master Acc | $54K | 7.0 |
| UNSW Master Acc | $52K | 7.0 |
| UMelb Master Acc | $58K | 6.5 |
| Monash Master Acc | $50K | 7.0 |
| UTS Master Acc | $44K | 6.5 |
| Macquarie Master Acc | $42K | 6.5 |

### 4️⃣ CPA 시험 = Master 졸업 후 또는 동시 진행

- CPA Foundation = Master로 면제 (보통)
- CPA Professional 6개 과목 + Practical Experience (3년)
- 호주 회사 회계 일하면서 CPA 수강 가능

### 5️⃣ 28세 + Master 2년 + CPA = PR 경로

```
한국 학사 + IELTS 7.0
        ↓
Master of Accounting 2년 ($90K~$110K)
        ↓
졸업 + CPA Australia 가입
        ↓
485 졸업비자 2년 (호주 회계 회사 취업)
        ↓
CPA Practical Experience 3년 + 시험
        ↓
PR (직업 + CPA)
```

**총 4-5년 호주 / 학비 약 $90K~$110K**

---

## 🎯 정답 경로

### Master Accounting + CPA + 485 + PR

```
한국 경영학 학사 + IELTS 7.0
        ↓
Master Accounting 2년 ($90K~$110K)
        ↓
CPA Australia 가입 + 485
        ↓
호주 회계 회사 취업 + Practical Experience
        ↓
CPA 자격 + PR
```

**총 4-5년 / 학비 약 $90K~$110K + CPA 시험비 별도**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 경영학 + 회계 경력 + IELTS 7.0이면 호주 회계사 + 영주권 빠른 경로 가능합니다.
> 
> 1. **Master of Accounting 2년** = CPA Foundation 면제
> 2. **CPA Australia 자격** = 호주 회계사 표준 자격
> 3. **PR**: Accountant 221111 (MLTSSL) 직업군
> 4. **시드니 학교**: USyd $54K / UNSW $52K / UTS $44K / Macquarie $42K
> 
> 9천만 예산이면 1년 학비 + 생활비 + CPA 시험비 가능합니다.
> 
> 시드니는 회계 회사 多 (Big 4 등)이지만 Non-regional이라 491 +15점 적용 X. **Adelaide/Perth/Canberra 등 Regional 지역 (491 +15점) 검토**도 가능 (Brisbane CBD는 Non-regional).
> 
> 카톡으로 알려주세요:
> ① IELTS 정확한 점수 (각 영역)  
> ② 한국 회계 경력 연수 + 분야  
> ③ 시드니 vs Adelaide 검토"

---

## ⚠️ 함정

1. **"한국 회계사 자격 = 호주 인정"** → 별도 평가 + CPA 시험 必
2. **"Master 졸업 = CPA 자동"** → Foundation 면제만 / Professional 시험 必
3. **"Big 4만 PR 가능"** → ❌ 어떤 회계 회사든 가능
4. **"시드니 대형 회사 = 영주권 빠름"** → 가산점은 0 / Regional 지역이 491 통한 PR 빠름

---

## 📞 카카오 응대 시 필수

1. IELTS 정확한 점수
2. 한국 회계 경력
3. CPA vs CA 선호
4. 시드니 (Non-regional) vs Regional 도시

---

## 🔍 직원 확인 사이트

- CPA Australia: cpaaustralia.com.au
- CA ANZ: charteredaccountantsanz.com
- Master Accounting 학교
- ANZSCO 회계 직업: immi.homeaffairs.gov.au
