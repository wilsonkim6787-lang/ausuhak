# #504 호주_한인_사기_피해_보이스피싱_가짜_유학원_세관_벌금_사칭

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "한인 카톡방에서 '학생 비자 도와준다' 사람한테 $5,000 송금했어요. 연락 끊겼어요. 어떻게 해요?"

**직원 멘붕 포인트:**
- 호주 한인 대상 사기 빈번 (가짜 유학원/이민 대리인/가짜 직장 등)
- MARA 등록 안 된 사람이 비자 자문 = 불법 (Migration Act)
- Scamwatch 신고 (ACCC) + 호주 경찰 + 한국 영사관
- 은행 즉시 신고 → Chargeback 시도 (송금 후 빠를수록 가능)
- 직원이 '돈 돌려받기 어렵다' 단념 X. 신고 절차 정확히 안내

---

## ❌ 절대 하지 말아야 할 답

> "송금한 돈은 돌려받기 어려워요 그냥 잊으세요"

→ ❌ 신고 절차로 일부 회수 가능 + 가해자 처벌. 단념 X

---

## ✅ 정답

안타깝지만 사기 피해 가능성 높아요. 즉시 (1) 호주 은행에 사기 신고하고 Chargeback 신청, (2) 송금 후 빠를수록 회수 가능성 있어요, (3) Scamwatch(scamwatch.gov.au) 신고, (4) 호주 경찰 신고(Police Report 발급), (5) 사기꾼이 MARA 미등록자면 Department of Home Affairs에도 신고 가능합니다(불법 이민 자문). 한인 커뮤니티에 알려서 추가 피해 막으시고, 카카오톡 대화 캡처 + 송금 영수증 보관하세요. 학생비자 자체 영향은 없으니 안심하세요.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 한인 대상 흔한 사기 유형**
1. 가짜 유학원/이민 대리인 (MARA 미등록)
2. 가짜 직장 (Casual Job 면접비/유니폼비 요구)
3. 보이스피싱 (한국 검찰/세무서 사칭)
4. 셰어하우스 사기 (가짜 매물 + Bond 송금)
5. 비자 사기 (PR 보장 + 거액 요구)
6. 한국 송금 환전 사기 (시세 차익 사기)
7. 카톡방 투자 사기 (코인/주식)

**2. MARA 등록 확인 (이민 대리인)**
Office of the Migration Agents Registration Authority
사이트: mara.gov.au
MARN (Migration Agent Registration Number) 확인
MARA 미등록자가 비자 자문 = 불법
Migration Act 1958 Section 280:
- 비자 자문 (Immigration Assistance) = MARA 또는 변호사만
- 위반 시 벌금 $26,640 + 10년 징역

**3. 즉시 신고 절차**
1. 호주 은행 즉시 (사기 의심 신고):
   - CommBank 13 22 21
   - Westpac 1300 651 089
   - NAB 13 22 65
   - ANZ 13 33 50
2. Chargeback 신청 (BPAY 등 시간 빠를수록 가능)
3. Scamwatch ACCC: scamwatch.gov.au
4. 호주 경찰: 131 444 (Non-emergency)
5. Police Report Reference Number 보관

**4. 증거 보관 (회수 + 처벌)**
필수 증거:
- 카카오톡/위챗/Whatsapp 대화 캡처
- 사기꾼 이름/카카오 ID/전화번호/은행 계좌
- 송금 영수증 + 은행 거래 내역
- 약속한 서비스 광고/메시지
- 다른 피해자 정보 (한인 커뮤니티)
보관 후:
- 호주 경찰 + Scamwatch 제출
- Civil Lawyer 자문 (Class Action 가능)

**5. 회수 가능성 (현실적)**
Chargeback (송금 후 24~48시간):
- 신용카드: 60~90% 회수 가능
- BPAY: 1~3일 안 가능
- 직접 송금 (BSB/Account): 어려움

Civil Lawsuit:
- 사기꾼 신원 확인 시 가능
- Limitation 시효 6년
- Small Claims Tribunal 무료 ($10,000 미만)
- NCAT/VCAT/QCAT 등 각 주

현실: 30~40% 회수 가능 (즉시 신고 시)

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 호주 은행 즉시 사기 신고 + Chargeback
**2단계**: 증거 보관 (대화/영수증/사기꾼 정보)
**3단계**: Scamwatch + 호주 경찰 신고
**4단계**: 한인 커뮤니티 경고 (추가 피해 방지)
**5단계**: Civil Lawyer 자문 (Small Claims 가능 시)

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 사기 피해는 빠른 신고가 중요해요. (1) 호주 은행 즉시 사기 신고 + Chargeback 신청, (2) Scamwatch scamwatch.gov.au 신고, (3) 호주 경찰 131 444 신고, (4) 카톡 대화 + 송금 영수증 보관하세요. MARA 미등록자가 비자 자문하면 Department of Home Affairs에도 신고 가능합니다. 학생비자 영향은 없으니 안심하세요. 자세한 회수 절차는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'돈 돌려받기 어렵다' 단념 X**
   → 신고 빠르면 Chargeback 60~90%

2. **MARA 등록 확인 안 함 X**
   → 비자 자문은 MARA만

3. **한국 가족한테 X**
   → 수치심으로 신고 안 하면 가해자 활개

4. **증거 안 보관 X**
   → 카톡 캡처 + 영수증 필수

5. **학생비자 영향 X**
   → 피해자 비자 영향 X

6. **한인 커뮤니티 알리지 않음 X**
   → 추가 피해 방지

7. **자체 해결 X**
   → 사기꾼 직접 만나면 위험

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 송금 후 며칠? (24시간 미만/24시간~7일/7일+)
2. 송금 방법? (신용카드/BPAY/직접 송금)
3. 사기꾼 정보 있어요? (이름/전화/계좌)
4. 다른 피해자 알아요? (있다/없다)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Scamwatch ACCC: scamwatch.gov.au
- MARA: mara.gov.au
- 호주 경찰 비응급: 131 444
- IDCARE 무료: 1800 595 160
- Department Home Affairs: immi.homeaffairs.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 사기 신고 절차 1차 안내
- 은행 사기 신고 안내
- MARA 등록 확인
- 한인 커뮤니티 경고 안내

**MARA / 변호사 영역**
- Civil Lawsuit 회수 (Civil Lawyer)
- Small Claims Tribunal (NCAT/VCAT)
- Class Action 동참 (Class Action Lawyer)
- MARA 위반 신고 (MARA OMARA)

---

## ✅ 완벽 응대 체크리스트

- [ ] 호주 은행 즉시 사기 신고
- [ ] Chargeback 신청
- [ ] Scamwatch + 경찰 신고
- [ ] 증거 보관 + 한인 커뮤니티 경고
- [ ] Civil Lawyer 자문 (Small Claims)
