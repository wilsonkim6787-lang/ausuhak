# #426 호주_학생_데이트_폭력_가정_폭력_1800RESPECT_AVO

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "남자친구가 자꾸 화내고 욕하고 한번은 손목 잡고 흔들었어요. 무서워서 신고하고 싶은데 학생비자라 강제출국 될까봐 못 하겠어요. 한국 부모님께 말 안 하고 도움받을 수 있나요?"

**직원 멘붕 포인트:**
- Domestic Violence 신고
- 1800 RESPECT 한국어
- AVO (Apprehended Violence Order)
- 비자 영향 (피해자 보호)
- Family Violence Provision Partner Visa

---

## ❌ 절대 하지 말아야 할 답

> "별일 아닐 거예요. 그냥 헤어지세요"

→ ❌ ❌ 폭력 평가 절대 X. 손목 잡기 = NSW Common Assault. 1800 RESPECT 즉시 연결 의무.

---

## ✅ 정답

최우선: ① 1800 RESPECT (1800 737 732) - 24시간 한국어 통역 / 무료 / 비밀보장, ② 즉각 위험 시 000 경찰, ③ AVO 신청 - Local Court 무료 / 가해자 접근 금지 명령 / 법적 강제력, ④ 피해자 비자 영향 X (오히려 보호), ⑤ Partner Visa 진행 중 가정폭력 시 Family Violence Provision = 비자 단독 신청 가능 (가해자와 분리해도 비자 유지), ⑥ Lifeline 13 11 14 (24시간 정신건강), ⑦ 한국어 가정폭력 핸드북 - safesteps.org.au. 학생비자 = 신고로 인한 비자 취소 절대 없음.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 1800 RESPECT**
1800 737 732 / 24시간 한국어

**2. AVO**
Apprehended Violence Order / Local Court 무료

**3. Family Violence Provision**
Partner Visa 단독 신청 가능

**4. Common Assault NSW**
신체 접촉 위협 / 처벌 가능

**5. Safe Steps 호주**
safesteps.org.au / 한국어 자료

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계: 즉각 위험도 평가 (현재 동거? 무기?)
**2단계**: 2단계: 1800 RESPECT 즉시 연결 권유
**3단계**: 3단계: 안전한 장소 (셸터/친구집) 이동
**4단계**: 4단계: AVO 신청 (Local Court 무료)
**5단계**: 5단계: 비자 영향 X 안내 / Partner Visa 시 FVP

---

## 💡 직원이 학생한테 말할 멘트

> "지금 안전이 가장 중요합니다. 1800 RESPECT (1800 737 732) 24시간 한국어 통역 무료입니다. 신고로 학생비자 취소 절대 없습니다. 경찰이 가해자를 처벌할 뿐 피해자에게 불이익 없습니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **폭력 정도 평가**
   → 직원 영역 X

2. **부모 알리라고 강요**
   → 피해자 결정

3. **헤어지면 끝**
   → AVO 없으면 가해자 추적 위험

4. **학생비자 취소 위험**
   → 법적으로 무관

5. **한국 영사관 신고**
   → 호주 사건은 호주 경찰

6. **Partner Visa 자동 취소**
   → Family Violence Provision으로 보호

7. **증거 X 신고 무의미**
   → AVO는 진술만으로도 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 동거 여부 / 즉각 위험도
2. 신체 폭력 vs 정서 폭력
3. Partner Visa 진행 중 여부
4. 응급 연락처 / 안전한 장소 유무

---

## 🔍 직원이 직접 확인 가능한 사이트

- ('1800 RESPECT', '1800respect.org.au')
- ('Safe Steps', 'safesteps.org.au')
- ('AVO 신청', 'Local Court NSW')

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 긴급 연결, 비자 영향 X 안내, 정보 제공

**MARA / 변호사 영역**
- Family Violence Provision Partner Visa / 형사 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] 1800 RESPECT 즉시 연결함
- [ ] 비자 영향 X 명확히 함
- [ ] AVO 무료 안내함
- [ ] FVP Partner Visa 언급함
- [ ] 안전 최우선 강조함
- [ ] 신고 위축 금지 강조함
