# #412 호주_이사_짐_운송_Backloading_Container_State_Move

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니에서 멜번으로 이사 가는데 짐이 책상, 침대, 옷, 책 정도예요. 이사 업체가 너무 비싸요. Backloading이라는 게 뭔가요? 한인 업체랑 호주 업체 차이도 모르겠고, 책 박스만 따로 보내는 방법도 있나요?"

**직원 멘붕 포인트:**
- Interstate 이사 비용 모름
- Backloading 개념 모름
- 한인 업체 vs 호주 업체 신뢰성
- 책/박스만 따로 보내는 옵션
- 보험 의무 여부

---

## ❌ 절대 하지 말아야 할 답

> "한인 업체가 무조건 싸요"

→ ❌ ❌ 부정확. 한인 업체 일부는 보험 미가입, 분쟁 시 한인 커뮤니티 평판으로만 압박 가능. 호주 등록 업체(AFRA 인증)가 분쟁 시 안전. 가격은 케이스마다 다름.

---

## ✅ 정답

시드니→멜번 풀 트럭 이사 $1,500~$3,500 (1Bed). Backloading(빈 트럭에 짐 추가) $400~$1,200 - 큰 가구 적은 짐 추천. 박스만 = StarTrack/Toll/Aramex 같은 Courier $20~$50/박스. AFRA(Australian Furniture Removers Association) 인증 업체 안전. 보험 별도 가입(Transit Insurance 1~3% of 짐 가치). 한인 업체는 견적+보험+계약서 명문화 + 카카오 채널/네이버 후기 검증.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Interstate 이사 비용 구조**
시드니↔멜번 풀 서비스 트럭: 1Bed $1,500~$2,500, 2Bed $2,500~$4,000, 3Bed $4,000~$6,500. 시드니↔브리즈번: 비슷. 시드니↔퍼스: 2배 ($3,000~$8,000, 5일~10일 소요). 시드니↔ 애들레이드: 1.5배. 견적 사이트 muval.com.au, findamover.com.au에서 3-5개 동시 비교.

**2. Backloading vs Full Service**
Backloading: 다른 손님 이사 끝나고 빈 트럭이 돌아갈 때 짐 추가. 50~70% 저렴 ($400~$1,200). 단, 픽업/배송 날짜 고정 안 됨 (1~2주 윈도우). 큰 가구 + 적은 짐 추천. Full Service: 픽업/배송 날짜 고정 + 풀 트럭 전용. 비싸지만 정확. Door-to-Door.

**3. AFRA 인증 + Transit Insurance**
AFRA(afra.com.au) = 호주 이사 업체 협회. 인증 업체는 분쟁 시 AFRA 중재 + 보험 의무. 비인증 업체 (한인 일부 포함) = 분쟁 시 ACCC/ACAT(Tribunal)만 가능. Transit Insurance: 짐 가치의 1~3% 비용. Total Loss Only(저렴) vs Full Cover. AFRA 인증 업체는 기본 보험 포함 多.

**4. 박스만 따로 보내는 Courier**
Sendle, Aramex(구 Fastway), StarTrack(Australia Post), Couriers Please. 박스 1개($20~$50) ~ 팰릿. 시드니↔멜번 5kg 박스 $20, 25kg 박스 $50. 사이즈 제한 (보통 22kg/박스). 보험 별도 (기본 $100~$1,500 자동 커버). 책/옷/소품만 보낼 때 가성비. Australia Post Parcel Post도 가능 (5kg $30, 22kg $60).

**5. 한인 업체 vs 호주 업체**
한인 업체 장점: 한국어 소통, 한인 커뮤니티 후기, 친근. 단점: AFRA 비인증 多, 보험 미가입 多, 분쟁 시 호주 법적 보호 약함. 호주 업체 장점: AFRA 인증, 보험 의무, 영어 분쟁 시 ACCC 보호. 단점: 영어 의사소통, 견적 비싼 편. 권장: 견적 5개 받기(한인 2 + 호주 3) → AFRA 인증 + 후기 검증 + 계약서 + 보험 명문화.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 짐 양 측정 (Cubic Meter, m3) - muval.com.au에서 자동 계산
**2단계**: 이사 업체 견적 5개 비교 (한인 2 + 호주 3, AFRA 인증 우선)
**3단계**: Backloading vs Full Service 결정 - 날짜 유연성에 따라
**4단계**: 보험 가입 (Transit Insurance 1~3% 짐 가치)
**5단계**: 이사 당일: Inventory List 작성 + 사진 촬영 (분쟁 시 증거)

---

## 💡 직원이 학생한테 말할 멘트

> "시드니→멜번 이사 알아보고 계시네요. 정리해드릴게요.

짐이 책상, 침대, 옷, 책 정도면 Backloading 추천드려요. 빈 트럭에 짐 추가하는 방식이라 50~70% 싸요 ($400~$1,200 정도). 단, 픽업/배송 날짜 1~2주 윈도우라서 정확히 못 정해요.

책/박스만 따로 보내실 거면 Sendle, Aramex, Australia Post Parcel Post 쓰시면 됩니다. 박스 1개 $20~$50 정도예요.

업체 선택할 때 한인 업체가 친근하긴 한데 AFRA(호주 이사 협회) 인증이 없는 곳이 많아서 분쟁 시 보호가 약해요. 호주 등록 업체 + AFRA 인증 + Transit Insurance 가입을 추천드립니다.

견적은 muval.com.au, findamover.com.au에서 동시에 5개 받아보시고 비교하세요.

이사가 단순 짐 옮기는 게 아니라 학교 변경(Course Transfer) + 비자 통보 + 은행/Medicare 주소 변경 등 같이 가는 부분이에요. 이 부분 윌슨 카톡(studywilson)에서 한꺼번에 정리해드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한인 업체가 무조건 싸다고 안내**
   → ❌ 부정확. 케이스마다. 견적 5개 비교 필수.

2. **Backloading이 항상 좋다고 안내**
   → ❌ 부분 거짓. 날짜 유연성 없으면 Full Service 필요. 시험/입주 일정 고정 시 부적합.

3. **Transit Insurance 의무라고 안내**
   → ❌ 거짓. 보험은 선택. 단, 강력 권장 (분실/파손 多).

4. **AFRA 비인증 = 사기라고 안내**
   → ❌ 부정확. 비인증도 정상 영업 多. 단, 분쟁 시 보호 약함.

5. **Australia Post가 가구 보낸다고 안내**
   → ❌ 부분 거짓. 22kg + 105cm 이내 박스만. 가구는 Courier 또는 Removalist.

6. **이사하면 비자에 영향 있다고 안내**
   → ❌ 거짓. 주소 변경은 의무 통보(28일 내, ImmiAccount)지만 비자 자체에 영향 X.

7. **학교 변경(Course Transfer) 자유롭다고 안내**
   → ❌ 거짓. Standard 7 ESOS - 6개월 미만 시 Release Letter 필요. 별도 케이스 (#383 매뉴얼 참조).

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 이사 짐 양 (m3) + 큰 가구 유무
2. 이사 일정 유연성 (Backloading 가능 여부)
3. 예산 ($500 이하 = Courier만, $500~$1,500 = Backloading, $1,500+ = Full Service)
4. 학교 변경 동반 여부 (Course Transfer 별도)

---

## 🔍 직원이 직접 확인 가능한 사이트

- Muval (이사 견적 비교): muval.com.au
- Find a Mover: findamover.com.au
- AFRA 인증 업체: afra.com.au
- Sendle (박스 운송): sendle.com
- Aramex (구 Fastway): aramex.com.au
- Australia Post Parcel: auspost.com.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 주간 이주 + 학교 변경 + 비자 통보 통합 코디네이션
- 주별 학비/생활비 차이 분석 (시드니/멜번/브리즈번)
- 이주 후 정착 가이드 (은행/Medicare/주소변경)

**MARA / 변호사 영역**
- 비자 주소 변경 통보 (28일 내, ImmiAccount) - 본인 직접 가능
- 이사 분쟁 (파손/분실) - ACCC / Tribunal (NCAT/VCAT)
- Transit Insurance 청구 거부 - Insurance Lawyer / AFCA

---

## ✅ 완벽 응대 체크리스트

- [ ] Backloading vs Full Service vs Courier 차이 안내
- [ ] AFRA 인증 + 보험 권장
- [ ] 한인 vs 호주 업체 장단점 객관적 안내
- [ ] 박스만 보내는 Courier 옵션 안내
- [ ] muval.com.au 견적 비교 안내
- [ ] 주소 변경 비자 통보 의무 안내
- [ ] Course Transfer는 별개 안내 (#383 참조)
- [ ] 윌슨 카톡 통합 코디네이션 유도
