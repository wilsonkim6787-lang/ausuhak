# #288 호주_치대_입학_경로_PR

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "윌슨님 저 한국 자연계 학생인데 호주 치대 가면 PR 받을 수 있나요? 비용 얼마예요?"

**직원 멘붕 포인트:**
- Bachelor of Dental Surgery 5년 vs Doctor of Dental Medicine 4년
- DCAT/UCAT 시험
- ADC (Australian Dental Council) 인증
- 치과의사 = MLTSSL (PR 가능)
- 한국 치과 면허 호주 인증 절차

---

## ❌ 절대 하지 말아야 할 답

> ""치대도 의대처럼 어려움""

→ ❌ 치대가 의대보다 약간 쉬움. 한국 학생 합격률 약대 다음.

---

## ✅ 정답

"호주 치대는 Bachelor of Dental Surgery (학사 5년) 또는 Doctor of Dental Medicine (석사 4년, 학사 졸업 후) 경로입니다. 졸업 후 ADC 시험 + IELTS 7.0 + Skill Assessment → 485 → PR 경로입니다."

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Bachelor vs Doctor of Dental Medicine**
Bachelor of Dental Surgery (BDS) = 고졸 5년. Adelaide/Queensland/Western Australia 등. ATAR 95+. Doctor of Dental Medicine (DMD) = 학사 후 4년. Sydney/Melbourne/Griffith 등. GPA 6.0+. 둘 다 ADC 인증.

**2. DCAT/UCAT 시험**
DCAT (Dental Combined Aptitude Test) = 호주 치대 일부. UCAT (UK Clinical Aptitude Test) = 대부분 치대. 한국 응시 가능 ($350). 5월~7월 응시. 80 percentile+ 필요. 면접 (MMI) 별도.

**3. ADC Skill Assessment**
Australian Dental Council. 호주 치대 졸업자 = 자동 인증. 한국 치대 졸업자 = ADC Examination 응시 (1차 MCQ + 2차 Clinical) + 영어 7.0 + Internship 옵션. $4,500. 1년 소요.

**4. PR 경로 (MLTSSL)**
치과의사 (Dentist) = MLTSSL. 189/190. EOI 65+ (실제 75+). Skill Assessment by ADC. IELTS 7.0 (각 영역 7.0). 졸업 후 485 (2~4년) → PR 신청 가능.

**5. 19년 경력 = 치대 = 약대 다음 합격 가능**
치대 = ATAR 95+ 필요 = 한국 자연계 상위권 학생. 의대보다 약간 쉬움. 학비 $80,000~$100,000/년 (의대와 비슷). 졸업 후 치과의사 연봉 $120,000~$200,000. ROI 매우 좋음.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 자연계 상위권 학생 = 치대 진학 결심
**2단계**: Bachelor (고졸) 또는 DMD (학사) 결정
**3단계**: ATAR 95+ + UCAT/DCAT + IELTS 7.0
**4단계**: 면접 (MMI) 통과 + 치대 입학
**5단계**: 졸업 후 ADC Skill Assessment + 485 → PR

---

## 💡 직원이 학생한테 말할 멘트

> ""학생, 치대는 의대보다 약간 쉽고 약대 다음으로 한국 학생 합격 가능성 있어요. 한국 자연계 상위권 (ATAR 95+ 환산) + UCAT/DCAT 시험 + IELTS 7.0 (각 영역 7.0) 필요해요. Bachelor (고졸 5년) 또는 DMD (학사 후 4년) 결정하시고요. 학비 $80,000~$100,000/년 + 5년 = $500,000 정도. 한국 내신/영어/예산 알려주시면 매칭해드릴게요.""

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **"치대 = 의대보다 쉬움"**
   → 한국 학생 기준 약간 쉬움. 절대 쉽지 않음. ATAR 95+.

2. **"한국 치과 면허로 호주"**
   → ADC Examination + 영어 7.0 + Internship.

3. **"DCAT 한국 응시 X"**
   → DCAT/UCAT 한국 Pearson VUE.

4. **"치대 졸업 = 즉시 PR"**
   → 485 → ADC → PR 경로 (3~5년).

5. **"학비 장학금"**
   → 국제학생 거의 X.

6. **"한국 치대 후 호주 = 빠름"**
   → ADC Examination 1년 + Internship 옵션.

7. **"치과의사 = TAFE"**
   → TAFE는 치위생사 (Dental Hygienist) 만. 치과의사 = 대학.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 자연계 학년 + 내신 (ATAR 95+ 환산)
2. 영어 IELTS (7.0 필요)
3. 예산 ($500,000+ 5년)
4. PR 목표

---

## 🔍 직원이 직접 확인 가능한 사이트

- ADC: https://www.adc.org.au
- AHPRA Dental Board
- UCAT/DCAT 시험
- 각 치대 사이트 (Adelaide/Sydney 등)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 윌슨 영역 = 치대 매칭 + 입학
- 한국 자연계 상위권 추천
- Bachelor vs DMD 결정 도움
- 비자 신청 대행
- 윌슨 직접 카카오 가능

**MARA / 변호사 영역**
- ADC = Skill Assessment
- AHPRA = 면허 등록
- MARA Lawyer = PR 비자
- 각 치대 = 입학 평가
- Internship = 옵션

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 내신 확인했다 (ATAR 95+)
- [ ] 영어 IELTS 확인했다
- [ ] Bachelor vs DMD 결정 도움 줬다
- [ ] 예산 확인했다 ($500,000+)
- [ ] PR 경로 안내했다
- [ ] ADC Skill Assessment 안내했다
- [ ] 치과의사 연봉 안내했다
- [ ] 윌슨 직접 카카오 ID 안내했다
