# #361 호주_학생_차량_구매_절차_등록_보험

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니에서 중고차 8천 불 정도로 사려고요. 학생비자도 차 살 수 있어요? 등록이랑 보험 어떻게 해요?"

**직원 멘붕 포인트:**
- 학생비자 차량 구매 가능 여부
- Rego (등록) vs Pink Slip vs Green Slip 구분
- Stamp Duty (인지세) 의무
- 보험 종류 (CTP/Comprehensive/TPP) 모름
- 한국 면허 → 호주 면허 전환

---

## ❌ 절대 하지 말아야 할 답

> "학생비자도 차 사도 되고 그냥 한국 면허로 운전하면 돼요."

→ ❌ 차량 구매 = 자유. 단, Rego + CTP + Stamp Duty 의무. 한국 면허 = 영문 번역본 (영사관) + 3개월만 운전 가능. 이후 호주 면허 전환 의무.

---

## ✅ 정답

**차량 구매 절차**:
1. 차량 검색: Carsales, Gumtree, 페이스북
2. PPSR 조회 ($2): 담보 여부 확인 (필수)
3. 시승 + 정비 점검 (NRMA $200~$300)
4. 가격 협상 + RWC (Roadworthy Certificate) 확인
5. NSW: Rego 이전 (RMS) + Stamp Duty (3% + $1,348/일정 금액)

**필수 비용**:
- Stamp Duty NSW: 3% + $1,348 (가격대별 추가)
- Rego (등록): 6개월 $370 / 연 $740
- CTP (Green Slip): $400~$700/년 (의무)
- Comprehensive 보험: $800~$2,000/년 (선택)
- Pink Slip (Safety Check): $35 (5년 이상 차량 의무)

**한국 면허 사용**:
- 한국 면허 영문 번역본 (시드니 영사관 무료) + IDP (한국 운전면허시험장) 또는 NAATI 번역
- 호주 도착 후 3개월 운전 가능
- 이후 호주 면허 전환 (NSW: RMS 직접 신청)

**한국 면허 → NSW 면허 전환**:
- RMS 방문 + 한국 면허 영문 번역
- Knowledge Test (필기) + Driving Test (실기)
- $58.40 (Photo Card) + $187 (Test)

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. PPSR (Personal Property Securities Register)**
ppsr.gov.au. 차량 담보 + 도난 차량 조회 ($2). 미조회 + 담보 차량 구매 = 채권자 회수 위험.

**2. Rego (Registration)**
주별 차량 등록. NSW: RMS, VIC: VicRoads. 매년 (또는 6개월) 갱신. CTP 포함.

**3. CTP vs Comprehensive**
CTP (Green Slip) = 인사 보상만 의무. Comprehensive = 차량 손해 + 도난 + 제3자. TPP = 제3자 손해만.

**4. RWC / Pink Slip**
VIC: RWC (Roadworthy Certificate) = 매매 시 의무. NSW: Pink Slip = 5년 이상 차량 매년 의무.

**5. Stamp Duty NSW**
$45,000 미만 = 3%. $45,000+ = 5%. 추가 $1,348 (수수료 + 처리). 면제 X.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 차량 검색: Carsales/Gumtree (예산 $8,000)
**2단계**: PPSR 조회 ($2) + NRMA 정비 점검 ($300)
**3단계**: 가격 협상 + Roadworthy/Pink Slip 확인
**4단계**: RMS 방문: Rego 이전 + Stamp Duty 납부
**5단계**: 보험 가입: CTP 의무 + Comprehensive 선택

---

## 💡 직원이 학생한테 말할 멘트

> "학생비자도 차량 구매 가능해요. 8천 불이면 Stamp Duty 약 $240 + Rego 6개월 $370 + CTP $500 = 추가 $1,100~$1,300 예산 잡으세요. PPSR 조회 ($2) 필수고 NRMA 정비 점검 ($300) 강추예요. 한국 면허는 영문 번역본 (영사관 무료)으로 3개월 운전 후 NSW 면허 전환 권장합니다. 자세한 절차는 윌슨 1:1 상담 가능해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **학생비자 = 차량 구매 X**
   → 구매 자유. 등록 + 보험만 의무.

2. **한국 면허로 영구 운전 OK**
   → 3개월만. 이후 호주 면허 전환 의무.

3. **CTP만 가입 = 안전**
   → CTP = 인사만. 차량 손해 = Comprehensive 별도.

4. **Stamp Duty 면제 가능**
   → 면제 X. NSW 3% (가격대별).

5. **PPSR 생략 OK**
   → 담보 차량 구매 = 채권자 회수. $2 필수 조회.

6. **Pink Slip 매년 OK**
   → 5년 이상 차량만 의무. 신차 면제.

7. **국제운전면허증 (IDP) 영구 OK**
   → 1년 한도 + 호주는 한국 면허 + 번역 인정.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 예산 (구매가 + 추가 $1,100~$1,300)
2. 차량 연식 (5년 이상 = Pink Slip 의무)
3. 한국 면허 보유 + 영문 번역본
4. NSW vs VIC vs QLD 등록 주

---

## 🔍 직원이 직접 확인 가능한 사이트

- PPSR: ppsr.gov.au
- NSW Rego: service.nsw.gov.au/transaction/register-a-vehicle
- Carsales: carsales.com.au
- NRMA: mynrma.com.au
- 시드니 한국 영사관 (면허 번역): overseas.mofa.go.kr/au-sydney-ko

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 예산 + 추가 비용 시뮬레이션
- 한국 면허 → 호주 면허 전환 절차
- 출국 시 차량 매각 + Rego 환불

**MARA / 변호사 영역**
- 사고 발생 시 인사 변호사
- 보험 분쟁 시 AFCA 신고

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생비자 구매 가능 안심
- [ ] Stamp Duty + Rego + CTP 의무 강조
- [ ] PPSR $2 조회 필수
- [ ] 한국 면허 3개월 한도 정확 안내
- [ ] Comprehensive 보험 권장
- [ ] NRMA 정비 점검 강추
- [ ] 윌슨 1:1 상담 자연 유도
