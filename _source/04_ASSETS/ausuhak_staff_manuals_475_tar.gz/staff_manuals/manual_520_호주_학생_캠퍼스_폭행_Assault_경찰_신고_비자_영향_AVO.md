# #520 호주_학생_캠퍼스_폭행_Assault_경찰_신고_비자_영향_AVO

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "캠퍼스에서 다른 학생한테 맞았어요. 경찰 신고하면 비자 영향 있어요? 가해자 처벌 받게 할 수 있어요?"

**직원 멘붕 포인트:**
- Common Assault: 6개월~5년 징역 (호주 형사)
- 피해자 비자 영향 X (가해자 비자 영향 있음)
- AVO (Apprehended Personal Violence Order) 신청 가능
- 응급실 진단서 + Police Report 필수
- 직원이 'Assault 가벼움' 안내 X. 형사 사건

---

## ❌ 절대 하지 말아야 할 답

> "캠퍼스 다툼은 학교에서만 처리하면 돼요"

→ ❌ 신체 폭력은 형사 사건 + AVO 신청 + 보상 청구 가능

---

## ✅ 정답

캠퍼스 폭행은 명백한 형사 사건(Common Assault)이에요. 즉시 (1) 응급실 진단서, (2) 경찰 131 444 신고 + Police Report, (3) AVO(Apprehended Personal Violence Order) 신청, (4) 학교 Sexual/Physical Misconduct Office 신고하세요. 피해자 비자 영향 절대 없습니다(가해자만 영향). Crime Victims Compensation $1,500~$15,000 신청 가능하고, Civil Lawsuit으로 손해배상도 가능해요. 가해자가 학생이면 학교 처분(정학/제적)도 받습니다.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. Common Assault (NSW Crimes Act 1900)**
Section 61: Common Assault
- 6개월~5년 징역 (Local Court)
- $5,500~$22,000 벌금
- 또는 양형

Section 33: Wounding/GBH (중상)
- 25년 징역

Section 35: Reckless GBH
- 14년 징역

Section 59: Assault Occasioning ABH
- 5년 징역

**2. 피해자 즉시 절차**
1. 응급실 (부상 시)
   - 진단서 + Discharge Summary
   - 사진 (멍/상처)
2. 경찰 131 444 (Non-emergency)
   - 또는 000 (응급)
   - Police Report
3. AVO 신청 (접근 금지)
4. 학교 신고 (가해자 학생인 경우)
5. Crime Victims Compensation
6. Civil Lawsuit 자문

**3. AVO (Apprehended Personal Violence Order)**
AVO 종류:
- ADVO (Domestic): 동거 가족
- APVO (Personal): 비동거
캠퍼스 폭행 → APVO

법원 명령:
- 가해자 접근 금지 (100m)
- 학교 출입 금지 (가해자만)
- 연락 금지
- 위반 시 즉시 체포 + 형사

신청:
- 경찰 통해 또는 본인 직접
- Local Court 무료
- 처리 1~3주 (Provisional 24시간)

**4. 비자 영향 (피해자 X / 가해자 O)**
피해자 (학생비자):
- 영향 X (절대)
- 오히려 보호 (Crime Victims)
- Special Consideration 학업

가해자 (학생비자):
- Section 116 NOICC (Character)
- 비자 취소 가능
- ART 항변 어려움 (Conviction 시)
- Section 501 Character Test
- 학교 제적 + 비자 취소 가능

**5. Crime Victims Compensation + Civil**
NSW Crime Victims Support:
- victimsservices.justice.nsw.gov.au
- 1800 633 063
- $1,500~$15,000 (피해 정도)
- 무료 신청
- Police Report + 진단서 첨부

Civil Lawsuit:
- Negligence + Battery
- 가해자 직접 손해배상 청구
- $5,000~$50,000+
- Civil Lawyer ($300~$500/시간)
- Limitation 6년

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 응급실 진단서 + 사진
**2단계**: 경찰 131 444 신고 + Police Report
**3단계**: AVO 신청 (Local Court)
**4단계**: 학교 Misconduct Office 신고
**5단계**: Crime Victims Compensation + Civil Lawsuit

---

## 💡 직원이 학생한테 말할 멘트

> "안녕하세요. 캠퍼스 폭행은 형사 사건이에요. 즉시 응급실 진단서 + 경찰 131 444 신고 + Police Report 받으세요. AVO 신청하면 가해자 접근 금지 명령 가능합니다. 피해자 비자 영향 절대 없으니 안심하세요(가해자만 영향). Crime Victims Compensation $1,500~$15,000 신청 가능하고, Civil Lawsuit으로 손해배상도 가능해요. 자세한 안내는 카카오 ID studywilson 으로 연락주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **'다툼' 가벼움 X**
   → Common Assault 형사 사건

2. **학교만 처리 X**
   → 경찰 + 학교 둘 다

3. **피해자 비자 영향 X**
   → 절대 X. 가해자만

4. **진단서 안 받음 X**
   → 보상 청구 증거

5. **AVO 무관 X**
   → 접근 금지 즉시 보호

6. **Crime Victims 외국인 X**
   → 외국인 학생 가능

7. **Civil Lawsuit 무용 X**
   → $5,000~$50,000+ 가능

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사건 후 며칠? (24시간 미만/24시간~7일/7일+)
2. 응급실 갔어요? (예/아니오)
3. 경찰 신고했어요? (했다/안 했다)
4. 가해자 신원 알아요? (학생/외부인)

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW Police: 131 444
- AVO: lawaccess.nsw.gov.au
- Crime Victims: victimsservices.justice.nsw.gov.au
- Crimes Act NSW: legislation.nsw.gov.au
- Legal Aid NSW: legalaid.nsw.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 응급실 + 경찰 1차 안내
- AVO 절차 안내
- 비자 영향 X 안내
- Crime Victims Compensation 안내

**MARA / 변호사 영역**
- AVO 신청 (Lawyer)
- Civil Lawsuit (Civil Lawyer)
- Crime Victims (Lawyer)
- 비자 영향 (MARA - 가해자만)

---

## ✅ 완벽 응대 체크리스트

- [ ] 응급실 진단서 + 사진
- [ ] 경찰 131 444 + Police Report
- [ ] AVO 신청
- [ ] 학교 Misconduct 신고
- [ ] Crime Victims + Civil
