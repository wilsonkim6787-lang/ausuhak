# #346 호주_수의대_DVM_경로_AVMA_등록

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "저 한국에서 수의대 졸업했어요. 호주에서 수의사 활동 가능한가요? 학력 인증 + 면허 절차 알려주세요."

**직원 멘붕 포인트:**
- 한국 수의대 호주 인정?
- AVBC 시험?
- Bridging Course?
- 비용 + 기간?

---

## ❌ 절대 하지 말아야 할 답

> "한국 수의대면 호주에서 바로 수의사 가능해요."

→ ❌ AVBC + AVE 시험 + Bridging Course + 면허 등록 모름. 외국 의료 면허 자동 인정 X.

---

## ✅ 정답

**호주 수의사 = ① Doctor of Veterinary Medicine(DVM, 학사 후 4년) ② AVBC + AVE 시험(외국 수의사). 한국 수의대 자동 인정 X.**

**핵심 사실:**
- **DVM Graduate Entry**: 학사(Bachelor of Science 등) + GPA 평균 75%+ + GAMSAT 또는 인터뷰 + IELTS 7.0(각 7.0). 4년. 학비 $80,000~$95,000/년.
- **DVM 학교**: Sydney/Melbourne/UQ/Murdoch/Adelaide/James Cook/Charles Sturt 7개. 합격률 10~20%.
- **AVBC(Australasian Veterinary Boards Council)**: 외국 수의사 평가 기관. AVE(Australian Veterinary Examination) MCQ + Clinical 시험 필수.
- **AVE 시험**: MCQ(Multiple Choice $1,500) + Clinical($2,500). 합격 + IELTS 7.0(각 7.0) → AVBC 등록.
- **Bridging Course**: AVE 미통과 또는 부족 시 호주 수의대 1~2년 추가 (Murdoch/Sydney). 학비 $40,000~$60,000/년.
- **Veterinary Board 등록**: 각 주별 면허(NSW Vet Board, Vic Vet Board 등). 등록비 $400~$600/년.
- **PR 경로**: DVM 또는 AVBC 등록 → 직업 평가(VETASSESS) → 189/190 PR. MLTSSL 직업.

**경로:**
한국 수의대 평가 → DVM Graduate Entry vs AVBC AVE 결정 → 시험/학교 신청 → 면허 등록 → 수의사 활동

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. DVM Graduate Entry vs AVBC**
DVM = 호주 학사 후 4년 학위 추가 (한국 수의대 무관). AVBC = 한국 수의대 활용 + AVE 시험.

**2. AVE 시험**
AVBC MCQ + Clinical = 합격률 30~40%. 평균 1~2회 응시. 비용 $4,000~$5,000.

**3. DVM 학비**
$80,000~$95,000/년 × 4년 = $320,000~$380,000. 호주 의대 다음 비싼 학과.

**4. Bridging Course**
AVE 미통과 시 Murdoch/Sydney Bridging Year 1년. 학비 $40,000~$60,000. 졸업 후 면허 인정.

**5. Veterinary Board 등록**
주별 면허(NSW/VIC/QLD/SA/WA/TAS). 1주 등록 시 다른 주 이전 가능 (재등록).

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 한국 수의대 평가 + 영어 IELTS 7.0 준비
**2단계**: DVM Graduate Entry vs AVBC AVE 결정
**3단계**: DVM: GAMSAT/인터뷰 + 학사 평균 75%+ → 4년 학위
**4단계**: AVBC: MCQ + Clinical 시험 → 합격 → AVBC 등록
**5단계**: Bridging Course (필요 시) → 주별 Veterinary Board 등록 → 수의사 활동

---

## 💡 직원이 학생한테 말할 멘트

> "호주 수의대는 DVM Graduate Entry vs AVBC AVE 시험(외국 수의사) 두 경로가 완전히 다릅니다. 한국 수의대 + 면허도 자동 인정 X.

한국 수의대 졸업 연도 + 평균 + 한국 면허 보유 + 영어 점수 가지고 카카오 1:1 상담 신청해주세요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **한국 수의대 = 호주 자동**
   → ❌ AVE 시험 + 면허 등록 별개 절차.

2. **AVE = 한 번 합격**
   → ❌ 합격률 30~40%. 평균 1~2회.

3. **DVM = 학사 무관**
   → ❌ DVM Graduate Entry는 학사 평균 + 과학 학과 매칭 필요.

4. **수의대 = 의대보다 쉬움**
   → ❌ 수의대 합격률 10~20%로 의대와 비슷. 학비도 $80K+.

5. **주별 면허 = 자동 호환**
   → ❌ 주별 등록 별개. 다른 주 이주 시 재등록 + 추가 비용.

6. **Bridging = 1년 자동 면허**
   → ❌ Bridging 졸업 + 시험 통과 + 등록 절차 필요.

7. **AVBC = 한국 시험 가능**
   → ❌ AVE Clinical은 호주 현지 시험. 호주 입국 필수.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 한국 수의대 졸업 연도 + 평균 + 면허 보유
2. DVM Graduate Entry vs AVBC AVE 결정
3. 영어 IELTS 7.0(각 7.0) 준비 가능
4. 학비 ($80K~$95K/년) 또는 시험비 ($4K~$5K) 재정

---

## 🔍 직원이 직접 확인 가능한 사이트

- AVBC (avbc.asn.au)
- AVE 시험 (avbc.asn.au/AVE)
- 각 학교 DVM Admission
- 주별 Veterinary Board (NSW/VIC/QLD)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- DVM vs AVBC 결정 + 시험/학교 신청 가이드
- Bridging Course 옵션 + 면허 등록
- 졸업 후 수의사 직장 + PR 가이드

**MARA / 변호사 영역**
- AVBC 등록 거부 + 항소 (AVBC + 변호사)
- PR 신청 + 직업 평가(VETASSESS) (MARA)
- AVE 시험 분쟁 (AVBC + 변호사)

---

## ✅ 완벽 응대 체크리스트

- [ ] 한국 수의대 평가 + 영어 7.0 준비
- [ ] DVM vs AVBC AVE 결정
- [ ] AVE MCQ + Clinical 응시 (AVBC)
- [ ] DVM 신청 (학사 평균 75%+) 또는 Bridging Course
- [ ] 주별 Veterinary Board 등록 + 면허비
- [ ] 졸업 후 485 (Post-Higher Education) + PR 직업 평가(VETASSESS)
- [ ] 한국 수의사 면허 호주 면허 전환 평가
