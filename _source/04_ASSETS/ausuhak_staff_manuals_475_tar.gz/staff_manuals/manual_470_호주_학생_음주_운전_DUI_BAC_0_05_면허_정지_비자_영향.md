# #470 호주_학생_음주_운전_DUI_BAC_0_05_면허_정지_비자_영향

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "시드니에서 친구들이랑 술 한 잔 마시고 운전했는데 RBT(음주측정)에 걸렸어요. BAC 0.07 나왔다고 해요. 면허 정지 + 벌금 받을 것 같은데 비자에도 영향 있나요? 한국 면허로 운전했는데 한국 면허도 정지되나요? 변호사 필요한가요?"

**직원 멘붕 포인트:**
- 호주 BAC 0.05 한도 / 학습/임시 면허 0.00
- BAC 0.05~0.08 = Low Range / Mid 0.08~0.15 / High 0.15+
- 면허 정지 + 벌금 + 형사 기록(Criminal Record)
- 비자 Character Test 영향 가능 (Mid/High Range)
- 한국 면허 = 한국 면허 정지 X (호주 운전권만 정지)
- Drink Driving Education Program 의무

---

## ❌ 절대 하지 말아야 할 답

> "BAC 0.07이면 약하니까 그냥 벌금만 내면 돼요"

→ ❌ BAC 0.05+ = 형사 기록 / Mid Range 0.08+ = 형사 + 비자 영향 가능 / 변호사 자문 필수 / 정확한 안내 + Section 10 적용 가능

---

## ✅ 정답

(1) 변호사 즉시 - LawAccess 1300 888 529 무료 (2) Section 10(NSW) 신청 - 유죄 인정 + Conviction X (3) Drink Driving Education Program 등록 - 의무 (4) 면허 정지 기간 + Interlock 장치 - BAC 0.08+ (5) 비자 Character 영향 - Mid/High Range 변호사 검토

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. BAC(혈중 알코올) 한도 (NSW 기준)**
Full License: 0.05 / Learner/Provisional/Heavy Vehicle/Public Vehicle: 0.00 / 학생비자 한국 면허 사용: 0.05 / Special Range(0.00~0.05 학습자) / Low(0.05~0.08): 벌금 $580~$2,200 + 면허 정지 3~6개월 / Mid(0.08~0.15): 벌금 $2,200~$3,300 + 6~12개월 / High(0.15+): 벌금 $3,300~$5,500 + 12~24개월.

**2. Section 10 NSW (Conviction X)**
Crimes (Sentencing Procedure) Act 1999 s.10 / 유죄 인정 + Conviction 기록 X / Drink Driving 첫 위반 일부 적용 / 변호사 신청 / 비자 Character Test 영향 X / 단, Mid/High Range 적용 어려움.

**3. Drink Driving Education Program (의무)**
Sober Driver Program(NSW) / Drink Drivers' Education Program(VIC) / 8주 / $200~$400 / Group Counseling / 의무 출석 / 미참석 시 면허 회복 X / 학생비자 OK.

**4. Interlock 장치 (BAC 0.08+)**
Mandatory Interlock Program / 차량 시동 전 음주 측정 / 12개월~5년 / 본인부담 $1,500~$2,500 / 학생비자도 의무 / 무시 시 면허 영구 박탈.

**5. 비자 Character Test (Section 501)**
Migration Act s.501 / Substantial Criminal Record(12개월+ 징역) / Drink Driving = 보통 징역 X / Low Range = 영향 X / Mid/High Range + 사고 = 비자 거절/취소 가능 / 변호사 필수 / Section 10 받으면 안전.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 음주측정 + 경찰 조서 - Notice to Appear in Court 받음
**2단계**: 2차: LawAccess 1300 888 529 (한국어 통역) 무료 자문 - 24~48시간 내
**3단계**: 3차: 변호사 선임 - Drink Driving 전문 / Section 10 신청
**4단계**: 4차: Local Court 출석 - 변호사 동행 / 첫 위반 + Section 10 + Education Program
**5단계**: 5차: 면허 회복 + Interlock(BAC 0.08+) + 비자 영향 변호사 검토

---

## 💡 직원이 학생한테 말할 멘트

> "BAC 0.07 = Low Range입니다(NSW 기준). 변호사 즉시 자문 권장합니다 - LawAccess 1300 888 529 무료입니다. 첫 위반 + Section 10 신청하면 Conviction 없이 끝낼 수 있습니다. 의무: Sober Driver Program 8주 + 면허 정지 3~6개월 + 벌금 $580~$2,200입니다. 한국 면허는 영향 없고 호주 운전권만 정지됩니다. 비자 Character Test 영향 = Low Range 거의 X / Mid Range(0.08+) = 변호사 검토 필요입니다."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **BAC 0.05 한도 학생 자주 위반**
   → 한국 0.03 / 호주 0.05 / 학생 '안전' 잘못 이해 / 와인 1잔 + 30분 = BAC 0.04~0.06.

2. **Provisional/Learner 0.00**
   → 처음 호주 면허 학생 = Provisional / 0.00 한도 / 학생비자 한국 면허 = Full 면허 0.05.

3. **Low Range 비자 영향 거의 X**
   → BAC 0.05~0.08 = Low / 보통 비자 영향 X / 단, 사고 + 인적 피해 = 형사 / 비자 영향.

4. **Mid/High Range 비자 영향**
   → BAC 0.08+ + 사고 = Section 501 Character / 비자 거절 가능 / 변호사 필수.

5. **한국 면허 한국 정지 X**
   → 호주 운전권만 정지 / 한국 도로교통공단 별도 / 단, 형사 기록 = 한국 영사관 통보 가능(드물게).

6. **Section 10 Mid/High X**
   → BAC 0.05~0.08 = Section 10 가능 / 0.08+ = 거의 불가 / 변호사 첫 위반 강조.

7. **Interlock 비용 + 시간**
   → Interlock 12개월 = $1,500~$2,500 / 매월 점검 / 학생비자 비용 부담 / 차량 1대 한정.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. (
2. 1
3. )
4.  
5. B
6. A
7. C
8.  
9. 정
10. 확
11.  
12. 수
13. 치
14. /
15. 시
16. 간
17. /
18. 장
19. 소
20. ?
21.  
22. (
23. 2
24. )
25.  
26. 사
27. 고
28.  
29. 인
30. 적
31.  
32. 피
33. 해
34. ?
35.  
36. (
37. 3
38. )
39.  
40. 첫
41.  
42. 위
43. 반
44.  
45. v
46. s
47.  
48. 재
49. 범
50. ?
51.  
52. (
53. 4
54. )
55.  
56. 한
57. 국
58.  
59. 면
60. 허
61.  
62. v
63. s
64.  
65. 호
66. 주
67.  
68. 면
69. 허
70. ?

---

## 🔍 직원이 직접 확인 가능한 사이트

- Transport for NSW(transport.nsw.gov.au), VicRoads(vicroads.vic.gov.au), TMR QLD(tmr.qld.gov.au), LawAccess NSW(lawaccess.nsw.gov.au), Drink Driving Australia(legalaid.nsw.gov.au)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- BAC 한도 안내 / Section 10 / Education Program / Interlock / 면허 정지 / 한국 면허 영향 X / Wilson 변호사 연결

**MARA / 변호사 영역**
- Section 10 신청 → 변호사 / 비자 Character 영향 → 이민 변호사 / Mid/High Range 사고 → 형사 변호사 / Interlock 면제 → 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] □
- [ ]  
- [ ] B
- [ ] A
- [ ] C
- [ ]  
- [ ] 수
- [ ] 치
- [ ]  
- [ ] 확
- [ ] 인
- [ ]  
- [ ] □
- [ ]  
- [ ] 변
- [ ] 호
- [ ] 사
- [ ]  
- [ ] 즉
- [ ] 시
- [ ]  
- [ ] 자
- [ ] 문
- [ ] (
- [ ] L
- [ ] a
- [ ] w
- [ ] A
- [ ] c
- [ ] c
- [ ] e
- [ ] s
- [ ] s
- [ ]  
- [ ] 1
- [ ] 3
- [ ] 0
- [ ] 0
- [ ]  
- [ ] 8
- [ ] 8
- [ ] 8
- [ ]  
- [ ] 5
- [ ] 2
- [ ] 9
- [ ] )
- [ ]  
- [ ] □
- [ ]  
- [ ] S
- [ ] e
- [ ] c
- [ ] t
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] 1
- [ ] 0
- [ ]  
- [ ] 신
- [ ] 청
- [ ]  
- [ ] □
- [ ]  
- [ ] E
- [ ] d
- [ ] u
- [ ] c
- [ ] a
- [ ] t
- [ ] i
- [ ] o
- [ ] n
- [ ]  
- [ ] P
- [ ] r
- [ ] o
- [ ] g
- [ ] r
- [ ] a
- [ ] m
- [ ]  
- [ ] 의
- [ ] 무
- [ ]  
- [ ] □
- [ ]  
- [ ] 한
- [ ] 국
- [ ]  
- [ ] 면
- [ ] 허
- [ ]  
- [ ] 영
- [ ] 향
- [ ]  
- [ ] X
- [ ]  
- [ ] □
- [ ]  
- [ ] M
- [ ] i
- [ ] d
- [ ] /
- [ ] H
- [ ] i
- [ ] g
- [ ] h
- [ ]  
- [ ] R
- [ ] a
- [ ] n
- [ ] g
- [ ] e
- [ ]  
- [ ] 비
- [ ] 자
- [ ]  
- [ ] 변
- [ ] 호
- [ ] 사
- [ ]  
- [ ] □
- [ ]  
- [ ] I
- [ ] n
- [ ] t
- [ ] e
- [ ] r
- [ ] l
- [ ] o
- [ ] c
- [ ] k
- [ ]  
- [ ] 안
- [ ] 내
