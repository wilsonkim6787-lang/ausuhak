# #411 호주_의료_사고_HCCC_AHPRA_의사_과실_보상_Medical_Negligence

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "병원에서 수술 잘못돼서 후유증 생겼어요. 의사가 책임 안 진다고 하고, 병원도 모른다고 해요. 학생비자인데 어떻게 해야 하나요? 한국으로 돌아가서 치료받아야 하는데 비용 누가 내야 하나요?"

**직원 멘붕 포인트:**
- 의료 과실 신고 어디로 하는지 모름
- AHPRA vs HCCC 차이 헷갈림
- OSHC가 의료 과실 보상도 해주는지
- 학생비자로 소송 가능한지
- 한국 귀국 후 치료비 청구 가능 여부

---

## ❌ 절대 하지 말아야 할 답

> "OSHC가 다 해줘요 / 그냥 한국 가서 치료받으세요"

→ ❌ ❌ 위험. OSHC는 의료 서비스 보상이지 의료 과실 보상이 아님 (별개). 한국 귀국 후 호주 의사 책임 묻기 매우 어려움. 시효 (보통 3년) + 증거 보존 필요.

---

## ✅ 정답

의료 과실(Medical Negligence) 신고 = 1) AHPRA(개인 의사 등록 취소/제재) 2) HCCC NSW (Health Care Complaints Commission, 주별 다름) 3) Personal Injury Lawyer (보상 소송, No Win No Fee 多). OSHC는 의료비 보상이지 과실 보상 아님. 의료기록 즉시 확보(Privacy Act 1988으로 본인 권리). 시효 3년 (NSW Limitation Act). 한국 귀국 전 호주 변호사 위임장 작성. 보상금 가능 케이스 $50K~$수백만.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. AHPRA vs HCCC 차이**
AHPRA(Australian Health Practitioner Regulation Agency, ahpra.gov.au) = 의료인 등록/제재 기관. 의사/간호사/한의사/물리치료사 등 14개 직군 등록 관리. 신고 시 면허 정지/취소/조건부. 보상 X. HCCC NSW(Health Care Complaints Commission, hccc.nsw.gov.au) = NSW 의료 서비스 신고/조사. 다른 주 - VIC: HCC, QLD: OHO. 환자 권리 보호 + 시스템 개선 권고. 보상 X (소송으로 가야 함).

**2. Personal Injury Lawyer / No Win No Fee**
의료 과실 = Negligence Tort 소송. 4가지 입증: 1) Duty of Care 2) Breach 3) Causation 4) Damage. Maurice Blackburn, Slater & Gordon, Shine Lawyers 등 'No Win No Fee' 방식 (이기면 30~40% 수수료, 지면 무료). 무료 초기 상담. 의학 감정인(Independent Medical Expert) 보고서 필수 ($3K~$10K). 평균 사건 1~3년.

**3. OSHC가 보상 안 하는 이유**
OSHC는 의료비(Hospital, GP, Specialist) 청구만 커버. 의사가 잘못해서 더 큰 의료비 발생 시 → OSHC가 그 추가 의료비 일부 커버 (Public Hospital 80%, Private 가입 등급별). 그러나 후유 장애 / 정신적 고통 / 미래 소득 손실 / 간병비 = OSHC 커버 X. Medical Negligence 보상은 별도 소송 또는 Indemnity Insurance(의사 가입 보험)에서 해결.

**4. 의료기록 확보 권리 (Privacy Act 1988)**
Australian Privacy Principles 12: 환자는 본인 의료기록 열람 권리. 병원에 서면 요청 → 30일 내 제공 의무. 비용 $30~$300 (사진 복사). 거부 사유 (위험/제3자 권리 침해 등) 매우 제한적. 의료 과실 의심 시 즉시 요청 (병원이 수정/삭제 전). Pathology 결과, X-ray, MRI, Operation Note, Nursing Note 모두.

**5. 시효 + 한국 귀국 처리**
Limitation Act 1969(NSW): Personal Injury 3년 시효 (사고 인지일 또는 18세 도달일). 학생비자 한국 귀국 후에도 호주 변호사가 진행 가능 (위임장 + 한국 주소 통신). 보상금은 호주 계좌로 입금 가능. 한국에서 서명한 진술서는 영사관 공증(Apostille). 화상 회의로 진행 多. 단, 변호사 비용 + 의학 감정 비용 선납이 부담스러우면 No Win No Fee 변호사 선택.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1단계 (즉시): 본인 의료기록 전체 서면 요청 - 병원 Medical Records Department
**2단계**: 2단계 (1주일 내): Personal Injury Lawyer 무료 초기 상담 (Maurice Blackburn 1800 810 812 등)
**3단계**: 3단계: AHPRA 신고(의사 면허) + HCCC/OHO 신고(시스템) 병행
**4단계**: 4단계: 변호사 위임 → No Win No Fee 계약 → 의학 감정 진행
**5단계**: 5단계: 한국 귀국 시 변호사 위임장 + 화상회의로 소송 진행 (시효 3년 내)

---

## 💡 직원이 학생한테 말할 멘트

> "정말 힘드시겠어요. 차근차근 짚어드릴게요.

먼저 가장 중요한 것: 의료기록을 즉시 서면으로 요청하세요. 병원이 수정/삭제 전에 확보하는 게 핵심입니다. Privacy Act 1988에 따라 30일 내 제공 의무예요.

신고/보상 경로 3가지가 있어요:
1) AHPRA (ahpra.gov.au) - 의사 면허 제재 (보상 X)
2) HCCC NSW(또는 거주 주 기관) - 의료 시스템 신고 (보상 X)
3) Personal Injury Lawyer - 실제 보상 소송

OSHC는 일반 의료비만 커버해서 후유증/장애/소득손실/간병비는 OSHC로 보상 안 됩니다. 그건 의료과실 소송으로만 가능해요.

Maurice Blackburn, Slater & Gordon 같은 No Win No Fee 변호사가 무료 초기 상담 해주고 이기면 30~40% 수수료, 지면 무료입니다.

시효가 NSW 기준 3년이니까 한국 귀국 전에 변호사 위임장 만들어두시면 한국에서도 진행 가능해요.

비자 영향 + 학업 중단 + 한국 귀국 후 추가 치료 등 종합적으로 봐야 하니 윌슨 카톡(studywilson)으로 사고 경위와 의료기록 일부 보내주세요. MARA 변호사 + Personal Injury 변호사 협업 케이스로 안내드릴게요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **OSHC가 의료 과실 보상한다고 안내**
   → ❌ 거짓. OSHC는 의료 서비스 비용 커버. 과실 보상은 별도 소송 또는 의사 Indemnity Insurance.

2. **AHPRA에 신고하면 돈 받는다고 안내**
   → ❌ 거짓. AHPRA는 면허 제재만. 보상 절차 없음.

3. **학생비자라 소송 못 한다고 안내**
   → ❌ 거짓. 비자 종류 무관. 모든 거주자 권리 동일.

4. **한국 가서 한국 변호사 통해 호주 의사 소송한다고 안내**
   → ❌ 거짓. 호주 의사는 호주 법원 관할. 호주 변호사만 가능.

5. **시효 5년이라고 안내**
   → ❌ 거짓. NSW Personal Injury 3년 (다른 주 비슷, VIC도 3년). 시효 지나면 소송 자체 불가.

6. **의료기록 병원이 안 줘도 된다고 안내**
   → ❌ 거짓. Privacy Act 1988으로 환자 권리. 거부 시 OAIC(개인정보위원회) 신고.

7. **No Win No Fee 변호사 무료라고 안내**
   → ❌ 부분 거짓. 변호사비는 무료지만 의학 감정 + 법원 비용 등 Disbursement는 일부 본인 부담 케이스. 계약서 확인.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 사고 시점 (시효 3년 - NSW 기준)
2. 현재 후유증 상태 (의학 감정 가능 여부)
3. 의료기록 확보 여부
4. 한국 귀국 일정 (위임장 사전 준비)

---

## 🔍 직원이 직접 확인 가능한 사이트

- AHPRA: ahpra.gov.au
- HCCC NSW: hccc.nsw.gov.au
- Maurice Blackburn: 1800 810 812 / mauriceblackburn.com.au
- OAIC (Privacy 신고): oaic.gov.au
- Legal Aid NSW: 1300 888 529

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 비자 영향 평가 (학업 중단 + LOA + 비자 연장)
- 한국 귀국 + 호주 소송 진행 코디네이션
- MARA 변호사 + Personal Injury 변호사 협업 케이스 연결

**MARA / 변호사 영역**
- Personal Injury 소송 - Personal Injury Lawyer (No Win No Fee)
- AHPRA / HCCC 신고 - Health Lawyer 또는 직접
- 비자 + 의료 영향 - MARA 변호사
- 장애 등급 평가 → 비자 의료 검진 영향 - MARA + 의료 변호사

---

## ✅ 완벽 응대 체크리스트

- [ ] AHPRA / HCCC / Personal Injury 3가지 경로 안내
- [ ] OSHC vs Medical Negligence 차이 명확히
- [ ] 의료기록 즉시 확보 권리 안내
- [ ] No Win No Fee 변호사 무료 상담 안내
- [ ] 시효 3년 명시
- [ ] 한국 귀국 전 위임장 준비 안내
- [ ] Maurice Blackburn 등 변호사 연락처 제공
- [ ] 윌슨 카톡 종합 케이스 코디네이션 유도
