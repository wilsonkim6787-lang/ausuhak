# 매뉴얼 #152 - EOI / CoE / 입학 서류 발급

## 🎬 상황 시뮬레이션

**카카오 첫 메시지:**
> "호주 학교 EOI 받았는데 이게 뭐예요? CoE랑 다른가요? 비자 신청 어떻게 해요?"

**직원 멘붕 포인트:**
- EOI / Offer Letter / CoE 차이
- 비자 신청 순서
- 학생 서류 제출 단계

---

## ❌ 절대 하지 말아야 할 답
- "다 같은 거예요" (다름)
- "받으면 비자 바로" (CoE 발급 후 비자)
- "윌슨이 알아서" (직원도 기본 알아야)

## ✅ 정답
"EOI는 입학 가능 통보, CoE는 등록금 낸 후 정식 등록증이에요. 비자 신청은 CoE 받은 후예요. 어느 학교 어떤 코스 진행 중이세요? 윌슨 대표가 19년 경험으로 1:1 단계별 안내드려요. 카톡 ID studywilson 이에요."

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1. 입학 서류 4단계 (순서)

| 순서 | 영문명 | 한국어 | 의미 |
|---|---|---|---|
| 1 | Application | 입학 신청 | 학생이 학교에 신청 |
| 2 | **Offer Letter** | 입학 허가서 | 조건부 (Conditional) 또는 무조건 (Unconditional) |
| 3 | **EOI / Acceptance** | 입학 수락 | 학생이 학교에 OK 응답 |
| 4 | **CoE** (Confirmation of Enrolment) | 정식 등록증 | 등록금 납부 후 |

### 2. Offer Letter 종류

**Conditional Offer (조건부)**:
- 영어 점수 부족 → IELTS 추가
- 학력 인증 미완 → 졸업증명서 + Apostille
- 재정증명 미완 → 통장 잔고

**Unconditional Offer (무조건)**:
- 모든 조건 충족
- 등록금 납부만 남음

### 3. CoE (Confirmation of Enrolment)

**발급 조건**:
- 1학기 등록금 납부 (보통 50% 또는 100%)
- OSHC 학생보험 가입 ($600~$2,000/년)
- 모든 서류 완료

**중요성**:
- 비자 신청 필수 (없으면 비자 신청 X)
- 학생 정보 정부 등록 (PRISMS 시스템)
- 학교 변경 시 CoE 취소/재발급

### 4. 비자 신청 순서

**Step 1**: 학교 입학 신청 → Offer Letter
**Step 2**: 학생 Offer 수락 + 등록금 납부
**Step 3**: 학교 CoE 발급
**Step 4**: 학생 OSHC 가입
**Step 5**: 비자 (subclass 500) 신청 - ImmiAccount
**Step 6**: GS Statement (Genuine Student) 작성
**Step 7**: 신체검사 + 영어 증명
**Step 8**: 비자 승인 (4-8주)

### 5. 학생 서류 일반 리스트

**한국 측 서류**:
- 여권 사본 (유효기간 6개월+)
- 졸업증명서 + Apostille
- 성적증명서 + Apostille
- 영어 점수 (IELTS/TOEFL/PTE)
- 재정증명 (통장 잔고)
- 부모 재정 보증 (학생인 경우)
- GS Statement (영문 에세이)
- 신원증명서 (Police Check)
- 한국 신체검사 결과

**호주 측 서류**:
- Offer Letter / CoE
- OSHC 보험증
- 호주 주소 (Address) - 임시 OK

---

## 🎯 이 학생에게 안내할 정답 경로

### Step 1: 현재 단계 확인
- Application? Offer? EOI? CoE? 비자?

### Step 2: 다음 단계 안내
- 단계별 다음 할 일

### Step 3: Conditional Offer 확인
- 조건 충족 안내

### Step 4: 윌슨 상담 연결
- 단계별 정확한 처리

---

## 💡 직원이 학생한테 말할 멘트

```
[입학 서류 단계 안내]
호주 입학은 4단계예요:

1️⃣ Offer Letter = 입학 허가서
   (Conditional 조건부 / Unconditional 무조건)

2️⃣ Acceptance = 학생 OK 응답

3️⃣ CoE = 등록금 납부 후 정식 등록증
   (비자 신청 필수)

4️⃣ Visa subclass 500 = 학생비자

지금 어느 단계세요?
정확한 다음 단계 윌슨 대표가 1:1 안내드려요.
ID: studywilson
```

```
[Conditional Offer 받음]
조건부 입학 받으셨군요!

▪️ 부족한 조건 = 영어? 학력? 재정?
▪️ 조건 충족 → Unconditional Offer 발급
▪️ 등록금 납부 → CoE 발급
▪️ CoE 받으면 비자 신청

조건 분석 + 처리 윌슨 대표가 1:1 도와드려요.
ID: studywilson
```

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

### 함정 1: "Offer = 비자"
**다름** - Offer는 학교 입학 OK. 비자 별도.

### 함정 2: "CoE 한 번 받으면 영원"
**아님** - 학교 변경 시 취소. 매 코스/Term 새 CoE.

### 함정 3: "OSHC = 호주 도착 후"
**아님** - CoE 받기 전 OSHC 가입. 학생비자 의무.

### 함정 4: "비자 신청 = 한국에서만"
**아님** - 호주 안에서도 가능 (관광/워홀 → 학생비자).

### 함정 5: "Conditional = 못 가는 거"
**아님** - 조건 충족시 Unconditional 변경. 일반적.

### 함정 6: "CoE = 학교 영원 등록"
**아님** - 학기별 갱신. 출석 미달 시 CoE 취소.

### 함정 7: "Offer 거절 가능"
**가능** - 학생이 거절 가능. 등록금 납부 전이면 Offer 무효.

---

## 📞 카카오 응대 시 필수 4가지 확인

```
[직원이 학생에게 물어볼 4가지]

1. 현재 어느 단계?
   (Application? Offer? CoE? 비자?)

2. 어느 학교 어떤 코스?

3. Offer 종류?
   (Conditional? Unconditional?)

4. 부족 조건은?
   (영어? 학력? 재정?)

→ 윌슨 카톡 연결: studywilson
```

---

## 🔍 직원이 직접 확인 가능한 사이트

- [PRISMS 시스템](https://prisms.education.gov.au/) - 정부 등록 (직원만 접근)
- [Department of Home Affairs 비자](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)
- [ImmiAccount](https://online.immi.gov.au/) - 비자 신청 시스템
- [DFAT Apostille](https://www.dfat.gov.au/about-us/services/authentications-and-apostilles)

---

## 🚨 직원 영역 vs 윌슨 영역

### 직원 영역
- 4단계 일반 안내
- 서류 리스트 안내
- Conditional vs Unconditional 차이

### 윌슨 영역 (1:1)
- 학생별 단계별 처리
- Conditional 충족 전략
- GS Statement 첨삭
- 비자 신청 직접 처리

---

## ✅ 완벽 응대 체크리스트

- [ ] 학생 현재 단계 파악
- [ ] 4단계 (Offer→Acceptance→CoE→Visa) 안내
- [ ] Conditional vs Unconditional 차이
- [ ] 서류 리스트 안내
- [ ] OSHC 가입 시기 안내
- [ ] 비자 처리 시간 안내
- [ ] 윌슨 카톡 연결 (studywilson)

---

**작성: 2026-05-04 **
**참조: PRISMS / ImmiAccount / Department of Home Affairs**
