# #460 호주_학생_일자리_못구함_Casual_Job_레쥬메_Cover_Letter

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주 와서 6개월 됐는데 아르바이트 자리 못 구해요. 한국 식당 같은 데서만 받아주는데 영어 안 늘고요. 카페/슈퍼마켓 지원해도 답이 없어요. 한국 학생들은 어떻게 일자리 구하나요? 영어 부족인가요?"

**직원 멘붕 포인트:**
- 한식당 = 한인 의존 (윌슨 6대 실패 패턴)
- 호주 레쥬메 = 한국과 형식 완전 다름
- Cover Letter 필수 (한국 자소서 X)
- Casual Job = 면접/Trial Shift 일반
- Tax File Number (TFN) 필수
- RSA(주류 자격증) 등 자격증 = 일자리 폭 확대

---

## ❌ 절대 하지 말아야 할 답

> "영어 부족이라 어쩔 수 없어요"

→ ❌ 영어 핑계 X / 한국 학생들 충분히 호주 일자리 구함 / 레쥬메/Cover Letter 형식 + 지원 채널 차이

---

## ✅ 정답

(1) 호주식 레쥬메 + Cover Letter 작성 (2) Seek/Indeed/Gumtree/직접 방문 (3) RSA/Barista 코스 등 자격증 (4) 한식당 탈출 = 영어 환경 (5) Trial Shift 적극

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 레쥬메 형식**
1~2장 / Personal Details(이름/연락처) / Summary(2~3문장) / Skills(불릿) / Work Experience(역순) / Education / References(2명, 'available on request' OK) / 사진 X / 나이 X / 결혼 X.

**2. Cover Letter (필수)**
1장 / 'Dear Hiring Manager' / 1단락=지원 동기 / 2단락=경력+Skill / 3단락=회사 기여 / 'Yours sincerely' / 한국 자소서식 X / 회사 맞춤 작성.

**3. 호주 일자리 채널**
Seek (seek.com.au, 대표 사이트) / Indeed / Jora / Gumtree (캐주얼) / 직접 매장 방문 + Resume 제출 (Cafe/Restaurant) / LinkedIn (전문직).

**4. RSA / Barista / White Card**
RSA (Responsible Service of Alcohol) = 카페/술집/마트 주류 판매 필수 ($50~$120, 4시간) / Barista (커피 만들기, $200) / White Card = 건설현장.

**5. Trial Shift / 면접**
캐주얼 잡 = 1~2시간 무급 Trial 일반 (호주 합법) / 면접 짧음(15~30분) / 'Tell me about yourself' / 'Why do you want to work here'

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 1차: 호주식 레쥬메 + Cover Letter 작성 (학교 Career Centre 무료)
**2단계**: 2차: TFN(Tax File Number) 발급 (ato.gov.au, 무료)
**3단계**: 3차: RSA + Barista 자격증 ($150~$300, 1~2일)
**4단계**: 4차: Seek/Indeed 온라인 + 직접 매장 방문 (CBD 카페/마트)
**5단계**: 5차: 한식당 탈출 (영어 환경 우선)

---

## 💡 직원이 학생한테 말할 멘트

> "답답하시겠어요. 영어 부족 핑계 마세요. 형식 + 채널 문제일 가능성 높습니다.

**한국 학생들이 흔히 빠지는 함정:**
1. 한식당만 지원 = 영어 안 늘고 (윌슨 6대 실패 패턴 = 한인 의존)
2. 한국식 자소서 그대로 = 호주 형식 X
3. Cover Letter 안 보냄 = 자동 거절
4. 자격증 없음 = 카페/술집 지원 거부

**호주 레쥬메 vs 한국 (다름):**
- 1~2장 (한국식 8~10장 X)
- 사진 X / 나이 X / 결혼 X
- Personal Statement + Skills + Experience + Education
- References 2명

**Cover Letter 필수:**
한국 자소서 형식 X. 1장. 회사별 맞춤. 'Dear Hiring Manager' 시작.

**즉시 할 일:**

1. **학교 Career Centre** 방문 - 레쥬메 무료 첨삭 (한국어 가능 일부)
2. **TFN 발급** (ato.gov.au, 무료, 1주)
3. **자격증 따기**:
   - **RSA** ($50~$120, 4시간) - 카페/술집/마트 주류 판매 필수
   - **Barista** ($200, 1일) - 카페 일자리 폭 확대
   - **White Card** - 건설현장
4. **Seek (대표 사이트) + Indeed + 직접 방문** (CBD 카페/마트, Resume 들고)
5. **한식당 탈출** - 영어 환경 우선

**Trial Shift:**
호주 캐주얼 잡 = 1~2시간 무급 Trial 일반. 합법 (Fair Work). 잘하면 채용.

학교/지역 알려주시면 한국어 가능 Career Centre + 자격증 학원 안내드릴게요. 레쥬메도 보여주시면 일반 피드백 드릴게요 (자세한 첨삭은 Career Centre)."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **영어 부족 = 일자리 못 구함**
   → 형식+채널+자격증이 더 큼 / 영어 중급도 캐주얼 잡 가능

2. **한국식 자소서 그대로**
   → 호주 형식 X / 자동 거절

3. **RSA는 비싸서 안 따도 됨**
   → $50~$120 / 카페/술집/마트 주류 = 필수 / 일자리 폭 5배

4. **Trial Shift 무급 = 사기**
   → Fair Work 합법 (1~2시간) / 학생들 흔히 무급 Trial 후 채용

5. **Seek만 보면 됨**
   → Seek + Indeed + Gumtree + 직접 방문 (Cafe/Restaurant 직방이 효과)

6. **한식당이 한국 학생 환영**
   → 한인 의존 패턴 / 영어 안 늘고 / 시간만 흘러감

7. **TFN 없어도 일 가능**
   → TFN 없이 일 = 세금 47% 원천징수 / 합법 X

---

## 📞 카카오 응대 시 필수 4가지 확인

1. 현재 호주 거주 기간
2. TFN 발급 여부
3. 자격증 보유 (RSA/Barista/White Card)
4. 지원 채널 (Seek/직접/한식당)

---

## 🔍 직원이 직접 확인 가능한 사이트

- seek.com.au (대표 사이트)
- indeed.com.au
- gumtree.com.au (캐주얼)
- ato.gov.au (TFN 무료 발급)
- fairwork.gov.au / 13 13 94 (한국어 - 임금/시간 분쟁)

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- 호주 레쥬메 형식 일반 안내
- Cover Letter 작성 일반 가이드
- 자격증(RSA/Barista) 일반 정보
- TFN 발급 안내
- 한식당 탈출 권고 (한인 의존 패턴)

**MARA / 변호사 영역**
- Tax File Number 발급 분쟁
- 임금 미지급 Fair Work 분쟁
- 비자 조건 위반 (주당 시간 초과)

---

## ✅ 완벽 응대 체크리스트

- [ ] 영어 핑계 X 강조
- [ ] 호주식 레쥬메/Cover Letter 안내
- [ ] 한식당 탈출 강조
- [ ] TFN 무료 발급 안내
- [ ] RSA/Barista 자격증 권장
- [ ] Seek + 직접 방문 채널 안내
- [ ] Trial Shift 합법 안내
- [ ] 학교 Career Centre 무료 안내
