# #352 호주_학생_한국_결혼_신고_절차_파트너_비자

## 🎬 상황 시뮬레이션

**카카오톡 첫 메시지:**
> "호주에서 만난 한국인 남자친구랑 결혼하려고요. 한국 결혼신고 어디서 하고 호주에서는 뭐 해야 돼요? 파트너 비자 받을 수 있나요?"

**직원 멘붕 포인트:**
- 한국 결혼신고 = 호주 영사관 vs 한국 직접 처리 헷갈림
- 호주 결혼식 vs 한국 결혼식 vs 동거 De facto 구분 못함
- 파트너 비자 (820/801) 자격 조건 모름
- 혼인관계증명서 발급 + Apostille 필요 여부
- 학생비자 → 파트너비자 전환 시점

---

## ❌ 절대 하지 말아야 할 답

> "결혼만 하시면 자동으로 파트너 비자 나와요."

→ ❌ 결혼 = 자동 비자 X. Subclass 820/801 별도 신청 필요. 신청 비용 $9,365 + 처리 12~24개월 + Sponsor 호주 시민/PR 필수.

---

## ✅ 정답

**한국 결혼신고**: 시드니 한국 영사관 또는 한국 가족관계등록소 직접 처리. 호주 결혼증명서 (Marriage Certificate) → Apostille → NAATI 번역 → 한국 제출. 또는 한국 일시 귀국 시 직접 신고.

**호주 결혼**: Births Deaths Marriages (BDM) 등록. NOIM (Notice of Intended Marriage) = 결혼식 1개월 전 제출. Celebrant 주관 결혼식 → Marriage Certificate 발급 ($60).

**파트너 비자 자격**: Sponsor = 호주 시민/PR/적격 NZ 시민. De facto 12개월 동거 또는 결혼 = 즉시 자격. Subclass 820 (임시) → 801 (영주) 2단계.

**예외**: De facto 12개월 미만 + 결혼 X = 자격 없음. Sponsor도 학생비자 = 자격 없음.

---

## 📖 직원이 먼저 공부해야 할 5가지

**1. 호주 결혼 등록 (BDM)**
Births Deaths Marriages = 주별 등록 기관. NSW: bdm.nsw.gov.au, VIC: bdm.vic.gov.au. NOIM 1개월 전 제출 의무.

**2. Celebrant 제도**
호주 = Celebrant (정부 인증 결혼 주례자) 의무. 종교 X 결혼식도 Celebrant 필수. 비용 $400~$1,500.

**3. Marriage Certificate 발급**
결혼식 후 BDM에 Celebrant 제출. 약 4주 후 정식 Certificate 발급. $60. 한국 제출용 = Apostille + NAATI 번역.

**4. Subclass 820/801 파트너 비자**
820 (임시 2년) → 801 (영주). $9,365 (2025). 처리 12~24개월. Sponsor = 호주 시민/PR/NZ. De facto 12개월 또는 결혼 자격.

**5. Bridging Visa A**
학생비자 → 820 신청 시 자동 Bridging Visa A. 처리 중 호주 거주 + 풀타임 근무 OK. 출국 시 Bridging B 별도 신청.

---

## 🎯 이 학생에게 안내할 정답 경로

**1단계**: 결혼 결정: Sponsor 자격 확인 (호주 시민/PR 여부)
**2단계**: 호주 결혼식: NOIM 제출 → Celebrant 예약 → 결혼식 → Marriage Certificate 발급
**3단계**: 한국 신고: 시드니 영사관 또는 한국 직접 (Apostille + 번역)
**4단계**: 파트너 비자 신청: 820 온라인 신청 (ImmiAccount) + Bridging Visa A 자동 발급
**5단계**: 2년 후: 801 영주 비자 자동 전환 심사

---

## 💡 직원이 학생한테 말할 멘트

> "축하드립니다. 한국 결혼신고는 시드니 영사관 또는 한국 직접 처리 가능하고, 호주에서는 BDM 등록 + Celebrant 결혼식 절차예요. 파트너 비자 (820/801)는 Sponsor가 호주 시민/PR이어야 자격 있고 비용 약 $9,365입니다. 학생비자 → 파트너 비자 전환은 윌슨 1:1 상담 필요해요."

---

## ⚠️ 직원이 헷갈리기 쉬운 함정

1. **결혼 = 자동 비자**
   → Subclass 820 별도 신청 필수 + $9,365 + 12~24개월.

2. **Sponsor도 학생비자 OK**
   → Sponsor 필수 = 호주 시민/PR/NZ. 학생비자 Sponsor 자격 X.

3. **De facto 6개월도 OK**
   → De facto 12개월 동거 의무. 미만 = 결혼 필수.

4. **호주 결혼식 = 자동 한국 인정**
   → Apostille + NAATI 번역 후 한국 제출 별도 절차.

5. **Celebrant 없이 결혼 OK**
   → Celebrant 의무. 종교 결혼도 Celebrant 자격 필요.

6. **파트너 비자 신청 중 출국 OK**
   → Bridging Visa A = 출국 불가. Bridging B 별도 신청.

7. **820 = 즉시 영주**
   → 820 = 임시 2년. 801 영주는 추가 심사.

---

## 📞 카카오 응대 시 필수 4가지 확인

1. Sponsor (파트너) 비자 상태 (시민/PR/학생/WHV)
2. 동거 기간 (De facto 12개월 충족 여부)
3. 결혼 장소 (호주 vs 한국)
4. 현재 학생비자 만료일 + 학기 진행

---

## 🔍 직원이 직접 확인 가능한 사이트

- NSW BDM: bdm.nsw.gov.au
- VIC BDM: bdm.vic.gov.au
- Subclass 820: immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/partner-onshore-820-801
- 시드니 한국 영사관: overseas.mofa.go.kr/au-sydney-ko
- DFAT Apostille: smartraveller.gov.au

---

## 🚨 직원 영역 vs 변호사/회계사 영역

**직원 영역 (OK)**
- 일반 절차 안내
- 기본 정보 + 서류 안내
- 윌슨 1:1 상담 자연 유도

**윌슨 영역**
- Sponsor 자격 검증 + 비자 전환 시점
- De facto 증명 서류 (공동 임대/통장/사진)
- 학생비자 만료 vs 파트너 비자 신청 타이밍

**MARA / 변호사 영역**
- 820/801 비자 신청 (MARA 등록 이민변호사)
- 거짓 결혼 의심 시 인터뷰 대응
- 이혼 시 비자 취소 + 가정폭력 조항

---

## ✅ 완벽 응대 체크리스트

- [ ] Sponsor 비자 상태 먼저 확인
- [ ] De facto 12개월 vs 결혼 자격 비교
- [ ] 한국 결혼신고 = 영사관/한국 양방향 안내
- [ ] Celebrant + NOIM 1개월 전 강조
- [ ] $9,365 + 12~24개월 정직 안내
- [ ] Bridging Visa A 자동 발급 안심 멘트
- [ ] 윌슨 1:1 상담 자연 유도
