# 📚 직원 응대 매뉴얼 #014

**케이스: 19세 / 한국 정규 고졸 / IELTS 5.5 / 학사 진학 + 1년 단축 / 7천만 예산**

---

## 🎬 상황 시뮬레이션

> 한국 일반고 졸업했고 IELTS 5.5 있어요. 호주 학사 가고 싶은데 1년 단축할 수 있는 방법 있다고 들었어요. 7천만까지 가능합니다.

**👉 정답**: **Diploma Pathway → Bachelor 2학년 직진**

---

## 📖 직원이 먼저 공부해야 할 5가지

### 1️⃣ Diploma Pathway = 학사 1년 단축 시스템

- 한국 정규 고졸 + IELTS 5.5+ 입학 가능
- Diploma 1년 = Bachelor 1학년 학점 인정
- 졸업 후 Bachelor 2학년 직진
- 결과: 학사 4년 → 3년 (1년 단축)

### 2️⃣ Diploma Pathway 학교 (Navitas, UTS Insearch 등)

| Pathway | 진학 가능 대학 | 학비 |
|---|---|---|
| UTS Insearch | UTS | $36K~$45K |
| WSU College | Western Sydney | $26K~$34K |
| SIBT | Macquarie | $30K~$38K |
| Curtin College | Curtin | $28K~$34K |
| Eynesbury | Adelaide University | $32K~$43K |
| Monash College | Monash | $36K~$45K (일부 학과만) |
| QIBT | Griffith | $28K~$34K |

### 3️⃣ Diploma 입학 조건

- 한국 정규 고졸 (Year 12 동등)
- IELTS 5.5 (각 영역 5.0~5.5) - 학교마다 약간 차이
- 학교 평균 C+ 이상

### 4️⃣ Foundation vs Diploma 차이

| 구분 | Foundation | Diploma |
|---|---|---|
| 진학 | Bachelor 1학년 | Bachelor 2학년 (1년 단축) |
| 기간 | 9~12개월 | 8~12개월 |
| 영어 | 5.5~6.0 | 5.5~6.5 |
| 학비 | $25K~$45K | $28K~$45K |
| 적합 | Go8 | 일반 대학 |

### 5️⃣ 7천만 예산 = 약 $50K AUD/년

- Diploma 1년 + Bachelor 2학년: 약 $30K + $40K = $70K → 빠듯
- 분할 납부 + 알바로 가능

---

## 🎯 정답 경로

### 한국 정규 고졸 + IELTS 5.5 → Diploma Pathway → Bachelor 2학년

```
한국 정규 고졸 + IELTS 5.5
        ↓
Diploma Pathway 1년 ($28K~$38K)
        ↓ 1년 학점 인정
Bachelor 2학년 직진 (2년) ($60K~$96K)
        ↓
졸업 + 485
```

**총 3년 / 학비 약 $90K~$140K (학교 따라 다름)**

---

## 💡 직원이 학생한테 말할 멘트

> "한국 정규 고졸 + IELTS 5.5 = Diploma Pathway 가능합니다. 학사 1년 단축돼요.
> 
> 1. **Diploma 1년 = Bachelor 1학년 학점 인정**
> 2. **Bachelor 2학년 직진** = 총 3년에 학사 졸업
> 3. **학교 옵션 多**: UTS Insearch (UTS), WSU College, SIBT (Macquarie), Curtin College, QIBT (Griffith), Eynesbury (Adelaide), Monash College
> 
> 7천만 예산이면 학교 따라 빠듯하지만 가능합니다. 시드니 주요 대학 (UTS) vs 학비 저렴 학교 비교해드릴 수 있어요.
> 
> 카톡으로 알려주세요:
> ① 희망 전공 (Business / IT / Engineering / 간호 등)  
> ② 도시 선호 (시드니 vs 멜번 vs Regional 도시)  
> ③ Go8 우선 vs 일반 대학 OK"

---

## ⚠️ 함정

1. **"검정고시도 Diploma 가능"** → 일부 학교만 / 사전 확인 필수
2. **"Diploma는 학사 미달"** → ❌ 1년 단축 효과 / 학사 졸업 동일
3. **"Foundation이 더 좋다"** → Go8 가면 Foundation / 일반 대학 가면 Diploma 효율적
4. **"Diploma는 학비 저렴"** → 학교 따라 다름 / Bachelor 학비도 합쳐 비교

---

## 📞 카카오 응대 시 필수

1. 희망 전공
2. 도시 선호
3. Go8 vs 일반 대학
4. 정규 고졸 vs 검정고시 (Diploma 인정 다름)

---

## 🔍 직원 확인 사이트

- UTS Insearch: insearch.edu.au
- WSU College: wsucollege.edu.au
- SIBT: sibt.nsw.edu.au
- Curtin College: curtincollege.edu.au
- Eynesbury: eynesbury.navitas.com
- 각 학교 IELTS 조건 확인
