# 🔧 Trade (기술직 — 셰프·정비·전기·용접·미용·배관·제빵)

> **모듈 타입**: 전공 / 직군
> **PR 적합도**: ⭐⭐⭐⭐⭐ (대부분 인력부족직군 — PR 골든 트랙)
> **마지막 검증**: 2026년 5월

---

## 📌 직군 개요

- **Trade(기술직) = 호주 인력부족직군 가장 활성화된 분야**
- **TRA(Trades Recognition Australia)** 직업평가 기관
- **검정고시·고졸·워홀러 PR 인기 트랙 1순위 중 하나**
- **2024-25 영주권 Top 10에 셰프·자동차정비사·용접사·제과제빵사 모두 포함**

### 한국 학생 인기 Trade 직군 7가지 (이번 모듈에서 다룸)
1. 🍳 셰프/요리사 (Chef/Cook)
2. 🔧 자동차 정비사 (Motor Mechanic)
3. ⚡ 전기 기능사 (Electrician)
4. 🔥 용접사 (Welder)
5. 💇 헤어드레서/미용사 (Hairdresser)
6. 🚿 배관공 (Plumber)
7. 🥖 제과제빵사 (Baker/Pastrycook)

---

## 🎓 공통 진학 루트 (모든 Trade 동일)

```
1. Cert III (1.5~2년) — 기본 자격증
2. Cert IV (6개월~1년) — 상급 자격증 (PR 필수)
3. Diploma (1년) — 추가 점수
4. TAFE 또는 사립 직업학교 (CRICOS 등록 필수)
```

### 입학 기준
| 항목 | 기준 |
|---|---|
| Cert III/IV IELTS | 5.5 (각 5.0) — Trade 중 가장 낮음 |
| Diploma IELTS | 5.5 (각 5.0) |
| 학력 | 고졸/검정고시/워홀러 모두 OK |

---

## 🛂 공통 PR 핵심: TRA Job Ready Program (JRP)

**이게 Trade PR의 핵심입니다.** 다른 직군과 다름.

```
JRP 4단계:
1단계 — Provisional Skills Assessment (학위 + 영어로 신청)
2단계 — Job Ready Workplace Assessment (호주 직장 12개월 경력 필수)
3단계 — Job Ready Employment Assessment (직무 평가)
4단계 — Job Ready Final Assessment (최종 직업평가서 발급)
```

### ⚠️ JRP 필수 조건
- **호주 정식 직장 12개월 경력** (페이슬립 받는 정식 직장)
- **Cash 알바 X** — 무조건 정식 고용
- **주 30시간 이상 풀타임 근무**
- **485 비자 동안 진행** (Diploma 졸업 후 1.5~2년)

⭐ **자세한 가이드는 05_비자PR_모듈/05_직업평가 참조**

---

## 🍳 1️⃣ 셰프/요리사 (Chef/Cook)

> **2024-25 영주권 Top 10 중 4위** — 가장 인기 Trade 직군
> **ANZSCO**: Chef 351311 / Cook 351411

### 진학 루트
```
Cert III in Commercial Cookery (1년) 
→ Cert IV in Kitchen Management (6개월) 
→ Diploma/Advanced Diploma of Hospitality Management (1년)
= 약 2~2.5년 패키지
```

### 추천 학교
- **Le Cordon Bleu** (시드니/멜번/애들레이드) — 세계 명문
- **William Blue College** (시드니) — Hospitality 명문
- **TAFE NSW / TAFE QLD** — 정부 운영
- **TasTAFE** (호바트) — 지방 보너스
- **Box Hill Institute** (멜번)

### PR 경로
```
Cert III + IV + Diploma → TRA JRP (호주 셰프 12개월 경력)
→ 485 비자 → 190/491 PR
```

### Wilson 핵심 팁
- **2024-25 데이터**: 셰프 PR의 50% 이상이 **고용주 스폰**
- 점수보다 **어떤 호텔·레스토랑에서 경력 쌓느냐**가 핵심
- 지방 호텔 (TAS/SA/Greater Perth) 강력 추천

---

## 🔧 2️⃣ 자동차 정비사 (Motor Mechanic)

> **2024-25 영주권 Top 10에 포함** — 안정적 PR 트랙
> **ANZSCO**: 321211 (Motor Mechanic - General)

### 진학 루트
```
Cert III in Light Vehicle Mechanical Technology (2년)
→ Cert IV in Automotive Mechanical Diagnosis (6개월)
→ Diploma of Automotive Management (1년 옵션)
= 약 2.5~3년
```

### 추천 학교
- **TAFE NSW** (시드니)
- **TAFE Queensland** (브리즈번)
- **TAFE SA** (애들레이드) — 지방 PR ⭐
- **South Metropolitan TAFE** (퍼스) — 지방 PR ⭐
- **Kangan Institute** (멜번)
- **Academique** (골드코스트) — 한국 유학생 인기

### PR 경로
```
Cert III/IV + 호주 정비소 12개월 경력 (JRP)
→ 485 또는 482 → 190/491 PR
```

### Wilson 핵심 팁
- **"점수가 아니라 사람을 못 구해서 PR 되는 직업"**
- 지방 정비소 = **고용주 스폰 사례 활발**
- 한국 자동차 정비 경력자 → **호주에서 매우 환영**
- 추천 지역: **퍼스, 애들레이드, 골드코스트, 호바트**

---

## ⚡ 3️⃣ 전기 기능사 (Electrician)

> **호주 최고 안정 + 고연봉 Trade** (의사·변호사급)
> **ANZSCO**: 341111 (Electrician - General)

### 진학 루트
```
Cert III in Electrotechnology Electrician (3~4년 — 도제 형식)
→ Electrical Licence (주별 — NSW: NSW Fair Trading)
```

⚠️ **전기는 다른 Trade와 다름**: 도제(Apprenticeship) 시스템
- Trainee로 회사에 고용되어 학교 + 현장 동시 진행
- 유학생은 호주 도제 진입 어려움 (호주 시민/PR 우선)

### 유학생 현실적 진입 방법
```
한국 전기 자격증 + 경력 → TRA RPL 평가
또는 호주 Cert IV in Electrical (한국 학력 인정 시)
→ 482 비자 (고용주 후원) → 186 PR
```

### 추천 지역
- **퍼스** (광산 산업 — 전기 기사 매우 부족)
- **애들레이드** (지방)
- **북부 QLD** (광산 지대)

### Wilson 핵심 팁
- 전기는 **한국에서 자격증 + 경력** 있어야 호주 진입 유리
- **광산 지역 (Kalgoorlie, Hunter Valley) = 시급 $40~60**
- 호주 Electrical Licence는 주별로 다름 (이주 시 재등록)

---

## 🔥 4️⃣ 용접사 (Welder)

> **2024-25 영주권 Top 10 포함**, 지방 비자 인기
> **ANZSCO**: 322313 (Structural Steel and Welding Trades Worker)

### 진학 루트
```
Cert III in Engineering - Fabrication Trade (2년)
→ Cert IV in Engineering (6개월~1년)
= 약 2.5~3년
```

### 추천 학교
- **TAFE NSW** (시드니)
- **TAFE Queensland** (브리즈번)
- **TAFE WA** (퍼스) — 광산 지역 ⭐
- **TAFE SA** (애들레이드) — 지방 ⭐
- **TasTAFE** (호바트) — 지방 ⭐

### PR 경로
```
Cert III/IV + TRA JRP (12개월 호주 경력)
→ 485 → 491 지방 PR ⭐
```

### Wilson 핵심 팁
- **한국 용접 자격증/경력** 있으면 → TRA RPL로 호주 자격 인정 가능
- **6G(파이프 수직) 용접 경력** = 호주 광산·플랜트에서 최고 대우
- 광산 지역 (Kalgoorlie WA, Hunter Valley NSW) = **연봉 1억+ 가능**
- FIFO (Fly In Fly Out) 근무 = 추가 수당

---

## 💇 5️⃣ 헤어드레서/미용사 (Hairdresser)

> **한국 학생 PR 인기 (특히 여학생)**
> **ANZSCO**: 391111 (Hairdresser)

### 진학 루트
```
Cert III in Hairdressing (1.5~2년)
→ Cert IV in Hairdressing (6개월)
= 약 2~2.5년
```

### 추천 학교
- **TAFE NSW / TAFE QLD** (정부 운영)
- **Australasian College Broadway** (시드니)
- **Australian Academy of Cinema** (멜번)
- **TasTAFE** (호바트) — 지방 PR ⭐

### ⚠️ 헤어드레서 특이사항
- **485 비자 안 나옴** (학사 학위 아니라서)
- **Cert III 졸업 후 호주 미용실 정식 취업 + 2년 파트타임 경력**
- → TRA 평가 → 482/491 비자 → PR

### PR 경로
```
Cert III + Cert IV (2~2.5년)
→ 호주 미용실 정식 취업 (2년 파트타임 또는 1년 풀타임)
→ TRA 직업평가 → 482 (고용주 후원) 또는 491 지방
→ 186 또는 191 PR
```

### Wilson 핵심 팁
- 헤어드레서는 **학사가 아니라서 485 비자 X** — 다른 Trade와 다름
- **고용주 스폰 (482) 트랙이 가장 현실적**
- 한국 미용 자격증 + 경력 → 호주 미용실 취업 유리
- 추천 지역: **시드니/멜번 한인타운 미용실** (한국인 고객 많음)
- **지방 (애들레이드/호바트) 미용실** = 고용주 스폰 더 쉬움

---

## 🚿 6️⃣ 배관공 (Plumber)

> **호주 최고 안정 Trade + 자영업 가능**
> **ANZSCO**: 334111 (Plumber - General)

### 진학 루트
```
Cert III in Plumbing (3~4년 — 도제 형식)
→ Plumbing Licence (주별)
```

⚠️ **전기와 마찬가지로 도제 시스템** — 유학생 진입 어려움

### 유학생 현실적 진입
```
한국 배관 자격증 + 경력 → TRA RPL 평가
→ 482 비자 (고용주 후원) → 186 PR
```

### Wilson 핵심 팁
- 배관도 전기와 같이 **한국 경력 + 호주 Licence** 조합이 현실적
- **자영업 시 연봉 $150,000+ 가능**
- 추천 지역: **시드니 (주택 건설 활발)**, **퍼스 (광산)**

---

## 🥖 7️⃣ 제과제빵사 (Baker / Pastrycook)

> **2024-25 영주권 Top 10 포함** (Bakers and Pastrycooks)
> **ANZSCO**: Baker 351111 / Pastrycook 351112

### 진학 루트
```
Cert III in Baking 또는 Patisserie (1.5~2년)
→ Cert IV (6개월)
= 약 2~2.5년
```

### 추천 학교
- **Le Cordon Bleu** (시드니/멜번/애들레이드) — 패티시에 명문
- **William Angliss Institute** (멜번) — 한국 학생 매우 인기
- **TAFE NSW / TAFE QLD**
- **TasTAFE** (호바트)

### PR 경로 (셰프와 동일)
```
Cert III/IV + TRA JRP (호주 베이커리 12개월 경력)
→ 485 → 190/491 PR
```

### Wilson 핵심 팁
- 한국 제과제빵 자격증 + 경력 있으면 → 호주 적응 빠름
- **호주 한식 베이커리 (Tortie's, 한인 빵집) 알바** 활발
- Le Cordon Bleu Pâtisserie = 글로벌 인지도

---

## 📊 7대 Trade 직군 PR 난이도 비교

| 직군 | 진학 기간 | 485 비자 | PR 난이도 | 추천 지역 |
|---|---|---|---|---|
| 🍳 셰프 | 2~2.5년 | ✅ | ⭐⭐⭐ 보통 | 호바트/애들레이드/지방 호텔 |
| 🔧 자동차 정비 | 2.5~3년 | ✅ | ⭐⭐⭐⭐ 쉬움 | 퍼스/애들레이드/지방 |
| ⚡ 전기 | 한국 경력 활용 | △ | ⭐⭐ 어려움 (도제) | 퍼스 광산 |
| 🔥 용접 | 2.5~3년 | ✅ | ⭐⭐⭐⭐ 쉬움 | 퍼스/광산 지역 |
| 💇 미용 | 2~2.5년 | ❌ | ⭐⭐ 보통 (482 트랙) | 호바트/애들레이드/한인타운 |
| 🚿 배관 | 한국 경력 활용 | △ | ⭐⭐ 어려움 (도제) | 시드니 |
| 🥖 제과제빵 | 2~2.5년 | ✅ | ⭐⭐⭐ 보통 | 호바트/멜번 |

⭐ **485 비자 OK 직군 (학사 패스웨이로 인정)**: 셰프/정비/용접/제빵
⭐ **485 비자 X 직군 (도제 또는 비학위)**: 전기/배관/미용 → 482 트랙

---

## 💰 평균 연봉 (2026 AUD, PayScale/SEEK Salary Guide)

| 직군 | 연봉 |
|---|---|
| ⚡ **전기 (Electrician)** | $75,000~120,000 ⭐ |
| 🚿 **배관 (Plumber)** | $75,000~130,000 ⭐ |
| 🔥 **용접 (Welder)** | $70,000~110,000 |
| 🍳 **셰프 (Chef)** | $65,000~95,000 |
| 🔧 **자동차정비 (Mechanic)** | $65,000~95,000 |
| 🥖 **제과제빵 (Baker)** | $60,000~85,000 |
| 💇 **헤어드레서** | $50,000~80,000 |

> 💡 **광산 지역 (Kalgoorlie, Hunter Valley) + FIFO 근무 = +30~50%**
> 💡 **자영업 운영 시 연봉 2~3배 상승 가능**

---

## 🌟 추천 대상

- ✅ **검정고시·고졸 학생** (학사보다 빠른 PR 트랙)
- ✅ **워홀러 → 학생비자 전환** (Wilson 추천 1순위 트랙)
- ✅ **한국에서 Trade 자격증 + 경력 있는 학생** (RPL 평가로 빠른 진입)
- ✅ 손재주 + 신체 건강 + 야외 작업 가능
- ✅ 학비 부담 줄이고 PR 노리는 학생

---

## ⚠️ 주의사항

- **노동 강도 높음** (장시간 야외, 신체 노동)
- **TRA JRP — 호주 정규 직장 12개월 경력 필수** (Cash 알바 X)
- **사립 Trade 학교 사기 주의** — CRICOS 등록 정부 인증 학교만 선택
- **전기/배관은 도제 시스템** — 유학생 진입 매우 어려움 (한국 경력 활용 필수)
- **헤어드레서는 485 비자 X** — 482 (고용주 스폰) 트랙 필수
- 영어 점수 PR 시 IELTS 6.0+ 필요
- **각 주별 Licence 등록 별도** (이주 시 재등록 필요)

---

## 🎯 카드 작성용 한 줄 요약

> "검정고시·고졸·워홀러 PR 골든 트랙, **셰프/정비/용접/제빵은 485 OK**, 전기/배관/미용은 482 트랙. **TRA JRP 12개월 호주 경력**이 PR 핵심. 지방(호바트/애들레이드/퍼스) 추천."

---

## 🔗 참조 모듈

- `05_비자PR_모듈/02_485_졸업비자.md` (485 비자 자격)
- `05_비자PR_모듈/03_PR경로_189_190_491.md` (190/491 트랙)
- `05_비자PR_모듈/05_직업평가.md` (TRA JRP 상세)
- `03_지역_모듈/05_퍼스.md`, `06_애들레이드.md`, `07_호바트.md` (지방 추천)

---

*Source: 호주 영주권 Top 10 (2024-25 Department of Home Affairs Migration Program Report) + Le Cordon Bleu / TAFE 공식 + tradesrecognitionaustralia.gov.au, 2026 검증*
