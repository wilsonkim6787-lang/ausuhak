# 🎓 Monash University

> **모듈 타입**: G8 명문대 / 멜번
> **마지막 검증**: 2026년 / 공식 사이트 기준

---

## 📌 기본 정보

- **위치**: 멜번 (Clayton 메인 캠퍼스 + 시티 캠퍼스 등 다수)
- **분류**: G8
- **설립**: 1958년
- **QS 세계랭킹**: 약 37~50위
- **호주 최대 규모 대학** (학생 수 약 8만 명)

## 💪 강세 분야

- **약학 (Pharmacy — 세계 Top 3)**
- 의학 (Medicine)
- 공학 (Engineering)
- 비즈니스 (Top 3)
- 디자인·아트

## 📋 입학 기준 (2026)

| 항목 | 기준 |
|---|---|
| 학부 IELTS | 6.5 (각 영역 6.0) |
| 학부 학비 | 연 약 45,000~55,000 AUD |
| 인테이크 | 2월(Sem 1), 7월(Sem 2) |

## 🛤️ 패스웨이 (검정고시·고졸 학생) ⭐

**부속 컬리지: Monash College**

✅ **G8 중 Diploma 패스웨이 운영 — UNSW와 함께 핵심 학교**

| 패스웨이 | 기간 | 영어 기준 | 진입 |
|---|---|---|---|
| Foundation Year | 약 12개월 | IELTS 5.5 | 학부 1학년 |
| **⭐ Diploma Part 1** | 9개월 | IELTS 5.5 (각 5.0) | Part 2 또는 학부 1학년 |
| **⭐ Diploma Part 2** | 4~12개월 | IELTS 6.0 (각 5.5) | **학부 2학년 직진학** |

**Diploma 가능 분야**: Business, IT, Engineering, Science, Arts, Design, Media

⚠️ **Diploma 불가 분야**: Law, Medicine, Nursing, Pharmacy, Health Sciences (이런 전공은 Foundation Year 필수)

- **인테이크**: 2월·6월·10월 (연 3회 — 시작 유연)
- **Diploma 학비**: 약 30,000~38,000 AUD
- **장점**: G8 중 학비 비교적 낮음 + 인테이크 유연

## 🌟 추천 대상

- ✅ 약학·의학·공학 지망 (세계적 명성)
- ✅ G8 가성비 원하는 학생
- ✅ 검정고시·고졸 (Diploma 활용 가능)
- ✅ 멜번 라이프스타일 선호

## ⚠️ 주의사항

- Clayton 캠퍼스는 멜번 시내에서 약 30분 (대중교통)
- 약학·의학·간호 지망 시 Diploma X → Foundation 필수
- 멜번 = PR 지방가산점 ❌

## 🎯 카드 작성용 한 줄 요약

> "G8 중 가성비 최강 + 약학·의학·공학 세계급. **Diploma 패스웨이 + 인테이크 연 3회**로 시작 유연."

---

*Source: monash.edu, monashcollege.edu.au, 2026 기준*
