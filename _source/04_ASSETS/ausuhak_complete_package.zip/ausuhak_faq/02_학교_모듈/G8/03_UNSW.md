# 🎓 UNSW Sydney (University of New South Wales)

> **모듈 타입**: G8 명문대 / 시드니
> **마지막 검증**: 2026년 / 공식 사이트 기준

---

## 📌 기본 정보

- **위치**: 시드니 동부 (Kensington 캠퍼스)
- **분류**: G8
- **설립**: 1949년
- **QS 세계랭킹**: 약 19~25위 (호주 Top 5)
- **한국 학생 비율**: 매우 높음

## 💪 강세 분야

- **공학 (Engineering — 호주 1위, QS 세계 Top 30)**
- IT·컴퓨터 사이언스
- 비즈니스 (Business School — 호주 Top 3)
- 건축 (Architecture)
- 미디어·디자인

## 📋 입학 기준 (2026)

| 항목 | 기준 |
|---|---|
| 학부 IELTS | 6.5 (각 영역 6.0) |
| 학부 학비 | 연 약 50,000~60,000 AUD |
| 인테이크 | T1(2월), T2(5월), T3(9월) — Trimester 시스템 |

## 🛤️ 패스웨이 (검정고시·고졸 학생) ⭐

**부속 컬리지: UNSW College**

✅ **G8 중 Diploma 패스웨이 운영 — 매우 중요!**

| 패스웨이 | 기간 | 영어 기준 | 진입 |
|---|---|---|---|
| Foundation Standard | 9개월 | IELTS 5.5 | 학부 1학년 |
| Foundation Plus | 12개월 | IELTS 5.5 | 학부 1학년 |
| Foundation Transition | 15개월 | IELTS 5.0 | 학부 1학년 |
| **⭐ Diploma 12개월** | 12개월 | IELTS 5.5~6.0 | **학부 2학년 직진학** |

**Diploma 가능 분야**: Architecture, Business, Computer Science, Engineering, Media & Communications, Science

- **인테이크**: 1월·5월·9월 (연 3회 — 시작 유연)
- **Diploma 학비**: 약 35,000~40,000 AUD
- **장점**: 1년 단축 + 본 대학 시설 사용

## 🌟 추천 대상

- ✅ 공학·IT·비즈니스 지망 (호주 최강)
- ✅ G8에 빠르게 진입 원하는 학생 (Diploma 활용)
- ✅ 검정고시·고졸 학생 (Diploma로 시간 단축)
- ✅ 졸업 후 호주 IT·금융권 취업 희망

## ⚠️ 주의사항

- Trimester 시스템 (1년 3학기) — 빠르지만 빡빡
- 시드니 동부 = 렌트 비싼 편
- 시드니 = PR 지방가산점 ❌
- 일부 인기 전공(Comp Sci 등) 입학 경쟁 매우 치열

## 🎯 카드 작성용 한 줄 요약

> "공학·IT 호주 1위 G8. **Diploma 1년 → 학부 2학년 직진학** 가능 → 검정고시생 G8 진입 최단 루트."

---

*Source: unsw.edu.au, unswcollege.edu.au, 2026 기준*
