# 🎓 Macquarie University

> **모듈 타입**: 시드니 차선책 / 시드니 북부
> **마지막 검증**: 2026년 / 엑셀 가이드 + 공식 사이트

---

## 📌 기본 정보

- **위치**: 시드니 북부 (North Ryde)
- **분류**: 시드니 차선책
- **설립**: 1964년
- **QS 세계랭킹**: 약 120~150위
- **호주 회계·금융 분야 명문**

## 💪 강세 분야

- **회계·금융 (Accounting/Finance — 호주 Top 5)**
- 언어학 (Linguistics — 세계 Top 10)
- 항공우주공학
- 비즈니스
- 심리학

## 📋 입학 기준 (2026)

| 항목 | 기준 |
|---|---|
| 학부 IELTS | 6.5 (각 영역 6.0) |
| 학부 학비 | 연 약 38,000~45,000 AUD |
| 인테이크 | 2월(Sem 1), 7월(Sem 2) |

## 🛤️ 패스웨이

**부속 컬리지: Macquarie University International College**

| 패스웨이 | 기간 | 영어 기준 | 진입 |
|---|---|---|---|
| Foundation Standard | 약 9~12개월 | IELTS 5.5 | 학부 1학년 |
| Foundation Extended | 약 15개월 | IELTS 5.0 | 학부 1학년 |
| **Diploma** | 약 8~12개월 | IELTS 5.5~6.0 | **학부 2학년 직진학** |

**Diploma 가능 분야**: Business, Commerce, IT, Engineering, Media, Arts

## 🌟 추천 대상

- ✅ 회계·금융·비즈니스 지망 (호주 Top 5)
- ✅ 시드니 학교 + 학비 절감 원하는 학생
- ✅ 언어학·번역 지망
- ✅ Diploma 1년 단축 활용

## ⚠️ 주의사항

- 시드니 = PR 지방가산점 ❌
- 시드니 도심에서 메트로로 약 30~40분 (북부 외곽)
- 회계 PR 트랙은 경쟁 매우 치열

## 🎯 카드 작성용 한 줄 요약

> "시드니 회계·금융 명문, **G8보다 학비 20% 저렴 + Diploma로 1년 단축**. 비즈니스·금융 지망생에게 가성비 좋은 선택."

---

*Source: mq.edu.au, mqcollege.com, 2026 공식 자료*
