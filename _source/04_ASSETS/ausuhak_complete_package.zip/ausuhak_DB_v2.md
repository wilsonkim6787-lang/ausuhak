# ausuhak.com 통합 DB

> 검증 + 호주 유학 정확 데이터
> 6변수(나이/지역/여유자금/영어/학력/유학목적) 매칭용
> 카드 엔진 Knowledge Base
> ⚠️ v2.1 (2026-05-03): Wilson 노트 / 비고(한국 학생 비율) / Q&A facts 제거 (1:1 상담 영역 보호)

- 학교 총 467개
- 학과 1227개
- 정책 + Wilson Alerts 24개
- Blocking Rules 39개

---

## Part 1. 학생 6변수 정의

학생이 카드 엔진에서 선택하는 6가지 변수.

### 1) 나이
- 17세 이하: HSP / 조기유학
- 18-25세: 학생비자 + ELICOS + Pathway 풀 옵션
- 26-34세: 485 졸업비자 + PR 가능 (35세 미만)
- 35세 이상: 485 어려움. 회사 스폰서 / 491 / 직접 PR 경로

### 2) 지역 (6개)
- **시드니** (NSW) - Cat 1 / 학비·생활비 최고 / 한국·중국 多 / 알바 多
- **멜번** (VIC) - Cat 1 / 시드니 다음 / 한국 학생 적당
- **브리즈번** (QLD) - Cat 2 +15 / 시드니 대비 15% 저렴 / 한국 학생 적음
- **애들레이드** (SA) - Cat 2 +15 / 호주 최저 학비 / 한국 학생 3-8%
- **퍼스** (WA) - Cat 2 +15 / Mining 특화 / 한국 학생 적음
- **호바트** (TAS) - Cat 3 +15+5 / 호주 최저 / 한국 학생 가장 적음

### 3) 여유자금 (1년 기준)
- $30,000 이하 (3,000만): TAFE Adelaide/Hobart + 알바 풀가동
- $30,000~$50,000 (3-5천만): TAFE 일반 + 사립 컬리지 + ELICOS
- $50,000~$80,000 (5-8천만): 일반 대학교 Bachelor
- $80,000~$130,000 (8천-1.3억): Go8대 / 의대·약대 등
- 학비 외 생활비 $29,710 (호주 정부 비자 표준) 별도 추가

### 4) 영어점수
- 없음/3.0 이하: ELICOS 30-52주
- IELTS 4.0-5.5: ELICOS 12-24주 + Direct Entry
- IELTS 5.5-6.0: TAFE/Diploma 직진 가능
- IELTS 6.0-6.5: 일반 대학교 직진
- IELTS 6.5+: Go8대 직진
- IELTS 7.0+: 간호 / Master / 의료직

### 5) 학력
- 초·중학생: HSP / 조기유학
- 고등학생 재학: HSP / 조기유학 + Foundation 준비
- 고졸 / 검정고시: ELICOS / TAFE / Foundation / Pathway
- 전문대 (2-3년): TAFE Diploma / Bachelor 편입
- 4년제 학사: Master / Pre-reg Master (간호 등)
- 석사 이상: PhD / 직무 연계 PR

### 6) 유학목적
- 어학연수만: ELICOS
- 학위 취득: Foundation/Pathway → Bachelor/Master
- 취업: TAFE Diploma + 485
- 이민/PR: PR 직업군 코스 (간호/요리/Trades/IT/Engineering)
- 조기유학: HSP / Boarding
- 가족 동반: Master + 배우자 풀타임 워크

---

## Part 2. 비자 정책 핵심

### 학생비자 (subclass 500)
- 신청비: $2,000 AUD (2024.07.01 인상)
- 생활비 재정증명: $29,710/년 (2024.05.10 인상)
- GTE → GS (Genuine Student) 변경 (2024.03.23)
- 학교 변경 6개월 룰 (2024.07.01~)
- 처리 기간: 평균 4-12주
- 알바: 2주 48시간 (학기 중) / 방학 풀타임

### 졸업비자 (subclass 485)
**Post-Higher Education Work stream (학사 이상)**
- Bachelor: 2년 / Master coursework: 2년 / Master research: 3년 / PhD: 3년
- 영어: IELTS 6.0 (각 영역 5.0)
- 연령: 35세 미만 (HK/BNO 50세)
- 92주 학업 + 16개월 요건

**Post-Vocational Education Work stream (Diploma/Trade)**
- 18개월 (HK/BNO 5년)
- MLTSSL 직업군과 closely related
- Skills Assessment 필수
- 영어 + 92주 + 16개월 동일

**Regional Bonus**
- Cat 2 (Adelaide/Brisbane/Perth/Gold Coast): +1년
- Cat 3 (Hobart/Darwin/Cairns 등): +2년


### 워홀(417/462) → 학생비자(500) 전환

호주 체류 중 워홀러가 학생비자로 전환하는 경우 자주 있음. 한국인 워홀러 多.

**조건**
- 호주 내 신청 (onshore 신청)
- 워홀 비자 만료 6개월 이내
- 학교 입학허가서 (CoE) 보유
- GS (Genuine Student) 에세이 - 학업 의지 강조
- 재정증명 + OSHC + 건강검진

**주의**
- GS-07 차단 룰: 단순 비자 연장 + 사파 학교 = GS 거절 + 폐교 위험
- 학업 의지 0% 의심받지 않도록 주의
- Multiple CoE 동시 진행 X
- 이전 비자 위반 이력 (출석 80% 미만 등) 있으면 거절 위험 高

**처리 기간**
- 호주 내 신청: 평균 4-12주
- 결과 대기 중 Bridging Visa A 자동 발급 (호주 체류 가능)
- 수업 시작은 학생비자 발급 후

**절차**
1. CRICOS 등록 학교 입학신청 → CoE 발급
2. OSHC 가입
3. 건강검진 (호주 패널 병원)
4. ImmiAccount에서 온라인 신청
5. 결과 대기 (Bridging A로 합법 체류)


### PTE 변경 2026.04.23 (의료직)
- Before: Overall 65 / S65 W65 R65 L65
- After: Overall 63 / S76 W60 R59 L58
- AHPRA + DHA 16개 의료직 적용
- Speaking 76 = 어려움 / Speaking 약하면 IELTS 추천

---

## Part 3. 학교 데이터

### 3-1. 대학교 (39개)

#### Go8 (8개)

#### 멜버른 대학교
*CRICOS 00116K | Melbourne (VIC) Cat 1 (Metro | QS Top 13 (Go8 / 호주 #1)*

**학비**: 학사: $37,312-$48,000 / 석사: $48,000-$70,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58-64
**학력**: 95+ (Go8)
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Melbourne International Undergraduate Scholarship (25-100%)

#### 시드니 대학교
*CRICOS 00026A | Sydney (NSW) Cat 1 (Metro | QS Top 18 (Go8)*

**학비**: 학사: $46,900-$52,000 / 석사: $45,200-$58,000
**영어**: IELTS 6.5 (각 6.0) / PTE 61
**학력**: 95+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Sydney Scholars Award (학비 25-100% 면제)

#### 뉴사우스웨일스 대학교
*CRICOS 00098G | Sydney (NSW) Cat 1 (Metro | QS Top 19 (Go8)*

**학비**: 학사: $40,000-$48,000 / 석사: $45,000-$58,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 90+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UNSW International Scholarship (25-100% 학비 면제)

#### 호주국립대학교
*CRICOS 00120C | Canberra (ACT - Australian Capital Territory) Cat 1 (Metro | QS Top 30 (Go8)*

**학비**: 학사: $48,000-$52,000 / 석사: $48,000-$58,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 80+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: ANU Chancellor's International Scholarship (전액 / 부분 (200명+))

#### 모나쉬 대학교
*CRICOS 00008C | Clayton (Melbourne 동부 | QS Top 37 (Go8)*

**학비**: 학사: $39,500-$46,000 / 석사: $41,000-$52,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58-65
**학력**: 80+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Monash International Merit Scholarship ($10,000 (학사 1년차)

#### 퀸즐랜드 대학교
*CRICOS 00025B | St Lucia (Brisbane CBD에서 7km) Cat 1 (Metro | QS Top 40 (Go8)*

**학비**: 학사: $37,792-$44,000 / 석사: $42,000-$58,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 80+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UQ International Scholarship (25-50% 학비 면제)

#### 서호주 대학교
*CRICOS 00126G | Crawley (Perth CBD에서 5km) Cat 2 +15 (Regional) | QS Top 77 (Go8)*

**학비**: 학사: $32,000-$40,000 / 석사: $42,000-$54,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 80+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UWA Global Excellence Scholarship ($48,000 (학사/석사)

#### 애들레이드 대학교
*CRICOS 00123M | North Terrace (Adelaide CBD) Cat 2 +15 (Regional) | QS Top 82 (Go8)*

**학비**: 학사: $32,000-$42,000 / 석사: $42,000-$54,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Global Academic Excellence International Scholarship (30-50% 학비 면제)

#### 일반 대학교 (31개)

#### 시드니 공과대학교
*CRICOS 00099F | Ultimo | QS Top 88*

**학비**: 학사: $36,000-$44,000 / 석사: $42,000-$52,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UTS International Undergraduate Scholarship (25-100% 학비)

#### RMIT 대학교 / 멜버른왕립공과대학교
*CRICOS 00122A | Melbourne CBD (RMIT City) 도심 한복판 Cat 1 (Metro | QS Top 123*

**학비**: 학사: $13,970-$20,000 / 석사: $32,640-$48,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: RMIT Asia Bursary (10% 자동 학비 면제 (한국 학생 포함)

#### 매쿼리 대학교
*CRICOS 00002J | Wallumattagal Campus (Macquarie Park) - Sydney CBD에서 25분 Cat 1 (Metro | QS Top 178*

**학비**: 학사: $37,900-$44,000 / 석사: $46,000-$50,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Vice-Chancellor's International Scholarship ($10,000 - $40,000)

#### 커틴 대학교
*CRICOS 00301J | Bentley (Perth CBD에서 8km | QS Top 185*

**학비**: 학사: $28,200-$34,000 / 석사: $30,000-$42,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Global Curtin Scholarships - Merit (25-100% 학비)

#### 울런공 대학교
*CRICOS 00102E | Wollongong (메인) + Sydney CBD + Liverpool Cat 2 +15 (Regional) | QS Top 167*

**학비**: 학사: $33,000-$42,000 / 석사: $35,000-$48,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 80+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UOW Vice-Chancellor's International Scholarship (30% 학비 면제 (성적 우수)

#### 디킨 대학교
*CRICOS 00113B | Melbourne Burwood (Melbourne CBD 30분) Cat 2 +15 (Regional) | QS Top 197*

**학비**: 학사: $35,000-$45,000 / 석사: $38,000-$50,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Deakin VC's International Scholarship (50% 학비 면제 (성적 우수)

#### 퀸즐랜드 공과대학교
*CRICOS 00213J | Gardens Point (Brisbane CBD 한복판) + Kelvin Grove (CBD 3km) Cat 1 (Metro | QS Top 191*

**학비**: 학사: $34,000-$45,000 / 석사: $36,000-$48,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: QUT International Scholarship (25-50% 학비 면제 (성적 우수)

#### 뉴캐슬 대학교
*CRICOS 00109J | Callaghan (Newcastle 외곽) + Newcastle CBD + Sydney CBD + Ourimbah (Central Coast) Cat 2 +15 (Regional) | QS Top 175*

**학비**: 학사: $33,000-$48,000 / 석사: $35,000-$50,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Newcastle International Scholarship (25-50% 학비 면제)

#### 웨스턴 시드니 대학교
*CRICOS 00917K | Parramatta (Sydney CBD 차 30분), Penrith (차 1시간 | QS Top 387*

**학비**: 학사: $32,000-$42,000 / 석사: $34,000-$44,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: WSU Vice-Chancellor's Academic Excellence Scholarship (50% 학비 면제)

#### 라트로브 대학교
*CRICOS 00115M | Melbourne Bundoora (Melbourne CBD 14km | QS Top 217*

**학비**: 학사: $32,000-$45,000 / 석사: $34,000-$48,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: La Trobe International Excellence Scholarship (25-50% 학비 면제)

#### 그리피스 대학교
*CRICOS 00233E | **Gold Coast (Southport)** + Nathan (Brisbane 메인) + Mt Gravatt + Logan + South Bank + Brisbane CBD (2027 NEW) Cat 2 +15 (Regional) | QS Top 201*

**학비**: 학사: $33,000-$48,000 / 석사: $35,000-$50,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Griffith International Excellence Scholarship (25-50% 학비 면제)

#### 태즈메이니아 대학교
*CRICOS 00586B | Hobart Sandy Bay (Tasmania 수도 | QS Top 183*

**학비**: 학사: $26,000-$38,000 / 석사: $30,000-$42,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: UTAS Tasmanian International Scholarship (TIS (25% 학비 면제 자동 (한국 학생 자동 적용)

#### 찰스 스터트 대학교
*CRICOS 00005F | None Cat 2 +15 (Regional) | QS Top 600*

**학비**: 학사: $30,000-$40,000 / 석사: $32,000-$42,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: CSU International Tuition Reduction Scholarship (25-50% 학비 면제)

#### 제임스 쿡 대학교
*CRICOS 00117J | Townsville Bebegu Yumba (Douglas | QS Top 415*

**학비**: 학사: $30,000-$42,000 / 석사: $32,000-$45,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: JCU International Excellence Scholarship (25% 학비 면제 자동 (한국 학생 자동)

#### 머독 대학교
*CRICOS 00125J | Murdoch (Perth CBD 차 20분 | QS Top 600*

**학비**: 학사: $25,000-$38,000 / 석사: $30,000-$40,500
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Murdoch International Welcome Scholarship (25% 학비 면제 (자동)

#### 본드 대학교
*CRICOS 00017B | Robina (Gold Coast | QS Top 256*

**학비**: 학사: $52,000-$72,000 / 석사: $55,000-$75,000
**영어**: IELTS 6.5 (각 6.0) / PTE 64
**학력**: 75+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Bond International Excellence Scholarship (25-50% 학비 면제)

#### 노트르담 호주 대학교
*CRICOS 01032F | Fremantle (Perth West End | QS Top 750*

**학비**: 학사: $32,000-$42,000 / 석사: $34,000-$45,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: 5 Star 학생 지원 Good Universities Guide 2024-2025 ((Learner Engagement / Skills Development / Graduate Salary /)

#### 호주 가톨릭 대학교
*CRICOS 00004G | None Cat 2 +15 (Regional) | QS Top 651*

**학비**: 학사: $26,000-$36,000 / 석사: $28,000-$38,000
**영어**: IELTS 6.0 (Bachelor) / PTE 50-58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: 5 Star 학생 지원 (Good Universities Guide (Learner Engagement / Skills Devel)

#### 캔버라 대학교
*CRICOS 00212K | Bruce (Canberra | QS Top 425*

**학비**: 학사: $32,000-$42,000 / 석사: $34,000-$45,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 70+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)

#### 뉴잉글랜드 대학교
*CRICOS 00003G | Armidale (NSW Northern Tablelands | QS Top 750*

**학비**: 학사: $28,000-$38,000 / 석사: $30,000-$40,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: 5 Star Overall Experience 20년 연속 ((Good Universities Guide / 호주 유일 공립 대학)

#### 남부 퀸즐랜드 대학교
*CRICOS 00244B | Toowoomba (호주 최대 내륙 도시 | QS Top 800*

**학비**: 학사: $28,000-$38,000 / 석사: $30,000-$40,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: NASA TESS 협력 (Mt Kent Observatory) ((호주 유일 / 행성 발견 2018)

#### 페더레이션 호주 대학교
*CRICOS 00103D | Ballarat (Mt Helen + SMB + Camp Street + Gillies Street 4개) - Melbourne 차 75분 Cat 2 +15 (Regional) | QS Top 800*

**학비**: 학사: $24,000-$32,000 / 석사: $26,000-$34,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 60+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: FedUni Global Excellence Scholarship: 50% 학비 면제 ((성적 우수)

#### 선샤인 코스트 대학교
*CRICOS 01595D | Sippy Downs (Sunshine Coast | QS Top 800*

**학비**: 학사: $28,000-$36,000 / 석사: $30,000-$38,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: 5 Star Good Universities Guide 7개 항목 ((Teaching Quality / Overall Educational Experience / Lea)

#### 찰스 다윈 대학교
*CRICOS 00300K | Casuarina Darwin (Northern Territory | QS Top 800*

**학비**: 학사: $26,000-$35,000 / 석사: $29,000-$40,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 60+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: CDU Vice-Chancellor's International High Achievers Scholarship: 50% 학비 면제 ((성적 우수)

#### 에디스 코완 대학교
*CRICOS 00279B | Joondalup (Perth 북쪽 25km) Cat 2 +15 (Regional) | QS Top 651*

**학비**: 학사: $30,000-$38,000 / 석사: $32,000-$42,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: ECU International Scholarship: 20% 학비 면제 자동 ((한국 학생 자동 / Bachelor 전체 기간)

#### 빅토리아 대학교
*CRICOS 00124K | Footscray Park (Melbourne CBD 5km | QS Top 800*

**학비**: 학사: $26,000-$36,000 / 석사: $30,000-$40,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 60+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: VU Block Model International Scholarship: 30% 학비 면제 ((Bachelor 전체 기간 / 자동)

#### 스윈번 공과 대학교
*CRICOS 00111D | Hawthorn (Melbourne CBD 동쪽 10분 | QS Top 285*

**학비**: 학사: $36,000-$48,000 / 석사: $38,000-$50,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Sarawak Campus 패스웨이 → Hawthorn 전학 ((Sarawak 학비 = 호주 50% / 1-2년 후 Melbourne 전학)

#### 아본데일 대학교
*CRICOS 02731D | Cooranbong Lake Macquarie NSW (Sydney 차 90분 | QS Unranked*

**학비**: 학사: $24,000-$32,000 / 석사: $26,000-$34,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 65+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)

#### 토렌스 호주 대학교
*CRICOS 03389E | Adelaide Wakefield Street (SA) Cat 2 +15 (Regional) | QS Unranked*

**학비**: 학사: $28,000-$36,000 / 석사: $30,000-$40,000
**영어**: IELTS 6.5 (각 6.0) / PTE 58
**학력**: 60+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: Three Pillars BMIHMS Hospitality Scholarship: 30% ((호텔 매니지먼트 / 자동)

#### 홈즈 인스티튜트
*CRICOS 02798F | Melbourne (Spring Street CBD) Cat 2 +15 (Regional) | QS Unranked*

**학비**: 학사: $25,000-$32,000 / 석사: $28,000-$35,000
**영어**: IELTS 6.0 (학사) / PTE 50
**학력**: 60+
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)
**장학금**: 호주 사립 가장 큰 비즈니스 학교 中 ((10,000+ 학생 / 70-80개국)

#### 호주 사립 Specialist Colleges
*CRICOS 01505M | Sydney | QS Specialist*

**학비**: 학사: $24,000-$32,000 / 석사: $26,000-$35,000
**영어**: IELTS 5.5 (각 6.0) / PTE 42-50
**학력**: 50
**기간**: 학사 3-4년 / 석사 1-2년 / PhD 3-4년
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Foundation / Diploma 패스웨이 (시트 5,7 참조) / 검정고시 OK (Foundation 경유)

### 3-2. TAFE (주별 8개)

#### TAFE NSW (시드니)
*CRICOS 00591E | NSW - Ultimo (Sydney CBD - 가장 큰 캠퍼스)*

**학비**: VET_Diploma: $16,803 - $24,000/년 / Bachelor_Degree: $21,270 - $28,000/년 / Higher_Education_Diploma: $18,000 - $25,000/년
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Sydney Metro = Cat 1 (가산점 X) / Newcastle/Wollongong/Regional NSW = Cat 2 (+15점)
**진학 옵션**: UTS (Sydney) - 1.5-2년 학점 / Western Sydney University - 1.5-2년 / UNSW (일부 코스) - 1년

#### TAFE Queensland (브리즈번)
*CRICOS 03020E | QLD - Brisbane (South Bank*

**학비**: Diploma_Trades: $12,000-$15,000/년 (Cabinet Making 등) / Diploma_Hospitality: $15,000-$20,000/년 / Diploma_Nursing: $18,000-$22,000/년
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Brisbane = Cat 2 (+15) / Gold Coast/Sunshine Coast = Cat 2 / Cairns/Townsville = Cat 2
**진학 옵션**: QUT (Brisbane) - Hospitality / Business / IT / Griffith University (Brisbane / Gold Coast) - 多 코스 / USC (Sunshine Coast) - 1년

#### TAFE SA (애들레이드)
*CRICOS 검증 필요 | SA - Adelaide City (CBD)*

**학비**: Diploma: $13,000-$18,000/년 (호주 가장 저렴 中 하나) / Bachelor: $18,000-$24,000/년 / Trades: $12,000-$15,000/년
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Adelaide = Cat 2 (+15) 
**진학 옵션**: University of Adelaide (Adelaide University 2026 신 / Flinders University - 1-2년 / UniSA (Adelaide University 합병)

#### TasTAFE (호바트/론서스턴)
*CRICOS 검증 필요 | TAS - Hobart (CBD)*

**학비**: Diploma: $12,000-$16,000/년 (호주 최저 中) / Bachelor: X (TasTAFE = Diploma까지) / ELICOS: 별도 운영
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: TAS 전체 = Cat 3 (+15+5 = 총 20점) 
**진학 옵션**: University of Tasmania (UTAS) / Diploma 졸업 = UTAS 직접 진학

#### TAFE VIC (멜번)
*CRICOS 검증 필요 | VIC -*

**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Melbourne = Cat 1 / 모든 Regional VIC = Cat 2 (+15)

#### TAFE WA / TIWA (퍼스)
*CRICOS 검증 필요 | WA -*

**학비**: Diploma: $13-20K/년 / Bachelor: X (TAFE에서 X / Curtin/UWA로 패스웨이) / ELICOS: $420/주
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Perth = Cat 2 (+15) / Regional WA = Cat 2 / Mining = 직업
**진학 옵션**: Curtin University - 多 코스 학점 인정 / Murdoch University / Edith Cowan University (ECU)

#### CDU TAFE (다윈 NT)
*CRICOS 검증 필요 | NT - Casuarina (Darwin Main)*

**학비**: Diploma: $12,000-$16,000/년 (호주 최저) / TAFE_Package: $29,600 (Palmerston Bakery 예시) / Bachelor: $22,000-$26,000/년 (CDU University)
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: NT 전체 = Cat 3 (+15+5 = 20점) 
**진학 옵션**: CDU University 직접 진학 (dual-sector)

#### CIT (캔버라 ACT)
*CRICOS 검증 필요 | ACT - Reid (CIT Main)*

**학비**: Diploma: $15,000-$20,000/년 / Bachelor: X (UC 또는 ANU 패스웨이) / Fee-Free_TAFE: ✅ Australian/PR/NZ만 (international X)
**영어**: IELTS Cert III/IV: 5.5 / Diploma: 5.5-6.0
**학력**: Year 10/11/12 / 검정고시 OK
**기간**: Cert III: 6m-1년 / Diploma: 1-2년 / Adv Diploma: 2-3년
**PR 가산점**: Canberra = Cat 2 (+15) 
**진학 옵션**: University of Canberra (UC) guaranteed entry + / ANU (선택 코스)

### 3-3. Foundation (8개)

#### Trinity College
*Melbourne CBD (100 Royal Parade Parkville) Cat 1 (Metro | QS Top 20 (Go8)*

**학비**: Standard: $44,540 / 8개월 (메모리 v6.2 검증) / 풀: 3 과정
**영어**: IELTS IELTS 6.0 (각 5.5) / TOEFL iBT 70 (W18) / PTE 50 (W42) / PTE 50
**학력**: 한국 고2 졸업 (B 평균) / 고3 / 검정고시 OK / IB 1년차 23점+
**기간**: Standard: 9개월 (Aug 시작 / Feb 시작) / Extended: 12개월 (Jul/Mar 시작) / Comprehensive: 15-18개월 (검정고시/영어 약한 학생)
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: UMelb 학사 1학년 직접 진학 (필요 점수 + 선수과목 충족 시 = guaranteed place)
**장학금**: Trinity Bursary (학비 25-50% (성적 우수))

#### Monash College Foundation
*Melbourne (Caulfield 캠퍼스) Cat 1 (Metro | QS Top 50 (Go8)*

**학비**: Standard: 약 $38,400 / 12개월 (메모리 v6.2 검증) / 풀: 3 과정
**영어**: IELTS Standard 6.0 (각 5.5) / Intensive 6.5 / Extended 5.5
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 12개월 / Intensive: 9개월 / Extended: 15-18개월
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: Monash 학사 1학년 직접
**장학금**: Monash International Foundation Award (학비 25%)

#### UNSW College Foundation
*Sydney (Kensington | QS Top 20 (Go8)*

**학비**: Standard: $42,700 / Year 11/12 (메모리 v6.2 검증) / 풀: 9 과정
**영어**: IELTS Standard 6.0 / Transition 5.5 / Plus 5.0
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 9개월 / Transition: 12개월 / Plus: 15개월
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: UNSW 학사 1학년
**장학금**: UNSW Foundation Scholarship (학비 25-50% (성적 우수))

#### Taylors College Sydney
*Sydney (Waterloo) Cat 1 (Metro | QS Top 20 (Go8)*

**학비**: Standard: $48,350 / 12개월 (메모리 v6.2 검증) / 풀: 3 과정
**영어**: IELTS Standard 5.5 / Extended 5.0 / Intensive 6.0
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 12개월 / Extended: 15개월 / Intensive: 8개월
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: USyd 학사 1학년
**장학금**: Taylors Foundation Scholarship (학비 25%)

#### Eynesbury College
*Adelaide CBD Cat 2 +15 (Regional) | QS Top 100 (Go8)*

**학비**: Foundation Standard: $28,700 / 12개월 (메모리 v6.2 / 호주 최저급) (메모리 v6.2 검증) / 풀: 9 과정
**영어**: IELTS Standard 5.5 / Extended 5.0
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 9개월 / Extended: 12개월
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: Adelaide University 학사 (구 UofA / UniSA 통합)
**장학금**: Eynesbury Foundation Scholarship ($5,000)

#### ANU College Foundation
*Canberra (Acton) Cat 2 +15 (Regional) | QS Top 30 (Go8)*

**학비**: Standard: $39,450 / 9개월 (메모리 v6.2 검증)
**영어**: IELTS Standard 5.5 (각 5.0) / Extended 5.0
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 9-12개월 / Extended: 12-15개월
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: ANU 학사 1학년
**장학금**: ANU College Pathway Scholarship (학비 20%)

#### UQ College Foundation
*Brisbane (St Lucia) Cat 1 (Metro | QS Top 50 (Go8)*

**학비**: Standard: $39,172 / 12개월 (메모리 v6.2 검증) / 풀: 2 과정
**영어**: IELTS Standard 6.0 / Extended 5.5
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 9개월 / Extended: 12-15개월
**PR 가산점**: Cat 1 (Metro / 가산점 0)
**진학 옵션**: UQ 학사 1학년
**장학금**: UQ College Achievement Award (학비 25%)

#### UWA Foundation
*Perth (Joondalup) Cat 2 +15 (Regional) | QS Top 100 (Go8)*

**학비**: Standard: $35,300 / 10개월 (메모리 v6.2 검증) / 풀: 2 과정
**영어**: IELTS Standard 5.5 / Extended 5.0
**학력**: 한국 고2/고3 / 검정고시 OK
**기간**: Standard: 9개월 / Extended: 12개월
**PR 가산점**: Cat 2 +15 (Regional)
**진학 옵션**: UWA 학사 1학년
**장학금**: UWA Foundation Scholarship (학비 20-30%)

### 3-4. ELICOS 어학원 (운영 중 47개)

#### 나비타스 English 시드니
*Sydney CBD (NSW) Metro*

**학비**: $440
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**진학 옵션**: 70+ 호주·해외 대학 EAP 패스웨이
**장학금**: Navitas Family Bursary (가족 두 번째 학생 학비 10% 할인)

#### ILSC 시드니
*Sydney CBD (NSW) Metro*

**학비**: $475
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**진학 옵션**: UTS / Macquarie / Western Sydney / Greenwich EAP

#### 카플란 시드니
*Sydney CBD (NSW) Metro*

**학비**: $485
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**진학 옵션**: UTS College / Murdoch / Bradford EAP

#### 그린위치 English
*Sydney CBD (NSW) Metro*

**학비**: $420
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### ELC 시드니
*Sydney CBD (NSW) Metro*

**학비**: $475
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### Lexis English Manly
*Manly Beach Sydney (NSW) Metro*

**학비**: $450
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**장학금**: 시즌 3월/9월 (등록비 면제)

#### APC English
*Sydney CBD (NSW) Metro*

**학비**: $400
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**장학금**: APC Diploma 패키지 (어학원 + Diploma 등록 시)

#### ELSIS 시드니
*Sydney CBD (NSW) Metro*

**학비**: $420
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### 카플란 멜번
*Melbourne CBD (VIC) Metro*

**학비**: $485
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**장학금**: Kaplan Long-stay Package (15-20% 절약)

#### ILSC 멜번
*Melbourne CBD (VIC) Metro*

**학비**: $475
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### 유니버설 English
*Melbourne CBD (VIC) Metro*

**학비**: $430
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### Discover English 멜번
*Melbourne CBD (VIC) Metro*

**학비**: $445
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### Hawthorn 멜번
*UniMelb 부속 (VIC) Metro*

**학비**: $560
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**진학 옵션**: UMelb 직속 EAP / Go8 직접 진입 (영어 시험 면제)

#### 모나쉬 English
*Monash 캠퍼스 (VIC) Metro*

**학비**: $545
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**진학 옵션**: Monash 직속 EAP / Go8 직접 진입
**장학금**: Monash English Bridging Package (Monash 학사 등록 시 패키지)

#### 임팩트 English
*Melbourne CBD (VIC) Metro*

**학비**: $440
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### 홈즈 English
*Melbourne CBD + Sydney + Brisbane + Gold Coast + Cairns (VIC+NSW+QLD) Cat 3 +15+5*

**학비**: $410
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Metro 0 / Cairns Cat 3 DRA
**장학금**: Holmes Diploma 패키지 (어학원 + Diploma + Bachelor)

#### 브라운스 English 멜번
*Melbourne CBD (VIC) Metro*

**학비**: $445
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**장학금**: BROWNS Free School Bus ($50/주 절약)

#### ILSC 브리즈번
*Brisbane CBD (QLD) Metro*

**학비**: $475
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### Lexis English 브리즈번
*Brisbane CBD (QLD) Metro*

**학비**: $440
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### 브라운스 English 브리즈번
*Brisbane CBD + Gold Coast (QLD) Cat 2 +15*

**학비**: $445
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Brisbane Metro / Gold Coast Cat 2 +15

#### EF 브리즈번
*Brisbane CBD (QLD) Metro*

**학비**: $510
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**장학금**: EF Global Scholarship (우수 학생 학비 20-30% 할인)

#### IH-ALS 브리즈번
*Brisbane CBD (QLD) Metro*

**학비**: $430
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### Sun Pacific College
*Cairns (QLD) Cat 3 +15+5*

**학비**: $360
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 3 DRA + 485 1년
**장학금**: Sun Pacific Long-stay Package (12주+ 학비 10% 할인)

#### 그린위치 브리즈번
*Brisbane CBD (QLD) Metro*

**학비**: $420
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)

#### 나비타스 English 퍼스
*Perth CBD (WA) Cat 2 +15*

**학비**: $400
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Lexis English 퍼스
*Perth CBD (WA) Cat 2 +15*

**학비**: $410
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### 피닉스 아카데미
*Perth CBD (WA) Cat 2 +15*

**학비**: $420
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### 밀너 인터내셔널
*Perth CBD (WA) Cat 2 +15*

**학비**: $395
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Polyglot 어학원
*Perth CBD (WA) Cat 2 +15*

**학비**: $385
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### ECU College English
*ECU 캠퍼스 (Joondalup*

**학비**: $510
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: ECU 직속 EAP / 영어 시험 면제 + 학부 20% 할인
**장학금**: ECC International Undergraduate Scholarship (ECU 학사 진학 시 학비 20% 할인)

#### 커틴 English
*Curtin 캠퍼스 (WA) Cat 2 +15*

**학비**: $530
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: Curtin 직속 EAP / Engineering·IT 진입

#### 머독 English
*Murdoch 캠퍼스 (WA) Cat 2 +15*

**학비**: $510
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: Murdoch 직속 EAP / 수의학 진입

#### SACE
*Adelaide CBD (SA) Cat 2 +15*

**학비**: $390
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Eynesbury College
*Adelaide CBD (SA) Cat 2 +15*

**학비**: $480
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: Adelaide / UniSA 직속 (Go8 진입)
**장학금**: Eynesbury Foundation Bursary ($5,000-$10,000 (Foundation 등록 시))

#### CES
*Adelaide CBD (SA) Cat 2 +15*

**학비**: $400
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Adelaide College English
*Adelaide 캠퍼스 (SA) Cat 2 +15*

**학비**: $510
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: Adelaide Foundation (Go8 진입)

#### 카플란 Adelaide
*Adelaide CBD (SA) Cat 2 +15*

**학비**: $470
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**장학금**: Kaplan Long-stay Package (15-20% 절약)

#### TAFE SA English
*Adelaide CBD (SA) Cat 2 +15*

**학비**: $370
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### 브라운스 Gold Coast
*Surfers Paradise Gold Coast (QLD) Cat 2 +15*

**학비**: $445
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### 이매진 Education
*Gold Coast (QLD) Cat 2 +15*

**학비**: $380
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Lexis Noosa
*Noosa (QLD) Cat 2 +15*

**학비**: $445
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15

#### Bond English
*Gold Coast (QLD) Cat 2 +15*

**학비**: $580
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15
**진학 옵션**: Bond 사립 직속 (학사 2년 가속)

#### UTAS English Hobart
*Hobart (TAS) Cat 3 +15+5*

**학비**: $420
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 3 DRA + 485 1년 (TAS 전체)
**진학 옵션**: UTAS Sandstone 직속

#### Lexis Cairns
*Cairns (QLD) Cat 3 +15+5*

**학비**: $440
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 3 DRA + 485 1년

#### Cairns College of English
*Cairns (QLD) Cat 3 +15+5*

**학비**: $400
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 3 DRA + 485 1년

#### CDU English Darwin
*Darwin (NT) Cat 3 +15+5*

**학비**: $410
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 3 DRA + 485 1년 (NT 전체)
**진학 옵션**: CDU 직속 (호주 첫 dual-sector)

#### ANU College English
*Canberra (ACT) Cat 2 +15*

**학비**: $510
**영어**: IELTS 입학 시험 X (Placement Test)
**학력**: 제한 X (만 16세+)
**기간**: 4-60주 (Long-stay 추가 할인)
**PR 가산점**: Cat 2 +15 (Canberra Cat 2)
**진학 옵션**: ANU Go8 직속

### 3-5. ELICOS 폐쇄 (18개)

아래 어학원은 폐쇄/폐업되어 추천 불가:

- EC English 호주
- 엠바시 English 호주
- IH 시드니
- 나비타스 English 브리즈번
- Discover English 시드니
- Lonsdale Institute
- ITHEA
- University Preparation College (UPC)
- Einstein College of Australia
- Astley English College
- RGIT (Royal Greenhill Institute of Technology)
- Business Institute of Australia
- Cocoon International College
- Perth International College of English
- The Language Academy
- Leeds College (호주)
- Lloyds International College / North Sydney English College
- SELC Australia (Sydney English Language Centre)

### 3-6. Diploma 검증 (22개)

Wilson 우선 검증된 Diploma/Pathway 코스:

#### UC-001 UTS College Sydney
*Diploma 검증 Round 2 (Wilson 우선 5)*

{'official source': 'utscollege.edu.au + IDP 2026', 'Diploma IT Standard 12개월': 'AUD $39,000', '운영': 'Insearch Limited (UTS 자회사) / CRICOS 00859D', '캠퍼스': 'Sydney CBD / Building 5 / Quay Street Haymarket', 'Foundation Studies Standard': '약 $35,000-40,000', 'Cambridge AS A Levels NEW 2026': '100% 장학금

#### UC-005 RMIT Training Pathways Melbourne
*Diploma 검증 Round 2 (Wilson 우선 5)*

{'official source': 'rmit.edu.au + 2026 Schedule of Fees PDF', '운영': 'RMIT Training Pty Ltd (CRICOS 01912G)', 'Foundation Studies': '주별 또는 학기별 (semester flat fee)', 'Diploma Pathway': '주별 학비 (RMIT UP)', 'RMIT 본 학사': '$13,970 - $50,880/년', 'scholarships 2026': ['10% ELICOS Bursary (한국 포함) = EAP → Fo

#### PC-006 Griffith College Brisbane GoldCoast
*Diploma 검증 Round 2 (Wilson 우선 5)*

{'official source': 'griffithcollege.edu.au + 2026 Quick Guide PDF', '운영': 'Queensland Institute of Business and Technology / CRICOS 01737F', '캠퍼스 2': 'Brisbane City (333 Ann Street) + Gold Coast (Southport / Parklands Drive)', 'Foundation Program 8개월': '약 $25,000-30,000', '12 Diploma Programs 2026'

#### PC-008 INTO JCU Brisbane
*Diploma 검증 Round 2 (Wilson 우선 5)*

{'official source': 'jcu.edu.au/brisbane/courses/fees + INTO JCU', '운영': 'Russo Higher Education / INTO Education', '캠퍼스': 'Brisbane CBD', 'JCU Brisbane 본 학사': '$30,400/년 - $36,899/년', 'Bachelor Business': '$30,400/년', 'Bachelor IT Engineering': '$33,000-36,899/년', 'MBA': '$32,720/년', 'PQP Postgradu

#### UC-008 UNCIE Newcastle Kaplan
*Diploma 검증 Round 2 (Wilson 우선 5)*

{'official source': 'internationalcollege.newcastle.edu.au/fees', '운영': 'Kaplan Higher Education / 수업 = U Newcastle 캠퍼스', '캠퍼스': 'Newcastle City Campus (NUspace, Hunter St) + Callaghan Campus', 'FSM 의대 Foundation 호주 유일 ': {'Program Fee 2026': '$37,400 ($3,740/course x 10)', 'Duration': '2 semesters

#### PC-001 APIC Australian Pacific International College
*Diploma 검증 Round 3 사립 8*

{'운영': 'TEQSA PRV12108 직접', '캠퍼스': 'Sydney + Melbourne + Brisbane', 'Bachelor Business 3년': '약 $26,000-32,000/년', 'Bachelor IT 3년': '약 $26,000-30,000/년', 'Diploma Business IT': '약 $20,000-25,000/년', 'Master Business 2년': '약 $26,000-30,000/년', 'Master IT 2년': '약 $26,000-30,000/년', 'Bachelor Bus WSU p

#### PC-002 MIT Melbourne Institute of Technology
*Diploma 검증 Round 3 사립 8*

{'운영': 'TEQSA PRV12063', '캠퍼스': 'Melbourne CBD (King St) + Sydney CBD', 'Diploma Business': '약 $24,000-28,000/년', 'Diploma IT': '약 $24,000-28,000/년', 'Bachelor Business 3년': '약 $26,000-32,000/년', 'Bachelor IT 3년': '약 $26,000-32,000/년', 'Bachelor Networking': '약 $26,000-32,000/년', 'Master Business 2년

#### PC-003 KOI King's Own Institute
*Diploma 검증 Round 3 사립 8*

{'운영': 'TEQSA PRV12012 / 2010 설립', '캠퍼스 2026': 'Sydney CBD (Market Street + Kent Street) + Newcastle (Darby Street, Cooks Hill)', 'Bachelor Accounting 3년': '약 $9,000-26,200/년', 'Bachelor Business 3년': '약 $24,000-26,200/년', 'Bachelor IT 3년': '약 $24,000-26,200/년', 'Master Accounting 1.5 2년': '약 $26,2

#### PC-004 Kaplan Business School KBS
*Diploma 검증 Round 3 사립 8*

{'운영': 'Kaplan Higher Education / TEQSA PRV12094', '캠퍼스 7': 'Sydney + Melbourne + Brisbane + Adelaide (Cat 2) + Gold Coast (Cat 2) + Perth + Online', 'Bachelor Business 3년': '약 $28,000-32,000/년', 'Master Business 1.5 2년': '약 $30,000-36,000/년', 'MBA 2년': '약 $36,000-40,000/년', 'Adelaide GoldCoast Cat2

#### PC-005 SIBT Sydney Institute of Business Technology
*Diploma 검증 Round 3 사립 8*

{'운영': 'Navitas / TEQSA PRV12077 / 1997 설립', '캠퍼스': 'Sydney City (4/255 Elizabeth St / 1개만) ← Korea Town 도보 ', 'Diploma Business 8개월': '약 $32,000-35,000', 'Diploma IT 8개월': '약 $32,000-35,000', 'Diploma Engineering Stage 1': '약 $32,000', 'Diploma Engineering Stage 2': '약 $35,000-38,000', 'WSU Sydney

#### PC-007 ECC 구 PIBT Edith Cowan College
*Diploma 검증 Round 3 사립 8*

{'운영': 'Navitas / ECU partnership / TEQSA PRV12125', '캠퍼스': 'Joondalup (ECU 캠퍼스 안) + Mount Lawley', 'Diploma Business Stage 1': '약 $20,000-24,000', 'Diploma IT Stage 1': '약 $20,000-24,000', 'Diploma Engineering Stage 1': '약 $22,000-26,000', 'Diploma Health Sci Stage 1': '약 $22,000-26,000', 'Cyber Se

#### PC-009 University of Adelaide College 구 Bradford
*Diploma 검증 Round 3 사립 8*

{'운영': 'Kaplan Higher Education (2016 리브랜딩)', '캠퍼스': 'Adelaide City Campus', 'Foundation': '약 $28,000-32,000', 'Degree Transfer Business': '약 $32,000-36,000', 'Degree Transfer Engineering': '약 $35,000-40,000', 'Degree Transfer Sciences IT': '약 $32,000-38,000', 'Pre Master Programs': '약 $30,000-35,00

#### PC-010 Taylors College Perth
*Diploma 검증 Round 3 사립 8*

{'운영': 'Navitas', '캠퍼스': 'Perth', 'Foundation Curtin': '약 $30,000-35,000', 'Foundation UWA': '약 $32,000-36,000', 'Diploma Curtin pathway': '약 $30,000-35,000/Stage', 'Perth Cat2 15PR': '+15 PR', 'wilson note': 'Curtin/UWA 2가지 진학 옵션 / Perth Cat 2'}

#### PC-011 SAIBT South Australian Institute of Business Tech
*Diploma 검증 Round 3 사립 8*

{'merger 2025': 'Eynesbury 합병 완료 = 단일 브랜드', '운영': 'Navitas (Eynesbury로 통합)', 'fees': 'Eynesbury 학비 적용 ($32,000-$43,720)', 'Adelaide University 2026 자동': True, 'Cat2 Adelaide 15PR': '+15 PR ', 'wilson note': 'Eynesbury 통합 = 동일 학비 / 별도 추천 X'}

#### UC-007 The College at Western WSU
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'Western Sydney University 직접 (≠ SIBT)', '캠퍼스 5': 'Bankstown + Campbelltown + Liverpool + Parramatta + Penrith', 'Diploma Business Online NEW 2026': '신규 ', 'Diploma Pathway Business': '약 $26,000-32,000', 'Diploma Pathway IT': '약 $26,000-32,000', 'Diploma Pathway Engineering': '약 $28,000-34,00

#### UC-009 ACU Foundation Australian Catholic Univ
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'ACU 직접 운영', '캠퍼스': 'Sydney + Melbourne + Brisbane + Canberra + Ballarat', 'Foundation': '$23,120 (호주 가장 저렴)', 'ACU 본 학사 Bachelor Nursing 3년': '약 $30,000-34,000/년', 'ACU Bachelor Education': '약 $26,000-30,000/년', 'Catholic Christian environment': True, 'wilson note': 'Foundation 호주 저렴 / Nursi

#### UC-010 Murdoch College Kaplan
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'Kaplan (구 Murdoch IT 2021.06 폐업 ❌ → 별도)', '캠퍼스': 'Murdoch University Perth', 'Foundation': '약 $28,000-32,000', 'Diploma Business 8개월': '약 $30,000-34,000', 'Diploma IT 8개월': '약 $30,000-34,000', 'Diploma Engineering': '약 $32,000-36,000', 'Diploma Health Science Vet pathway': '약 $32,000-36,000'

#### UC-011 Flinders Foundation Pathway
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'Flinders International Study Centre', '캠퍼스': 'Adelaide Bedford Park + City', 'Foundation Standard': '약 $30,000-34,000', 'Foundation Extended': '약 $34,000-38,000', 'Diploma Business': '약 $30,000-34,000', 'Diploma IT': '약 $30,000-34,000', 'Diploma Health Sci Nursing pathway': '약 $32,000-36,000

#### UC-012 CDU Pathway Charles Darwin University
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'CDU 직접 운영', '캠퍼스': 'Darwin + Sydney + Melbourne', 'Foundation': '약 $20,000-24,000 (호주 저렴)', 'Diploma Business': '약 $20,000-25,000', 'Diploma IT': '약 $20,000-25,000', 'Diploma Health Sci Nursing pathway': '약 $22,000-26,000', 'Aboriginal Health AU 유일': True, 'Indigenous Knowledges AU 유일': True

#### UC-013 UTAS College University of Tasmania
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'UTAS 직접 운영', '캠퍼스': 'Hobart + Launceston (AMC) + Cradle Coast', 'Foundation': '약 $26,000-30,000', 'Diploma Business': '약 $30,000-34,000', 'Diploma IT': '약 $30,000-34,000', 'Diploma Engineering Maritime': '약 $32,000-36,000', 'Diploma Health Sci Pharmacy pathway': '약 $32,000-36,000', 'Antarcti

#### UC-014 UC College University of Canberra
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'Navitas', '캠퍼스': 'Canberra (Bruce)', 'Foundation': '약 $28,000-32,000', 'Diploma Business': '약 $28,000-32,000', 'Diploma IT': '약 $28,000-32,000', 'Diploma Sport Mgmt TOP': '약 $30,000-34,000 / Sport Mgmt ', 'Diploma Health Sci': '약 $30,000-34,000', 'Canberra Cat1': True, 'wilson note': 'Sport

#### UC-015 Federation Pathway Federation University Ballarat
*Diploma 검증 Round 3 패스웨이 8*

{'운영': 'Navitas / TIWA partnership', '캠퍼스': 'Ballarat + Brisbane + Melbourne (CBD)', 'Foundation': '약 $20,000-25,000 (호주 최저급)', 'Diploma Business': '약 $22,000-26,000', 'Diploma IT': '약 $22,000-26,000', 'Diploma Engineering Mining': '약 $26,000-30,000 / Mining', 'Diploma ECE Education AU TOP': '약 $

### 3-7. 사립 직업 컬리지 (검증 10개)

#### Le Cordon Bleu Australia
위치: Adelaide + Sydney + Brisbane
학비: Diploma_Patisserie_18개월: 약 $40,000-45,000
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Diploma_Patisserie_18개월: 약 $40,000-45,000 / Diploma_Cuisine_18개월: 약 $40,000-45,000 / Bachelor_International_Hotel_Management_3년: 약 $32,000-38,000/년 / Master_Hospitality_Management_2년: 약 $35,000-42,000
비고: ⚠️ 사립 직업 College = 폐교 위험 검증 필요

#### William Angliss Institute Melbourne
위치: Melbourne CBD (La Trobe Street)
학비: Cert_III_Commercial_Cookery_12개월: 약 $14,000-18,000
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Commercial_Cookery_12개월: 약 $14,000-18,000 / Cert_IV_Patisserie_12개월: 약 $14,000-18,000 / Diploma_Hospitality_Management_2년: 약 $25,000-30,000 / Diploma_Tourism_Travel_2년: 약 $24,000-28,000

#### TAFE QLD NSW VIC Commercial Cookery
위치: 각 주 TAFE 본부 + 다중 캠퍼스
학비: Cert_III_Commercial_Cookery_12개월: 약 $12,000-18,000 (TAFE QLD 가장 저렴)
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Commercial_Cookery_12개월: 약 $12,000-18,000 (TAFE QLD 가장 저렴) / Cert_IV_Commercial_Cookery_12개월: 약 $12,000-15,000 (추가) / Diploma_Hospitality_Management_2년: 약 $15,000-20,000

#### Australian Institute of Beauty Dermal
위치: Melbourne + Sydney
학비: Cert_III_Beauty_Services_12개월: 약 $14,000-18,000
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Beauty_Services_12개월: 약 $14,000-18,000 / Cert_IV_Beauty_Therapy_18개월: 약 $16,000-22,000 / Diploma_Beauty_Therapy_18-24개월: 약 $20,000-26,000 / Cert_IV_Hairdressing_18개월: 약 $14,000-20,000

#### TAFE NSW Hair Beauty
위치: Ultimo + Northern Sydney + Western Sydney
학비: Cert_III_Hairdressing_12개월: 약 $12,000-15,000
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Hairdressing_12개월: 약 $12,000-15,000 / Cert_III_Beauty_Services_12개월: 약 $12,000-15,000 / Cert_IV_Hairdressing_18개월: 약 $14,000-17,000 / Diploma_Beauty_Therapy_18-24개월: 약 $16,000-22,000

#### TAFE Diploma IT Networking
위치: 각 주 TAFE
학비: Cert_IV_Information_Technology_12개월: 약 $12,000-15,000
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_IV_Information_Technology_12개월: 약 $12,000-15,000 / Diploma_IT_18-24개월: 약 $18,000-22,000 / Diploma_Cyber_Security_18-24개월: 약 $20,000-26,000 / Diploma_Software_Development_18-24개월: 약 $20,000-26,000

#### Endeavour College of Natural Health
위치: Sydney + Melbourne + Brisbane + Adelaide + Perth + Gold Coast
학비: Bachelor_Health_Science_Naturopathy_4년: 약 $26,000-30,000/년
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Bachelor_Health_Science_Naturopathy_4년: 약 $26,000-30,000/년 / Bachelor_Health_Science_Acupuncture_4년: 약 $26,000-30,000/년 / Bachelor_Health_Science_Nutrition_3년: 약 $24,000-28,000/년 / Bachelor_Health_Sci
비고: ⚠️ 사립 직업 College = 폐교 위험 검증 필요

#### TAFE Aged Care Disability
위치: 각 주 TAFE
학비: Cert_III_Individual_Support_Aged_Care_12개월: 약 $8,000-12,000 (학비 저렴)
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Individual_Support_Aged_Care_12개월: 약 $8,000-12,000 (학비 저렴) / Cert_IV_Aged_Care_18개월: 약 $12,000-15,000 / Diploma_Nursing_2년: 약 $20,000-25,000 / Bachelor Nursing 진학 / Cert_III_Early_Childhood

#### ACAP Australian College Applied Professions
위치: Sydney + Melbourne + Brisbane + Adelaide + Perth + Online
학비: Bachelor_Counselling_3년: 약 $25,000-29,000/년
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Bachelor_Counselling_3년: 약 $25,000-29,000/년 / Bachelor_Psychological_Science_3년: 약 $25,000-29,000/년 / Bachelor_Social_Work_4년: 약 $24,000-28,000/년 / Diploma_Counselling: 약 $20,000-24,000

#### TAFE Trade Carpenter Welder Plumber Electrician
위치: 각 주 TAFE
학비: Cert_III_Carpentry_3-4년: 약 $12,000-18,000 (apprentice = 무료 가능)
IELTS: 5.5 (Cert III/IV) / 6.0 (Diploma)
코스: Cert_III_Carpentry_3-4년: 약 $12,000-18,000 (apprentice = 무료 가능) / Cert_III_Welding_Fabrication_3-4년: 약 $12,000-15,000 / Cert_III_Plumbing_4년: 약 $15,000-20,000 / Cert_III_Electrician_4년: 약 $15,000-20,00

### 3-8. Under 18 (조기유학 / 21개)

17세 이하 학생 대상. 검증 + 회피 분리:

#### Wilson 검증 (18개)

- **[NSW] Killara High School** - 한국인 비율: 약 5-10% () - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[NSW] Cherrybrook Technology High School** - 한국인 비율: 약 8-12% - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[NSW] Pittwater High School** - 한국인 비율: 약 3-5% () - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[NSW] Beacon Hill High School** - 한국인 비율: 약 5-8% - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[NSW] Davidson High School** - 한국인 비율: 약 5-10% - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[NSW] NSW Selective High Schools (호주 학생용 / 국제 학생 직접 지원 X)** - - Sydney Metro = Cat 1 / Regional NSW = Cat 2 +15
- **[VIC] Balwyn High School** - 한국인 비율: 약 8-12% - Melbourne = Cat 1 / Regional VIC = Cat 2 +15
- **[VIC] Camberwell High School** - 한국인 비율: 약 10-15% - Melbourne = Cat 1 / Regional VIC = Cat 2 +15
- **[VIC] McKinnon Secondary College** - 한국인 비율: 약 5-10% - Melbourne = Cat 1 / Regional VIC = Cat 2 +15
- **[QLD] Brisbane State High School** - 한국인 비율: 약 5-8% - Brisbane/GC = Cat 2 +15
- **[QLD] Robina State High School** - 한국인 비율: 약 5-10% - Brisbane/GC = Cat 2 +15
- **[SA] Adelaide High School** - 한국인 비율: 약 3-5% - Adelaide = Cat 2 +15
- **[SA] Glenunga International High School** - 한국인 비율: 약 5-8% - Adelaide = Cat 2 +15
- **[TAS] Hobart College** - 한국인 비율: 약 2-5% () - TAS 전체 = Cat 3 +15+5
- **[TAS] Elizabeth College** - 한국인 비율: 약 2-5% - TAS 전체 = Cat 3 +15+5
- **[NT] Darwin High School** - 한국인 비율: 약 2-3% () - NT 전체 = Cat 3 +15+5
- **[WA] Perth Modern School** - 한국인 비율: 약 3-5% - Perth = Cat 2 +15
- **[WA] Rossmoyne Senior High School** - 한국인 비율: 약 5-8% - Perth = Cat 2 +15

#### Wilson 회피 (3개)

⛔ 한국인 비율 높음 = RISK-07 자동 차단

- [NSW] Strathfield Girls / Burwood Girls / Homebush Boys - 한국인 비율: 약 30-40%+
- [NSW] Chatswood High School - 한국인 비율: 약 25-35%
- [VIC] Box Hill High School / Glen Waverley Secondary - 한국인 비율: 약 25-35% (한국+중국+동아시아 합치면 50%+)

### 3-9. Under 18 공립 (6개 주)

#### NSW Sydney 공립학교 (조기유학)
위치: NSW - Sydney + 지역 200개 이상
학비: 신청비: $150 (1회 / 환불 X) / Primary K-Year 6: $15,500/년 / Junior High Year 7-10: $18,000/년 / Senior High Year 11-12: $18,000/년 / Wilson 2026 할인: 표준 홈스테이 거주 = $3,500 1회 할인 / Study Abroad =
비고: NSW 2026 = 표준 홈스테이 = $3,500 할인 () / Killara HS / Pittwater HS = 한국인 적음 = Wilson / ❌ Strathfield Girls / Burwood / Chatswood = 한국인 30%+ 회피

#### VIC Melbourne 공립학교 (조기유학)
위치: VIC - Melbourne + 지역 약 130개 학교
학비: Primary Prep-Year 6: 약 $13,200-$16,000/년 / Junior Secondary Year 7-10: 약 $17,000-$22,000/년 / Senior Secondary Year 11-12 VCE: 약 $22,000-$26,820/년 / VET 추가: $49-$1,739/과목/년 / VET 자료비: $60-$950/과목/년
비고: Melbourne 공립 = VCE = UMelb / Monash 진학 / Camberwell HS / McKinnon SC = 한국인 5-15% = / ❌ Box Hill HS / Glen Waverley SC = 동아시아 50%+ 회피

#### QLD Brisbane/Gold Coast EQI (조기유학)
위치: QLD - Queensland 95개 학교 (Brisbane / Gold Coast / Cairns / Sunshine Coast)
학비: Primary Prep-Year 6: $15,176/년 (3 terms = $11,382 / 2 terms / HSP High School Prep: $507/주 / Junior High Year 7-10: $16,612/년 / Senior High Year 11-12: $18,776/년 (QCAA 시험비 포함) / IB Diploma: $21,458/년
비고: Brisbane / Gold Coast = Cat 2 +15 PR 가산점 (대학 진학 시) / EQI 무료 공항 픽업 = 다른 주 X () / Cairns / Sunshine Coast = Cat 3 DRA = PR

#### WA Perth TIWA (조기유학)
위치: WA - Perth + 지역 약 70개 공립
학비: Kindergarten 선택: $7,809/년 / Pre primary: $14,575/년 / Primary Year 1 6: $14,575/년 (IEC 추가 시 $17,575) / Lower Sec Year 7 10: $17,286/년 (IEC 추가 시 $20,286) / Upper Sec Year 11 12: $18,980/년 (IEC 추가 시 $21,980)
비고: Perth = Cat 2 +15 PR 가산점 / Rossmoyne SHS / Perth Modern = 한국인 3-8% / Perth 처리 8-12주 = 조기 신청 필수

#### SA Adelaide HSGP (조기유학)
위치: SA - 약 90+ 학교
학비: Primary Reception Year 6: $12,960/년 학비 / Junior HS Year 7 10: $15,880/년 / Senior HS Year 11 12: $17,440/년 / ISEC 영어: 포함 ( = NSW/VIC/QLD/WA 별도 +$3,000 절약) / Primary Study Abroad 1term: $4,436
비고: SA = 호주 공립 학비 가장 저렴 (Primary $12,960 / Junior $15,880 / Senior $17,440) / ISEC 영어 = 학비 포함 = 다른 주 대비 +$3,000 절약 / Adelaide Cat 2 +15 PR + 한국인 3-8% ()

#### 6개 주 종합 전략
위치: 6개 주 (NSW/VIC/QLD/WA/SA/NT/TAS)
학비: 학비 순서: SA Adelaide < QLD Brisbane Regional < QLD Brisbane Metro < WA Perth < VIC Melbourne < NSW Sydney

### 3-10. Cat 30 (신규 223개)

호주 정부 지정 230개 학교 중 신규 추가 223개 학교 (학교명만).
Wilson 검증 진행 중. 카드 엔진은 Wilson 검증된 학교만 사용.

**[?] 223개**: Carrick Institute of Education, Spencer Institute, Skills Recognition International (SRI), BMIHMS by Torrens, William Blue College of Hospitality (Torrens)...

### 3-11. HSP (조기유학)

HSP 사립 ELICOS 15개 + 정부 HSP 5개 주.

**HSP 5개 운영 주체**:
- QLD EQI HSP (Education Queensland International)
- NSW IEC (Intensive English Centres)
- VIC ELC / Language School
- WA IEC (TIWA)
- SA ISEC (Intensive Secondary English Course)

---

### 3-12. Foundation 코스 상세 (32개)

Foundation 학교 8개의 세부 코스. 학교별 Standard/Extended/Express 등 변형:

#### Trinity College
*패스웨이: University of Melbourne (UMelb)*

- **Standard** (Foundation) - $44,540 / 8개월
- **Comprehensive** (Foundation) - $55,290 / 10개월
- **Fast Track** (Foundation) - $44,540 / 6개월 (NEW)

#### Monash College Foundation
*패스웨이: Monash University*

- **Standard** (Foundation) - 약 $38,400 / 12개월
- **Intensive** (Foundation) - 약 $40,000+ / 8개월
- **Extended** (Foundation) - 약 $48,000+ / 15개월

#### UNSW College Foundation
*패스웨이: UNSW Sydney*

- **Transition** (Foundation) - $29,200 / 단축
- **Standard** (Foundation) - $42,700 / Year 11/12
- **Standard Plus** (Foundation) - $47,800 / 영어 약
- **Diploma Engineering** (Diploma) - $48,480
- **Diploma Business** (Diploma) - $54,540
- **Diploma Architecture** (Diploma) - $48,060
- **Diploma Media** (Diploma) - $45,330
- **Pre-Masters Eng/IT** (Other) - $24,400
- **Academic English** (Other) - $694/주

#### Taylors College Sydney
*패스웨이: University of Sydney*

- **Standard** (Foundation) - $48,350 / 12개월
- **Intensive** (Foundation) - $46,300 / 9개월
- **HAPP (Health Path)** (Other) - $31,300 / 6개월

#### Eynesbury College
*패스웨이: Adelaide University (구 Adelaide + UniSA 통합 - 2026.01 시작)*

- **Foundation Standard** (Foundation) - $28,700 / 12개월 (메모리 v6.2 / 호주 최저급)
- **Foundation Stage 1 (Arts/Bus/IT/Health)** (Foundation) - $32,000
- **Diploma Stage 2 Arts** (Diploma) - $35,120
- **Diploma Stage 2 Business** (Diploma) - $40,240
- **Diploma Stage 2 Computing/IT** (Diploma) - $41,120
- **Diploma Stage 2 Engineering** (Diploma) - $43,720 (최고)
- **Diploma Stage 2 Health Science** (Diploma) - $40,720
- **Grad Cert Bus** (Other) - $23,440
- **ELICOS** (Other) - $400/주

#### ANU College Foundation
*패스웨이: Australian National University (ANU)*

- **Standard** (Foundation) - $39,450 / 9개월

#### UQ College Foundation
*패스웨이: University of Queensland (UQ)*

- **Standard** (Foundation) - $39,172 / 12개월
- **Accelerated** (Other) - $27,490 / 5개월 (호주 최저)

#### UWA Foundation
*패스웨이: University of Western Australia (UWA)*

- **Standard** (Foundation) - $35,300 / 10개월
- **Extended** (Foundation) - $36,900 / 14개월

### 3-13. HSP 사립 ELICOS (15개)

HSP (조기유학) 사립 어학원 15개:

- **[QLD] BROWNS English Language School** (CRICOS 검증 필요) - tuition: $510/주 (HSP) / Junior Price List 별도 / OSHC: Allianz Care Australia / 유니폼: 필수 (HSP/PSP 학생 = 셔츠 2장 필수 / 3-10월 = Hoodie 1장 필수) / QLD - Brisbane / Gold Coast / Melbourne (3개 캠퍼스)
- **[QLD] Shafston International College** (CRICOS 검증 필요) - tuition: $550/주 (HSP) / Brisbane 캠퍼스 = AUD $550/주 / Application_Fee: $260 / Accommodation_Placement: 별도 / QLD - Brisbane (Kangaroo Point) / Gold Coast (Sout
- **[QLD] Imagine Education Australia** (CRICOS 검증 필요) / QLD - Gold Coast
- **[NSW] Lexis English Sydney** (CRICOS 검증 필요) - 약 $480-$520/주 (정확한 공식 가격 어학원 직접 문의) / NSW - Sydney (Manly = 해변) / Brisbane / Perth / Byr
- **[NSW] ELC English Language Company** (CRICOS 검증 필요) / NSW - Sydney CBD
- **[NSW] Greenwich English College** (CRICOS 검증 필요) / NSW -
- **[VIC] Hawthorn Melbourne EfHS** (CRICOS 검증 필요) / VIC -
- **[VIC] Acknowledge Education 구 Melbourne Language Centre** (CRICOS 검증 필요) / VIC - Melbourne
- **[VIC] BROWNS Melbourne** (CRICOS 검증 필요) / VIC -
- **[WA] Phoenix Academy** (CRICOS 검증 필요) / WA - West Perth
- **[WA] AngliSchools International** (CRICOS 검증 필요) / WA - Perth
- **[WA] Milner International College** (CRICOS 검증 필요) / WA -
- **[SA] Kaplan International College Adelaide** (CRICOS 검증 필요) / SA -
- **[SA] South Australian College of English SACE** (CRICOS 검증 필요) / SA -
- **[SA] Eynesbury College** (CRICOS 검증 필요) / SA -

### 3-14. 운영 검증 알림 (13개)

Wilson 2026.04.28 검증한 운영 변경 알림 (합병/명칭변경/신규 등):

- **Adelaide University** - 신규 운영 (2026.01.05 합병)
 - ✅ 2026.01.05 운영 시작 / Eynesbury/Bradford = 패스웨이 유지
- **ECU City Campus** - 2026.02 신규 캠퍼스 오픈
 - ✅ ECU = Perth CBD 진출 = 한국 학생 접근성 ↑
- **Trinity College Melbourne** - ✅ 운영 중
- **Eynesbury College** - ✅ 운영 중 (Adelaide University 패스웨이)
- **ECC Edith Cowan College** - ✅ 운영 중 (Joondalup + Mount Lawley → ECU City)
- **APIC** - ✅ 운영 중 (Sydney Ultimo)
- **Excelsia University College** - ✅ 운영 중 (2024 TEQSA University College 승격)
 - 윌슨님 ECE 학교 / 정식 University College 승격 = 학생/학부모 신뢰도 ↑
- **Australian University of Theology AUT** - 🆕 신규 대학 (2025.01.01)
 - 신학 전문 대학. 윌슨님 학생 = 사용 대상 X (특수)
- **UTS 2026 alert** - ⚠️ 운영 중 / 비즈니스 변화 주의 ⚠️ 2025년 = 400명 감원 + 150 코스 2026년 정지 = Operational Sustainability Initiative
- **UMelb 2026 alert** - ⚠️ 운영 중 / 입학 마감 빠름 ⚠️ 2026년 7월 입학 = 신규 지원 마감 ⚠️
- **UTS College INSEARCH** - ✅ 운영 중
 - UTS 진학 패스웨이 (Navitas 그룹 X / UTS 직접 운영)
- **Torrens University** - ✅ 운영 중
 - DB의 #038 Torrens 정확 / Adelaide CBD 메인
- **SAE University College** - ✅ 운영 중 (TEQSA University College 승격)
 - 오디오/필름/애니메이션/게임 호주 + University College 승격 = 신뢰도 ↑

### 3-15. Cat 30 신규 학교 상세 (223개 / Wilson 검증 진행 중)

호주 정부 지정 학교 중 신규 추가 223개. 학교명/지역/학비 정보 (Wilson 검증 미완료 = 카드 엔진 안내 시 검증 필요):

#### Cat A - 의료/약학 (14개)
- **Carrick Institute of Education** (사립)
- **Spencer Institute** (사립)
- **Skills Recognition International (SRI)** (사립)
- **Le Cordon Bleu Australia** (사립) / PR: Chef 351311
- **William Angliss Institute** (사립) / PR: Chef 351311
- **Imagine Education Australia** (사립) / PR: Chef 351311
- **Greenwich Management College** (사립) / PR: Chef 351311
- **Australian Pacific College (APC)** (사립) / PR: Chef 351311
- **Sydney College of Business and IT (SCBIT)** (사립) / PR: Chef 351311
- **Australian National College (ANC)** (사립) / PR: Chef 351311
- **Australian Institute of Commerce and Language (AICL)** (사립) / PR: Chef 351311
- **Lonsdale Institute - Cookery** (사립) / PR: Chef 351311
- **TAFE NSW - Cookery** (국립 (TAFE)) / PR: Chef 351311
- **TAFE QLD - Cookery** (국립 (TAFE)) / PR: Chef 351311

#### Cat AB - 기타2 (4개)
- **Bond University (#025 v2)** (국립)
- **Notre Dame Australia (#026 v2)** (국립)
- **Torrens University (#038 v2)** (국립)
- **Avondale University (#037 v2)** (국립)

#### Cat AC - 국제대학 (2개)
- **Carnegie Mellon University Australia (CMU)** (국립)
- **University College London (UCL) Australia** (국립)

#### Cat AD - TAFE 시스템 (9개)
- **TAFE NSW** (국립 (TAFE))
- **TAFE SA** (국립 (TAFE))
- **TAFE WA / South Metropolitan** (국립 (TAFE))
- **Bendigo Kangan Institute** (국립 (TAFE))
- **Holmesglen Institute** (국립 (TAFE))
- **CIT (Canberra)** (국립 (TAFE))
- **TasTAFE** (국립 (TAFE))
- **TAFE Queensland** (국립 (TAFE))
- **Box Hill Institute** (국립 (TAFE))

#### Cat B - IT (12개)
- **BMIHMS by Torrens** (국립)
- **William Blue College of Hospitality (Torrens)** (국립)
- **Kenvale College** (사립)
- **ACU Hospitality** (국립)
- **TAFE SA Hospitality** (국립 (TAFE))
- **Holmes Institute Hospitality** (국립)
- **Griffith University Hospitality** (국립)
- **UniSC Tourism** (국립)
- **Victoria University Hospitality** (국립)
- **International College of Hotel Management (ICHM)** (사립) / PR: Hotel/Cafe Manager 141311/141111
- **Le Cordon Bleu Hotel Management** (사립) / PR: Hotel/Cafe Manager 141311/141111
- **TAFE Queensland Hospitality** (국립 (TAFE)) / PR: Hotel/Cafe Manager 141311/141111

#### Cat C - Business (10개)
- **APIC** (사립)
- **Holmes Institute (#039 v2)** (국립)
- **Stott's Colleges** (사립)
- **Kaplan Business School (KBS)** (사립) / PR: Accountant 221111
- **Australian Institute of Business (AIB)** (사립) / PR: Accountant 221111
- **Melbourne Institute of Technology (MIT)** (사립) / PR: Accountant 221111
- **Sydney International Business School (SIBS)** (사립) / PR: Accountant 221111
- **King's Own Institute (KOI)** (사립) / PR: Accountant 221111
- **Education Centre of Australia (ECA)** (사립) / PR: Accountant 221111
- **Australian Institute of Higher Education (AIH)** (사립) / PR: Accountant 221111

#### Cat D - Engineering (5개)
- **APIC** (사립)
- **MIT (Melbourne Institute of Technology)** (사립) / PR: Software Engineer 261313
- **AIH (Australian Institute of Higher Education)** (사립) / PR: Software Engineer 261313
- **KOI (King's Own Institute)** (사립) / PR: Software Engineer 261313
- **Lonsdale Institute** (사립) / PR: Software Engineer 261313

#### Cat E - 교육 (6개)
- **JMC Academy** (사립)
- **SAE Institute** (사립)
- **Billy Blue College of Design (Torrens)** (국립)
- **Whitehouse Institute of Design** (사립)
- **Academy of Information Technology (AIT)** (사립)
- **RMIT Design** (국립)

#### Cat F - 디자인/예술 (9개)
- **Australasian Academy of Cosmetic Dermal Science** (사립) / PR: Hairdresser 391111
- **Elly Lukas Beauty Therapy College** (사립) / PR: Hairdresser 391111
- **The French Beauty Academy** (사립) / PR: Hairdresser 391111
- **Demi International** (사립) / PR: Hairdresser 391111
- **Cynergex Group / Australasian College Broadway** (사립) / PR: Hairdresser 391111
- **Australian National College of Beauty** (사립) / PR: Hairdresser 391111
- **TAFE NSW Beauty** (국립 (TAFE)) / PR: Hairdresser 391111
- **Endeavour College of Natural Health** (사립) / PR: Hairdresser 391111
- **Australian Institute of Applied Sciences (AIAS)** (사립) / PR: Hairdresser 391111

#### Cat G - 호스피탈리티 (4개)
- **Basair Aviation College** (사립)
- **Royal Victorian Aero Club** (국립)
- **Aviation Australia (Brisbane)** (사립)
- **Sydney Flight College** (사립) / PR: Pilot 231114 / Aircraft Maintenance Eng 323111

#### Cat H - Trade (3개)
- **TAFE NSW - Health Services Assistance** (국립 (TAFE))
- **Open Colleges (Online)** (사립)
- **Australian Institute of Professional Counsellors** (사립) / PR: Health Services Assistant

#### Cat I - 농업/수의 (18개)
- **Holmesglen TAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **South Metropolitan TAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **Bendigo Kangan Institute** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE NSW** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE SA** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE WA** (국립 (TAFE)) / PR: Trade MLTSSL
- **TasTAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **RMIT Trade School** (국립) / PR: Trade MLTSSL
- **Swinburne TAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **North Metropolitan TAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE QLD - Brisbane SkillsTech** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE QLD - Cairns** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE QLD - Townsville** (국립 (TAFE)) / PR: Trade MLTSSL
- **Box Hill Institute** (국립 (TAFE)) / PR: Trade MLTSSL
- **TAFE Queensland** (국립 (TAFE)) / PR: Trade MLTSSL
- **Canberra Institute of Technology (CIT)** (국립 (TAFE)) / PR: Trade MLTSSL
- **William Angliss TAFE** (국립 (TAFE)) / PR: Trade MLTSSL
- **Charles Darwin University TAFE** (국립 (TAFE)) / PR: Trade MLTSSL

#### Cat K - 항공 (24개)
- **USyd Foundation (Taylors College Sydney)** (국립)
- **ANU College** (국립)
- **UTS College / UTS Insearch** (국립)
- **Macquarie College / MUIC** (국립)
- **Newcastle Navitas (NIC)** (국립)
- **Holmes Institute Foundation/Diploma** (국립)
- **Trinity College** (사립) / PR: Foundation 학과별
- **Monash College Foundation** (국립) / PR: Foundation 학과별
- **UNSW Foundation Studies (UNSW Global)** (국립) / PR: Foundation 학과별
- **Adelaide College Foundation** (국립) / PR: Foundation 학과별
- **Western Sydney University College** (국립) / PR: Foundation 학과별
- **Curtin College** (국립) / PR: Foundation 학과별
- **Eynesbury College** (사립) / PR: Foundation 학과별
- **Bradford College** (사립) / PR: Foundation 학과별
- **Taylors College Perth** (사립) / PR: Foundation 학과별
- **Deakin College** (국립) / PR: Foundation 학과별
- **La Trobe College** (국립) / PR: Foundation 학과별
- **RMIT Training** (국립) / PR: Foundation 학과별
- **Murdoch College** (사립) / PR: Foundation 학과별
- **Edith Cowan College (구 PIBT)** (사립) / PR: Foundation 학과별
- **Queensland Institute of Business (QIBT)** (사립) / PR: Foundation 학과별
- **SIBT (Sydney Institute of Business)** (사립) / PR: Foundation 학과별
- **INTO James Cook University** (국립) / PR: Foundation 학과별
- **University of Canberra College** (국립) / PR: Foundation 학과별

#### Cat L - 해양 (6개)
- **RMIT Diploma of Remedial Massage** (국립)
- **NSW School of Massage** (사립)
- **Max Therapy Institute (MTI)** (사립)
- **Mastery Institute Australia** (사립) / PR: Massage Therapist 411611
- **TAFE NSW Diploma of Remedial Massage (HLT52021)** (국립 (TAFE)) / PR: Massage Therapist 411611
- **TAFE Queensland Diploma of Remedial Massage** (국립 (TAFE)) / PR: Massage Therapist 411611

#### Cat M - 간호 (8개)
- **IHNA (Institute of Health and Nursing Australia)** (사립) / PR: Enrolled Nurse 411411
- **EQUALS International** (사립) / PR: Enrolled Nurse 411411
- **UTS** (국립) / PR: Enrolled Nurse 411411
- **Federation University** (국립) / PR: Enrolled Nurse 411411
- **TAFE NSW Diploma of Nursing (HLT54121)** (국립 (TAFE)) / PR: Enrolled Nurse 411411
- **ACN (Australian College of Nursing)** (사립) / PR: Enrolled Nurse 411411
- **Imagine Education Diploma of Nursing** (사립) / PR: Enrolled Nurse 411411
- **Western Sydney University** (국립) / PR: Enrolled Nurse 411411

#### Cat N - 유아교육 (22개)
- **Excelsia College - GD of Early Childhood Teaching** (국립) / PR: Early Childhood Teacher 241111
- **UMelb - Master of Teaching ECE** (국립) / PR: Early Childhood Teacher 241111
- **UNSW Master of Teaching** (국립) / PR: Early Childhood Teacher 241111
- **USyd Master of Teaching** (국립) / PR: Early Childhood Teacher 241111
- **Monash Master of Teaching** (국립) / PR: Early Childhood Teacher 241111
- **Macquarie Master of Teaching** (국립) / PR: Early Childhood Teacher 241111
- **Federation University Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **ACU Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **Avondale Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **Charles Sturt Bachelor of ECE** (사립) / PR: Early Childhood Teacher 241111
- **Berkeley International Diploma of ECE (CHC50121)** (사립) / PR: Early Childhood Teacher 241111
- **QUT Bachelor of ECE** (사립) / PR: Early Childhood Teacher 241111
- **Deakin Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **RMIT Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **ECU Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **Curtin Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **VU Bachelor of ECE** (사립) / PR: Early Childhood Teacher 241111
- **Swinburne Bachelor of ECE** (국립) / PR: Early Childhood Teacher 241111
- **Holmes Institute ECE** (국립) / PR: Early Childhood Teacher 241111
- **TAFE NSW Diploma of ECE (CHC50121)** (국립 (TAFE)) / PR: Early Childhood Teacher 241111
- **TAFE QLD Diploma of ECE** (국립 (TAFE)) / PR: Early Childhood Teacher 241111
- **Western Sydney Bachelor of ECE** (사립) / PR: Early Childhood Teacher 241111

#### Cat P - 요리 (5개)
- **UTAS Bachelor of Pharmacy (Honours)** (국립) / PR: Hospital Pharmacist 251513
- **Curtin Master of Pharmacy** (국립) / PR: Hospital Pharmacist 251513
- **Adelaide Master of Pharmacy** (국립) / PR: Hospital Pharmacist 251513
- **Monash Master of Pharmacy** (국립) / PR: Hospital Pharmacist 251513
- **USyd Master of Pharmacy** (국립) / PR: Hospital Pharmacist 251513

#### Cat Q - 수의학 (5개)
- **Murdoch University Vet** (국립) / PR: Veterinarian 234711
- **Melbourne University Vet** (국립) / PR: Veterinarian 234711
- **Queensland University Vet** (국립) / PR: Veterinarian 234711
- **Sydney University Vet** (국립) / PR: Veterinarian 234711
- **James Cook Vet** (사립) / PR: Veterinarian 234711

#### Cat R - Foundation/Pathway (6개)
- **USyd Master of Physiotherapy** (국립) / PR: Physiotherapist 252511 / Occupational Therapist 252411
- **UMelb Master of Physiotherapy** (국립) / PR: Physiotherapist 252511 / Occupational Therapist 252411
- **UQ Master of Physiotherapy** (국립) / PR: Physiotherapist 252511 / Occupational Therapist 252411
- **Curtin Physio** (국립) / PR: Physiotherapist 252511 / Occupational Therapist 252411
- **Charles Sturt Physio** (사립) / PR: Physiotherapist 252511 / Occupational Therapist 252411
- **JCU Physio** (국립) / PR: Physiotherapist 252511 / Occupational Therapist 252411

#### Cat S - 심리/사회복지 (6개)
- **Swinburne MSW** (국립) / PR: Social Worker 272511
- **USyd Master of Social Work** (국립) / PR: Social Worker 272511
- **UMelb Master of Social Work** (국립) / PR: Social Worker 272511
- **Monash Master of Social Work** (국립) / PR: Social Worker 272511
- **RMIT Master of Social Work** (국립) / PR: Social Worker 272511
- **ACU Master of Social Work** (국립) / PR: Social Worker 272511

#### Cat T - 관광 (7개)
- **UMelb Master of TESOL** (국립) / PR: TESOL Teacher
- **USyd Master of TESOL** (국립) / PR: TESOL Teacher
- **UNSW Master of TESOL** (국립) / PR: TESOL Teacher
- **Monash Master of TESOL** (국립) / PR: TESOL Teacher
- **Macquarie Master of TESOL** (국립) / PR: TESOL Teacher
- **UTS Master of TESOL** (국립) / PR: TESOL Teacher
- **RMIT Master of TESOL** (국립) / PR: TESOL Teacher

#### Cat U - 컴퓨터/사이버 (6개)
- **UNSW Master of Construction Management** (국립) / PR: Construction Project Manager 133111
- **USyd Master of Construction** (국립) / PR: Construction Project Manager 133111
- **RMIT Master of Construction** (국립) / PR: Construction Project Manager 133111
- **Deakin Master of Construction** (국립) / PR: Construction Project Manager 133111
- **Bond Master of Construction** (국립) / PR: Construction Project Manager 133111
- **QUT Master of Construction** (사립) / PR: Construction Project Manager 133111

#### Cat V - 음악/공연 (5개)
- **Sydney Conservatorium of Music** (국립)
- **Melbourne Conservatorium** (국립)
- **JMC Academy Music** (사립)
- **VCA (Victorian College of the Arts)** (국립)
- **WAAPA (Edith Cowan)** (사립) / PR: Music Teacher / Performer

#### Cat W - 체육/스포츠 (5개)
- **UNSW Renewable Energy Engineering** (국립)
- **Monash Renewable Energy** (국립)
- **USyd Sustainable Energy** (국립)
- **ANU Renewable Energy** (국립)
- **Adelaide Renewable Energy** (국립)

#### Cat X - 법학 (7개)
- **UNSW Master of Data Science / AI** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **Monash Master of AI** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **USyd Master of Data Science** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **RMIT Master of AI** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **UTS Master of AI** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **Torrens AIRO (세계 1위 AI 연구자)** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313
- **Carnegie Mellon University Australia (CMU)** (국립) / PR: ICT Business Analyst 261111 / Software Engineer 261313

#### Cat Y - 미디어 (7개)
- **UNSW Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **USyd Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **UTS Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **RMIT Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **Monash Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **Deakin Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112
- **La Trobe Master of Cybersecurity** (국립) / PR: ICT Security Specialist 262112

#### Cat Z - 기타 (8개)
- **UMelb (#001 v2)** (국립)
- **USyd (#002 v2)** (국립)
- **UNSW (#003 v2)** (국립)
- **ANU (#004 v2)** (국립)
- **Monash (#005 v2)** (국립)
- **UQ (#006 v2)** (국립)
- **UWA (#007 v2)** (국립)
- **Adelaide (#008 v2)** (국립)

## Part 4. 검증 알림 (24개)

호주 유학원 운영 중 검증된 핵심 알림. 카드 엔진은 학교 안내 시 알림과 충돌하지 않는지 체크.

### ibt_renaming - ibt renaming
- ✅ 2026-04-28 검증 완료 / IBT 형식 명칭 = 모두 새 명칭 사용

### closures_total - closures total
- 18

### new_universities - new universities
- Adelaide University (2026.01.05 합병) + AUT (2025.01 신규) = 호주 41개 대학

### uts_alert - uts alert
- UTS 400명 감원 + 150 코스 정지 = 학생 코스 사전 확인 必

### umelb_alert - umelb alert
- UMelb 2026.07 신규 지원 마감 = 7월 입학 거의 불가

### excelsia_upgrade - excelsia upgrade
- Excelsia College → University College 승격 (2024) + Pennant Hills 이전 (2025.07)

### elicos_market - elicos market
- 비자료 $2,000 (2025.07~) = 어학원 단독 비자 39% 감소 = 패키지 비자 권장

### apic_disambiguation - apic disambiguation
- APIC = 두 학교 (Asia Pacific International College ≠ Australian Pacific College)

### ALERT_FUNNEL_FINAL_GATE - 윌슨 최종 체크 게이트 (Funnel → 카카오 사이)
- 카카오 보내기 전 내가 최종 체크 하고 버튼 누르면 카카오. 이거 중요하니까 메모 해놔. 다음 채팅창에 가면 또 꼬여
- 적용: STEP 3 Funnel + STEP 6 카드 + STEP 7 관리자 페이지

### ALERT_A6_ABSORBED_BY_B1 - A6 페르소나 삭제 → B1에 흡수 (시장 진실)
- 워홀 고객들은 한국보다 현지에서 연락 많이 오고, 한국에서 문의한 친구들은 PR을 크게 생각지 않음

### ALERT_ADULT_STUDENTS_COMPARE - 성인 학생 = 여러 유학원 비교 = 마케팅 필수
- 대학 재학생들도 문의가 많지만, 성인이기에 여러군데 많이 알아보지
- 적용: A3 (대학 재학 포함) / B1, B3, B4 (성인 페르소나 모두)

### ALERT_PRE_DECISION_MARKET - 자퇴 결정 前 시장 = 새 발견 (윌슨 19년 통찰)
- 요즘에 나이가 16~19세로 해줘
- 적용: A1 (학생) + A2 (부모) / 카드 ID 분기

### ALERT_OPTION_3_WILSON_EMPTY_MARKET - 옵션 3 = 빈 시장 핵심

### ALERT_KAKAO_PERSISTENT_BUTTON - 사이트 하단 카카오 버튼 항상 표시 = 모든 페이지 안전망
- 원칙: 카카오 / 잘 모르는 학생도 직행 / 19년 윌슨 = 다른 유학원 챗봇과

### ALERT_REALITY_CHECK_SECTION - 카드 6 Section 핵심 = '현실 체크' (실패 사례)
- 1. 상황 선택 (공감) / 2. 실패 사례·현실 체크 (신뢰) / 3. 노하우 / 4. 루트 / 5. 간단 입력 / 6. 카톡 연결
- 적용: 모든 페르소나 카드 15가지 = Section 2에 페르소나별 실패 사례 박힘

### ALERT_TRANSPARENT_BUSINESS_MODEL - 투명 비즈니스 모델 = ausuhak 핵심
- 학비를 학생 또는 부모님이 직접 보내게 할꺼야. 기타 보험료 및 수속비, 비자 신청비만 받고, 그것도 영수증 다 드림. 학생 수속페이지에 직접 체크 가능하게.

### ALERT_PARENT_DOUBT_CHILD_ABILITY - A2 부모님 가장 큰 의문 = 자녀 능력 의심 + 자책감
- 검정고시 부모님, 고등학교 자퇴 했는데, 잘 할 수 있을까? 이런 의문을 가짐.
- Wilson 진실: answer 1: 한국에서 못 한 거 = 자녀 능력 X 절대 아님 (시스템 차이) / answer 2: 한국 = 조건 / 호주 = 달란트만 봄 (다른 시스템 = 다른 결과) / answer 3: 윌슨 시스템 = 졸업 보장 (Foundation + EAP + 화상영어 + 작은 도시 + 부모 카카오)
- 적용: A2_post / A2_pre 카드 = Section 1, 2, 6에 박혔음. A4 부모도 적용 가능 (다음 카드)

### ALERT_CLAUDE_BAKING_PRINCIPLE - Claude 박을 원칙: 윌슨님 말씀 그대로 박음 / 자동 해석 X
- 위에 작업 할때, 왜 니맘대로 해? 시골이 좋은데 학생은 안간다고 이야기 해잖아.
- 적용: 모든 박제 작업 (영구 원칙)

### ALERT_GO8_DIPLOMA_TRUTH - Go8 Diploma 진실 (윌슨 19년 정정 / UMelb 추가)
- Wilson 진실: Go8 8개 中 빠른 진학 (2학년 편입) 가능 = 6개 (UNSW/Monash/UQ/UWA/Adelaide/ANU) / USyd = Foundation만 (Diploma 없음) / UMelb = Foundation 必 (Diploma 빠른 루트 아님)

### ALERT_DIPLOMA_REQUIRES_KOREAN_UNI - Diploma 입학 조건 = 한국 대학 재학 1-2년 必
- 한국 친구들이 디플로마를 좋아해 이유는 1년 아낄 수 있으니까
- Wilson 진실: Diploma = 한국 대학 재학 1-2년 학점 필요 / 검정고시 학생 = Diploma X = Foundation만 / 고3 졸업 + 한국 대학 재학 1년 = Diploma 가능

### ALERT_ENGLISH_SKILL_VS_SCORE - 영어 점수 ≠ 학업 성공 (활용 능력 + 의지)
- G8 대학도 디플로마가 있어서 바로 학생이 가기도 하는데, 영어 점수 뿐만 아니라, 실제 영어 활용 능력이 좋은 학생, 열심히 하는 학생은 가서도 잘해. 안하는 학생이 문제지.
- Wilson 진실: IELTS 점수 = 입학 자격일 뿐 ≠ 학업 성공 / 영어 활용 능력 (회화/작문/이해) = 진짜 변수 / 학업 의지 (열심히 하는 학생) = 가장 큰 변수

### ALERT_STUDENT_WILL_IS_KEY - 학생 의지 = 가장 큰 변수
- 안 하는 학생이 문제지
- Wilson 진실: 학교 / 도시 / Foundation / Diploma 모두 좋아도 / 학생 의지 0% = 페일 / 학생 의지 100% = 시스템 다 극복

### ALERT_RURAL_VS_CITY_DILEMMA - 시골 학교 vs 도시 욕심 = 윌슨 19년 안타까움 ⚠️
- 이런 학생은 시골로 빼면 좋은데 학생이 싫어해 ;;

### ALERT_NO_SINGLE_SCHOOL_RECOMMENDATION - 특정 학교 단일 추천 X = 윌슨 절대 원칙
- 특정 학교만 추천 하는 거야?
- 원칙: ['학교 같은 것 없음', '학교에 등급 매기는 표현 X', '학생 상황별 맞춤 옵션 안내만', '윌슨 매칭 = 카카오에서 직접']
- 적용: 모든 카드 / 시뮬레이션 / 매칭 엔진

---

## Part 5. 차단 규칙 (Blocking Rules / 39개)

Wilson: "추천보다 차단이 핵심 (19년 950명 PR 60% 비결)"

### 카테고리 1: 절대 차단

*비자/입학 자체가 불가능한 절대 차단 룰*

**ABS-01**: CRICOS 미등록 학교 차단
- 조건: 추천 학교가 CRICOS 등록 안 된 경우
- 조치: ❌ 추천 제외 (학생비자 발급 불가)
- 대안: ✅ CRICOS 등록 학교만 추천
- 이유: CRICOS = 호주 정부 등록 외국학생 교육기관 코드. 미등록 = 학생비자 자체 불가

**ABS-02**: 온라인-only 과정 차단
- 조건: 100% 온라인 과정 추천 시도
- 조치: ❌ 학생비자 목적 불가
- 대안: ✅ Face-to-face 또는 Hybrid (대면 33%+ 필수)
- 이유: DHA 학생비자 = 대면 교육 33% 이상 필수. 온라인-only = 비자 발급 X

**ABS-03**: 초기 학비 납입 불가 차단
- 조건: 초기 학비 (보통 1학기) 납입 능력 없음
- 조치: ❌ COE 발급 불가 = 비자 신청 불가
- 대안: ✅ 학비 코스 (Cat 3 / TAFE) + 분할 납부 학교 추천
- 이유: COE (Confirmation of Enrolment) = 학비 선납 후 발급. 납입 불가 = 비자 신청 자체 불가능

**ABS-04**: 비자 거절 이력 + 사유 불명 차단
- 조건: 이전 호주 비자 거절 이력 + 거절 사유 정확히 모름
- 조치: ❌ 즉시 추천 차단 → 이민 변호사 상담 필수
- 대안: ✅ 거절 사유 파악 → 사유서 보강 → 재신청 전략
- 이유: 비자 거절 이력 = 재신청 매우 어려움. 사유 모르고 진행 = 또 거절 + 시간/돈 손실

**ABS-05**: EC English / Embassy / IH Sydney / 폐교 18곳 차단
- 조건: 어학원 추천 시 18개 폐교 학교 포함
- 조치: ❌ 절대 추천 X
- 대안: ✅ 운영 중인 어학원 47개 풀 중 추천
- 이유: EC English (2021 호주 폐교) / Embassy (EC 자매 폐교) / IH Sydney (2024.12.09 영구 폐교) 외 SELC, Lonsdale, ITHEA, UPC, Einstein, Astley, RGIT, Business Institute, Cocoon, Perth ICE, Language Academy, Leeds, Lloyds 등 18곳. 다른 유학원 아직도 SELC 추천 中 ⚠️

### 카테고리 2: GS 핵심

*Genuine Student (GS) 평가 = 2026년 호주 비자 심사 가장 중요. '왜 지금 이 과정을 하는가' 설명 못 하면 차단*

**GS-01**: 전공 변경 + 이유 없음
- 조건: 이전 학력/직업 ≠ 새 전공 + 변경 이유 설명 없음
- 조치: 🔴 GS 평가 BLOCK 위험
- 대안: ✅ 전공 변경 사유서 작성 + 커리어 연결성 명확화
- 이유: DHA = 전공 변경 시 학업 목적/커리어 연결 평가. 이유 없으면 = 학업 목적 불명확 = GS 거절

**GS-02**: 학업 공백 3년+ 설명 없음
- 조건: 최종 학력 또는 마지막 학업 종료 후 3년+ 공백 + 설명 없음
- 조치: 🔴 GS 평가 BLOCK 위험
- 대안: ✅ 공백 기간 활동 (직장/사업/육아 등) + 다시 공부하는 이유 명확화
- 이유: DHA = 학업 공백 = 학업 동기 약함으로 판단. 3년+ = 강한 설명 필요. 한국 고졸 후 30대 = 위험

**GS-03**: 고학력 → 낮은 과정 (다운그레이드)
- 조건: 이미 학사 보유 + 호주에서 Diploma/Cert 지원 (다운그레이드)
- 조치: 🔴 GS 평가 BLOCK 위험
- 대안: ✅ 같은 또는 높은 레벨 (Master) 또는 명확한 PR 목적/직업 전환 사유
- 이유: DHA = 다운그레이드 = '비자 목적 의심' 신호. PR 목적이라면 PR 경로 명확히 설명 필수 (TAFE 트레이드 PR 95% 등)

**GS-04**: GS 거절 위험 워홀러
- 조건: 워홀 1년+ + 영어 낮음 + 학력/경력 X + 학생비자 전환 시도
- 조치: 🔴 GS 거절 가능성 매우 높음
- 대안: ✅ 워홀 직종 = PR 경력 카운트 가능한 직종 매칭 + 학업 연결 명확화 + 사유서 보강
- 이유: 윌슨 19년 = 워홀 후 학업 연결 없으면 GS 거절 多. : 워홀 직종 → PR 경력 카운트 → 학업 연결 = 강한 GS

**GS-05**: 관광비자 → 학생비자 전환
- 조건: 관광비자 (600/651) 입국 후 학생비자 전환 시도
- 조치: 🔴 GS 평가 매우 엄격
- 대안: ✅ 한국 귀국 후 학생비자 신청 + 사유서 보강
- 이유: DHA = 관광 → 학생비자 전환 = '비자 쇼핑' 의심. GS 평가 매우 까다로움. 한국 귀국 후 신청이 안전

**GS-06**: 잦은 코스 변경
- 조건: 호주 도착 후 코스 2회+ 변경 이력
- 조치: 🔴 다음 비자 GS 평가 위험
- 대안: ✅ 코스 변경 사유 일관성 있게 설명 + 커리어 연결
- 이유: DHA = 코스 잦은 변경 = 학업 목적 불명확. 추천 시 학생에게 '이번이 마지막 변경' 명확히 인지시킴

**GS-07**: 단순 비자 연장 + 사파 학교 고집
- 조건: 워홀러 비자 연장 목적 + 학업 의지 0% + 저가/사파 학교 고집
- 조치: 🔴 GS 거절 + 폐교 위험 동시
- 대안: ✅ 학업 의지 점검 + 운영 안전한 학비 학교 추천
- 이유: 윌슨 19년 = 단순 비자 연장 + 사파 학교 = 학교 폐교 시 비자 영향 + GS 의심 동시. B2 페르소나 핵심 차단

### 카테고리 3: Direct Entry 차단

*학력/영어/성적 부족 시 = Direct Entry 불가 → 우회 루트로 자동 전환*

**DIR-01**: 영어 부족 + 학부 직접 차단
- 조건: IELTS < 5.5 또는 영어 시험 없음 + 학부/석사 Direct 지원
- 조치: ❌ Direct 차단
- 대안: ✅ 어학원 (필리핀 EC → 호주 EAP) → Foundation/Diploma → 학부
- 이유: 영어 부족 = 호주 도착 후 학업 따라가기 불가능 = 가장 큰 실패 케이스 (윌슨 19년 실패)

**DIR-02**: 고졸 + 석사 직접 차단
- 조건: 한국 학력 = 고졸 (검정고시/수능/내신) + 호주 석사 Direct 지원
- 조치: ❌ 석사 Direct 차단
- 대안: ✅ Foundation/Diploma → 학사 → 석사 (단계별)
- 이유: 석사 = 학사 학위 필수. 고졸 = 학사부터 시작

**DIR-03**: 검정고시 + Go8 직접 차단
- 조건: 한국 학력 = 검정고시 + Go8 Direct 입학 시도
- 조치: ⚠️ Go8 8개 학교 Direct = 까다로움 (불가능 가까움)
- 대안: ✅ Foundation 컬리지 (Trinity/Monash College/UNSW Foundation/Eynesbury) → Go8 1학년
- 이유: 검정고시 = 호주 학교가 한국 정규 고졸로 인정 안 함 = Foundation 안전한 길

**DIR-04**: 비전공 + Master 차단
- 조건: 한국 학사 학과 ≠ 호주 Master 전공 (Engineering/IT/Nursing/MSW 등)
- 조치: ⚠️ Direct 차단 또는 추가 코스 필요
- 대안: ✅ Graduate Certificate (6개월) → Master / 또는 학부 1년 추가
- 이유: Engineering/IT/Nursing/MSW 석사 = 학부 전공 이수 필수. 비전공 = 추가 학습 필요. AASW/ACS/AHPRA 등 협회 인증 엄격

**DIR-05**: 경력 없음 + MBA 차단
- 조건: 한국 직장 경력 < 2년 + MBA 지원
- 조치: ❌ MBA Direct 차단 (대부분 호주 MBA = 2-3년 경력 必)
- 대안: ✅ Master of Business / Master of Management (경력 X 가능) 또는 Bond MBA
- 이유: MBA = 경력자용. 경력 없음 = MBA 가치 낮고 비싸게 시간 낭비

**DIR-06**: GPA 2.0 미만 + Go8 석사 차단
- 조건: 한국 학사 GPA < 2.0/4.5 (= 2.0/4.0) + Go8 석사 지원
- 조치: ❌ Go8 석사 Direct 차단
- 대안: ✅ 비-Go8 석사 또는 Graduate Diploma → 석사 단계별
- 이유: Go8 석사 입학 = 평균 GPA 3.0+/4.0. 너무 낮으면 입학 거부

**DIR-07**: 학점은행/사이버대 + Go8 차단
- 조건: 한국 학력 = 학점은행 / 사이버대 / 야간대 졸업 + Go8 지원
- 조치: ⚠️ USyd / UMelb / UNSW / Monash 등 = 학위 인정 안 함 (대부분)
- 대안: ✅ 비-Go8 공립대 일부 / 사립대 / Foundation 패스웨이
- 이유: Go8 = 정규 4년제 한국 대학 학위만 인정. 학점은행 = 학위 인정 학교 별도 확인 必

**DIR-08**: Year 12만 1년 = 호주 대학 진학 차단
- 조건: 한국 고2 + 호주 Year 12 1년 = 호주 대학 직진
- 조치: ⚠️ ATAR 1년 = 호주 대학 매우 어려움
- 대안: ✅ Foundation (1년) → 학사 1학년 / 또는 Year 11-12 (2년) → ATAR
- 이유: ATAR = 2년 누적 평가. 1년만 하면 Year 12 시험만으로 평가되어 한국 학생 매우 불리

### 카테고리 4: 높은 리스크

*차단은 아니지만 = 매우 신중한 검토와 사유서 보강 필수*

**RISK-01**: 워홀 → 전공 변경
- 조건: 워홀 후 학생비자 전환 + 한국 학력과 다른 전공 선택
- 조치: ⚠️ HIGH RISK / 사유서 필수
- 대안: ✅ 전공 변경 사유 + 워홀 경험 연결 + 커리어 계획
- 이유: DHA = 워홀 후 무관한 전공 = GS 의심. 워홀 직종 + 새 전공 = 연결성 명확히

**RISK-02**: 나이 대비 낮은 과정
- 조건: 30대+ 학생 + Cert/Diploma 등 낮은 과정 지원
- 조치: ⚠️ HIGH RISK / GS 평가 까다로움
- 대안: ✅ 직업 전환 사유 + PR 경로 명확화 (TAFE 트레이드 = OK)
- 이유: 30대+ = 보통 Master 진학. 낮은 과정 선택 시 = 직업/PR 명확한 사유 必

**RISK-03**: PR + Sydney/Melbourne Metro 차단
- 조건: PR 목표 + 도시 = Sydney / Melbourne Metro
- 조치: ❌ Metro = Regional 가산점 0점 = PR 어려움
- 대안: ✅ Cat 3 DRA: Hobart / Darwin / Cairns / Townsville / Ballarat (+15점 + 추가) / Cat 2 +15: Perth / Adelaide / Gold Coast / Canberra / Newcastle
- 이유: PR 빠른 길 = Regional 가산점 必. Metro = 학벌만 가능 / PR 어려움

**RISK-04**: PR 목적 + 트레이드 1.5년 미만
- 조건: PR 목적 + 트레이드 (Carpenter/Welder/Chef 등) 1.5년 미만 코스
- 조치: ❌ 자동 차단 + 2년 패키지 자동 추천
- 대안: ✅ 2년 패키지 (Cert IV + Diploma 또는 Diploma + Adv Diploma)
- 이유: PR 트레이드 = 2년+ 학업 必 (485 비자 자격). 1.5년 = PR 0% / 시간/돈 낭비

**RISK-05**: 검정고시 + 단순 자유 추구 + 부모 의지 0%
- 조건: 검정고시 학생 + 자퇴 사유 = 단순 자유 + 부모 동기 0%
- 조치: ⚠️ 또 자퇴 위험 / 호주 가서도 못 적응
- 대안: ✅ 부모 동시 상담 → 양측 동기 정렬 → 진행 / 또는 1년 유예
- 이유: 윌슨 19년 = 학생만 자유 추구 + 부모 미지원 = 호주 도착 후 또 중도 포기 多

**RISK-06**: 검정고시 + 매우 강한 트라우마 + 큰 도시
- 조건: 검정고시 학생 + 학교 폭력/우울증 등 강한 트라우마 + Sydney/Melbourne 큰 도시 지원
- 조치: ⚠️ 재발 방지 위해 매칭 전환
- 대안: ✅ Adelaide/Hobart 작은 도시 + 한국 학생 < 5% + 케어 좋은 학교 (Foundation)
- 이유: 윌슨 19년 = 트라우마 학생 큰 도시 = 또 압박/우울증 재발 위험. 작은 도시 = 회복 시간

**RISK-07**: 한국 학생 30%+ 학교 추천 차단 ()
- 조건: 추천하려는 학교 한국 학생 비율 ≥ 30%
- 조치: ❌ 한국 학생 30%+ 학교 추천 차단
- 대안: ✅ 한국 학생 < 15% 학교 우선 / Cat 2-3 도시 우선 (Adelaide/Darwin/Hobart 한국인 < 5%)
- 이유: 윌슨 19년 = 한국 학생 多 학교 = 한국어 사용 多 = 영어 향상 X = 호주 대학 진학 페일 多. Strathfield/Burwood/Chatswood/Box Hill/Glen Waverley = 회피

**RISK-08**: 18세 미만 + 부모 동반 X + 영어 X
- 조건: 학생 14-17세 + 부모/Guardian X + IELTS 5.0 미만
- 조치: ❌ 호주 단독 유학 차단
- 대안: ✅ 옵션 A: 부모 동반 (590 Guardian Visa) / 옵션 B: 어학원 6개월 + 부모 단기 동반 + 적응 후 단독
- 이유: 14-17세 + 부모 동반 X + 영어 X = 학교 적응 매우 어려움 / Welfare 위반 多 / 비자 취소 위험

**RISK-09**: 35세+ + 영어 부족 + 자격 없음 (B4 핵심)
- 조건: B4 직장인 + 35세+ + IELTS < 6.0 + PR 자격 직업 X
- 조치: ⚠️ HIGH RISK / PR 매우 어려움 / 시간/돈 손실 위험
- 대안: ✅ 영어 점수 우선 보강 (IELTS 7.0+ Proficient 10점) / 또는 491 지방 후원 (Cat 3) / 또는 직업 전환 (TAFE 트레이드)
- 이유: B4 페르소나 차단룰 = 윌슨 19년 = 35세+ 영어 부족 = PR 점수 부족 + 비자 자격 부족 = PR 거의 불가능. 영어/직업 보강 必

### 카테고리 5: 예산

*2026 학생비자 재정 증빙 강화. 학비만이 아닌 = 생활비 + 초기 비용 + 비상금 = 모두 증빙 필수*

**BUD-01**: 예산 부족 + Go8 학사 차단
- 조건: 연간 예산 < $30,000 + Go8 학사 지원
- 조치: ❌ Go8 학사 = 평균 $40-60K/년 = 4년 = $160-240K = 부담 과도
- 대안: ✅ Cat 3 DRA Regional (Federation/CDU/UTAS/JCU/Avondale) = $24-35K + PR
- 이유: 예산 부족 = 부모 지원 끊김 → 중도 포기 → 귀국 (윌슨 19년 자주 본 실패)

**BUD-02**: 생활비 증빙 없음
- 조건: 학비 외 생활비 12개월 증빙 불가 (2026 기준 = $29,710/년)
- 조치: ❌ 학생비자 신청 자체 불가
- 대안: ✅ 부모 후원 증빙 + 은행 잔고 + 12개월 생활비 마련
- 이유: DHA 2026 = 학생비자 = 학비 + 생활비 $29,710 + 항공료 $2,500 = 모두 증빙 필수. 미증빙 = 비자 거절

### 카테고리 6: 학과별 GS

*전공별 GS 평가 및 영어/면허 요구 사항 = 윌슨 19년 + 협회 규정*

### 카테고리 7: 2026 5단계 로직

*ChatGPT 제안 = 2026 추천 시 5단계 순차 체크 로직*

**5단계 로직**:
- 1: 
- 2: 
- 3: 
- 4: 
- 5: 

---

---

## Part 5-1. Auto Block Rules (자동 차단)

*학교 등록 시 자동 발동되는 차단 룰 (학교 정보로 즉시 판단 가능)*

### ABS-01: 
- 조건: cricos = ""
- 조치: CRICOS 미등록 차단

### ABS-05: 
- 조건: type = closed
- 조치: 폐교 18 자동 차단

### RISK-07: 
- 조건: _korean_ratio_pct >= 30
- 조치: 한국인 30%+ Wilson 회피

**Dynamic Rules**: 나머지 36개 룰 = 학생 매칭 시 동적 검사

---

## Part 5-2. 정책 상세 (Under 18 / HSP / 공립학교)

Wilson 검증 정책 데이터 10개 (조기유학·HSP·공립학교 6개 주별).

### [Under 18 / Visa] CAAW (Confirmation of Appropriate Accommodation and Welfare)

/

### [HSP (조기유학)] complete matrix table

{'alert': '영어 점수 없음 = HSP 의무 = 어디로 가능?', 'Type_1_Government_HSP_to_Government_HS': {'이름': '정부 HSP → 정부 공립 학교 (가장 보편적)', 'Wilson_학비': ' (한국 학생 80% 선택)', '운영_주체': '주별 교육부 (DE International / EQI / IED / TIWA / SA)', 'subdivisions': {'QLD_EQI_HSP': {'운영': 'Education Queensland International (EQI)', 'CRICOS': '087993A', '운영_학교_3': ['Indooroopilly State High School (Brisbane West)', 'Whites Hi

### [HSP (조기유학)] wilson decision tree HSP 2026

{'alert': ' 영어 점수 없는 한국 학생 = Wilson 의사 결정 트리 (검증)', 'step_1_age': {'5_11세': 'Primary HSP/IEC (NSW K-Year 6 = 시험 X / SA = ISEC 학비 포함 / 부모 동반 의무)', '12_15세': 'Junior High HSP (모든 주 가능 / = SA HSGP)', '15_17세': 'Junior/Senior High HSP (HSP → 정규 진학)', '16_18세': 'Senior HSP / Foundation Studies / EfHS ( = Hawthorn EfHS)', '18세_이상': 'Foundation Studies / EAP (Navitas Acade

### [HSP (조기유학)] wilson top 3 winning combos

{'옵션A_학비_PR_조합': {'이름': 'SA Adelaide HSGP (ISEC 포함) → Adelaide HS', 'tuition': '$15,880/년 (ISEC 영어 학비 포함)', 'Homestay_40주': '$14,400 ($360/주 호주 최저)', '공항_픽업': '포함 (학비 안)', '1년_총': '약 $33,000-$35,000', 'PR': 'Cat 2 +15 가산점', '한국인': '3-8% ()', 'wilson_quote': "'학비 가장 저렴 + ISEC 포함 + 공항 픽업 포함 + Cat 2 PR + 한국인 적음 = 윌슨 '"}, '옵션B_상위대학_직결_조합': {'이름': 'Hawthorn EfHS → UMelb / Monash / Ca

### [조기유학 공립학교] NSW Sydney

운영: NSW Department of Education - DE International (CRICOS 00588M) / 학교수: Sydney + 지역 200개 이상 / 학비: 신청비: $150 (1회 / 환불 X) / Primary K-Year 6: $15,500/년 / Junior High Year 7-10: $18,000/년 / Senior High Year 11-12: $18,000/년 / Wilson_2026_할인: 표준 홈스테이 거주 = $3,500 1회 할인 / Study Abroad = $1,750 할인


### [조기유학 공립학교] VIC Melbourne

운영: Victorian Department of Education - International Education Division (IED) (CRICOS 00861K) / 학교수: Melbourne + 지역 약 130개 학교 / 학비: Primary Prep-Year 6: 약 $13,200-$16,000/년 / Junior Secondary Year 7-10: 약 $17,000-$22,000/년 / Senior Secondary Year 11-12 VCE: 약 $22,000-$26,820/년 / VET 추가: $49-$1,739/과목/년 / VET_자료비: $60-$950/과목/년


### [조기유학 공립학교] QLD Brisbane GoldCoast

운영: Education Queensland International (EQI) (CRICOS 00608A) / 학교수: Queensland 95개 학교 (Brisbane / Gold Coast / Cairns / Sunshine Coast) / 학비:


### [조기유학 공립학교] WA Perth

운영: TAFE International Western Australia (TIWA) - Department of Education (CRICOS 01723A) / 학교수: Perth + 지역 약 70개 공립 / 학비:


### [조기유학 공립학교] SA Adelaide

운영: Department for Education - International Education Services (CRICOS 00018A) / 학교수: 약 90+ 학교 / 학비:


### [조기유학 공립학교] wilson total strategy

운영: 학교수: 학비:

---

## Part 5-3. 카드 시스템 정의 (Card Engine Spec)

> 카드 엔진을 만들 때 반드시 따라야 하는 구조 정의 + Wilson 절대 규칙.

### 카드 구조 (10 섹션)

#### card_id

- **format**: CARD-{persona_id}-{timestamp}
- **예**: CARD-A1-20260429

#### persona_id
A1~B4 중 하나

#### student_input
*학생 폼 7개 입력값*

- **name**: 이름
- **age**: 나이
- **education**: 현재 학력
- **english_level**: 영어 점수 (또는 '없음')
- **goal**: 목표 (어학연수/대학/직업+PR/조기유학)
- **timeline**: 희망 시기
- **budget_range**: 예산 (저/중/고)
- **kakao_id**: 카카오톡 연락처
- **submitted_at**: ISO 8601 시간

#### blocking_check
*차단룰 39 5단계 검사 결과*

- **step_1_cricos**: PASS / FAIL
- **step_2_gs**: PASS / RISK / BLOCK
- **step_3_english_education**: PASS / FAIL
- **step_4_budget**: PASS / FAIL
- **step_5_eap_safety**: PASS / RECOMMENDED
- **triggered_rules**: 1개
 - 차단된 룰 ID 리스트
- **blocking_status**: GREEN / YELLOW / RED

#### section_1_empathy
*Section 1 = 상황 공감*

- **title**: 지금 이런 상황이시죠?
- **wilson_principle**: ALERT_PARENT_DOUBT_CHILD_ABILITY = 학생/부모 의심 인정 + 공감
- **content**: 페르소나별 학생 상황 공감 문장 (윌슨 19년 950명 통찰)
- **personalization**: 학생 폼 입력값 인용 (이름/나이/학력)

#### section_2_reality_check
*Section 2 = 실패 사례·현실 체크 (신뢰 형성 핵심)*

- **title**: 윌슨 19년 = 이런 케이스 자주 봤어요
- **wilson_principle**: ALERT_REALITY_CHECK_SECTION = 페르소나별 실패 사례 박힘
- **content**: 이 페르소나가 자주 빠지는 함정 + 실패 사례 + 윌슨이 본 결과
- **출처**: wilson_critical_alerts.json + blocking_rules_39 (RISK 카테고리)

#### section_3_wilson_know_how
*Section 3 = 윌슨 노하우 = 다른 유학원이 안 알려주는 것*

- **title**: 윌슨만의 19년 노하우
- **wilson_principle**: 차단이 핵심 = 추천보다 차단
- **content**: 이 페르소나에 적용되는 윌슨 노하우 인용 (직접 인용 우선)
- **출처**: wilson_critical_alerts.json (wilson_quote 필드)

#### section_4_route_options
*Section 4 = 루트 옵션 (단일 X = 윌슨 절대 원칙)*

- **title**: 이런 옵션이 있어요 - 직접 비교해 보세요
- **wilson_principle**: ALERT_NO_SINGLE_SCHOOL_RECOMMENDATION = 단일 학교 추천 X
- **options_count**: 최소 2개 / 권장 3개
- **options**: 1개
 - {"option_name": "옵션 A: ___", "school_name_examples": "학교 이름 (3개 이상 비교)", "pros": ["장점 리스트"], "cons": ["단점 리스트"], "예산": "$", "타겟": "이런 학생에게 적합", "blocked_check": "이 옵션이 학생 차단룰 통과했는지 확인"}

#### section_5_simple_input
*Section 5 = 간단 입력 (카톡 상담 전 추가 정보)*

- **title**: 1분만 더 - 더 정확한 매칭을 위해
- **questions**: 3개
 - 지금 가장 고민되는 1가지는?
 - 부모님과 상의 중인지?
 - 구체적 도시 선호 있는지?
- **principle**: 절대 길게 X = 1분 안에 작성 가능

#### section_6_kakao_cta
*Section 6 = 카톡 연결 (CTA)*

- **title**: 윌슨과 직접 1:1 무료 상담
- **wilson_principle**: ALERT_KAKAO_PERSISTENT_BUTTON = 모든 페이지 카카오 버튼
- **cta_text**: 지금 카톡 상담 받기 (무료)
- **trust_signals**: 3개
 - 19년 950명 학생 / PR 60%
 - 투명 비즈니스 = 학비 직접 송금 / 영수증 100% 공개
 - 윌슨이 직접 1:1 답변
- **kakao_link**: {kakao_channel_url}

#### wilson_check_gate
*윌슨 최종 검수 게이트 (자동 발송 절대 X)*

- **wilson_principle**: ALERT_FUNNEL_FINAL_GATE = 카카오 보내기 전 윌슨 최종 체크
- **status**: PENDING / APPROVED / REJECTED / NEEDS_EDIT
- **wilson_notes**: 윌슨님 검수 메모
- **approved_at**: 승인 시간
- **sent_to_kakao_at**: 카카오 발송 시간

### 카드 품질 체크리스트 (9개)

- ✅ Section 1-6 모두 채워졌는가?
- ✅ 페르소나 매칭 정확한가?
- ✅ 차단룰 39 검사 완료?
- ✅ 단일 학교 추천 X (최소 2-3 옵션)?
- ✅ 폐교 18 추천 안 됐는가?
- ✅ 한국인 30%+ 학교 회피?
- ✅ 윌슨 인용 직접 사용 (자동 해석 X)?
- ✅ 카톡 CTA 명확한가?
- ✅ 신뢰 시그널 (19년/950명/PR 60%) 박혀있는가?

### Wilson 절대 규칙 (10개)

- 1. 윌슨님 인용 = 그대로 박음 (자동 해석 X) [ALERT_CLAUDE_BAKING_PRINCIPLE]
- 2. 단일 학교 추천 X = 최소 2-3 옵션 비교 [ALERT_NO_SINGLE_SCHOOL_RECOMMENDATION]
- 3. 폐교 18 절대 추천 X (특히 SELC) [ABS-05]
- 4. 한국인 30%+ 학교 회피 [RISK-07]
- 5. 부모님 의심 = 능력 X 절대 아님 시스템 차이일 뿐 [ALERT_PARENT_DOUBT_CHILD_ABILITY]
- 6. 시골이 좋은데 학생이 싫어함 = 학생 의지 우선 [ALERT_RURAL_VS_CITY_DILEMMA]
- 7. 영어 점수 ≠ 학업 성공 = 활용 능력 + 의지가 핵심 [ALERT_ENGLISH_SKILL_VS_SCORE]
- 8. 학생 의지 0% = 페일 / 학생 의지 100% = 시스템 다 극복 [ALERT_STUDENT_WILL_IS_KEY]
- 9. EAP 권장 = 영어 있어도 [윌슨 명언]
- 10. 카톡 발송 전 윌슨 최종 검수 [ALERT_FUNNEL_FINAL_GATE]

---

## Part 5-4. 데이터 스키마

*v8 스키마 (학교 데이터 표준 32 필드)*

### schema_v8

**description**: 윌슨님 13 카테고리 31 필드 + blocked_by (차단 룰 자동 연결)

**fields**: 32개
- school_name
- category
- type
- cricos
- campus

**categories**:
- 기본: list (3)
- 학교정보: list (5)
- 과정: list (4)
- 학비: list (2)
- 장학금: list (3)
- 입학조건: list (3)
- 영어: list (4)
- 패스웨이: list (1)
- PR: list (3)
- 설명: list (1)
- facts: list (1)
- warnings: list (1)
- 차단: list (1)

### meta_master

- **version**: v8.0 (2단계 완료)
- **created**: 2026-04-29
- **schema_fields**: 32
- **wilson_principle**: 추천보다 차단이 핵심 = 19년 950명 PR 60% 비결
- **previous_version**: v4.5 (보존)
- **previous_files**: ['/mnt/project/ALL_DB__2_.json', '/mnt/project/AUSUHAK_COMPLETE_DB_v4_5.xlsx']
- **change_log**: ['필드 통일: 그룹별 다른 → 32 필드 통일', '차단 룰 자동 연결: blocked_by 필드 추가', '" 학교" 표현 제거 (학교 등급 X)', '폐교 18 = type=closed + ABS-05 자동 차단', 'Eynesbury 치대 = Biomedical 거쳐서 정정']
- **work_stage**: ✅ 10차 정밀 검색 완료 = 모든 누락 통합
- **next_stages**: ['2단계: Foundation 8 + 사립대 12 + 패스웨이 15', '3단계: 정규대학 39', '4단계: TAFE 5주 + HSP / Under 18']
- **updated**: 10차 풀 스캔 완료 = Under 18 6주 + 홈스테이 11 + 운영 13 + Alerts 24 + O 41
- **total_data**: {'schools': 451, 'majors': 1227, 'wilson_alerts': 24, 'courses_normalized': 32, 'blocking_rules': 39, 'policy_items': 10}

---

## Part 5-5. 검색 인덱스 (참조용)

> 카드 엔진이 학교/학과 빠르게 매칭할 때 사용하는 인덱스 정의.
> 실제 인덱스 데이터는 `ausuhak_master_v1.json`의 `_indices` 참조.

*FAQ 작성용 빠른 검색 인덱스*

- `schools_by_name`: 169개 학교 → 카테고리 매핑
- `majors_by_name`: 456개 학과명 → ID 매핑
- `majors_by_school`: 179개 학교 → 학과 리스트

**PR 카테고리**:
- MLTSSL: 180개
- STSOL: 0개
- STSOL_MLTSSL: 13개
- CSOL: 5개
- 차단: 4개

---

## Part 5-6. ANMAC / AHPRA 인증 시스템 (간호 학과 핵심)

> **Wilson 절대 원칙**: 사파(ANMAC 미인증) 간호 학교 졸업 = AHPRA 등록 거부 = 간호사 등록 불가 = PR 불가.
> 카드 엔진은 간호 학교 추천 시 반드시 ANMAC 인증 여부를 자동 검증해야 함.

### 5-6-1. 핵심 기관 3개 (ANMAC / AHPRA / NMBA)

**ANMAC** (Australian Nursing and Midwifery Accreditation Council)
- 간호/조산사 교육 프로그램 인증 기관
- NMBA가 지정한 외부 인증 기관
- ANMAC 인증 받지 않은 간호 코스 = AHPRA 등록 자격 없음
- Skills Migration 평가도 ANMAC 담당 (해외 간호사 호주 이민 시)

**AHPRA** (Australian Health Practitioner Regulation Agency)
- 호주 모든 의료직 등록·관리하는 정부 기관
- 간호사 등록은 AHPRA 통해 진행
- ANMAC 인증된 코스 졸업자만 AHPRA 등록 신청 가능
- 16개 의료 직군 관할 (간호/의사/약사/물리치료 등)

**NMBA** (Nursing and Midwifery Board of Australia)
- 간호사·조산사 면허 발급 기관 (AHPRA 산하)
- 영어 표준(IELTS 7.0) 정의
- ANMAC에 인증 권한 위임

**관계도**: 학교 → ANMAC 인증 → NMBA 승인 → AHPRA 등록 → 간호사 면허

### 5-6-2. AHPRA/NMBA 영어 표준 (절대)

**모든 간호 학과 입학 + 면허 등록 = IELTS 7.0 (각 영역 7.0)**
- TAFE Diploma (EN/Enrolled Nurse): 7.0
- Bachelor of Nursing (RN/Registered Nurse): 7.0
- Master of Nursing (Pre-registration): 7.0
- 사립 컬리지 Diploma: 7.0
- AHPRA 면허 등록: 7.0

**다른 영어 시험 등가 점수 (2025 기준)**:
- PTE Academic: 65 (각 영역 65)
- TOEFL iBT: 94 (W 27 / S 23 / R 24 / L 24)
- OET: B (각 영역 B)
- Cambridge: 185 (각 영역 185)

**⚠️ 함정**: 일부 대학교는 입학 시 IELTS 6.5만 요구하지만, 졸업 후 AHPRA 등록 시 7.0 필요. 입학만 보고 진학 시 졸업해도 면허 못 받음. **반드시 IELTS 7.0 미리 준비** 또는 **재학 중 7.0 달성**.

### 5-6-3. ANMAC 인증 간호 학교 (마스터 DB 검증)

> 아래 학교는 마스터 DB에 등록된 학교 + AHPRA Approved Programs of Study 매칭 결과.
> **모든 학교는 IELTS 7.0 (각 영역 7.0) 입학 + 면허 등록 표준 적용**.

#### Bachelor of Nursing (RN) - 정식 간호사 학사 (3년)

- **ACU (호주 가톨릭 대학교)** - $32K
- **ACU Sydney/Melbourne/Brisbane** - $36,400/년
- **Adelaide / UofA (애들레이드 대학교)** - $44,000-$48,000
- **Avondale (아본데일 대학교)** - $28K
- **CDU (찰스 다윈 대학교)** - $30K
- **CSU / Charles Sturt (찰스 스터트 대학교)** - $36K
- **Curtin (커틴 대학교)** - $40,000-$44,000
- **Deakin (디킨 대학교)** - $38K
- **Deakin Geelong** - $44,800/년
- **ECU (에디스 코완 대학교)** - $32K
- **ECU Bachelor Sci (Nursing) + Bachelor Sci (Midwifery)** - $55,000/년
- **FedUni / Federation (페더레이션 호주 대학교)** - $28K
- **Griffith (그리피스 대학교)** - $40K
- **JCU (제임스 쿡 대학교)** - $36K
- **La Trobe (라트로브 대학교)** - $38K
- **Macquarie / MQ (매쿼리 대학교)** - $44,000-$48,000
- **Monash (모나쉬 대학교)** - $48,000-$52,000
- **Murdoch (머독 대학교)** - $34K
- **Notre Dame / UNDA (노트르담 호주 대학교)** - $34K
- **Notre Dame Sydney** - $42K
- **QUT (퀸즐랜드 공과대학교)** - $40K
- **RMIT (RMIT 대학교 / 멜버른왕립공과대학교)** - $44,000-$48,000
- **Swinburne / SUT (스윈번 공과 대학교)** - $36K
- **Torrens / TUA (토렌스 호주 대학교)** - $30K
- **UC / Canberra (캔버라 대학교)** - $34K
- **UNE (뉴잉글랜드 대학교)** - $32K
- **UNSW (뉴사우스웨일스 대학교)** - $52,000-$56,000
- **UOW (울런공 대학교)** - $38K
- **UQ (퀸즐랜드 대학교)** - $45,792
- **USyd / Sydney Uni (시드니 대학교)** - $54,000-$56,000
- **UTAS (태즈메이니아 대학교)** - $36K
- **UTS (시드니 공과대학교)** - $44,000-$48,000
- **UniSC (구 USC) (선샤인 코스트 대학교)** - $30K
- **UniSQ (구 USQ / 2022년 리브랜드) (남부 퀸즐랜드 대학교)** - $32K
- **Univ of Newcastle** - $40,800/년
- **UoN / Newcastle (뉴캐슬 대학교)** - $38K
- **VU (빅토리아 대학교)** - $32K
- **WSU / Western (웨스턴 시드니 대학교)** - $35K

#### Master of Nursing (Pre-registration) - 학사 보유자용 석사 (2년)

> 다른 분야 학사 학위 보유자가 빠르게 RN 자격 취득하는 경로.

- **A**
- **ACU (호주 가톨릭 대학교)** - $34K
- **Adelaide / UofA (애들레이드 대학교)** - $44,000-$48,000
- **Avondale (아본데일 대학교)** - $32K
- **C**
- **CDU (찰스 다윈 대학교)** - $34K
- **CSU / Charles Sturt (찰스 스터트 대학교)** - $38K
- **Curtin (커틴 대학교)** - $40,000-$44,000
- **ECU (에디스 코완 대학교)** - $36K
- **F**
- **FedUni / Federation (페더레이션 호주 대학교)** - $30K
- **J**
- **JCU (제임스 쿡 대학교)** - $38K
- **La Trobe (라트로브 대학교)** - $42K
- **Macquarie / MQ (매쿼리 대학교)** - $44,000-$48,000
- **Monash (모나쉬 대학교)** - $48,000-$52,000
- **Murdoch (머독 대학교)** - $38K
- **Notre Dame / UNDA (노트르담 호주 대학교)** - $36K
- **QUT (퀸즐랜드 공과대학교)** - $42K
- **RMIT (RMIT 대학교 / 멜버른왕립공과대학교)** - $42,000-$46,000
- **U**
- **UC / Canberra (캔버라 대학교)** - $36K
- **UMelb / Melbourne Uni (멜버른 대학교)** - $52,000-$56,000
- **UNE (뉴잉글랜드 대학교)** - $34K
- **UNSW (뉴사우스웨일스 대학교)** - $52,000-$56,000
- **UQ (퀸즐랜드 대학교)** - $48,000-$52,000
- **USyd / Sydney Uni (시드니 대학교)** - $54,000-$57,000
- **UTAS (태즈메이니아 대학교)** - $40K
- **UTS (시드니 공과대학교)** - $42,000-$46,000
- **UWA (서호주 대학교)** - $44,000-$48,000
- **UniSC (구 USC) (선샤인 코스트 대학교)** - $32K
- **UniSQ (구 USQ / 2022년 리브랜드) (남부 퀸즐랜드 대학교)** - $34K
- **UoN / Newcastle (뉴캐슬 대학교)** - $42K
- **VU (빅토리아 대학교)** - $34K
- **WSU / Western (웨스턴 시드니 대학교)** - $38K

#### TAFE Diploma of Nursing (HLT54121) - 준간호사 (EN, 18-24개월)

> Wilson 검증 완료 - 모든 TAFE 주별 1개씩.

- **1 TAFE NSW** - $28,500 AUD
- **10 TasTAFE TAS** - 약 $25,000-30,000 AUD
- **11 CDU TAFE NT** - 약 $25,000-28,000 AUD
- **2 TAFE QLD** - $32,400 AUD
- **3 TAFE SA NEW 정확** - Tuition $36,960 + Incidental $1,500 = 총
- **4 TAFE WA TIWA** - 약 $25,000-30,000 AUD (TIWA 운영)
- **5 TAFE VIC RMIT** - 약 $28,000-32,000 AUD (RMIT 국제)
- **6 Box Hill Institute VIC** - 약 $28,000 AUD (추정)
- **7 Holmesglen TAFE VIC** - 약 $28,000 AUD
- **8 Chisholm Institute VIC** - 약 $25,000-28,000 AUD
- **9 Victoria Univ Polytechnic VIC** - 약 $28,000 AUD

#### 사립 컬리지 Diploma of Nursing (Wilson 검증)

> 사립 = 사파 위험 高. Wilson이 직접 ANMAC 인증 확인한 곳만 추천.

- **12 IHNA 사립 ** (Wilson 검증 ✅) - 약 $28,000-32,000 AUD
- **13 ALG Australian Learning Group 사립** (Wilson 검증 ✅) - 약 $28,000 AUD

### 5-6-4. ⛔ 사파(ANMAC 미인증) 학교 회피 원칙

**사파 = ANMAC 인증 받지 않은 간호 코스 운영 학교**

**증상 (사파 의심 신호)**
- '학비 저렴' 광고 ($20,000 이하 Diploma of Nursing)
- '단기 코스' 광고 (12개월 이하 Diploma)
- 'IELTS 5.5만 있으면 입학 가능' 광고
- ANMAC 인증 표시 없음 / AHPRA 등록 가능 표시 없음
- HLT54121 코스 코드 미명시
- 한국 학생 대상 카카오 광고 多

**졸업 시 결과**
- AHPRA 등록 거부
- 간호사 등록 불가 = 호주에서 간호사로 일할 수 없음
- 485 졸업비자 신청은 가능하나 PR 불가
- ANMAC Skills Assessment 통과 불가 = 이민 차단
- 학비 환불 매우 어려움 (학교 폐교 시)
- Bachelor of Nursing 편입 학점 불인정 (학사 처음부터)

**Wilson 검증 방법 (직원용)**
1. ANMAC 공식 사이트 확인: anmac.org.au/accreditation/accredited-programs
2. AHPRA Approved Programs of Study 리스트: portal.ahpra.gov.au/s/approved-programs-of-study
3. 코스 코드가 HLT54121 (Diploma of Nursing) 인지 확인
4. CRICOS 코드 확인 + 실제 운영 여부 (폐교 18개 리스트 대조)
5. 검증 사립 = IHNA / ALG / Le Cordon Bleu 등 일부만

### 5-6-5. EN → RN 편입 경로 (일반)

**경로**: TAFE Diploma of Nursing (EN) → Bachelor of Nursing (RN) 편입

**장점**
- 영어 7.0이 한 번에 안 되는 케이스: TAFE 입학 7.0 → 졸업 후 Bachelor 편입
- 비용 분산: TAFE 18개월 후 Bachelor 1.5-2년 (총 3년 4년차 단축)
- 일하면서 공부: EN 자격으로 호주 병원 알바 + Bachelor 학업
- 한국 학생 다수가 활용하는 표준 경로

**대학별 편입 학점 (예시)**
- Southern Cross University: Diploma → Bachelor 1년 학점 인정 (108 Block Credit Points = 9 units / 24 units)
- Adelaide University: TAFE SA Diploma 졸업자 우선 입학
- 기타: 학교마다 1-1.5년 단축 가능

**필수 조건**
- TAFE Diploma 졸업 + AHPRA EN 등록
- Bachelor 입학 시 IELTS 7.0 다시 충족 (입학+면허 표준)


### 5-6-6. OBA (해외 간호사 호주 등록 시험) - 한국 간호사 대상

한국에서 간호 학위 취득한 사람이 호주 RN/EN으로 등록하려면 OBA 절차 통과 필수.

**OBA = Outcome-Based Assessment**
- 2단계 시험 시스템
- 한국 간호 학위가 호주와 substantially equivalent하지 않을 때 적용

**1단계: AHPRA 자격 평가**
- AHPRA에 한국 간호 학위 + 경력 + 영어 점수 제출
- 호주 표준과 비교 평가
- 결과: Substantially Equivalent / Not Substantially Equivalent
- 후자면 OBA 시험 응시 자격 부여

**2단계: OBA 시험 (2개)**
- **NCLEX-RN** (또는 NCLEX-EN): 컴퓨터 기반 이론 시험
  - 미국 간호사 시험과 동일 시스템
  - 4시간 / 다지선다 + 적응형 문제
  - 한국에서도 응시 가능 (Pearson VUE 시험장)
- **OSCE** (Objective Structured Clinical Examination): 임상 실기 시험
  - 호주 현지에서 응시 (Adelaide / Newcastle 등 지정 센터)
  - 시뮬레이션 환자 대상 임상 술기 평가

**둘 다 통과 시 → AHPRA 등록 신청 가능**

**대안 경로: RN Conversion (Bridging)**
- OBA 대신 호주 대학 Bridging 코스 수료 (1-1.5년)
- Curtin / UTS / Murdoch / La Trobe 등에서 운영
- IELTS 7.0 필수
- 학비 약 $30K~$45K
- 코스 수료 = 자동 RN 자격 (OBA 면제)

**Wilson 안내 시 확인 사항**
1. 한국 간호사 면허 보유 여부 + 경력 연수
2. IELTS 7.0 (각 7.0) 보유 여부
3. OBA vs Bridging 선호도 (시험 vs 학업)
4. 호주 체류 가능 기간 (OSCE 응시 위해)
5. 예산 (OBA 시험비 vs Bridging 학비)

**비용 비교**
- OBA: NCLEX $400 + OSCE $4,000 = 약 $4,400 (1회 응시 기준)
- Bridging: $30K~$45K + 1-1.5년 학업

### 5-6-7. 간호 PR 경로

**직업 코드**
- Registered Nurse: ANZSCO 254499 (MLTSSL)
- Enrolled Nurse: ANZSCO 411411 (CSOL/STSOL)
- Nurse Practitioner: ANZSCO 254411 (MLTSSL)
- Midwife: ANZSCO 254111 (MLTSSL)

**PR 5년 표준 타임라인 (RN)**
1. Bachelor of Nursing 입학 (IELTS 7.0)
2. 3년 학업 + 800-1,000시간 임상 실습
3. 졸업 후 AHPRA 등록 (2-3개월)
4. 485 졸업비자 신청 (Post-Higher Education Work, 2년)
5. 호주 병원 취업 + 1-2년 경력
6. ANMAC Skills Assessment
7. EOI 제출 → 초청 → 영주권 (189/190/491)
8. 총 4-5년 (학업 시작부터 PR 승인까지)

**EN PR 경로 (시간 더 오래 걸림)**
- Diploma 18-24개월 → 485 (Post-Vocational Education Work, 18개월)
- EN 경력 2-3년 → 491(Regional 4년) → 191 PR
- 또는 Bachelor 편입 → RN 전환 후 PR

### 5-6-7. Wilson 검증 간호 진학 경로 (2026)

| 경로 | 학교 | 학비 (총) | 기간 | 적합 |
|------|------|----------|------|------|
| TAFE SA Diploma + 편입 | TAFE SA + Adelaide Uni | 약 $80K | 4-5년 | 영어 7.0 한번에 X / 비용 분산 |
| EN→RN 편입 | TAFE → 사립/대학 Bachelor | 약 $100K | 4-5년 | 영어 7.0 한번에 X / 일하면서 |
| USC Direct Bachelor | UniSC (Sunshine Coast) | $93K | 3년 | 한국인 적음 / Cat 3 PR |
| Federation Master Pre-reg | Federation University | $66K | 2년 | 다른 분야 학사 보유자 |

## Part 6. 학과 데이터 (1,227개)

호주 학과 데이터베이스 총 1227개. 카드 엔진 학과별 매칭 핵심 데이터.

### 분포

- go8_majors: 375개
- regular_universities_majors: 561개
- private_courses: 36개
- pathway_courses: 29개

**학위 레벨**
- Bachelor: 476개
- Master: 477개
- Diploma: 22개
- Foundation: 21개
- Other: 5개

---

### 학교별 학과 (179개 학교)

#### 1 TAFE NSW
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - $28,500 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 10 TasTAFE TAS
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $25,000-30,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 11 CDU TAFE NT
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $25,000-28,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 12 IHNA 사립 
*사립*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000-32,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 13 ALG Australian Learning Group 사립
*사립*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 2 TAFE QLD
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - $32,400 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 3 TAFE SA NEW 정확
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - Tuition $36,960 + Incidental $1,500 = 총 / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 4 TAFE WA TIWA
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $25,000-30,000 AUD (TIWA 운영) / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 5 TAFE VIC RMIT
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000-32,000 AUD (RMIT 국제) / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 6 Box Hill Institute VIC
*사립*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000 AUD (추정) / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 7 Holmesglen TAFE VIC
*국립 (TAFE)*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 8 Chisholm Institute VIC
*사립*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $25,000-28,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### 9 Victoria Univ Polytechnic VIC
*사립*

**총 1개 학과**

**Diploma (1개)**

- **Diploma of Nursing (HLT54121)** - 약 $28,000 AUD / IELTS 7.0 (NMBA 표준 / EN 등록) / Year 12 / 검정고시 OK / PR STSOL → MLTSSL (Enrolled Nurse 411411 (STSOL) → Bachelor 1년 면제 → RN 254418 (MLTSSL))

---

#### A
*국립*

**총 2개 학과**

**Master (2개)**

- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / PR MLTSSL (Registered Nurse 254418 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / Cat 2 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))

---

#### ACAP Sydney/Melb/Brisbane/Adelaide
*국립*

**총 1개 학과**

**Diploma (1개)**

- **Counselling/Psychology (Counselling Diploma 사립 빠른 입문)** - IELTS 6.5 / ACAP Sydney/Melb/Brisbane/Adelaide: Diploma 1년 / Bachelor 3년 / Master 2년 ( 사 / PR MLTSSL (Psychologist 272311 (MLTSSL))

---

#### ACU
*국립*

**총 4개 학과**

**Bachelor (4개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $36,400/년 / IELTS 7.0 (AHPRA 의료 표준) / ACU: $36,400/년 (학비) / PR MLTSSL (Physiotherapist 252511 (MLTSSL))
- **Occupational Therapy (Bachelor OT 4년 2026)** - $36,400/년 / IELTS 7.0 (AHPRA 의료 표준) / ACU: $36,400/년 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL))
- **Speech Pathology (Bachelor Speech 4년 2026)** - $36,400/년 / IELTS 7.0 (AHPRA 의료 표준) / ACU: $36,400/년 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL))
- **Social Work (Bachelor Social Work 4년 2026)** - $36,400/년 / IELTS 6.5 / ACU: $36,400/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### ACU (호주 가톨릭 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Nursing** - $32K / IELTS 7.0 / 70+ (3년 / $32K (NMBA / IELTS 7.0) Catholic Healthcare 직결)
- **Bachelor of Education (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 70+ (4년 / $30K (AITSL IELTS 7.5) 가톨릭 학교)
- **Bachelor of Early Childhood Education** - $28K / IELTS 6.0 (Bachelor) / 70+ (4년 / $28K (ACECQA IELTS 7.5))
- **Bachelor of Exercise & Sports Science** - $34K / IELTS 6.0 (Bachelor) / 70+ (3년 / $34K)
- **Bachelor of Biomedical Science** - $34K / IELTS 6.0 (Bachelor) / 70+ (3년 / $34K)
- **Bachelor of Business** - $28K / IELTS 6.0 (Bachelor) / 70+ (3년 / $28K)
- **Bachelor of Information Technology** - $30K / IELTS 6.0 (Bachelor) / 70+ (3년 / $30K (ACS 인증))
- **Bachelor of Theology** - $26K / IELTS 6.0 (Bachelor) / 70+ (3년 / $26K 호주 가톨릭 신학 + Rome)

**Master (6개)**

- **Master of Teaching (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $32K AITSL 호주·한국 교사)
- **Master of Social Work** - $34K / IELTS 7.0 / 학사 학위 (2년 / $34K (AASW IELTS 7.0))
- **Master of Nursing** - $34K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $34K (NMBA))
- **Master of Education** - $30K / IELTS 6.0 (Bachelor) / 학사 학위 (1.5-2년 / $30K)
- **Master of Business Administration (MBA)** - $36-42K / IELTS 6.0 (Bachelor) / 학사 학위 (1.5-2년 / $36-42K)
- **Master of Counselling** - $32K / IELTS 6.0 (Bachelor) / 학사 학위 (1.5-2년 / $32K)

---

#### ACU Australian Catholic
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $36,400/년 / IELTS 7.0 (NMBA 표준) / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $36,400/년 / Sydney/Melb/Brisbane/Bal)

---

#### ACU Foundation
*패스웨이*

**총 1개 학과**

**Foundation (1개)**

- **Foundation Studies** - Foundation $23,120 (2026 공식 - IDP 확인) 호주 Foundation 학비 저렴 5 / IELTS 5.5 (각 5.0) / 고2/고3/검정고시 OK (→ Australian Catholic University 학사 2학년 직진)

---

#### ACU Sydney/Melb/Brisbane
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $36,400/년 / IELTS 6.5 / ACU Sydney/Melb/Brisbane: $36,400/년 / PR MLTSSL (Ambulance Officer 411111 (MLTSSL))

---

#### ACU Sydney/Melbourne/Brisbane
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (Dual Bachelor Nursing Midwifer)** - $36,400/년 / IELTS 7.0 (AHPRA 의료 표준) / ACU Sydney/Melbourne/Brisbane: $36,400/년 × 4년 = $146K (학비) / PR MLTSSL (Registered Midwife 254111 (MLTSSL))

---

#### AIB (Australian Institute of Business)
*사립*

**총 2개 학과**

**Master (2개)**

- **Online MBA** - MBA $24,000-$30,000 (호주 온라인 MBA 학비) / IELTS 6.5 (각 6.0) / 한국 대졸 / 경력 2-3년+
- **Online Master of Business** - MBA $24,000-$30,000 (호주 온라인 MBA 학비) / IELTS 6.5 (각 6.0) / 한국 대졸 / 경력 2-3년+

---

#### AIPC
*국립*

**총 1개 학과**

**Diploma (1개)**

- **Counselling/Psychology (Counselling Diploma 사립 빠른 입문)** - IELTS 6.5 / AIPC: Diploma Counselling 1년 / PR MLTSSL (Psychologist 272311 (MLTSSL))

---

#### ANU
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $50,400/년 / IELTS 6.5 / ANU: $50,400/년 / Cat 2 +15 / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2 +15)
- **Social Work (Bachelor Social Work 4년 2026)** - $50,400/년 / IELTS 6.5 / ANU: $50,400/년 / Cat 2 +15 / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2 +15)

---

#### ANU (호주국립대학교)
*국립 (Go8)*

**총 43개 학과**

**Bachelor (19개)**

- **Bachelor of Commerce** - $52,000-$56,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Business Administration** - $52,000-$56,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Economics** - $50,000-$54,000 / IELTS 6.5 / 85+ (ANU)
- **Bachelor of Actuarial Studies** - $52,000-$56,000 / IELTS 6.5 / 90+ (XXX)
- **Bachelor of Engineering (Honours)** - $56,000-$62,000 / IELTS 6.5 / 85+ + 수학 (EA 등록)
- **Bachelor of Software Engineering (Honours)** - $56,000-$62,000 / IELTS 6.5 / 85+ + 수학 (EA + ACS)
- **Bachelor of Computer Science** - $50,000-$56,000 / IELTS 6.5 / 85+ (ANU CS)
- **Bachelor of Cybernetics (Honours)** - $52,000-$56,000 / IELTS 6.5 / 90+ (ANU 호주 유일)
- **Bachelor of Psychology (Honours)** - $50,000-$56,000 / IELTS 6.5 / 85+ (AHPRA)
- **Bachelor of Science** - $50,000-$56,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Health Science** - $50,000-$54,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Laws (LLB)** - $52,000-$54,000 / IELTS 7.0 / 95+ (ANU Law / 4년)
- **Bachelor of International Relations** - $48,000-$52,000 / IELTS 6.5 / 85+ (ANU 세계)
- **Bachelor of Political Science** - $48,000-$52,000 / IELTS 6.5 / 80+ (ANU)
- **Bachelor of Asian Studies** - $48,000-$52,000 / IELTS 6.5 / 80+ (ANU 호주 1위)
- **Bachelor of Arts** - $48,000-$52,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Sociology** - $48,000-$52,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Environment & Sustainability** - $50,000-$54,000 / IELTS 6.5 / 80+ (Fenner School)
- **Bachelor of Resource & Environmental Management** - $50,000-$54,000 / IELTS 6.5 / 80+ (XXX)

**Master (24개)**

- **Master of Business Administration (Public Sector)** - $54,000-$58,000 / IELTS 7.0 / 학사 (정부 분야 강)
- **Master of Finance** - $52,000-$56,000 / IELTS 6.5 / Finance 학사 (XXX)
- **Master of Professional Accounting** - $52,000-$56,000 / IELTS 7.0 / 학사 (CPA 등록 / Pre-Master 25% 장학)
- **Master of Computing** - $50,000-$56,000 / IELTS 6.5 / 학사 (ANU CS)
- **Master of Cybersecurity** - $54,000-$58,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Machine Learning & Computer Vision** - $54,000-$58,000 / IELTS 6.5 / CS 학사 (ANU / AI)
- **Master of Data Science** - $54,000-$58,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Cybernetics** - $52,000-$56,000 / IELTS 6.5 / 학사 (ANU 호주 유일)
- **Master of Engineering** - $54,000-$60,000 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Engineering (Renewable Energy)** - $54,000-$60,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Doctor of Medicine and Surgery (MChD)** - $87,000-$92,000 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23 / 4년)
- **Master of Public Health** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Psychology** - $54,000-$58,000 / IELTS 7.0 / Psych 학사 (AHPRA)
- **Juris Doctor (JD)** - $52,000-$58,000 / IELTS 7.0 / 학사 + LSAT (ANU Law)
- **Master of Laws (LLM)** - $48,000-$52,000 / IELTS 7.0 / LLB (XXX)
- **Master of Public Policy (MPP)** - $52,000-$56,000 / IELTS 6.5 / 학사 (ANU 세계)
- **Master of International Relations** - $52,000-$56,000 / IELTS 6.5 / 학사 (ANU 세계)
- **Master of Diplomacy** - $52,000-$56,000 / IELTS 6.5 / 학사 (ANU 호주 1위)
- **Master of National Security Policy** - $54,000-$58,000 / IELTS 6.5 / 학사 (호주 유일)
- **Master of Teaching** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Social Work** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Environment** - $50,000-$54,000 / IELTS 6.5 / 학사 (Fenner School)
- **Master of Climate Change** - $50,000-$54,000 / IELTS 6.5 / 학사 (ANU)
- **PhD (모든 분야)** - **$0 (학비 전액 면제)** / IELTS 6.5 / 석사 + 연구 (HDR Fee Remission + $39,069/년 stipend)

---

#### ANU Canberra
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $50,400/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $50,400/년 / Canberra Cat 2 +15 PR (예외))

---

#### APIC (Asia Pacific International College) - ECA 그룹
*사립*

**총 3개 학과**

**Bachelor (2개)**

- **Bachelor of Business / IT (BIT) / Project Management** - $13,000-$18,000/년 (호주 사설 학비 저렴) / IELTS 5.5 (각 5.0) / Diploma 입학 / 한국 검정고시 OK / 고졸 / 고2 졸업도 가능
- **Diploma → Bachelor 패스웨이** - $13,000-$18,000/년 (호주 사설 학비 저렴) / IELTS 5.5 (각 5.0) / Diploma 입학 / 한국 검정고시 OK / 고졸 / 고2 졸업도 가능

**Master (1개)**

- **Master of Business Administration (MBA) / Master of Project Management** - $13,000-$18,000/년 (호주 사설 학비 저렴) / IELTS 5.5 (각 5.0) / Diploma 입학 / 한국 검정고시 OK / 고졸 / 고2 졸업도 가능

---

#### Adelaide / UofA (애들레이드 대학교)
*국립 (Go8)*

**총 49개 학과**

**Bachelor (23개)**

- **Bachelor of Commerce** - $44,000-$50,000 / IELTS 6.5 / 75+ (Regional +15)
- **Bachelor of Business** - $44,000-$50,000 / IELTS 6.5 / 75+ (Regional +15)
- **Bachelor of Economics** - $44,000-$50,000 / IELTS 6.5 / 78+ (Regional +15)
- **Bachelor of Accounting** - $44,000-$50,800 / IELTS 7.0 / 75+ (CPA + Regional +15)
- **Bachelor of Engineering Honours (Civil)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Mechanical)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학/물리 (EA + Regional +15)
- **Bachelor of Engineering Honours (Electrical)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Mining)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (Adelaide)
- **Bachelor of Engineering Honours (Petroleum)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (Adelaide)
- **Bachelor of Engineering Honours (Software)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + ACS + Regional +15)
- **Bachelor of Computer Science** - $46,000-$52,000 / IELTS 6.5 / 75+ (ACS + Regional +15)
- **Bachelor of Information Technology** - $44,000-$48,000 / IELTS 6.5 / 70+ (ACS + Regional +15)
- **Bachelor of Medical Studies (BMD/MD 통합 6년)** - $80,000-$94,500 / IELTS 7.0 / 95+ + UCAT/ISAT (AHPRA / 학부 직접 6년)
- **Bachelor of Pharmacy (Honours)** - $54,000-$58,000 / IELTS 7.0 / 85+ + 화학 (AHPRA + Regional +15)
- **Bachelor of Nursing** - $44,000-$48,000 / IELTS 7.0 / 75+ (NMBA + Regional +15)
- **Bachelor of Veterinary Bioscience** - $74,000-$80,000 / IELTS 6.5 / 90+ + 과학 (Adelaide / Roseworthy)
- **Bachelor of Health and Medical Sciences** - $44,000-$48,000 / IELTS 6.5 / 78+ (XXX)
- **Bachelor of Psychological Science** - $44,000-$48,000 / IELTS 6.5 / 80+ (AHPRA)
- **Bachelor of Arts** - $32,000-$42,000 / IELTS 6.5 / 70+ (Adelaide 가장 저렴)
- **Bachelor of Social Work (Honours)** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 75+ (⛔ AASW = IELTS only / Regional +15)
- **Bachelor of Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Viticulture and Oenology (와인학)** - $44,000-$48,000 / IELTS 6.5 / 75+ (Adelaide 세계 / Waite)
- **Bachelor of Agricultural Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (Waite 캠퍼스)

**Master (26개)**

- **MBA (Adelaide Business School)** - $58,000-$65,000 / IELTS 7.0 / 학사 + 경력 3년+ (Regional +15)
- **Master of Commerce** - $44,000-$48,000 / IELTS 6.5 / 학사 (Regional +15)
- **Master of Finance** - $44,000-$48,000 / IELTS 6.5 / Finance 학사 (Regional +15)
- **Master of Professional Accounting** - $44,000-$50,800 / IELTS 7.0 / 학사 (CPA + Regional +15)
- **Master of Information Technology** - $44,000-$48,000 / IELTS 6.5 / 학사 (ACS + Regional +15)
- **Master of Computer Science** - $48,000-$52,000 / IELTS 6.5 / CS 학사 (Regional +15)
- **Master of Data Science** - $48,000-$52,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드 + Regional +15)
- **Master of Cybersecurity** - $48,000-$52,000 / IELTS 6.5 / 학사 (미래 트렌드 + Regional +15)
- **Master of Artificial Intelligence** - $48,000-$52,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Engineering (Civil)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Engineering (Mechanical)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Engineering (Electrical)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Mining Engineering** - $48,000-$54,000 / IELTS 6.5 / 학사 (Adelaide)
- **Master of Petroleum Engineering** - $48,000-$54,000 / IELTS 6.5 / 학사 (Adelaide)
- **Master of Defence and Space (NEW)** - $48,000-$54,000 / IELTS 6.5 / 학사 (Adelaide 호주 허브)
- **Doctor of Medicine (MD)** - $80,000-$90,000 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23)
- **Master of Nursing Science** - $44,000-$48,000 / IELTS 7.0 / 학사 (NMBA + Regional +15)
- **Master of Pharmacy** - $54,000-$58,000 / IELTS 7.0 / 약학 학사 (AHPRA + Regional +15)
- **Master of Public Health** - $42,000-$46,000 / IELTS 6.5 / 학사 (Regional +15)
- **Master of Wine Business (와인 비즈니스)** - $44,000-$48,000 / IELTS 6.5 / 학사 (Adelaide 세계 유일)
- **Juris Doctor (JD)** - $48,000-$52,000 / IELTS 7.0 / 학사 + LSAT (Regional +15)
- **Master of Laws (LLM)** - $44,000-$48,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $42,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL + Regional +15)
- **Master of Teaching (Secondary)** - $42,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL + Regional +15)
- **Master of Social Work** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW + Regional +15)
- **PhD (모든 분야)** - RTP 면제 / IELTS 6.5 / 석사 + 연구 (RTP = 학비 면제 + 생활비)

---

#### Adelaide University
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $50K / IELTS 7.0 (AHPRA 의료 표준) / Adelaide University: ~$50K/년 / Cat 2 +15 PR / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)

---

#### Australian Institute Counselling 사립
*국립*

**총 1개 학과**

**Diploma (1개)**

- **Counselling/Psychology (Counselling Diploma 사립 빠른 입문)** - IELTS 6.5 / Australian Institute Counselling 사립 / PR MLTSSL (Psychologist 272311 (MLTSSL))

---

#### Avondale (아본데일 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Nursing** - $28K / IELTS 7.0 / 65+ (3년 / $28K (NMBA / IELTS 7.0) **호주 1위 학사 Nursing** + Sydney Adventist Hospital)
- **Bachelor of Education / Teaching (Primary/Secondary/Early Childhood)** - $28K / IELTS 7.5 (AITSL) / 65+ (4년 / $28K (AITSL IELTS 7.5) **호주 1위 학사 Teaching**)
- **Bachelor of Business / Accounting** - $26K / IELTS 6.5 (각 6.0) / 65+ (3년 / $26K)
- **Bachelor of Arts (Humanities / Counselling)** - $26K / IELTS 6.5 (각 6.0) / 65+ (3년 / $26K)
- **Bachelor of Science / Mathematics** - $28K / IELTS 6.5 (각 6.0) / 65+ (3년 / $28K)
- **Bachelor of Lifestyle Medicine** - $30K / IELTS 6.5 (각 6.0) / 65+ (3년 / $30K Avondale 호주 첫 (건강·웰니스 산업))
- **Bachelor of Theology / Ministry** - $24K / IELTS 6.5 (각 6.0) / 65+ (3년 / $24K 호주 가장 저렴)
- **Bachelor of Outdoor Recreation** - $26K / IELTS 6.5 (각 6.0) / 65+ (3년 / $26K 호주 유일 (VET 통합))

**Master (6개)**

- **Master of Nursing** - $32K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $32K (NMBA) Sydney Adventist Hospital)
- **Master of Teaching (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $30K (AITSL IELTS 7.5) 호주 1위)
- **Master of Education** - $30K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $30K)
- **Master of Arts / Counselling** - $30K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $30K)
- **Master of Leadership and Management / MBA** - $32K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $32K)
- **Master of Lifestyle Medicine** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K 호주 첫)

---

#### B
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of International Hospitality** - IELTS 6.5 / PR MLTSSL (Hotel Manager 141311 / Hospitality Manager (CSOL))

---

#### Bond (본드 대학교)
*국립*

**총 13개 학과**

**Bachelor (8개)**

- **Bachelor of Medicine MD** - $85-95K / IELTS 6.5 (각 6.0) / 75+ (4년 8개월 / $85-95K 호주 가장 빠른 의대)
- **Bachelor of Laws (LLB)** - $58K / IELTS 6.5 (각 6.0) / 75+ (2년 가속 / $58K 호주 사립)
- **Bachelor of Business** - $54K / IELTS 6.5 (각 6.0) / 75+ (2년 가속 / $54K)
- **Bachelor of Biomedical Science** - $58K / IELTS 6.5 (각 6.0) / 75+ (2년 / $58K)
- **Bachelor of Communication / Film and Television** - $54K / IELTS 6.5 (각 6.0) / 75+ (2년 / $54K)
- **Bachelor of Architecture** - $58K / IELTS 6.5 (각 6.0) / 75+ (2년 / $58K)
- **Bachelor of Sport Management** - $52K / IELTS 6.5 (각 6.0) / 75+ (2년 / $52K)
- **Bachelor of Psychology** - $54K / IELTS 6.5 (각 6.0) / 75+ (2년 / $54K)

**Master (5개)**

- **Master of Business Administration (MBA)** - $65-78K / IELTS 6.5 (각 6.0) / 학사 학위 (12개월 / $65-78K 호주 가장 빠른 MBA)
- **Master of Project Management** - $58K / IELTS 6.5 (각 6.0) / 학사 학위 (12개월 / $58K)
- **Master of Communication** - $52K / IELTS 6.5 (각 6.0) / 학사 학위 (12개월 / $52K)
- **Master of Actuarial Science** - $58K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5년 / $58K)
- **Master of Counselling** - $54K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5년 / $54K)

---

#### Bradford College
*사립*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / Engineering / IT** - Foundation $25,000-$32,000 / Diploma $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $25,000-$32,000 / Diploma $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### C
*국립*

**총 4개 학과**

**Master (4개)**

- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / Cat 2 / PR MLTSSL (Registered Nurse 254418 (MLTSSL))
- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / Cat 3 / PR MLTSSL (Registered Nurse 254418 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / Cat 2 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Professional Accounting** - IELTS 6.5 / Cat 2 / PR MLTSSL (Accountant 221111 (MLTSSL))

---

#### CDU (찰스 다윈 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Nursing** - $30K / IELTS 7.0 / 60+ (3년 / $30K (NMBA / IELTS 7.0) Royal Darwin Hospital)
- **Bachelor of Education (Primary/Secondary)** - $28K / IELTS 7.5 (AITSL) / 60+ (4년 / $28K (AITSL IELTS 7.5))
- **Bachelor of Engineering** - $32K / IELTS 6.5 (각 6.0) / 60+ (4년 / $32K)
- **Bachelor of Information Technology** - $30K / IELTS 6.5 (각 6.0) / 60+ (3년 / $30K (ACS 인증))
- **Bachelor of Aboriginal & Australian Studies** - $28K / IELTS 6.5 (각 6.0) / 60+ (3년 / $28K 호주 유일)
- **Bachelor of Environmental Science (Tropical)** - $32K / IELTS 6.5 (각 6.0) / 60+ (3년 / $32K 호주 유일 Tropical)
- **Bachelor of Business / Sustainable Business** - $28K / IELTS 6.5 (각 6.0) / 60+ (3년 / $28K)
- **Bachelor of Social Work** - $30K / IELTS 7.0 / 60+ (4년 / $30K (AASW IELTS 7.0))

**Master (6개)**

- **Master of Nursing Practice** - $34K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $34K (NMBA))
- **Master of Public Health (Tropical / Indigenous)** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K 호주 유일)
- **Master of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K (ACS 인증))
- **Master of Teaching (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $32K (AITSL))
- **Master of Business Administration (MBA)** - $36-42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36-42K)
- **Master of Education (First Nations / Indigenous)** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K 호주 유일)

---

#### CDU Darwin
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $35,800/년 / IELTS 7.0 (NMBA 표준) / Cat 3 +5 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $35,800/년 / Cat 3 +5 PR)

---

#### CDU Darwin/Sydney/Alice Springs
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $35,800/년 / IELTS 7.0 (AHPRA 의료 표준) / CDU Darwin/Sydney/Alice Springs: $35,800/년 / Cat 3 +5 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 3 +5)

---

#### CQUniversity
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $36,400/년 / IELTS 6.5 / CQUniversity: ~$36,400/년 / Cat 2 +15 PR / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2 +15)

---

#### CSU / Charles Sturt (찰스 스터트 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Education (Primary/Secondary)** - $34K / IELTS 7.5 (AITSL) / 65+ (4년 / $34K AITSL)
- **Bachelor of Nursing** - $36K / IELTS 7.0 / 65+ (3년 / $36K (NMBA / IELTS 7.0))
- **Bachelor of Dental Medicine (Orange)** - $70-78K / IELTS 6.5 (각 6.0) / 65+ (5년 / $70-78K 학부 직접 5년)
- **Bachelor of Veterinary Biology / Medicine (Wagga)** - $50-60K / IELTS 6.5 (각 6.0) / 65+ (6년 / $50-60K (호주 5개교만))
- **Bachelor of Agriculture (Wagga 640 ha)** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K 호주 최대 농장)
- **Bachelor of Information Technology** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K)
- **Bachelor of Business** - $30K / IELTS 6.5 (각 6.0) / 65+ (3년 / $30K)
- **Bachelor of Communication / Journalism** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K)

**Master (6개)**

- **Master of Teaching (Primary/Secondary)** - $38K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $38K AITSL)
- **Master of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $38K (NMBA))
- **Master of Information Technology** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K)
- **Master of Public Health** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Business Administration (MBA)** - $40-46K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40-46K)
- **Master of TESOL (Teaching English)** - $36K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $36K AITSL 한국·호주 듀얼)

---

#### CSU Albury
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Speech Pathology (Bachelor Speech 4년 2026)** - $35,200/년 / IELTS 7.0 (AHPRA 의료 표준) / CSU Albury: $35,200/년 / Cat 2 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2)

---

#### Charles Darwin University Pathway College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Health** - Foundation $20,000-$25,000 NT 정부 보조 = 호주 Foundation 가장 저렴 / Diploma $22,000-$2 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Charles Darwin University (CDU 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $20,000-$25,000 NT 정부 보조 = 호주 Foundation 가장 저렴 / Diploma $22,000-$2 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Charles Darwin University (CDU 학사 2학년 직진)

---

#### Charles Sturt Univ
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Occupational Therapy (Bachelor OT 4년 2026)** - $35,200/년 / IELTS 7.0 (AHPRA 의료 표준) / Charles Sturt Univ: $35,200/년 / Cat 2 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $35,200/년 / IELTS 6.5 / Charles Sturt Univ: $35,200/년 / Cat 2 / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2)
- **Social Work (Bachelor Social Work 4년 2026)** - $35,200/년 / IELTS 6.5 / Charles Sturt Univ: $35,200/년 / Cat 2 / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2)

---

#### Charles Sturt Univ Albury
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $35,200/년 / IELTS 7.0 (AHPRA 의료 표준) / Charles Sturt Univ Albury: $35,200/년 / Cat 2 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)

---

#### Charles Sturt Univ Bathurst
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $35,200/년 / IELTS 7.0 (AHPRA 의료 표준) / Charles Sturt Univ Bathurst: $35,200/년 / Cat 2 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2)
- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $35,200/년 / IELTS 6.5 / Charles Sturt Univ Bathurst: $35,200/년 / Cat 2 +15 PR / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2 +15)

---

#### Charles Sturt Wagga
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Radiography (Bachelor Medical Imaging 4년 20)** - $35,200/년 / IELTS 6.5 / Charles Sturt Wagga: $35,200/년 / Cat 2 (호주 저렴) / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 2)

---

#### Charles Sturt Wagga (Oral Health 3년)
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Dental (Direct Bachelor Dentistry 5년 2)** - $35,200/년 / IELTS 7.0 (AHPRA 의료 표준) / Charles Sturt Wagga (Oral Health 3년): $35,200/년 × 3 = $105K / Cat 2 (호주 저렴) / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2)

---

#### Curtin
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $42,400/년 / IELTS 6.5 / Curtin: $42,400/년 / Cat 2 / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2)

---

#### Curtin (커틴 대학교)
*국립*

**총 48개 학과**

**Bachelor (24개)**

- **Bachelor of Commerce** - $36,000-$42,000 / IELTS 6.5 / 70+ (Regional +15)
- **Bachelor of Business Administration** - $36,000-$42,000 / IELTS 6.5 / 70+ (Regional +15)
- **Bachelor of Economics** - $36,000-$42,000 / IELTS 6.5 / 75+ (Regional +15)
- **Bachelor of Accounting** - $36,000-$42,000 / IELTS 7.0 / 70+ (CPA + Regional +15)
- **Bachelor of Engineering Honours (Mining)** - $44,000-$47,347 / IELTS 6.5 / 70+ + 수학 (Curtin + Regional +15)
- **Bachelor of Engineering Honours (Petroleum)** - $44,000-$47,347 / IELTS 6.5 / 70+ + 수학 (Curtin + Regional +15)
- **Bachelor of Engineering Honours (Civil)** - $42,000-$47,347 / IELTS 6.5 / 70+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Mechanical)** - $42,000-$47,347 / IELTS 6.5 / 70+ + 수학/물리 (EA + Regional +15)
- **Bachelor of Engineering Honours (Electrical)** - $42,000-$47,347 / IELTS 6.5 / 70+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Chemical)** - $42,000-$47,347 / IELTS 6.5 / 70+ + 수학/화학 (EA + Regional +15)
- **Bachelor of Computing** - $40,000-$45,000 / IELTS 6.5 / 70+ (ACS + Regional +15 / 미래 트렌드)
- **Bachelor of Information Technology** - $40,000-$45,000 / IELTS 6.5 / 70+ (ACS + Regional +15)
- **Bachelor of Cyber Security** - $40,000-$45,000 / IELTS 6.5 / 75+ (미래 트렌드 + Regional +15)
- **Bachelor of Pharmacy** - $44,000-$48,000 / IELTS 7.0 / 80+ + 화학 (AHPRA + Regional +15)
- **Bachelor of Nursing** - $40,000-$44,000 / IELTS 7.0 / 70+ (NMBA + Regional +15)
- **Bachelor of Health Sciences** - $36,000-$40,000 / IELTS 6.5 / 65+ (Regional +15)
- **Bachelor of Psychology** - $36,000-$40,000 / IELTS 6.5 / 75+ (AHPRA)
- **Bachelor of Physiotherapy** - $44,000-$48,000 / IELTS 7.0 / 85+ (AHPRA + Regional +15)
- **Bachelor of Arts** - $28,200-$34,000 / IELTS 6.5 / 65+ (호주 가장 저렴)
- **Bachelor of Education (Primary)** - $30,000-$36,000 / IELTS 7.5 (L8 S8 R7 W7) / 70+ (⛔ AITSL = IELTS만)
- **Bachelor of Social Work** - $32,000-$36,000 / IELTS 7.0 (모든 7.0) / 70+ (⛔ AASW + Regional +15)
- **Bachelor of Design** - $36,000-$40,000 / IELTS 6.5 / 70+ + 포트폴리오 (XXX)
- **Bachelor of Science** - $36,000-$42,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Architecture** - $40,000-$44,000 / IELTS 6.5 / 75+ + 포트폴리오 (XXX)

**Master (24개)**

- **MBA (Curtin Business School)** - $42,000-$48,000 / IELTS 6.5 / 학사 + 경력 3년+ (호주 비즈니스 스쿨 10 + Regional +15)
- **Master of Commerce** - $36,000-$42,000 / IELTS 6.5 / 학사 (Regional +15)
- **Master of Finance** - $36,000-$42,000 / IELTS 6.5 / Finance 학사 (Regional +15)
- **Master of Professional Accounting** - $36,000-$42,000 / IELTS 7.0 / 학사 (CPA + Regional +15)
- **Master of Marketing** - $36,000-$42,000 / IELTS 6.5 / 학사 (Regional +15)
- **Master of Information Technology** - $36,000-$42,000 / IELTS 6.5 / 학사 (ACS + Regional +15 / 미래 트렌드)
- **Master of Computer Science** - $40,000-$45,000 / IELTS 6.5 / CS 학사 (Regional +15)
- **Master of Data Science** - $40,000-$45,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드 + Regional +15)
- **Master of Cyber Security** - $40,000-$45,000 / IELTS 6.5 / 학사 (미래 트렌드 + Regional +15)
- **Master of Professional Engineering (Mining)** - $49,026 / IELTS 6.0 / 학사 (Curtin + Regional +15)
- **Master of Professional Engineering (Petroleum)** - $49,026 / IELTS 6.0 / 학사 (Curtin + Regional +15)
- **Master of Professional Engineering (Civil)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Professional Engineering (Mechanical)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Professional Engineering (Electrical)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Engineering (Chemical)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Nursing Practice** - $40,000-$44,000 / IELTS 7.0 / 학사 (NMBA + Regional +15)
- **Master of Pharmacy** - $44,000-$48,000 / IELTS 7.0 / 약학 학사 (AHPRA + Regional +15)
- **Master of Public Health** - $36,000-$40,000 / IELTS 6.5 / 학사 (Regional +15)
- **Master of Physiotherapy** - $44,000-$48,000 / IELTS 7.0 / 관련 학사 (AHPRA + Regional +15)
- **Master of Teaching (Primary)** - $30,000-$36,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL + Regional +15)
- **Master of Teaching (Secondary)** - $30,000-$36,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL + Regional +15)
- **Master of Social Work** - $32,000-$36,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW + Regional +15)
- **Master of Architecture** - $40,000-$44,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (Regional +15)
- **PhD (모든 분야)** - RTP 면제 / IELTS 6.5 / 석사 + 연구 (RTP = 학비 면제 + 생활비 + Regional +15)

---

#### Curtin College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / Engineering / Mass Communication / Health Sciences** - {'Foundation': '$24,000-$30,000', 'Diploma': '$28,000-$34,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ Curtin University 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - {'Foundation': '$24,000-$30,000', 'Diploma': '$28,000-$34,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ Curtin University 학사 2학년 직진)

---

#### Curtin Perth
*국립*

**총 7개 학과**

**Bachelor (7개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $50,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Curtin Perth: $50,800/년 / Cat 2 +15 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2 +15)
- **Physiotherapy (Bachelor PT 4년 2026)** - $50,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Curtin Perth: $50,800/년 / Cat 2 +15 ( 5) / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2 +15)
- **Occupational Therapy (Bachelor OT 4년 2026)** - $50,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Curtin Perth: $50,800/년 / Cat 2 +15 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2 +15)
- **Speech Pathology (Bachelor Speech 4년 2026)** - $50,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Curtin Perth: $50,800/년 / Cat 2 +15 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2 +15)
- **Radiography (Bachelor Medical Imaging 4년 20)** - $50,800/년 / IELTS 6.5 / Curtin Perth: $50,800/년 / Cat 2 +15 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 2 +15)
- **Social Work (Bachelor Social Work 4년 2026)** - $42,400/년 / IELTS 6.5 / Curtin Perth: $42,400/년 / Cat 2 +15 / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2 +15)
- **Bachelor of Nursing (Direct 3년)** - $43,150/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $43,150/년 / Perth Cat 2 +15 PR / 840시간 임상 / 3.5년)

---

#### Curtin Univ Perth
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $40-43K / IELTS 7.0 (AHPRA 의료 표준) / Curtin Univ Perth: $40-43K/년 / Cat 2 +15 PR / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)

---

#### D
*국립*

**총 2개 학과**

**Master (2개)**

- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of Construction Management** - IELTS 6.5 / PR MLTSSL (Construction Project Manager 133111 (MLTSSL))

---

#### Deakin (디킨 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Cybersecurity** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K 학비)
- **Bachelor of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Computer Science** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Engineering** - $42-45K / IELTS 6.5 (각 6.0) / 75+ (4년 / $42-45K)
- **Bachelor of Sport Management** - $38K / IELTS 6.5 (각 6.0) / 75+ (3년 / $38K 세계 10)
- **Bachelor of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 75+ (3년 / $38K (NMBA 인증))
- **Bachelor of Business** - $35K / IELTS 6.5 (각 6.0) / 75+ (3년 / $35K)
- **Bachelor of Commerce** - $35K / IELTS 6.5 (각 6.0) / 75+ (3년 / $35K)

**Master (6개)**

- **Master of Cybersecurity** - $45K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $45K Geelong 캠퍼스 = +15점 PR)
- **Master of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Engineering** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K)
- **Master of Sport Management** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K 세계 10)
- **Master of Business Administration (MBA)** - $48-55K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48-55K)
- **Master of Professional Accounting** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K (CPA 인증))

---

#### Deakin College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / Engineering / IT / Health** - {'Foundation': '$28,000-$34,000', 'Diploma': '$30,000-$38,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ Deakin University 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - {'Foundation': '$28,000-$34,000', 'Diploma': '$30,000-$38,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ Deakin University 학사 2학년 직진)

---

#### Deakin Geelong
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (Dual Bachelor Nursing Midwifer)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Deakin Geelong: $44,800/년 × 4년 / Cat 2 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2)

---

#### ECC (Edith Cowan College, 구 PIBT)
*사립*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Communications / Engineering** - Foundation $24,000-$30,000 / Diploma $28,000-$32,000 (호주 학비 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $24,000-$30,000 / Diploma $28,000-$32,000 (호주 학비 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### ECU
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $36,500/년 / IELTS 6.5 / ECU: $36,500/년 / Cat 2 (학비) / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2)

---

#### ECU (에디스 코완 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Cyber Security** - $34K / IELTS 6.5 (각 6.0) / 65+ (3년 / $34K 호주 최대 Security Research)
- **Bachelor of Acting / Music Theatre / Dance (WAAPA)** - $36-42K / IELTS 6.5 (각 6.0) / 65+ (3년 / $36-42K (Audition))
- **Bachelor of Nursing** - $32K / IELTS 7.0 / 65+ (3년 / $32K (NMBA / IELTS 7.0) WA 최대)
- **Bachelor of Education (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 65+ (4년 / $30K (AITSL IELTS 7.5))
- **Bachelor of Engineering (Motorsports / Mechanical)** - $36K / IELTS 6.5 (각 6.0) / 65+ (4년 / $36K)
- **Bachelor of Sports Science** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K)
- **Bachelor of Counselling / Psychology** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K)
- **Bachelor of Communication / Media** - $30K / IELTS 6.5 (각 6.0) / 65+ (3년 / $30K (Mount Lawley → ECU City))

**Master (6개)**

- **Master of Cyber Security** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K)
- **Master of Nursing Practice / Midwifery** - $36K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $36K (NMBA))
- **Master of Teaching (Primary/Secondary)** - $34K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $34K (AITSL IELTS 7.5))
- **Master of Information Technology** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K (ACS 인증))
- **Master of Music / Music Theatre (WAAPA)** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Business Administration (MBA)** - $38-42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38-42K)

---

#### ECU Bachelor Sci (Nursing) + Bachelor Sci (Midwifery)
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (Dual Bachelor Nursing Midwifer)** - $55,000/년 / IELTS 7.0 (AHPRA 의료 표준) / ECU Bachelor Sci (Nursing) + Bachelor Sci (Midwifery): $55,000/년 × 4년 = $220K (W / PR MLTSSL (Registered Midwife 254111 (MLTSSL))

---

#### ECU Perth
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Social Work (Bachelor Social Work 4년 2026)** - $36,500/년 / IELTS 6.5 / ECU Perth: $36,500/년 / Cat 2 (학비) / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2)

---

#### Edith Cowan ECU
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $42,900/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $42,900/년 / Perth Cat 2 +15 PR / 20% 장학금)

---

#### Edith Cowan ECU Perth
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $42,800-55K / IELTS 7.0 (AHPRA 의료 표준) / Edith Cowan ECU Perth: $42,800-55K/년 / Cat 2 +15 PR / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)
- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $42,000/년 / IELTS 6.5 / Edith Cowan ECU Perth : ~$42,000/년 / Cat 2 +15 PR (명성) / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2 +15)

---

#### F
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / Cat 2 / PR MLTSSL (Registered Nurse 254418 (MLTSSL))

---

#### FedUni / Federation (페더레이션 호주 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Information Technology** - $26K / IELTS 6.5 (각 6.0) / 60+ (3년 / $26K Co-op + IBM 인턴 (Ballarat Tech Park))
- **Bachelor of Engineering (Mining / Mechanical)** - $30K / IELTS 6.5 (각 6.0) / 60+ (4년 / $30K 호주 첫 Mining Engineering)
- **Bachelor of Nursing** - $28K / IELTS 7.0 / 60+ (3년 / $28K (NMBA / IELTS 7.0))
- **Bachelor of Education (Primary/Secondary)** - $28K / IELTS 7.5 (AITSL) / 60+ (4년 / $28K (AITSL IELTS 7.5))
- **Bachelor of Business / Accounting** - $24K / IELTS 6.5 (각 6.0) / 60+ (3년 / $24K 호주 가장 저렴)
- **Bachelor of Psychology** - $28K / IELTS 6.5 (각 6.0) / 60+ (4년 / $28K)
- **Bachelor of Visual Arts (SMB Camp Street)** - $26K / IELTS 6.5 (각 6.0) / 60+ (3년 / $26K 호주 4번째 오래된 Arts Academy)
- **Bachelor of Sport Management** - $26K / IELTS 6.5 (각 6.0) / 60+ (3년 / $26K)

**Master (6개)**

- **Master of Information Technology** - $30K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $30K Co-op + IBM)
- **Master of Teaching (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $30K AITSL 호주·한국 교사)
- **Master of Engineering (Mining / Civil)** - $32K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $32K)
- **Master of Nursing** - $30K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $30K (NMBA))
- **Master of Business Administration (MBA)** - $32-36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $32-36K)
- **Master of Public Health** - $30K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $30K)

---

#### Federation
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Speech Pathology (Bachelor Speech 4년 2026)** - $32,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Federation: $32,800/년 / Cat 2 (호주 저렴) / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $32,800/년 / IELTS 6.5 / Federation: $32,800/년 / Cat 2 (호주 저렴) / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2)

---

#### Federation Ballarat
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $41,800/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $41,800/년 / Cat 2 +15 PR + 장학금 20%)

---

#### Federation Pathway College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Engineering / Education** - Foundation $20,000-$26,000 호주 학비 저렴 / Diploma $22,000-$28,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Federation University Australi 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $20,000-$26,000 호주 학비 저렴 / Diploma $22,000-$28,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Federation University Australi 학사 2학년 직진)

---

#### Federation Univ
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Occupational Therapy (Bachelor OT 4년 2026)** - $32,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Federation Univ: $32,800/년 / Cat 2 (호주 저렴) / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2)
- **Social Work (Bachelor Social Work 4년 2026)** - $32,800/년 / IELTS 6.5 / Federation Univ: $32,800/년 / Cat 2 (호주 저렴) / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2)

---

#### Federation Univ Ballarat
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $41,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Federation Univ Ballarat: $41,800/년 / Cat 2 + 20% 장학금 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2)
- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $32,800/년 / IELTS 6.5 / Federation Univ Ballarat: $32,800/년 / Cat 2 +15 PR (호주 저렴) / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2 +15)
- **Physiotherapy (Bachelor PT 4년 2026)** - $32,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Federation Univ Ballarat: $32,800/년 / Cat 2 (호주 저렴) / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)

---

#### Flinders University Foundation Studies
*패스웨이*

**총 1개 학과**

**Foundation (1개)**

- **Foundation Studies → Flinders 학사** - $26,000-$32,000 / IELTS 5.5 (각 5.0) / 고2/고3/검정고시 OK (→ Flinders University 학사 2학년 직진)

---

#### G
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of International Hospitality** - IELTS 6.5 / Cat 2 / PR MLTSSL (Hotel Manager 141311 / Hospitality Manager (CSOL))

---

#### Griffith (그리피스 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of International Tourism and Hotel Management** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K 호주 1위 (Gold Coast))
- **Bachelor of Dentistry / Doctor of Dental Medicine** - $75-85K / IELTS 6.5 (각 6.0) / 70+ (5년 / $75-85K Gold Coast 학부 직접)
- **Bachelor of Medicine MD** - $75-85K / IELTS 6.5 (각 6.0) / 70+ (4년 PG / $75-85K Gold Coast Hospital)
- **Bachelor of Nursing** - $40K / IELTS 7.0 / 70+ (3년 / $40K (NMBA / IELTS 7.0))
- **Bachelor of Pharmacy** - $42K / IELTS 6.5 (각 6.0) / 70+ (4년 / $42K)
- **Bachelor of Music (Queensland Conservatorium)** - $38K / IELTS 6.5 (각 6.0) / 70+ (3년 / $38K)
- **Bachelor of Aviation** - $48K / IELTS 6.5 (각 6.0) / 70+ (3년 / $48K (호주 유일급))
- **Bachelor of Criminology** - $35K / IELTS 6.5 (각 6.0) / 70+ (3년 / $35K)

**Master (6개)**

- **Master of International Tourism and Hospitality Management** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K 호주 1위)
- **Master of Dental Surgery (Doctor of Dentistry)** - $75-85K / IELTS 6.5 (각 6.0) / 학사 학위 (4년 / $75-85K)
- **Master of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Public Health** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Business Administration (MBA)** - $48-55K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48-55K)
- **Master of Music (Queensland Conservatorium)** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)

---

#### Griffith Brisbane GoldCoast
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $44,500/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $44,500/년 / Cat 2 +15 PR)

---

#### Griffith College (구 QIBT)
*사립*

**총 3개 학과**

**Diploma (1개)**

- **Diploma of Business / Hospitality / IT** - Foundation $26,000-$32,000 / Diploma $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $26,000-$32,000 / Diploma $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Other (1개)**

- **→ Griffith 학사 2학년 직접** - Foundation $26,000-$32,000 / Diploma $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### Griffith Univ
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $35,500/년 / IELTS 7.0 (AHPRA 의료 표준) / Griffith Univ: $35,500/년 (Paramedicine 기준) / Cat 2 +15 PR / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)
- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $44,500/년 / IELTS 7.0 (AHPRA 의료 표준) / Griffith Univ: $44,500/년 / Cat 2 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2)
- **Dental (Direct Bachelor Dentistry 5년 2)** - $63,000/년 / IELTS 7.0 (AHPRA 의료 표준) / Griffith Univ: $63,000/년 × 5 = $315K / Brisbane/GC Cat 2 +15 PR (학비) / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2 +15)

---

#### Griffith Univ Gold Coast
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $35,500/년 / IELTS 6.5 / Griffith Univ Gold Coast: $35,500/년 / Cat 2 +15 PR / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2 +15)

---

#### H
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of Professional Accounting** - IELTS 6.5 / Cat 3 / PR MLTSSL (Accountant 221111 (MLTSSL))

---

#### Holmes (홈즈 인스티튜트)
*국립*

**총 10개 학과**

**Bachelor (6개)**

- **Bachelor of Business** - $26K / IELTS 6.0 (학사) / 60+ (3년 / $26K (Cairns Cat 3 / Gold Coast Cat 2 / 5 캠퍼스 자유))
- **Bachelor of Professional Accounting** - $28K / IELTS 6.0 (학사) / 60+ (3년 / $28K CPA Australia + CA ANZ 인증)
- **Bachelor of Information Systems** - $28K / IELTS 6.0 (학사) / 60+ (3년 / $28K ACS 인증)
- **Bachelor of Fashion Business** - $26K / IELTS 6.0 (학사) / 60+ (3년 / $26K (Melbourne))
- **Bachelor of Marketing / Hospitality** - $26K / IELTS 6.0 (학사) / 60+ (3년 / $26K)
- **Bachelor of Banking & Finance** - $28K / IELTS 6.0 (학사) / 60+ (3년 / $28K)

**Master (4개)**

- **Master of Professional Accounting** - $30K / IELTS 6.0 (학사) / 학사 학위 (1.5년 (3 Trimester) / $30K CPA Australia + CA ANZ)
- **Master of Business Administration (MBA)** - $32-40K / IELTS 6.0 (학사) / 학사 학위 (1.5년 / $32-40K)
- **Master of Information Systems / Cyber Security** - $32K / IELTS 6.0 (학사) / 학사 학위 (1.5년 / $32K)
- **Master of Marketing** - $30K / IELTS 6.0 (학사) / 학사 학위 (1.5년 / $30K)

---

#### I
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of International Hospitality** - IELTS 6.5 / Cat 2 / PR MLTSSL (Hotel Manager 141311 / Hospitality Manager (CSOL))

---

#### INTO James Cook University
*사립*

**총 3개 학과**

**Master (1개)**

- **Pre-Master Programme** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Diploma (1개)**

- **Diploma of Business / IT / Tourism** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### J
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / Cat 3 / PR MLTSSL (Registered Nurse 254418 (MLTSSL))

---

#### JCU
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Occupational Therapy (Bachelor OT 4년 2026)** - $39,840/년 / IELTS 7.0 (AHPRA 의료 표준) / JCU: $39,840/년 / Cat 2 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2)
- **Social Work (Bachelor Social Work 4년 2026)** - $39,840/년 / IELTS 6.5 / JCU: $39,840/년 / Cat 2/3 / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2)

---

#### JCU (제임스 쿡 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Medicine MBBS (Townsville/Cairns)** - $70-80K / IELTS 6.5 (각 6.0) / 70+ (6년 / $70-80K 학부 직접 6년)
- **Bachelor of Veterinary Science (Townsville)** - $65-75K / IELTS 6.5 (각 6.0) / 70+ (5년 / $65-75K 호주 5개교만 + 열대 수의학 호주 유일)
- **Bachelor of Marine Biology** - $38K / IELTS 6.5 (각 6.0) / 70+ (3년 / $38K 세계 (Great Barrier Reef))
- **Bachelor of Nursing** - $36K / IELTS 7.0 / 70+ (3년 / $36K (NMBA / IELTS 7.0))
- **Bachelor of Engineering** - $42K / IELTS 6.5 (각 6.0) / 70+ (4년 / $42K)
- **Bachelor of Tourism Management (Cairns)** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Business** - $32K / IELTS 6.5 (각 6.0) / 70+ (3년 / $32K)

**Master (6개)**

- **Master of Marine Biology** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K 세계)
- **Master of Public Health (Tropical Health)** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K AITHM 호주 1위)
- **Master of Information Technology** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Business Administration (MBA)** - $40-46K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40-46K)
- **Master of Education** - $36K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $36K (AITSL IELTS 7.5))
- **Master of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $38K (NMBA))

---

#### JCU Cairns Far North
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $39,840/년 / IELTS 7.0 (NMBA 표준) / Cat 3 +5 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $39,840/년 / Cat 3 +5 PR)

---

#### JCU Townsville
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $39,840/년 / IELTS 7.0 (AHPRA 의료 표준) / JCU Townsville: $39,840/년 / Cat 2/3 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)
- **Dental (Direct Bachelor Dentistry 5년 2)** - $60K / IELTS 7.0 (AHPRA 의료 표준) / JCU Townsville: ~$60K/년 × 5 / Cat 2/3 / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2)

---

#### JCU Townsville Cairns
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $39,840/년 / IELTS 7.0 (NMBA 표준) / Cat 2 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $39,840/년 / Cat 2/3 PR)

---

#### James Cook Univ JCU
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $44,000/년 / IELTS 7.0 (AHPRA 의료 표준) / James Cook Univ JCU: $44,000/년 / Cat 2/3 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2)

---

#### KOI (King's Own Institute)
*사립*

**총 4개 학과**

**Bachelor (2개)**

- **Bachelor of Accounting** - Bachelor $18,000-$22,000 / Master $22,000-$26,000 / IELTS Bachelor 6.0 (각 6.0) / Master / 한국 대졸 / 검정고시 + 영어 OK
- **Bachelor of Business** - Bachelor $18,000-$22,000 / Master $22,000-$26,000 / IELTS Bachelor 6.0 (각 6.0) / Master / 한국 대졸 / 검정고시 + 영어 OK

**Master (2개)**

- **Master of Accounting (CPA)** - Bachelor $18,000-$22,000 / Master $22,000-$26,000 / IELTS Bachelor 6.0 (각 6.0) / Master / 한국 대졸 / 검정고시 + 영어 OK
- **Master of Business** - Bachelor $18,000-$22,000 / Master $22,000-$26,000 / IELTS Bachelor 6.0 (각 6.0) / Master / 한국 대졸 / 검정고시 + 영어 OK

---

#### Kaplan Business School (KBS)
*사립*

**총 3개 학과**

**Bachelor (1개)**

- **Bachelor of Business** - Bachelor $20,000-$26,000 / Master $24,000-$32,000 / MBA $28, / IELTS Bachelor 6.0 / Master 6.5 / 한국 대졸 / 경력자 MBA

**Master (2개)**

- **Master of Business (다양한 트랙)** - Bachelor $20,000-$26,000 / Master $24,000-$32,000 / MBA $28, / IELTS Bachelor 6.0 / Master 6.5 / 한국 대졸 / 경력자 MBA
- **MBA** - Bachelor $20,000-$26,000 / Master $24,000-$32,000 / MBA $28, / IELTS Bachelor 6.0 / Master 6.5 / 한국 대졸 / 경력자 MBA

---

#### L
*국립*

**총 1개 학과**

**Master (1개)**

- **Master of International Hospitality** - IELTS 6.5 / PR MLTSSL (Hotel Manager 141311 / Hospitality Manager (CSOL))

---

#### La Trobe (라트로브 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Physiotherapy** - $44K / IELTS 6.5 (각 6.0) / 70+ (4년 / $44K)
- **Bachelor of Nursing** - $38K / IELTS 7.0 / 70+ (3년 / $38K (NMBA / IELTS 7.0))
- **Bachelor of Medicine MBBS (Bendigo Joint with Monash)** - $75-85K / IELTS 6.5 (각 6.0) / 70+ (5년 / $75-85K)
- **Bachelor of Education (Primary/Secondary)** - $36K / IELTS 7.5 (AITSL) / 70+ (4년 / $36K (AITSL IELTS 7.5))
- **Bachelor of Engineering** - $42K / IELTS 6.5 (각 6.0) / 70+ (4년 / $42K)
- **Bachelor of Information Technology** - $40K / IELTS 6.5 (각 6.0) / 70+ (3년 / $40K)
- **Bachelor of Business** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Public Health** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K)

**Master (6개)**

- **Master of Physiotherapy** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K)
- **Master of Nursing** - $42K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $42K (NMBA))
- **Master of Teaching (Primary/Secondary)** - $40K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $40K AITSL)
- **Master of Information Technology** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K)
- **Master of Public Health** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Business Administration (MBA)** - $48-55K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48-55K)

---

#### La Trobe Bendigo
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $50,400/년 / IELTS 7.0 (AHPRA 의료 표준) / La Trobe Bendigo: $50,400/년 / Cat 2 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)
- **Occupational Therapy (Bachelor OT 4년 2026)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / La Trobe Bendigo: $44,800/년 / Cat 2 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2)
- **Speech Pathology (Bachelor Speech 4년 2026)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / La Trobe Bendigo: $44,800/년 / Cat 2 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2)

---

#### La Trobe Bendigo (Oral Health 3년)
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Dental (Direct Bachelor Dentistry 5년 2)** - $50,400/년 / IELTS 7.0 (AHPRA 의료 표준) / La Trobe Bendigo (Oral Health 3년): $50,400/년 × 3 / Cat 2 / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2)

---

#### La Trobe College Australia
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Health Sciences** - {'Foundation': '$26,000-$32,000', 'Diploma': '$28,000-$34,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ La Trobe University 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - {'Foundation': '$26,000-$32,000', 'Diploma': '$28,000-$34,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ La Trobe University 학사 2학년 직진)

---

#### La Trobe Univ Bendigo
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / La Trobe Univ Bendigo: $44,800/년 / Cat 2 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2)

---

#### M
*국립*

**총 6개 학과**

**Master (6개)**

- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Professional Accounting** - IELTS 6.5 / PR MLTSSL (Accountant 221111 (MLTSSL))
- **Master of Business Analytics** - IELTS 6.5 / PR MLTSSL (ICT Business Analyst 261111 / Data Scientist 224711 (MLTSSL))
- **Master of Business Analytics** - IELTS 6.5 / PR MLTSSL (ICT Business Analyst 261111 / Data Scientist 224711 (MLTSSL))

---

#### MIT (Melbourne Institute of Technology)
*사립*

**총 6개 학과**

**Bachelor (2개)**

- **Bachelor of IT** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능
- **Bachelor of Business** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능

**Master (2개)**

- **Master of Business Analytics** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능
- **Master of IT** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능

**Diploma (2개)**

- **Diploma of IT** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능
- **Diploma of Business** - Diploma $14,000-$18,000 / Bachelor $20,000-$26,000 / Master / IELTS Bachelor 6.0 (각 5.5) / Master / 검정고시 OK / 한국 대학 1-2학년 편입 가능

---

#### Macquarie
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $49,600/년 / IELTS 6.5 / Macquarie: $49,600/년 / PR MLTSSL (Psychologist 272311 (MLTSSL))

---

#### Macquarie / MQ (매쿼리 대학교)
*국립*

**총 46개 학과**

**Bachelor (22개)**

- **Bachelor of Actuarial Studies** - $48,000-$52,000 / IELTS 6.5 / 90+ + 수학 (호주 1위 / Centre of Excellence)
- **Bachelor of Actuarial Studies (Honours / Co-op)** - $48,000-$52,000 / IELTS 6.5 / 95+ + 수학 (/ 인턴십 직결)
- **Bachelor of Commerce** - $43,200-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Business Analytics** - $43,200-$48,000 / IELTS 6.5 / 80+ (Macquarie / 미래 트렌드)
- **Bachelor of Accounting** - $43,200-$48,000 / IELTS 7.0 / 75+ (CPA 합격률 91% 호주 1위)
- **Bachelor of Economics** - $43,200-$48,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Business Administration** - $43,200-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Engineering Honours (Mechatronics)** - $44,000-$50,000 / IELTS 6.5 / 80+ + 수학 (EA / Macquarie)
- **Bachelor of Engineering Honours (Electronics)** - $44,000-$50,000 / IELTS 6.5 / 80+ + 수학 (EA)
- **Bachelor of Engineering Honours (Software)** - $44,000-$50,000 / IELTS 6.5 / 80+ + 수학 (EA + ACS)
- **Bachelor of Information Technology** - $42,600-$46,000 / IELTS 6.5 / 75+ (ACS / 미래 트렌드)
- **Bachelor of Computer Science** - $42,600-$46,000 / IELTS 6.5 / 78+ (ACS)
- **Bachelor of Cyber Security** - $44,000-$48,000 / IELTS 6.5 / 80+ (Macquarie / 미래 트렌드)
- **Bachelor of Data Science** - $44,000-$48,000 / IELTS 6.5 / 80+ (Macquarie / 미래 트렌드)
- **Bachelor of Medical Sciences** - $48,000-$54,000 / IELTS 6.5 / 85+ (MD 패스 / Macquarie)
- **Bachelor of Nursing** - $44,000-$48,000 / IELTS 7.0 / 75+ (NMBA 2026.04.23)
- **Bachelor of Psychology** - $44,000-$48,000 / IELTS 6.5 / 80+ (AHPRA / Macquarie Top 100 (THE))
- **Bachelor of Speech, Hearing and Language Sciences** - $44,000-$48,000 / IELTS 6.5 / 80+ (Macquarie / 호주)
- **Bachelor of Laws (LLB)** - $46,000-$50,000 / IELTS 7.0 / 88+ (XXX)
- **Bachelor of Arts** - $37,900-$44,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Education (Early Childhood)** - $37,900-$44,000 / IELTS 7.5 (L8 S8 R7 W7) / 75+ (⛔ ACECQA = IELTS만)
- **Bachelor of Linguistics** - $37,900-$44,000 / IELTS 6.5 / 75+ (Macquarie)

**Master (24개)**

- **MBA (Macquarie Business School)** - $58,500-$61,100 / IELTS 6.5 / 학사 + 경력 3년+ (AACSB + EQUIS 더블 인증)
- **Master of Applied Finance** - $46,000-$50,000 / IELTS 6.5 / 학사 (호주 1위 / 세계 40위)
- **Master of Commerce** - $42,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Business Analytics** - $48,000 / IELTS 6.5 / 학사 (Macquarie)
- **Master of Marketing** - $42,000-$46,000 / IELTS 6.5 / 학사 (호주 1위 / 세계 25위)
- **Master of Professional Accounting** - $42,000-$48,000 / IELTS 7.0 / 학사 (CPA 합격률 91% 호주 1위)
- **Master of Actuarial Practice** - $48,000-$52,000 / IELTS 6.5 / 학사 (수학/통계 OK) (Macquarie 호주 1위)
- **Master of Information Technology** - $42,000-$46,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Data Science** - $46,300 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Cyber Security** - $46,000-$50,000 / IELTS 6.5 / 학사 (Macquarie / 미래 트렌드)
- **Master of Artificial Intelligence** - $46,000-$50,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Engineering (Mechatronic)** - $44,000-$50,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Electronic)** - $44,000-$50,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Management** - $44,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Nursing (Graduate Entry)** - $44,000-$48,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $40,000-$44,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Clinical Audiology** - $48,000-$52,000 / IELTS 7.0 / 학사 (AHPRA / Macquarie)
- **Master of Speech and Language Pathology** - $48,000-$52,000 / IELTS 7.0 / 학사 (AHPRA / Macquarie)
- **Juris Doctor (JD)** - $46,000-$50,000 / IELTS 7.0 / 학사 (XXX)
- **Master of Laws (LLM)** - $42,000-$46,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $40,000-$44,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $40,000-$44,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Counselling** - $40,000-$44,000 / IELTS 6.5 / 학사 (XXX)
- **PhD (모든 분야)** - $35,000-$45,000 / IELTS 6.5 / 석사 + 연구 (MUR Postgraduate Research 장학)

---

#### Monash
*국립*

**총 5개 학과**

**Bachelor (5개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $58,000/년 / IELTS 7.0 (AHPRA 의료 표준) / Monash: $58,000/년 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL))
- **Radiography (Bachelor Medical Imaging 4년 20)** - $52,200/년 / IELTS 6.5 / Monash: $52,200/년 / Cat 1 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 1)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $52,200/년 / IELTS 6.5 / Monash: $52,200/년 / PR MLTSSL (Psychologist 272311 (MLTSSL))
- **Social Work (Bachelor Social Work 4년 2026)** - $52,200/년 / IELTS 6.5 / Monash: $52,200/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))
- **Bachelor of Nursing (Direct 3년)** - $52,200/년 / IELTS 7.0 (NMBA 표준) / Cat 1 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $52,200/년 / Melbourne Cat 1)

---

#### Monash (모나쉬 대학교)
*국립 (Go8)*

**총 50개 학과**

**Bachelor (23개)**

- **Bachelor of Business** - $48,000-$52,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Commerce** - $48,000-$52,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Banking and Finance** - $48,000-$52,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Accounting** - $48,000-$52,000 / IELTS 7.0 / 80+ (CPA 등록)
- **Bachelor of Engineering Honours (Civil)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA 등록)
- **Bachelor of Engineering Honours (Mechanical)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학/물리 (EA 등록)
- **Bachelor of Engineering Honours (Electrical)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA 등록)
- **Bachelor of Engineering Honours (Software)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA + ACS)
- **Bachelor of Engineering Honours (Aerospace)** - $52,000-$58,000 / IELTS 6.5 / 85+ + 수학/물리 (Monash)
- **Bachelor of Computer Science** - $50,000-$54,000 / IELTS 6.5 / 80+ (ACS / 미래 트렌드)
- **Bachelor of Information Technology** - $48,000-$52,000 / IELTS 6.5 / 78+ (ACS)
- **Bachelor of Medicine and Bachelor of Surgery (MBBS/MD)** - $90,000-$101,600 / IELTS 7.0 / 95+ + UCAT/ISAT (학부 직접 5년 (UMelb는 X))
- **Bachelor of Pharmacy (Honours)** - $58,000-$65,000 / IELTS 7.0 / 88+ + 화학 (Parkville /)
- **Bachelor of Nursing** - $48,000-$52,000 / IELTS 7.0 / 80+ (NMBA 2026.04.23)
- **Bachelor of Biomedical Science** - $50,000-$54,000 / IELTS 6.5 / 85+ (MD 패스)
- **Bachelor of Psychology (Honours)** - $50,000-$54,000 / IELTS 6.5 / 85+ (AHPRA)
- **Bachelor of Health Sciences** - $48,000-$52,000 / IELTS 6.5 / 78+ (XXX)
- **Bachelor of Laws (LLB)** - $52,000-$56,000 / IELTS 7.0 / 95+ (XXX)
- **Bachelor of Arts** - $39,500-$46,000 / IELTS 6.5 / 75+ (가장 저렴)
- **Bachelor of Education (Early Years)** - $42,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 80+ (⛔ ACECQA = IELTS만)
- **Bachelor of Social Work (Honours)** - $44,000-$48,000 / IELTS 7.0 (모든 7.0) / 80+ (⛔ AASW = IELTS only)
- **Bachelor of Science** - $50,000-$54,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Design** - $46,000-$50,000 / IELTS 6.5 / 78+ + 포트폴리오 (XXX)

**Master (27개)**

- **MBA (Monash Business School)** - $58,000-$65,400 / IELTS 7.0 / 학사 + 경력 5년+ (UMelb $99K보다 저렴)
- **Master of Business** - $48,000-$52,000 / IELTS 6.5 / 학사 (경력 X 가능)
- **Master of Banking and Finance** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Professional Accounting** - $48,000-$52,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Information Technology** - $48,000-$52,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Cybersecurity** - $48,000-$52,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Data Science** - $50,000-$54,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Artificial Intelligence** - $50,000-$54,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Engineering (Civil)** - $52,000-$58,000 / IELTS 6.5 / 학사 (EA / Engineering $15K 장학)
- **Master of Engineering (Mechanical)** - $52,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Electrical)** - $52,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Advanced Engineering** - $52,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Doctor of Medicine (Graduate Entry)** - $93,000-$101,600 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23)
- **Master of Pharmacy** - $58,000-$65,000 / IELTS 7.0 / 약학 학사 (Parkville /)
- **Master of Nursing** - $48,000-$52,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $42,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Physiotherapy** - $54,000-$58,000 / IELTS 7.0 / 관련 학사 (AHPRA 2026.04.23)
- **Master of Psychology** - $50,000-$54,000 / IELTS 7.0 / Psych 학사 (AHPRA)
- **Juris Doctor (JD)** - $52,000-$56,000 / IELTS 7.0 / 학사 + LSAT (XXX)
- **Master of Laws (LLM)** - $48,000-$52,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $42,000-$48,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $42,000-$48,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Teaching (Early Childhood)** - $42,000-$48,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ ACECQA = IELTS만)
- **Master of Social Work (Qualifying)** - $44,000-$48,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Translation Studies** - $42,000-$46,000 / IELTS 6.5 / 학사 + 한국어 (NAATI)
- **Master of Architecture** - $48,000-$52,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **PhD (모든 분야)** - $32,000-$46,000 / IELTS 6.5 / 석사 + 연구 (Monash Graduate Scholarship ($36K stipend))

---

#### Monash College Diploma
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / Engineering / IT / Science / Art & Design** - $36,000-$45,000 / IELTS 6.0 (각 5.5) / 한국 고3 졸업 (정규) / 검정고시 일부 OK (→ Monash University 학사 2학년 직진)

**Pathway (1개)**

- **→ Monash 학사 2학년** - $36,000-$45,000 / IELTS 6.0 (각 5.5) / 한국 고3 졸업 (정규) / 검정고시 일부 OK (→ Monash University 학사 2학년 직진)

---

#### Murdoch (머독 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Veterinary Medicine DVM** - $65-75K / IELTS 6.5 (각 6.0) / 70+ (5-6년 / $65-75K 호주 5개교만 +)
- **Bachelor of Chiropractic Science** - $36-42K / IELTS 6.5 (각 6.0) / 70+ (5년 / $36-42K 호주 5개교만)
- **Bachelor of Nursing** - $34K / IELTS 7.0 / 70+ (3년 / $34K (NMBA / IELTS 7.0))
- **Bachelor of Engineering** - $38K / IELTS 6.5 (각 6.0) / 70+ (4년 / $38K)
- **Bachelor of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Business** - $30K / IELTS 6.5 (각 6.0) / 70+ (3년 / $30K)
- **Bachelor of Law** - $36K / IELTS 6.5 (각 6.0) / 70+ (4년 / $36K (Moot Court))
- **Bachelor of Psychology** - $32K / IELTS 6.5 (각 6.0) / 70+ (4년 / $32K)

**Master (6개)**

- **Master of Veterinary Studies** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48K)
- **Master of Information Technology** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K)
- **Master of Engineering** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $42K)
- **Master of Business Administration (MBA)** - $40-46K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40-46K)
- **Master of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $38K (NMBA))
- **Master of Public Health** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)

---

#### Murdoch College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Engineering** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Murdoch University 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Murdoch University 학사 2학년 직진)

---

#### Notre Dame / UNDA (노트르담 호주 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Nursing** - $34K / IELTS 7.0 / 70+ (3년 / $34K (NMBA / IELTS 7.0) Catholic Healthcare 직결)
- **Bachelor of Education (Primary/Secondary)** - $34K / IELTS 7.5 (AITSL) / 70+ (4년 / $34K (AITSL IELTS 7.5))
- **Bachelor of Health Sciences** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K (의대 그래듀에이트 진입 패스웨이))
- **Bachelor of Biomedical Science** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K)
- **Bachelor of Laws (LLB)** - $36K / IELTS 6.5 (각 6.0) / 70+ (4년 / $36K (Sydney/Fremantle))
- **Bachelor of Business** - $32K / IELTS 6.5 (각 6.0) / 70+ (3년 / $32K)
- **Bachelor of Counselling** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Physiotherapy** - $40K / IELTS 6.5 (각 6.0) / 70+ (4년 / $40K)

**Master (6개)**

- **Doctor of Medicine MD** - $75-85K / IELTS 6.5 (각 6.0) / 학사 학위 (4년 / $75-85K Sydney Darlinghurst (St Vincent's Hospital 옆))
- **Master of Teaching (Primary/Secondary)** - $36K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $36K AITSL 호주·한국 교사)
- **Master of Nursing** - $36K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $36K (NMBA))
- **Master of Counselling** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K)
- **Master of Business Administration (MBA)** - $42-48K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42-48K)
- **Master of Social Work** - $36K / IELTS 7.0 / 학사 학위 (2년 / $36K (AASW IELTS 7.0))

---

#### Notre Dame Sydney
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (Dual Bachelor Nursing Midwifer)** - $42K / IELTS 7.0 (AHPRA 의료 표준) / Notre Dame Sydney: $42K/년 × 4년 = $168K / PR MLTSSL (Registered Midwife 254111 (MLTSSL))

---

#### Notre Dame Sydney Fremantle
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $42,000/년 / IELTS 7.0 (NMBA 표준) / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $42,000/년)

---

#### Notre Dame Sydney/Fremantle
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $48,000/년 / IELTS 7.0 (AHPRA 의료 표준) / Notre Dame Sydney/Fremantle: $48,000/년 / PR MLTSSL (Physiotherapist 252511 (MLTSSL))

---

#### Q
*국립*

**총 2개 학과**

**Master (2개)**

- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))

---

#### QUT (퀸즐랜드 공과대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Creative Industries (Animation/Game Design/Film)** - $38K / IELTS 6.5 (각 6.0) / 75+ (3년 / $38K 호주 1위)
- **Bachelor of Communication (Journalism/PR/Media)** - $36K / IELTS 6.5 (각 6.0) / 75+ (3년 / $36K)
- **Bachelor of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Engineering (Honours)** - $42-45K / IELTS 6.5 (각 6.0) / 75+ (4년 / $42-45K)
- **Bachelor of Business** - $38K / IELTS 6.5 (각 6.0) / 75+ (3년 / $38K (Triple-accredited))
- **Bachelor of Nursing** - $40K / IELTS 7.0 (NMBA/AHPRA) / 75+ (3년 / $40K (NMBA 인증 / 시뮬레이션))
- **Bachelor of Paramedicine** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Design (Architecture/Industrial)** - $40K / IELTS 6.5 (각 6.0) / 75+ (4년 / $40K)

**Master (6개)**

- **Master of Information Technology** - $44K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $44K)
- **Master of Engineering** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K)
- **Master of Business Administration (MBA)** - $48-55K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48-55K Triple-accredited (호주 5개만))
- **Master of Professional Accounting** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K (CPA 인증))
- **Master of Design** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Nursing** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)

---

#### QUT Brisbane
*국립*

**총 4개 학과**

**Bachelor (4개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $44,500/년 / IELTS 7.0 (AHPRA 의료 표준) / QUT Brisbane: $44,500/년 / Cat 2 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2)
- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $44,500/년 / IELTS 6.5 / QUT Brisbane: $44,500/년 / Cat 2 / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 2)
- **Radiography (Bachelor Medical Imaging 4년 20)** - $44,500/년 / IELTS 6.5 / QUT Brisbane: $44,500/년 / Cat 2 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 2)
- **Bachelor of Nursing (Direct 3년)** - $44,500/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $44,500/년 / Cat 2 +15 PR)

---

#### R
*국립*

**총 4개 학과**

**Master (4개)**

- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Professional Accounting** - IELTS 6.5 / PR MLTSSL (Accountant 221111 (MLTSSL))
- **Master of Construction Management** - IELTS 6.5 / PR MLTSSL (Construction Project Manager 133111 (MLTSSL))

---

#### RMIT
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Social Work (Bachelor Social Work 4년 2026)** - $44,160/년 / IELTS 6.5 / RMIT: $44,160/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### RMIT (RMIT 대학교 / 멜버른왕립공과대학교)
*국립*

**총 49개 학과**

**Bachelor (23개)**

- **Bachelor of Business** - $42,000-$48,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Accounting** - $42,000-$48,000 / IELTS 7.0 / 70+ (CPA 등록)
- **Bachelor of Economics and Finance** - $42,000-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Marketing** - $42,000-$48,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Engineering Honours (Civil)** - $44,000-$50,880 / IELTS 6.5 / 70+ + 수학 (EA)
- **Bachelor of Engineering Honours (Mechanical)** - $44,000-$50,880 / IELTS 6.5 / 70+ + 수학/물리 (EA)
- **Bachelor of Engineering Honours (Electrical)** - $44,000-$50,880 / IELTS 6.5 / 70+ + 수학 (EA)
- **Bachelor of Engineering Honours (Aerospace)** - $44,000-$50,880 / IELTS 6.5 / 75+ + 수학/물리 (RMIT 호주)
- **Bachelor of Software Engineering** - $44,000-$50,880 / IELTS 6.5 / 70+ + 수학 (EA + ACS)
- **Bachelor of Information Technology** - $42,000-$48,000 / IELTS 6.5 / 65+ (ACS / 미래 트렌드)
- **Bachelor of Computer Science** - $44,000-$50,000 / IELTS 6.5 / 70+ (ACS)
- **Bachelor of Nursing** - $44,000-$48,000 / IELTS 7.0 / 65+ (NMBA 2026.04.23)
- **Bachelor of Health Sciences** - $40,000-$44,000 / IELTS 6.5 / 65+ (XXX)
- **Bachelor of Communication (Media)** - $36,000-$44,000 / IELTS 6.5 / 70+ (RMIT 호주)
- **Bachelor of Communication (Journalism)** - $36,000-$44,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Communication (Public Relations)** - $36,000-$44,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Design (Communication Design)** - $36,000-$44,000 / IELTS 6.5 / 70+ + 포트폴리오 (RMIT 세계)
- **Bachelor of Fashion (Design)** - $36,000-$44,000 / IELTS 6.5 / 70+ + 포트폴리오 (RMIT 세계)
- **Bachelor of Animation and Interactive Media** - $44,000-$50,000 / IELTS 6.5 / 70+ + 포트폴리오 (RMIT)
- **Bachelor of Game Design** - $44,000-$50,000 / IELTS 6.5 / 70+ + 포트폴리오 (RMIT)
- **Bachelor of Architectural Design** - $44,000-$50,000 / IELTS 6.5 / 75+ + 포트폴리오 (RMIT 호주)
- **Bachelor of Education (Early Childhood)** - $36,000-$42,000 / IELTS 7.5 (L8 S8 R7 W7) / 70+ (⛔ ACECQA = IELTS만)
- **Bachelor of Science** - $42,000-$48,000 / IELTS 6.5 / 70+ (XXX)

**Master (26개)**

- **MBA (RMIT MBA)** - $52,000-$55,805 / IELTS 7.0 / 학사 + 경력 3년+ (XXX)
- **Master of Business Analytics** - $42,000-$48,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Professional Accounting** - $42,000-$48,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Finance** - $42,000-$48,000 / IELTS 6.5 / Finance 학사 (XXX)
- **Master of Marketing** - $42,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Information Technology** - $42,000-$48,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Data Science** - $42,000-$48,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Cyber Security** - $42,000-$48,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Computing** - $42,000-$48,000 / IELTS 6.5 / CS 학사 (XXX)
- **Master of Engineering (Civil)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Mechanical)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Electrical)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Aerospace)** - $44,000-$48,000 / IELTS 6.5 / 학사 (EA / RMIT)
- **Master of Nursing** - $42,000-$46,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $40,000-$44,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Pharmacy** - $48,000-$52,000 / IELTS 7.0 / 약학 학사 (AHPRA 2026.04.23)
- **Master of Teaching (Primary)** - $36,000-$42,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $36,000-$42,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Education (TESOL)** - $36,000-$42,000 / IELTS 6.5 / 학사 (RMIT /)
- **Master of Social Work** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Communication** - $36,000-$42,000 / IELTS 6.5 / 학사 (RMIT)
- **Master of Design (Industrial Design)** - $42,000-$48,000 / IELTS 6.5 / 학사 + 포트폴리오 (RMIT 세계)
- **Master of Architecture** - $44,000-$48,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (RMIT 호주)
- **Master of Fashion (Entrepreneurship)** - $42,000-$48,000 / IELTS 6.5 / 학사 (RMIT 세계)
- **Master of Animation, Games and Interactivity** - $44,000-$48,000 / IELTS 6.5 / 학사 + 포트폴리오 (RMIT)
- **PhD (모든 분야)** - $32,000-$46,000 / IELTS 6.5 / 석사 + 연구 (RMIT Postgraduate 장학)

---

#### RMIT Melbourne
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $44,160/년 / IELTS 7.0 (AHPRA 의료 표준) / RMIT Melbourne: $44,160/년 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL))
- **Radiography (Bachelor Medical Imaging 4년 20)** - $44,160/년 / IELTS 6.5 / RMIT Melbourne: $44,160/년 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL))

---

#### RMIT Training
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Commerce / IT / Engineering / Design / Communication** - {'Foundation': '$29,350 (2026 공식 - IDP 확인)', 'Diploma': '$32,000-$38,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ RMIT University 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - {'Foundation': '$29,350 (2026 공식 - IDP 확인)', 'Diploma': '$32,000-$38,000'} / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ RMIT University 학사 2학년 직진)

---

#### S
*국립*

**총 2개 학과**

**Master (2개)**

- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Social Work** - IELTS 6.5 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### SAIBT (South Australian Institute of Business and
*사립*

**총 3개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Engineering / Health Sciences** - Foundation $24,000-$30,000 / Diploma $26,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $24,000-$30,000 / Diploma $26,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Other (1개)**

- **→ Adelaide University 학사 2학년** - Foundation $24,000-$30,000 / Diploma $26,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### SCU Lismore/Gold Coast
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $36,000/년 / IELTS 7.0 (AHPRA 의료 표준) / SCU Lismore/Gold Coast: $36,000/년 / Cat 2 +15 PR / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)

---

#### SIBT (Sydney Institute of Business and Technology)
*사립*

**총 3개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Engineering / Communication & Creative Industries** - $28,000-$36,000 (Diploma) / Foundation $26,000-$32,000 / IELTS Diploma 5.5-6.0 / Foundation 5 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - $28,000-$36,000 (Diploma) / Foundation $26,000-$32,000 / IELTS Diploma 5.5-6.0 / Foundation 5 / 한국 고2/고3 / 검정고시 OK

**Other (1개)**

- **→ Western Sydney University 학사 2학년 직접 진학** - $28,000-$36,000 (Diploma) / Foundation $26,000-$32,000 / IELTS Diploma 5.5-6.0 / Foundation 5 / 한국 고2/고3 / 검정고시 OK

---

#### Specialist Colleges (호주 사립 Specialist Colleges)
*국립*

**총 12개 학과**

**Bachelor (8개)**

- **Bachelor of Culinary Management (William Angliss / Melbourne)** - $30K / IELTS 5.5 (각 6.0) / 50 (3년 / $30K)
- **Bachelor of Tourism and Hospitality Management (William Angliss)** - $30K / IELTS 5.5 (각 6.0) / 50 (3년 / $30K)
- **Bachelor of Resort and Hotel Management (William Angliss)** - $30K / IELTS 5.5 (각 6.0) / 50 (3년 / $30K)
- **Bachelor of Event Management (William Angliss)** - $28K / IELTS 5.5 (각 6.0) / 50 (3년 / $28K)
- **Bachelor of Health Science Naturopathy (Endeavour / Adelaide)** - $28K / IELTS 5.5 (각 6.0) / 50 (3-4년 / $28K)
- **Bachelor of Health Science Acupuncture (Endeavour)** - $28K / IELTS 5.5 (각 6.0) / 50 (4년 / $28K)
- **Bachelor of Audio Production (SAE)** - $30K / IELTS 5.5 (각 6.0) / 50 (2년 / $30K Audio Engineering)
- **Bachelor of Film / Animation (SAE / JMC)** - $30K / IELTS 5.5 (각 6.0) / 50 (2-3년 / $30K)

**Master (4개)**

- **Master of Hospitality Management (William Angliss)** - $32K / IELTS 5.5 (각 6.0) / 학사 학위 (1.5년 / $32K)
- **Master of Health Science Naturopathy (Endeavour)** - $32K / IELTS 5.5 (각 6.0) / 학사 학위 (1.5년 / $32K)
- **Master of Audio Engineering (SAE)** - $32K / IELTS 5.5 (각 6.0) / 학사 학위 (1.5년 / $32K)
- **Master of Film & TV Production (JMC)** - $32K / IELTS 5.5 (각 6.0) / 학사 학위 (1.5년 / $32K)

---

#### Stott's College
*국립*

**총 1개 학과**

**Diploma (1개)**

- **Counselling/Psychology (Counselling Diploma 사립 빠른 입문)** - IELTS 6.5 / Stott's College: Diploma Counselling / PR MLTSSL (Psychologist 272311 (MLTSSL))

---

#### Swinburne / SUT (스윈번 공과 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Astronomy / Astrophysics** - $42K / IELTS 6.5 (각 6.0) / 65+ (3년 / $42K (CSIRO·SKA 협력))
- **Bachelor of Design (Adobe Creative Campus)** - $40K / IELTS 6.5 (각 6.0) / 65+ (3년 / $40K 호주 첫 Adobe)
- **Bachelor of Aviation (Pilot Training)** - $80-120K / IELTS 6.5 (각 6.0) / 65+ (3년 / $80-120K 호주 유일 학사 Pilot)
- **Bachelor of Engineering (Aerospace / Robotics)** - $42K / IELTS 6.5 (각 6.0) / 65+ (4년 / $42K)
- **Bachelor of Information Technology** - $38K / IELTS 6.5 (각 6.0) / 65+ (3년 / $38K (ACS 인증))
- **Bachelor of Nursing** - $36K / IELTS 7.0 / 65+ (3년 / $36K (NMBA / IELTS 7.0))
- **Bachelor of Business / Accounting** - $36K / IELTS 6.5 (각 6.0) / 65+ (3년 / $36K (CPA 인증))
- **Bachelor of Communication / Media** - $36K / IELTS 6.5 (각 6.0) / 65+ (3년 / $36K + Adobe)

**Master (6개)**

- **Master of Astronomy & Astrophysics** - $45K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $45K)
- **Master of Design (Adobe Campus)** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K 호주 첫 Adobe)
- **Master of Engineering (Aerospace / Robotics)** - $45K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $45K)
- **Master of Information Technology / Cyber Security** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K)
- **Master of Business Administration (MBA)** - $42-50K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42-50K)
- **Master of Teaching (Primary/Secondary)** - $38K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $38K (AITSL IELTS 7.5))

---

#### TAFE NSW
*국립 (TAFE)*

**총 3개 학과**

**Diploma (1개)**

- **Beauty Therapy SHB50121** - $22-26K / 1년 (29 units) / IELTS 5.5-6.0 (TAFE 표준) / Sydney 다수 / PR CSOL (Beauty Therapist 451815 (CSOL) / Diploma Beauty Therapy (SHB50121-01))

**Other (1개)**

- **Aged Care/Disability (TAFE Cert III Aged Care 2026)** - $10,500-11,240 / IELTS 6.5 / TAFE NSW: $10,500-11,240 / 6개월 / PR MLTSSL (Aged or Disabled Carer 423111 (MLTSSL))

**Cert III (1개)**

- **Carpentry Cert III CPC30220** - Apprenticeship Only = 회사 고용 必 / IELTS 5.5 (TAFE 표준) / PR ⛔ 차단 (Carpenter 331212 (MLTSSL) / CRICOS / ⚠️ Apprenticeship Only = 학생비자 X)

---

#### TAFE QLD
*국립 (TAFE)*

**총 3개 학과**

**Diploma (1개)**

- **Beauty Therapy SHB50121** - $28,800 / 1년 / IELTS 5.5-6.0 (TAFE 표준) / Brisbane / Robina GC / Cairns / Townsville = 모두 Cat 2 +15 / PR CSOL (Beauty Therapist 451815 (CSOL) / SHB50121 / 111236A)

**Other (1개)**

- **Aged Care/Disability (TAFE Cert III Aged Care 2026)** - $6,800 / IELTS 6.5 / TAFE QLD : $6,800 / 6개월 (호주 저렴) / PR MLTSSL (Aged or Disabled Carer 423111 (MLTSSL))

**Cert III (1개)**

- **Carpentry Cert III CPC30220** - $27,800 / 2년 / IELTS 5.5 (TAFE 표준) / Acacia Ridge Brisbane / Nambour Sun.Coast / Ashmore GC = Cat / PR MLTSSL (Carpenter 331212 (MLTSSL) / CRICOS)

---

#### TAFE QLD Bachelor Nursing
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $31,000/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $31,000/년 / Brisbane Cat 2 +15 PR (TAFE 자체 Bachelor))

---

#### TAFE SA
*국립 (TAFE)*

**총 3개 학과**

**Diploma (1개)**

- **Beauty Therapy SHB50121** - $22-25K / 1년 / IELTS 5.5-6.0 (TAFE 표준) / Adelaide Cat 2 +15 PR ( PR) / PR CSOL (Beauty Therapist 451815 (CSOL) / Diploma Beauty Therapy)

**Other (1개)**

- **Aged Care/Disability (TAFE Cert III Aged Care 2026)** - $8,675 / IELTS 6.5 / TAFE SA : $8,675 / 6개월 / Adelaide Cat 2 +15 PR (PR 가산점 高 (Cat 2/3)) / PR MLTSSL (Aged or Disabled Carer 423111 (MLTSSL) / Cat 2 +15)

**Cert III (1개)**

- **Carpentry Cert III CPC30220** - Apprenticeship 우선 / 일부 직접 진학 옵션 (Adelaid / IELTS 5.5 (TAFE 표준) / PR ⛔ 차단 (Carpenter 331212 (MLTSSL) / CRICOS / ⚠️ Apprenticeship Only = 학생비자 X)

---

#### TAFE VIC
*국립 (TAFE)*

**총 3개 학과**

**Diploma (1개)**

- **Beauty Therapy SHB50121** - $22-28K / 1년 / IELTS 5.5-6.0 (TAFE 표준) / Melbourne Cat 1 / Bendigo Cat 2 / PR CSOL (Beauty Therapist 451815 (CSOL) / RMIT / Holmesglen / Bendigo Diploma Beauty)

**Other (1개)**

- **Aged Care/Disability (TAFE Cert III Aged Care 2026)** - $10-14K / IELTS 6.5 / TAFE VIC: $10-14K / PR MLTSSL (Aged or Disabled Carer 423111 (MLTSSL))

**Cert III (1개)**

- **Carpentry Cert III CPC30220** - Apprenticeship Only / Free TAFE 호주인만 / IELTS 5.5 (TAFE 표준) / Bendigo / SWTAFE / Holmesglen / RMIT / Swinburne / PR ⛔ 차단 (Carpenter 331212 (MLTSSL) / CRICOS / ⚠️ Apprenticeship Only = 학생비자 X)

---

#### TAFE WA
*국립 (TAFE)*

**총 3개 학과**

**Diploma (1개)**

- **Beauty Therapy SHB50121** - $23-26K / 1년 / IELTS 5.5-6.0 (TAFE 표준) / Perth Cat 2 +15 PR / PR CSOL (Beauty Therapist 451815 (CSOL) / North Metropolitan TAFE Diploma Beauty)

**Other (1개)**

- **Aged Care/Disability (TAFE Cert III Aged Care 2026)** - $9-12K / IELTS 6.5 / TAFE WA: $9-12K / Perth Cat 2 +15 PR / PR MLTSSL (Aged or Disabled Carer 423111 (MLTSSL) / Cat 2 +15)

**Cert III (1개)**

- **Carpentry Cert III CPC30220** - Apprenticeship Only / 호주 영주권 후 $400-1,20 / IELTS 5.5 (TAFE 표준) / PR ⛔ 차단 (Carpenter 331212 (MLTSSL) / CRICOS / ⚠️ Apprenticeship Only = 학생비자 X)

---

#### Taylors College Perth
*사립*

**총 2개 학과**

**Diploma (1개)**

- **Diploma → Curtin / UWA 학사 2학년** - Foundation $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

**Foundation (1개)**

- **Foundation** - Foundation $28,000-$34,000 / IELTS Foundation 5.5 / Diploma 6.0 / 한국 고2/고3 / 검정고시 OK

---

#### Torrens / TUA (토렌스 호주 대학교)
*국립*

**총 12개 학과**

**Bachelor (7개)**

- **Bachelor of Business in Hotel Management (BMIHMS)** - $36K / IELTS 6.5 (각 6.0) / 60+ (3년 / $36K QS 1위 호텔)
- **Bachelor of Design (Billy Blue / Animation / Graphic / 3D)** - $32K / IELTS 6.5 (각 6.0) / 60+ (3년 / $32K 글로벌 12)
- **Bachelor of Business / Marketing / HR** - $30K / IELTS 6.5 (각 6.0) / 60+ (3년 / $30K)
- **Bachelor of Information Technology / Cyber Security** - $32K / IELTS 6.5 (각 6.0) / 60+ (3년 / $32K)
- **Bachelor of Nursing** - $30K / IELTS 7.0 / 60+ (3년 / $30K (NMBA / IELTS 7.0))
- **Bachelor of Public Health / Counselling** - $30K / IELTS 6.5 (각 6.0) / 60+ (3년 / $30K)
- **Bachelor of Education (Early Childhood)** - $30K / IELTS 6.5 (각 6.0) / 60+ (3년 / $30K)

**Master (5개)**

- **Master of International Hotel Management (BMIHMS)** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K QS 1위 + Adelaide Cat 2)
- **Master of Design / UX / Animation (Billy Blue)** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Business Administration (Chifley MBA)** - $38-48K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38-48K)
- **Master of Information Technology / AI** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K AIRO 세계 1위 AI 연구자)
- **Master of Public Health** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K)

---

#### U
*국립*

**총 12개 학과**

**Master (12개)**

- **Master of Nursing Practice** - IELTS 6.5 (석사 표준) / 7.0 (의료/Teaching) / Cat 3 / PR MLTSSL (Registered Nurse 254418 (MLTSSL))
- **Master of IT** - $80-95K / IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of IT** - IELTS 6.5 / PR MLTSSL (Software Engineer 261313 / ICT BA 261111 (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Engineering** - IELTS 6.5 / PR MLTSSL (Engineer (학과별 233xxx) (MLTSSL))
- **Master of Professional Accounting** - IELTS 6.5 / Cat 2 / PR MLTSSL (Accountant 221111 (MLTSSL))
- **Master of Professional Accounting** - IELTS 6.5 / PR MLTSSL (Accountant 221111 (MLTSSL))
- **Master of Construction Management** - IELTS 6.5 / PR MLTSSL (Construction Project Manager 133111 (MLTSSL))
- **Master of Construction Management** - IELTS 6.5 / PR MLTSSL (Construction Project Manager 133111 (MLTSSL))
- **Master of Business Analytics** - IELTS 6.5 / PR MLTSSL (ICT Business Analyst 261111 / Data Scientist 224711 (MLTSSL))
- **Master of Business Analytics** - IELTS 6.5 / PR MLTSSL (ICT Business Analyst 261111 / Data Scientist 224711 (MLTSSL))

---

#### UC / Canberra (캔버라 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Sports Science / Sports Management** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K AIS 옆)
- **Bachelor of Nursing** - $34K / IELTS 7.0 / 70+ (3년 / $34K (NMBA / IELTS 7.0))
- **Bachelor of Communication / Journalism** - $32K / IELTS 6.5 (각 6.0) / 70+ (3년 / $32K 정부·미디어 직결)
- **Bachelor of Information Technology** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K (ACS 인증))
- **Bachelor of Business / Accounting** - $32K / IELTS 6.5 (각 6.0) / 70+ (3년 / $32K (CPA 인증))
- **Bachelor of Politics & International Relations** - $32K / IELTS 6.5 (각 6.0) / 70+ (3년 / $32K 정부 직결)
- **Bachelor of Architecture / Built Environment** - $38K / IELTS 6.5 (각 6.0) / 70+ (4년 / $38K)
- **Bachelor of Education (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 70+ (4년 / $32K (AITSL IELTS 7.5))

**Master (6개)**

- **Master of Sports Science / Sports Management** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K AIS 옆)
- **Master of Information Technology** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Business Administration (MBA)** - $40-45K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40-45K)
- **Master of Teaching (Primary/Secondary)** - $36K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $36K (AITSL))
- **Master of Nursing** - $36K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $36K (NMBA))
- **Master of Public Health** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)

---

#### UC College Foundation
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Sport** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ University of Canberra (UC) 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $25,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ University of Canberra (UC) 학사 2학년 직진)

---

#### UMelb
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Dental (Direct Bachelor Dentistry 5년 2)** - $89,824/년 / IELTS 7.0 (AHPRA 의료 표준) / UMelb: $89,824/년 × 4 (Master Direct) = $359K / Cat 1 / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 1)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $51,776/년 / IELTS 6.5 / UMelb: $51,776/년 / PR MLTSSL (Psychologist 272311 (MLTSSL))
- **Social Work (Bachelor Social Work 4년 2026)** - $51,776/년 / IELTS 6.5 / UMelb: $51,776/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### UMelb / Melbourne Uni (멜버른 대학교)
*국립 (Go8)*

**총 37개 학과**

**Bachelor (9개)**

- **Bachelor of Commerce** - $52,360-$59,052 / IELTS 6.5 (모든 6.0) / ATAR 95+ (Finance/Marketing/Economics 전공)
- **Bachelor of Biomedicine** - $54,780-$61,460 / IELTS 6.5 (모든 6.0) / ATAR 94+ (MD 진학 패스웨이)
- **Bachelor of Oral Health** - **$80,984** / IELTS 7.0 (모든 7.0) / ATAR 95+ (UMelb 학사 가장 비쌈)
- **Bachelor of Arts** - $38,004-$56,252 / IELTS 6.5 (모든 6.0) / ATAR 85+ (UMelb 학사 가장 저렴 / 인문학 多 전공)
- **Bachelor of Science** - $52,944-$62,208 / IELTS 6.5 (모든 6.0) / ATAR 85+ (Engineering/IT 석사 패스웨이)
- **Bachelor of Agriculture** - $48,000-$54,000 / IELTS 6.5 (모든 6.0) / ATAR 80+ (Dookie 캠퍼스 / PR 직결)
- **Bachelor of Design** - $43,868-$57,900 / IELTS 6.5 (모든 6.0) / ATAR 85+ (Architecture 석사 패스웨이)
- **Bachelor of Fine Arts** - $39,936-$44,213 / IELTS 6.5 (모든 6.0) / ATAR 80+ + 포트폴리오 / PR - (Southbank 캠퍼스)
- **Bachelor of Music** - $39,936-$44,213 / IELTS 6.5 (모든 6.0) / ATAR 80+ + 오디션 / PR - (Southbank 캠퍼스)

**Master (28개)**

- **MBA (Melbourne Business School)** - $99,000-$110,000 / IELTS 7.0 / 학사 + 경력 4년+ + GMAT (호주 1위)
- **Master of Commerce** - $52,000-$58,000 / IELTS 6.5 / Commerce 학사 (Finance/Marketing/Economics)
- **Master of Finance** - $54,000-$60,000 / IELTS 6.5 / Finance/Commerce 학사 (XXX)
- **Master of Management (Accounting)** - $52,000-$56,000 / IELTS 7.0 / 학사 (CPA 등록 必)
- **Master of Information Technology** - $52,000-$56,000 / IELTS 6.5 / 학사 (전공 X) (ACS 등록 / 미래 트렌드)
- **Master of Information Systems** - $52,000-$56,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Data Science** - $54,000-$58,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Computer Science** - $54,000-$58,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Engineering (Civil)** - $54,000-$60,000 / IELTS 6.5 / 학사 (EA 등록 / 변경 X)
- **Master of Engineering (Mechanical)** - $54,000-$60,000 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Engineering (Electrical)** - $54,000-$60,000 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Engineering (Software)** - $54,000-$60,000 / IELTS 6.5 / 학사 (EA + ACS)
- **Doctor of Medicine (MD)** - $107,000-$122,976 / IELTS 7.0 / Biomed 학사 + GAMSAT (AHPRA 2026.04.23 변경)
- **Master of Nursing Science** - $52,000-$56,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23 변경)
- **Master of Pharmacy** - $54,000-$58,000 / IELTS 7.0 / 관련 학사 (AHPRA 2026.04.23)
- **Master of Physiotherapy** - $54,000-$58,000 / IELTS 7.0 / 관련 학사 (AHPRA 2026.04.23)
- **Master of Public Health** - $48,000-$54,000 / IELTS 6.5 / 학사 (보건 정책)
- **Master of Psychology (Clinical)** - $52,000-$56,000 / IELTS 7.0 / Psych 학사 (AHPRA)
- **Juris Doctor (JD)** - $52,000-$58,000 / IELTS 7.0 / 학사 + LSAT (한국 학사 졸 + JD = 호주 변호사)
- **Master of Laws (LLM)** - $49,984 / IELTS 7.0 / LLB (한국 변호사 자격 + LLM)
- **Master of Teaching (Primary)** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Teaching (Early Childhood)** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ ACECQA = IELTS만)
- **Master of Social Work (MSW)** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Translation** - $48,000-$52,000 / IELTS 6.5 / 학사 + 한국어/영어 (NAATI 등록 가능)
- **Master of Architecture** - $52,000-$56,000 / IELTS 6.5 / Design 학사 + 포트폴리오 (XXX)
- **Master of Urban Planning** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **PhD (모든 분야)** - $32,000-$48,000 / IELTS 6.5 / 석사 + 연구 계획서 (GRS 장학금 (학비+생활비))

---

#### UMelb UMelbourne
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $51,776/년 / IELTS 7.0 (NMBA 표준) / Cat 1 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $51,776/년 (Master Direct) / Melbourne Cat 1)

---

#### UNE (뉴잉글랜드 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Medicine MBBS (Joint Newcastle)** - $70-80K / IELTS 6.5 (각 6.0) / 65+ (5년 / $70-80K 학부 직접)
- **Bachelor of Agriculture / Rural Science** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K (한국 농업 정책 직결))
- **Bachelor of Animal Science** - $34K / IELTS 6.5 (각 6.0) / 65+ (3년 / $34K 동물 유전학)
- **Bachelor of Education (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 65+ (4년 / $30K (AITSL IELTS 7.5))
- **Bachelor of Nursing** - $32K / IELTS 7.0 / 65+ (3년 / $32K (NMBA / IELTS 7.0))
- **Bachelor of Psychology** - $32K / IELTS 6.5 (각 6.0) / 65+ (4년 / $32K)
- **Bachelor of Business / Accounting** - $28K / IELTS 6.5 (각 6.0) / 65+ (3년 / $28K (CPA 인증))
- **Bachelor of Environmental Science** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K)

**Master (6개)**

- **Master of Teaching (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $32K AITSL 호주·한국 교사)
- **Master of Agriculture** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K)
- **Master of Nursing** - $34K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $34K (NMBA))
- **Master of Business Administration (MBA)** - $36-42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36-42K)
- **Master of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K (ACS 인증))
- **Master of Public Health** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K)

---

#### UNE Armidale
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $32,400/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $32,400/년 / Cat 2 +15 PR / Armidale NSW)

---

#### UNE Univ New England
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $32,400/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $32,400/년 / Cat 2 +15 PR / Armidale NSW)

---

#### UNSW
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $50,400/년 / IELTS 7.0 (NMBA 표준) / Cat 1 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $50,400/년 / Sydney Cat 1)

---

#### UNSW (뉴사우스웨일스 대학교)
*국립 (Go8)*

**총 51개 학과**

**Bachelor (23개)**

- **Bachelor of Commerce** - $52,000-$56,000 / IELTS 7.0 / 92+ (XXX)
- **Bachelor of Economics** - $50,000-$54,000 / IELTS 7.0 / 90+ (XXX)
- **Bachelor of Actuarial Studies** - $52,000-$56,000 / IELTS 7.0 / 95+ (UNSW 호주 1위)
- **Bachelor of Engineering Honours (Civil)** - $58,000-$62,000 / IELTS 6.5 / 91+ + 수학 (EA / UNSW 1위)
- **Bachelor of Engineering Honours (Mechanical)** - $58,000-$62,000 / IELTS 6.5 / 91+ + 수학/물리 (EA)
- **Bachelor of Engineering Honours (Electrical)** - $58,000-$62,000 / IELTS 6.5 / 91+ + 수학 (EA)
- **Bachelor of Engineering Honours (Software)** - $58,000-$62,000 / IELTS 6.5 / 91+ + 수학 (EA + ACS / 미래 트렌드)
- **Bachelor of Engineering Honours (Aerospace)** - $58,000-$62,000 / IELTS 6.5 / 91+ + 수학/물리 (UNSW 호주 1위)
- **Bachelor of Computer Science** - $54,000-$58,000 / IELTS 6.5 / 90+ (ACS / 미래 트렌드)
- **Bachelor of Information Systems** - $52,000-$56,000 / IELTS 6.5 / 88+ (XXX)
- **Bachelor of Quantum Engineering** - $58,000-$62,000 / IELTS 6.5 / 95+ (UNSW 호주 유일)
- **Bachelor of Medicine and Surgery (BMed/MD)** - $80,000-$92,000 / IELTS 7.0 / 96+ + UCAT/ISAT (AHPRA 2026.04.23 / 6년 통합)
- **Bachelor of Nursing** - $52,000-$56,000 / IELTS 7.0 / 88+ (NMBA 2026.04.23)
- **Bachelor of Optometry** - $58,000-$62,000 / IELTS 7.0 / 95+ (AHPRA)
- **Bachelor of Psychology (Honours)** - $52,000-$56,000 / IELTS 6.5 / 88+ (AHPRA)
- **Bachelor of Laws (LLB)** - $58,000-$62,000 / IELTS 7.0 / 96+ (XXX)
- **Bachelor of Arts** - $44,000-$50,000 / IELTS 7.0 / 80+ (XXX)
- **Bachelor of Social Work** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 85+ (⛔ AASW IELTS only)
- **Bachelor of International Studies** - $48,000-$52,000 / IELTS 7.0 / 88+ (XXX)
- **Bachelor of Science** - $52,000-$56,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Advanced Science (Honours)** - $52,000-$56,000 / IELTS 6.5 / 95+ (4년 / 트랙)
- **Bachelor of Architectural Studies** - $52,000-$56,000 / IELTS 6.5 / 88+ (XXX)
- **Bachelor of Design** - $50,000-$54,000 / IELTS 6.5 / 85+ (XXX)

**Master (28개)**

- **MBA (AGSM)** - $84,500-$87,500 / IELTS 7.0 / 학사 + 경력 5년+ (/ 12개월)
- **Master of Commerce** - $54,000-$58,000 / IELTS 7.0 / Commerce 학사 (XXX)
- **Master of Finance** - $54,000-$58,000 / IELTS 7.0 / Finance 학사 (XXX)
- **Master of Professional Accounting** - $54,000-$58,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Actuarial Studies** - $54,000-$58,000 / IELTS 7.0 / Math/Stats 학사 (UNSW 호주 1위)
- **Master of Information Technology** - $52,000-$56,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Cybersecurity** - **$50,000** / IELTS 6.5 / 학사 (USyd $52K보다 $2K 저렴)
- **Master of Data Science** - $54,000-$58,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Computing** - $54,000-$58,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Quantum Computing** - $54,000-$58,000 / IELTS 6.5 / 학사 (UNSW 호주 유일)
- **Master of Engineering Science (Civil)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Mechanical)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Electrical)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Petroleum)** - $54,000-$58,000 / IELTS 6.5 / 학사 (UNSW)
- **Master of Engineering (Project Management)** - $54,000-$58,000 / IELTS 6.5 / 학사 (XXX)
- **Doctor of Medicine (MD)** - $87,000-$92,000 / IELTS 7.0 / BMed 4년 후 진행 (AHPRA 2026.04.23 / 통합 6년)
- **Master of Nursing (Graduate Entry)** - $52,000-$56,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $37,000-$42,000 / IELTS 6.5 / 학사 (학비)
- **Master of Health Management** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Psychology** - $52,000-$56,000 / IELTS 7.0 / Psych 학사 (AHPRA)
- **Juris Doctor (JD)** - $58,000-$62,000 / IELTS 7.0 / 학사 + LSAT (XXX)
- **Master of Laws (LLM)** - $50,000-$54,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $48,000-$52,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $48,000-$52,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Social Work (Qualifying)** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Architecture** - $54,000-$58,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **Master of Urban Policy and Strategy** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **PhD (모든 분야)** - $32,000-$48,000 / IELTS 6.5 / 석사 + 연구 (RTP 장학금)

---

#### UOW (울런공 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Engineering (Honours)** - $42-48K / IELTS 6.5 (각 6.0) / 80+ (Mechanical/Civil/Electrical/Mechatronic - 4년 / $42-48K BlueScope 산학)
- **Bachelor of Computer Science** - $42K / IELTS 6.5 (각 6.0) / 80+ (3년 / $42K)
- **Bachelor of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 80+ (3년 / $42K)
- **Bachelor of Cybersecurity** - $42K / IELTS 6.5 (각 6.0) / 80+ (3년 / $42K)
- **Bachelor of Business** - $35K / IELTS 6.5 (각 6.0) / 80+ (3년 / $35K)
- **Bachelor of Commerce** - $35K / IELTS 6.5 (각 6.0) / 80+ (3년 / $35K)
- **Bachelor of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 80+ (3년 / $38K (NMBA 인증))
- **Bachelor of Psychology** - $36K / IELTS 6.5 (각 6.0) / 80+ (4년 / $36K)

**Master (6개)**

- **Master of Engineering** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K)
- **Master of Computer Science** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K)
- **Master of Cybersecurity** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $48K NSW Regional + IT 직결 PR)
- **Master of Information Technology** - $44K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $44K)
- **Master of Business Administration (MBA)** - $42-50K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42-50K)
- **Master of Professional Accounting** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K (CPA 인증))

---

#### UQ
*국립*

**총 5개 학과**

**Bachelor (5개)**

- **Occupational Therapy (Bachelor OT 4년 2026)** - $54,224/년 / IELTS 7.0 (AHPRA 의료 표준) / UQ: $54,224/년 / Cat 2 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2)
- **Speech Pathology (Bachelor Speech 4년 2026)** - $54,224/년 / IELTS 7.0 (AHPRA 의료 표준) / UQ: $54,224/년 / Cat 2 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2)
- **Dental (Direct Bachelor Dentistry 5년 2)** - $86,400/년 / IELTS 7.0 (AHPRA 의료 표준) / UQ: $86,400/년 × 5 = $432K / Brisbane Cat 2 / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $48,720/년 / IELTS 6.5 / UQ: $48,720/년 / Cat 2 / PR MLTSSL (Psychologist 272311 (MLTSSL) / Cat 2)
- **Social Work (Bachelor Social Work 4년 2026)** - $48,720/년 / IELTS 6.5 / UQ: $48,720/년 / Cat 2 / PR MLTSSL (Social Worker 272511 (MLTSSL) / Cat 2)

---

#### UQ (퀸즐랜드 대학교)
*국립 (Go8)*

**총 48개 학과**

**Bachelor (22개)**

- **Bachelor of Business Management** - $48,000-$52,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Commerce** - $48,000-$52,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Economics** - $48,000-$52,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Accounting** - $48,000-$52,000 / IELTS 7.0 / 80+ (CPA 등록)
- **Bachelor of Engineering Honours (Civil)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA)
- **Bachelor of Engineering Honours (Mechanical)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학/물리 (EA)
- **Bachelor of Engineering Honours (Electrical)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA)
- **Bachelor of Engineering Honours (Software)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (EA + ACS)
- **Bachelor of Engineering Honours (Mining)** - $52,000-$58,000 / IELTS 6.5 / 80+ + 수학 (UQ)
- **Bachelor of Computer Science** - $52,000-$58,000 / IELTS 6.5 / 80+ (ACS / 미래 트렌드)
- **Bachelor of Information Technology** - $48,000-$52,000 / IELTS 6.5 / 78+ (ACS)
- **Bachelor of Pharmacy (Honours)** - $58,000-$65,000 / IELTS 7.0 / 88+ + 화학 (UQ 세계 10)
- **Bachelor of Nursing** - $45,792 / IELTS 7.0 / 78+ (NMBA 2026.04.23)
- **Bachelor of Medicine and Surgery (MD 통합)** - $90,000-$94,856 / IELTS 7.0 / 95+ + UCAT/ISAT (AHPRA 2026.04.23)
- **Bachelor of Veterinary Science** - $74,000-$80,000 / IELTS 6.5 / 90+ + 과학 (UQ / 5년)
- **Bachelor of Health Sciences** - $48,000-$52,000 / IELTS 6.5 / 78+ (XXX)
- **Bachelor of Psychological Science** - $50,000-$54,000 / IELTS 6.5 / 85+ (AHPRA)
- **Bachelor of Laws (Honours)** - $52,000-$56,000 / IELTS 7.0 / 95+ (XXX)
- **Bachelor of Arts** - $37,792-$44,000 / IELTS 6.5 / 75+ (가장 저렴)
- **Bachelor of Social Work (Honours)** - $44,000-$48,000 / IELTS 7.0 (모든 7.0) / 80+ (⛔ AASW = IELTS only)
- **Bachelor of Science** - $50,000-$54,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Agribusiness** - $46,000-$50,000 / IELTS 6.5 / 78+ (Gatton 캠퍼스)

**Master (26개)**

- **MBA (UQ Business School)** - $69,112 / IELTS 7.0 / 학사 + 경력 4년+ (QS 30)
- **Master of Business** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Commerce** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Professional Accounting** - $48,000-$52,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Information Technology** - $48,000-$52,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Computer Science** - $54,000-$58,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Cyber Security** - $54,000-$58,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Data Science** - $58,056 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Quantum Technology** - $54,000-$58,000 / IELTS 6.5 / 학사 (UQ)
- **Master of Engineering Science (Civil)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Mechanical)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Electrical)** - $54,000-$58,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Science (Mining)** - $54,000-$58,000 / IELTS 6.5 / 학사 (UQ)
- **Doctor of Medicine (MD)** - $93,000-$104,120 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23)
- **Master of Pharmacy** - $58,000-$65,000 / IELTS 7.0 / 약학 학사 (UQ 세계 10)
- **Master of Nursing** - $48,000-$52,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $42,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Physiotherapy Studies** - $54,000-$58,000 / IELTS 7.0 / 관련 학사 (AHPRA 2026.04.23)
- **Master of Animal Science** - $48,000-$52,000 / IELTS 6.5 / 학사 (UQ)
- **Juris Doctor (JD)** - $52,000-$56,000 / IELTS 7.0 / 학사 + LSAT (XXX)
- **Master of Laws (LLM)** - $48,000-$52,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $42,000-$48,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $42,000-$48,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Social Work Studies** - $44,000-$48,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Architecture** - $48,000-$52,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **PhD (모든 분야)** - $32,000-$48,000 / IELTS 6.5 / 석사 + 연구 (RTP 장학 / VC Excellence $25K)

---

#### USC Sunshine Coast
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $31,030/년 / IELTS 7.0 (AHPRA 의료 표준) / USC Sunshine Coast: $31,030/년 (Bachelor 기준) / Cat 2 (호주 저렴) / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2)
- **Bachelor of Nursing (Direct 3년)** - $31,030/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $31,030/년 / Cat 2 +15 PR / 800시간 임상 (호주 저렴 Bachelor))

---

#### USyd
*국립*

**총 7개 학과**

**Bachelor (7개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $61,000/년 / IELTS 7.0 (AHPRA 의료 표준) / USyd: $61,000/년 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL))
- **Physiotherapy (Bachelor PT 4년 2026)** - $58,500/년 / IELTS 7.0 (AHPRA 의료 표준) / USyd: $58,500/년 / PR MLTSSL (Physiotherapist 252511 (MLTSSL))
- **Occupational Therapy (Bachelor OT 4년 2026)** - $58,500/년 / IELTS 7.0 (AHPRA 의료 표준) / USyd: $58,500/년 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL))
- **Speech Pathology (Bachelor Speech 4년 2026)** - $58,500/년 / IELTS 7.0 (AHPRA 의료 표준) / USyd: $58,500/년 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL))
- **Radiography (Bachelor Medical Imaging 4년 20)** - $58,500/년 / IELTS 6.5 / USyd: $58,500/년 / Cat 1 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 1)
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $58,500/년 / IELTS 6.5 / USyd: $58,500/년 / PR MLTSSL (Psychologist 272311 (MLTSSL))
- **Social Work (Bachelor Social Work 4년 2026)** - $58,500/년 / IELTS 6.5 / USyd: $58,500/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### USyd / Sydney Uni (시드니 대학교)
*국립 (Go8)*

**총 53개 학과**

**Bachelor (25개)**

- **Bachelor of Commerce** - $53,600-$57,000 / IELTS 7.0 / 90+ (Accounting/Finance/Marketing 多전공)
- **Bachelor of Economics** - $52,000-$55,000 / IELTS 7.0 / 90+ (XXX)
- **Bachelor of Engineering Honours (Civil)** - $58,000-$60,600 / IELTS 6.5 / 90+ + 수학/과학 (EA 등록)
- **Bachelor of Engineering Honours (Mechanical)** - $58,000-$60,600 / IELTS 6.5 / 90+ + 수학/물리 (EA 등록)
- **Bachelor of Engineering Honours (Electrical)** - $58,000-$60,600 / IELTS 6.5 / 90+ + 수학 (EA 등록)
- **Bachelor of Engineering Honours (Software)** - $58,000-$60,600 / IELTS 6.5 / 90+ + 수학 (EA + ACS / 미래 트렌드)
- **Bachelor of Computer Science and Technology** - $54,000-$56,000 / IELTS 6.5 / 88+ (ACS / 미래 트렌드)
- **Bachelor of Nursing** - $54,000-$56,000 / IELTS 7.0 / 88+ (NMBA 2026.04.23 변경)
- **Bachelor of Pharmacy (Honours)** - $54,000-$56,000 / IELTS 7.0 / 90+ + 화학 (AHPRA 2026.04.23)
- **Bachelor of Medical Science** - $54,000-$58,000 / IELTS 6.5 / 88+ + 과학 (MD 패스웨이)
- **Bachelor of Science (Health)** - $54,000-$58,000 / IELTS 6.5 / 88+ (MD 패스웨이)
- **Bachelor of Oral Health** - $74,000-$80,000 / IELTS 7.0 / 90+ (AHPRA 2026.04.23)
- **Bachelor of Psychology (Honours)** - $54,000-$56,000 / IELTS 6.5 / 88+ (AHPRA)
- **Bachelor of Laws (LLB)** - $58,000-$60,000 / IELTS 7.0 / 95+ (USyd Law 호주 1위)
- **Bachelor of Arts (BA)** - $46,900-$54,000 / IELTS 7.0 / 80+ (XXX)
- **Bachelor of Arts (Honours)** - $46,900-$54,000 / IELTS 7.0 / 85+ (4년)
- **Bachelor of Social Work (Honours)** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 85+ (⛔ AASW IELTS only / OSR X)
- **Bachelor of Education (Early Childhood)** - $48,000-$52,000 / IELTS 7.5 (L8 S8 R7 W7) / 85+ (⛔ ACECQA = IELTS만)
- **Bachelor of International Studies** - $48,000-$52,000 / IELTS 7.0 / 88+ (XXX)
- **Bachelor of Science** - $54,000-$58,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Veterinary Biology / DVM** - $74,000-$80,000 / IELTS 7.0 / 95+ (6년 통합 /)
- **Bachelor of Design Computing** - $52,000-$56,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Architecture and Environments** - $52,000-$56,000 / IELTS 6.5 / 85+ (XXX)
- **Bachelor of Music (Performance)** - $42,000-$46,000 / IELTS 6.5 / 80+ + 오디션 / PR - (XXX)
- **Bachelor of Visual Arts** - $42,000-$46,000 / IELTS 6.5 / 80+ + 포트폴리오 / PR - (XXX)

**Master (28개)**

- **MBA (USyd Business School)** - $90,000-$93,500 / IELTS 7.0 / 학사 + 경력 4년+ (XXX)
- **Master of Commerce** - $54,000-$58,000 / IELTS 7.0 / Commerce 학사 (XXX)
- **Master of Management (CEMS)** - $54,000-$58,000 / IELTS 7.0 / 학사 (글로벌 네트워크)
- **Master of International Business** - $54,000-$58,000 / IELTS 7.0 / 학사 (XXX)
- **Master of Professional Accounting** - $54,000-$58,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Finance** - $54,000-$58,000 / IELTS 7.0 / Finance 학사 (XXX)
- **Master of Information Technology** - $54,000-$58,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Cybersecurity** - $52,000-$54,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Data Science** - $54,000-$58,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Computing** - $54,000-$58,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Engineering (Civil)** - $54,000-$57,900 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Engineering (Mechanical)** - $54,000-$57,900 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Engineering (Electrical)** - $54,000-$57,900 / IELTS 6.5 / 학사 (EA 등록)
- **Master of Professional Engineering** - $54,000-$57,900 / IELTS 6.5 / 학사 (전공 X) (EA 등록 / 전공 변경 가능)
- **Doctor of Medicine (MD)** - $93,000-$100,000 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23)
- **Master of Nursing (Graduate Entry)** - $54,000-$57,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Pharmacy** - $54,000-$58,000 / IELTS 7.0 / 학사 (AHPRA 2026.04.23)
- **Master of Physiotherapy** - $54,000-$58,000 / IELTS 7.0 / 관련 학사 (AHPRA 2026.04.23)
- **Master of Public Health** - $48,000-$54,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Psychology** - $52,000-$56,000 / IELTS 7.0 / Psych 학사 (AHPRA)
- **Juris Doctor (JD)** - $58,000-$60,000 / IELTS 7.0 / 학사 + LSAT (USyd Law 1위)
- **Master of Laws (LLM)** - $50,000-$55,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $48,000-$54,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Social Work (Qualifying)** - $48,000-$52,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Architecture** - $54,000-$57,900 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **Master of Urban Planning** - $48,000-$52,000 / IELTS 6.5 / 학사 (XXX)
- **PhD (모든 분야)** - $40,000-$50,000 / IELTS 6.5 / 석사 + 연구 계획서 (PRS 장학금)

---

#### USyd Master Direct
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Dental (Direct Bachelor Dentistry 5년 2)** - $89,500/년 / IELTS 7.0 (AHPRA 의료 표준) / USyd Master Direct: $89,500/년 × 4 = $358K / Cat 1 / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 1)

---

#### USyd USydney
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $52,500/년 / IELTS 7.0 (NMBA 표준) / Cat 1 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $52,500/년 / Sydney Cat 1)

---

#### UTAS (태즈메이니아 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Marine and Antarctic Science** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K 호주 1위)
- **Bachelor of Medicine MBBS** - $70-80K / IELTS 6.5 (각 6.0) / 70+ (5년 / $70-80K 학부 직접 5년)
- **Bachelor of Pharmacy** - $40K / IELTS 6.5 (각 6.0) / 70+ (4년 / $40K)
- **Bachelor of Nursing** - $36K / IELTS 7.0 / 70+ (3년 / $36K (NMBA / IELTS 7.0))
- **Bachelor of Engineering (Honours)** - $38K / IELTS 6.5 (각 6.0) / 70+ (4년 / $38K)
- **Bachelor of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Business** - $30K / IELTS 6.5 (각 6.0) / 70+ (3년 / $30K (TIS 25% = $22.5K 호주 최저))
- **Bachelor of Maritime Engineering (Launceston)** - $42K / IELTS 6.5 (각 6.0) / 70+ (4년 / $42K)

**Master (6개)**

- **Master of Marine and Antarctic Science** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K 호주 1위)
- **Master of Information Technology** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Engineering** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $42K)
- **Master of Business Administration (MBA)** - $40-46K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40-46K)
- **Master of Professional Accounting** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K (CPA 인증))
- **Master of Nursing** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K)

---

#### UTAS College
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of University Studies** - Foundation $24,000-$30,000 / Diploma $26,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ University of Tasmania (UTAS) 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $24,000-$30,000 / Diploma $26,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ University of Tasmania (UTAS) 학사 2학년 직진)

---

#### UTAS Hobart Launceston
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $36,950/년 / IELTS 7.0 (NMBA 표준) / Cat 3 +5 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $36,950/년 / Cat 3 +5 PR)

---

#### UTS (시드니 공과대학교)
*국립*

**총 49개 학과**

**Bachelor (23개)**

- **Bachelor of Business** - $42,000-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Accounting** - $42,000-$48,000 / IELTS 7.0 / 75+ (CPA 등록)
- **Bachelor of Economics** - $42,000-$48,000 / IELTS 6.5 / 78+ (XXX)
- **Bachelor of Engineering Honours (Civil)** - $48,000-$54,000 / IELTS 6.5 / 75+ + 수학 (EA)
- **Bachelor of Engineering Honours (Mechanical)** - $48,000-$54,000 / IELTS 6.5 / 75+ + 수학/물리 (EA)
- **Bachelor of Engineering Honours (Electrical)** - $48,000-$54,000 / IELTS 6.5 / 75+ + 수학 (EA)
- **Bachelor of Engineering Honours (Software)** - $48,000-$54,000 / IELTS 6.5 / 75+ + 수학 (EA + ACS)
- **Bachelor of Engineering Honours (Diploma in Professional Engineering Practice)** - $48,000-$56,000 / IELTS 6.5 / 75+ + 수학 (산업 실습 1년 추가 (4+1))
- **Bachelor of Information Technology** - $46,000-$50,000 / IELTS 6.5 / 70+ (ACS / 미래 트렌드)
- **Bachelor of Computing Science** - $46,000-$50,000 / IELTS 6.5 / 75+ (ACS)
- **Bachelor of Nursing** - $44,000-$48,000 / IELTS 7.0 / 70+ (NMBA 2026.04.23)
- **Bachelor of Health Science** - $40,000-$44,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Sport and Exercise Science** - $42,000-$46,000 / IELTS 6.5 / 70+ (UTS)
- **Bachelor of Laws (LLB)** - $46,000-$52,000 / IELTS 7.0 / 88+ (XXX)
- **Bachelor of Communication (Media Arts and Production)** - $36,000-$44,000 / IELTS 6.5 / 75+ (UTS)
- **Bachelor of Communication (Journalism)** - $36,000-$44,000 / IELTS 6.5 / 75+ (UTS 호주)
- **Bachelor of Communication (Advertising)** - $36,000-$44,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Design in Animation** - $44,000-$52,000 / IELTS 6.5 / 75+ + 포트폴리오 (UTS)
- **Bachelor of Design in Visual Communication** - $44,000-$52,000 / IELTS 6.5 / 75+ + 포트폴리오 (XXX)
- **Bachelor of Design in Interior Architecture** - $44,000-$52,000 / IELTS 6.5 / 75+ + 포트폴리오 (XXX)
- **Bachelor of Architecture and Environments** - $44,000-$52,000 / IELTS 6.5 / 75+ + 포트폴리오 (XXX)
- **Bachelor of Science** - $44,000-$48,000 / IELTS 6.5 / 70+ (XXX)
- **Bachelor of Forensic Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (UTS)

**Master (26개)**

- **MBA (UTS Business School)** - $52,000-$58,000 / IELTS 7.0 / 학사 + 경력 3년+ (1년 4회 입학)
- **Executive MBA** - $58,000-$64,440 / IELTS 7.0 / 학사 + 경력 5년+ (XXX)
- **Master of Business Administration (Entrepreneurship)** - $52,000-$58,000 / IELTS 7.0 / 학사 + 경력 (XXX)
- **Master of Professional Accounting** - $42,000-$48,000 / IELTS 7.0 / 학사 (CPA 등록)
- **Master of Business Analytics** - $46,000-$52,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Information Technology** - $42,000-$48,000 / IELTS 6.5 / 학사 (ACS / 미래 트렌드)
- **Master of Data Science and Innovation** - $46,000-$52,000 / IELTS 6.5 / Math/CS 학사 (UTS)
- **Master of Artificial Intelligence** - $46,000-$52,000 / IELTS 6.5 / CS 학사 (미래 트렌드)
- **Master of Cybersecurity** - $46,000-$52,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Engineering (Civil)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Mechanical)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Electrical)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering Management** - $48,000-$54,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Biomedical Engineering** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA / UTS)
- **Master of Nursing** - $42,000-$46,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23)
- **Master of Public Health** - $40,000-$44,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Pharmacy** - $48,000-$52,000 / IELTS 7.0 / 약학 학사 (AHPRA 2026.04.23)
- **Juris Doctor (JD)** - $46,000-$52,000 / IELTS 7.0 / 학사 + LSAT (XXX)
- **Master of Laws (LLM)** - $42,000-$48,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $40,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $40,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Social Work** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Animation and Visualisation** - $46,000-$52,000 / IELTS 6.5 / 학사 + 포트폴리오 (UTS)
- **Master of Design** - $44,000-$48,000 / IELTS 6.5 / 관련 학사 (XXX)
- **Master of Architecture** - $46,000-$52,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **PhD (모든 분야)** - $35,000-$48,000 / IELTS 6.5 / 석사 + 연구 (UTS Research Excellence 장학)

---

#### UTS College
*패스웨이*

**총 3개 학과**

**Diploma (1개)**

- **Diploma → UTS 학사 2학년** - {'Foundation': '$33,000-$38,000', 'Diploma': '$36,000-$42,000', 'EAP': '$5,500-$ / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK / 한국 대학 1학년 편입 (→ University of Technology Sydne 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - {'Foundation': '$33,000-$38,000', 'Diploma': '$36,000-$42,000', 'EAP': '$5,500-$ / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK / 한국 대학 1학년 편입 (→ University of Technology Sydne 학사 2학년 직진)

**EAP (1개)**

- **EAP English Pathway** - {'Foundation': '$33,000-$38,000', 'Diploma': '$36,000-$42,000', 'EAP': '$5,500-$ / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK / 한국 대학 1학년 편입 (→ University of Technology Sydne 학사 2학년 직진)

---

#### UTS Sydney
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Bachelor of Nursing (Direct 3년)** - $48,832/년 / IELTS 7.0 (NMBA 표준) / Cat 1 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $48,832/년 / Sydney Cat 1)

---

#### UWA (서호주 대학교)
*국립 (Go8)*

**총 44개 학과**

**Bachelor (20개)**

- **Bachelor of Commerce** - $44,000-$48,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Economics** - $44,000-$48,000 / IELTS 6.5 / 80+ (XXX)
- **Bachelor of Accounting** - $44,000-$48,000 / IELTS 7.0 / 80+ (CPA 등록 + Regional +15)
- **Bachelor of Engineering Honours (Civil)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Mechanical)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학/물리 (EA + Regional +15)
- **Bachelor of Engineering Honours (Electrical)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + Regional +15)
- **Bachelor of Engineering Honours (Mining)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (UWA)
- **Bachelor of Engineering Honours (Software)** - $48,000-$54,000 / IELTS 6.5 / 80+ + 수학 (EA + ACS)
- **Bachelor of Computer Science** - $46,000-$50,000 / IELTS 6.5 / 78+ (ACS)
- **Bachelor of Information Technology** - $44,000-$48,000 / IELTS 6.5 / 75+ (ACS)
- **Bachelor of Pharmacy** - $54,000-$58,000 / IELTS 7.0 / 85+ + 화학 (AHPRA 2026.04.23)
- **Bachelor of Biomedical Science** - $44,000-$48,000 / IELTS 6.5 / 80+ (MD 패스)
- **Bachelor of Health Sciences** - $44,000-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Psychological Science** - $44,000-$48,000 / IELTS 6.5 / 80+ (AHPRA)
- **Bachelor of Arts** - $32,000-$40,000 / IELTS 6.5 / 70+ (UWA 가장 저렴)
- **Bachelor of Social Work (Honours)** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 75+ (⛔ AASW = IELTS only)
- **Bachelor of Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (XXX)
- **Bachelor of Marine Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (UWA 세계)
- **Bachelor of Agricultural Science** - $44,000-$48,000 / IELTS 6.5 / 75+ (세계 50)
- **Bachelor of Design** - $42,000-$46,000 / IELTS 6.5 / 75+ (XXX)

**Master (24개)**

- **MBA (UWA Business School)** - $58,000-$65,000 / IELTS 7.0 / 학사 + 경력 3년+ (XXX)
- **Master of Commerce** - $44,000-$48,000 / IELTS 6.5 / 학사 (XXX)
- **Master of Finance** - $44,000-$48,000 / IELTS 6.5 / Finance 학사 (XXX)
- **Master of Professional Accounting** - $44,000-$48,000 / IELTS 7.0 / 학사 (CPA + Regional +15)
- **Master of Information Technology** - $44,000-$48,000 / IELTS 6.5 / 학사 (ACS + Regional +15)
- **Master of Computer Science** - $48,000-$52,000 / IELTS 6.5 / CS 학사 (XXX)
- **Master of Data Science** - $48,000-$52,000 / IELTS 6.5 / Math/CS 학사 (미래 트렌드)
- **Master of Cybersecurity** - $48,000-$52,000 / IELTS 6.5 / 학사 (미래 트렌드)
- **Master of Professional Engineering** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA + Regional +15)
- **Master of Engineering (Civil)** - $48,000-$54,000 / IELTS 6.5 / 학사 (EA)
- **Master of Engineering (Mining)** - $48,000-$54,000 / IELTS 6.5 / 학사 (UWA)
- **Master of Engineering (Petroleum)** - $48,000-$54,000 / IELTS 6.5 / 학사 (UWA)
- **Doctor of Medicine (MD)** - $80,000-$92,900 / IELTS 7.0 / 학사 + GAMSAT (AHPRA 2026.04.23)
- **Master of Nursing Science** - $44,000-$48,000 / IELTS 7.0 / 학사 (NMBA 2026.04.23 + Regional +15)
- **Master of Pharmacy** - $54,000-$58,000 / IELTS 7.0 / 약학 학사 (AHPRA 2026.04.23)
- **Master of Public Health** - $42,000-$46,000 / IELTS 6.5 / 학사 (XXX)
- **Juris Doctor (JD)** - $48,000-$52,000 / IELTS 7.0 / 학사 + LSAT (XXX)
- **Master of Laws (LLM)** - $44,000-$48,000 / IELTS 7.0 / LLB (XXX)
- **Master of Teaching (Primary)** - $42,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 (⛔ AITSL = IELTS만)
- **Master of Teaching (Secondary)** - $42,000-$46,000 / IELTS 7.5 (L8 S8 R7 W7) / 학사 + 교과 (⛔ AITSL = IELTS만)
- **Master of Social Work** - $40,000-$44,000 / IELTS 7.0 (모든 7.0) / 학사 (⛔ AASW = IELTS only / OSR X)
- **Master of Architecture** - $44,000-$48,000 / IELTS 6.5 / 관련 학사 + 포트폴리오 (XXX)
- **Master of Environmental Science** - $44,000-$48,000 / IELTS 6.5 / 학사 (UWA 세계 50)
- **PhD (모든 분야)** - RTP 면제 / IELTS 6.5 / 석사 + 연구 (RTP = 학비 면제 + 생활비)

---

#### UWA Perth
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $50,400/년 / IELTS 7.0 (AHPRA 의료 표준) / UWA Perth: $50,400/년 / Cat 2 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2)

---

#### UniSA
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Occupational Therapy (Bachelor OT 4년 2026)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / UniSA: $44,800/년 / Cat 2 +15 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL) / Cat 2 +15)
- **Radiography (Bachelor Medical Imaging 4년 20)** - $44,800/년 / IELTS 6.5 / UniSA: $44,800/년 / Cat 2 +15 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 2 +15)

---

#### UniSC (구 USC) (선샤인 코스트 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Tourism / Hospitality** - $30K / IELTS 6.5 (각 6.0) / 65+ (3년 / $30K Sunshine Coast 관광지)
- **Bachelor of Environmental Science / Climate Action** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K 호주 1위 Climate Action)
- **Bachelor of Sport Science / Exercise Science** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K Olympic 50m 풀 + Lightning)
- **Bachelor of Nursing** - $30K / IELTS 7.0 / 65+ (3년 / $30K (NMBA / IELTS 7.0))
- **Bachelor of Education (Primary/Secondary)** - $28K / IELTS 7.5 (AITSL) / 65+ (4년 / $28K (AITSL IELTS 7.5))
- **Bachelor of Business / Marketing** - $28K / IELTS 6.5 (각 6.0) / 65+ (3년 / $28K)
- **Bachelor of Information Technology** - $30K / IELTS 6.5 (각 6.0) / 65+ (3년 / $30K)
- **Bachelor of Animal Ecology** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K 100 ha 야생동물 보호구 캠퍼스)

**Master (6개)**

- **Master of Tourism Management** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K Sunshine Coast)
- **Master of Environmental Management / Climate Action** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K 호주 1위)
- **Master of Sport Management** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K)
- **Master of Nursing** - $32K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $32K (NMBA))
- **Master of Teaching (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $30K AITSL 호주·한국 교사)
- **Master of Business Administration (MBA)** - $36-40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36-40K)

---

#### UniSQ (구 USQ / 2022년 리브랜드) (남부 퀸즐랜드 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Aviation** - $36K / IELTS 6.5 (각 6.0) / 65+ (3-4년 / $36K 호주 유일 Boeing 737 + Airbus A320 시뮬레이터)
- **Bachelor of Engineering (Agricultural / Mechanical)** - $36K / IELTS 6.5 (각 6.0) / 65+ (4년 / $36K John Deere 협력)
- **Bachelor of Education (Primary/Secondary)** - $30K / IELTS 7.5 (AITSL) / 65+ (4년 / $30K (AITSL IELTS 7.5))
- **Bachelor of Nursing** - $32K / IELTS 7.0 / 65+ (3년 / $32K (NMBA / IELTS 7.0))
- **Bachelor of Science (Astronomy / Physics)** - $34K / IELTS 6.5 (각 6.0) / 65+ (3년 / $34K NASA TESS 협력)
- **Bachelor of Information Technology** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K (ACS 인증))
- **Bachelor of Business / Accounting** - $28K / IELTS 6.5 (각 6.0) / 65+ (3년 / $28K (CPA 인증))
- **Bachelor of Creative Arts (Film & TV)** - $32K / IELTS 6.5 (각 6.0) / 65+ (3년 / $32K Springfield 라디오·TV 스튜디오)

**Master (6개)**

- **Master of Engineering (Agricultural / Civil)** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)
- **Master of Teaching (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $32K AITSL 호주·한국 교사)
- **Master of Nursing** - $34K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $34K (NMBA))
- **Master of Information Technology** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K (ACS 인증))
- **Master of Business Administration (MBA)** - $36-42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36-42K)
- **Master of Astrophysics / Astronomy** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K NASA TESS)

---

#### Univ of Adelaide
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $51,500/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Adelaide: $51,500/년 / Cat 2 +15 (Eynesbury 패스웨이) / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2 +15)

---

#### Univ of Adelaide BDS
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Dental (Direct Bachelor Dentistry 5년 2)** - $86,500/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Adelaide BDS: $86,500/년 × 5 = $432K / Cat 2 +15 (Eynesbury 패스웨이) / PR MLTSSL (Dentist 252312 (MLTSSL) / Cat 2 +15)

---

#### Univ of Melbourne UMelb (Doctor)
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $54,176/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Melbourne UMelb (Doctor): $54,176/년 / Master만 / Cat 1 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 1)

---

#### Univ of Newcastle
*국립*

**총 5개 학과**

**Bachelor (5개)**

- **Midwifery (단일 Bachelor Midwifery 3년 2026)** - $40,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Newcastle: $40,800/년 / Cat 2 +15 PR + Tertiary Health Subsidy $12,000 / PR MLTSSL (Registered Midwife 254111 (MLTSSL) / Cat 2 +15)
- **Midwifery (Dual Bachelor Nursing Midwifer)** - $40,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Newcastle: $40,800/년 × 4년 / PR MLTSSL (Registered Midwife 254111 (MLTSSL))
- **Physiotherapy (Bachelor PT 4년 2026)** - $50,400/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Newcastle: $50,400/년 / Cat 2 +15 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2 +15)
- **Speech Pathology (Bachelor Speech 4년 2026)** - $40,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Newcastle: $40,800/년 / Cat 2 / PR MLTSSL (Speech Pathologist 252712 (MLTSSL) / Cat 2)
- **Radiography (Bachelor Medical Imaging 4년 20)** - $40,800/년 / IELTS 6.5 / Univ of Newcastle: $40,800/년 / Cat 2 / PR MLTSSL (Medical Radiation Therapist 251214 (MLTSSL) / Cat 2)

---

#### Univ of Queensland UQ
*국립*

**총 3개 학과**

**Bachelor (3개)**

- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $54,224/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Queensland UQ: $54,224/년 / Cat 2 / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 2)
- **Physiotherapy (Bachelor PT 4년 2026)** - $54,224/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Queensland UQ: $54,224/년 / Cat 2 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)
- **Bachelor of Nursing (Direct 3년)** - $45,792/년 / IELTS 7.0 (NMBA 표준) / Cat 2 +15 / PR MLTSSL (Registered Nurse 254418 (MLTSSL) / $45,792/년 / Brisbane Cat 2 +15 PR / IELTS 7.0 / Go8)

---

#### Univ of South Australia UniSA
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Physiotherapy (Bachelor PT 4년 2026)** - $44,800/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of South Australia UniSA: $44,800/년 / Cat 2 / PR MLTSSL (Physiotherapist 252511 (MLTSSL) / Cat 2)

---

#### Univ of Tasmania UTAS
*국립*

**총 2개 학과**

**Bachelor (2개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - IELTS 6.5 / Univ of Tasmania UTAS : 2년 fast-track (호주 유일!) / Hobart + Sydney 캠퍼스 / Cat 3 +5 / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 3 +5)
- **Pharmacy (Direct Bachelor Pharmacy 4년 20)** - $35,450-45,741/년 / IELTS 7.0 (AHPRA 의료 표준) / Univ of Tasmania UTAS: $35,450-45,741/년 / Cat 3 +5 (검증 패스웨이) / PR MLTSSL (Hospital Pharmacist 251513 (MLTSSL) / Cat 3 +5)

---

#### University of Newcastle College of International Education (UNCIE)
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / Engineering / IT** - Foundation $29,880 (2026 공식 - IDP 확인) / Diploma $32,000-$38,000 / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ University of Newcastle (UoN) 학사 2학년 직진)

**Foundation (1개)**

- **Foundation (2-3 Trimesters)** - Foundation $29,880 (2026 공식 - IDP 확인) / Diploma $32,000-$38,000 / IELTS Foundation 5.5 / Diploma 6.0 / 고2/고3/검정고시 OK (→ University of Newcastle (UoN) 학사 2학년 직진)

---

#### UoN / Newcastle (뉴캐슬 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Medicine (Joint Medical Program with UNE)** - $75-85K / IELTS 6.5 (각 6.0) / 75+ (5년 / $75-85K 호주 5개교만)
- **Bachelor of Engineering (Mining/Mechanical/Civil)** - $42-48K / IELTS 6.5 (각 6.0) / 75+ (4년 / $42-48K Hunter Valley)
- **Bachelor of Computer Science** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Nursing** - $38K / IELTS 7.0 (NMBA/AHPRA) / 75+ (3년 / $38K (NMBA 인증))
- **Bachelor of Pharmacy** - $45K / IELTS 6.5 (각 6.0) / 75+ (4년 / $45K)
- **Bachelor of Business** - $35K / IELTS 6.5 (각 6.0) / 75+ (3년 / $35K)
- **Bachelor of Information Technology** - $42K / IELTS 6.5 (각 6.0) / 75+ (3년 / $42K)
- **Bachelor of Architecture** - $42K / IELTS 6.5 (각 6.0) / 75+ (4년 / $42K)

**Master (6개)**

- **Master of Engineering (Mining/Mechanical)** - $48K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $48K Hunter Valley + Regional +15)
- **Master of Information Technology** - $44K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $44K)
- **Master of Business Administration (MBA)** - $42-50K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42-50K)
- **Master of Professional Accounting** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K (CPA 인증))
- **Master of Nursing** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)
- **Master of Public Health** - $42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42K)

---

#### VU (빅토리아 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Sport Science / Exercise Science** - $34K / IELTS 6.5 (각 6.0) / 60+ (3년 / $34K 세계 6위 Shanghai Ranking)
- **Bachelor of Hospitality / Tourism Management** - $30K / IELTS 6.5 (각 6.0) / 60+ (3년 / $30K Melbourne 호텔)
- **Bachelor of Nursing** - $32K / IELTS 7.0 / 60+ (3년 / $32K (NMBA / IELTS 7.0))
- **Bachelor of Education (Primary/Secondary)** - $28K / IELTS 7.5 (AITSL) / 60+ (4년 / $28K (AITSL IELTS 7.5))
- **Bachelor of Cyber Security / IT** - $32K / IELTS 6.5 (각 6.0) / 60+ (3년 / $32K Cisco Training Centre 호주)
- **Bachelor of Engineering** - $34K / IELTS 6.5 (각 6.0) / 60+ (4년 / $34K)
- **Bachelor of Business / Accounting** - $28K / IELTS 6.5 (각 6.0) / 60+ (3년 / $28K (CPA 인증))
- **Bachelor of Health Science (Biomedicine)** - $32K / IELTS 6.5 (각 6.0) / 60+ (3년 / $32K)

**Master (6개)**

- **Master of Sport Science** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K 세계 6위)
- **Master of Information Technology / Cyber Security** - $36K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36K)
- **Master of Teaching (Primary/Secondary)** - $32K / IELTS 7.5 (AITSL) / 학사 학위 (1.5-2년 / $32K (AITSL IELTS 7.5))
- **Master of Business Administration (MBA)** - $36-42K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $36-42K)
- **Master of Nursing** - $34K / IELTS 7.0 (NMBA/AHPRA) / 학사 학위 (1.5-2년 / $34K (NMBA))
- **Master of Hospitality / Event Management** - $34K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $34K)

---

#### Victoria Univ
*국립*

**총 1개 학과**

**Bachelor (1개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $32,400/년 / IELTS 6.5 / Victoria Univ: $32,400/년 / Cat 1 / PR MLTSSL (Ambulance Officer 411111 (MLTSSL) / Cat 1)

---

#### WSU / Western (웨스턴 시드니 대학교)
*국립*

**총 14개 학과**

**Bachelor (8개)**

- **Bachelor of Sustainable Development** - $36K / IELTS 6.5 (각 6.0) / 70+ (3년 / $36K THE 세계 1위)
- **Bachelor of Engineering (Civil/Mechanical/Mechatronic)** - $42K / IELTS 6.5 (각 6.0) / 70+ (4년 / $42K)
- **Bachelor of Nursing** - $35K / IELTS 7.0 (NMBA/AHPRA) / 70+ (3년 / $35K (NMBA 인증))
- **Bachelor of Information Technology** - $38K / IELTS 6.5 (각 6.0) / 70+ (3년 / $38K)
- **Bachelor of Business** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Construction Management** - $40K / IELTS 6.5 (각 6.0) / 70+ (4년 / $40K (Sydney 인프라 직결))
- **Bachelor of Communication** - $34K / IELTS 6.5 (각 6.0) / 70+ (3년 / $34K)
- **Bachelor of Education (Primary/Secondary)** - $36K / IELTS 7.5 (AITSL) / 70+ (4년 / $36K (AITSL IELTS 7.5))

**Master (6개)**

- **Master of Sustainable Development** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K 세계 1위)
- **Master of Information Technology** - $40K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $40K)
- **Master of Engineering** - $44K / IELTS 6.5 (각 6.0) / 학사 학위 (2년 / $44K)
- **Master of Business Administration (MBA)** - $42-48K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $42-48K)
- **Master of Professional Accounting** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K (CPA 인증))
- **Master of Nursing** - $38K / IELTS 6.5 (각 6.0) / 학사 학위 (1.5-2년 / $38K)

---

#### Western Sydney Univ
*국립*

**총 4개 학과**

**Bachelor (4개)**

- **Paramedicine (Bachelor Paramedicine 3년 2026)** - $39,600/년 / IELTS 6.5 / Western Sydney Univ: $39,600/년 / PR MLTSSL (Ambulance Officer 411111 (MLTSSL))
- **Occupational Therapy (Bachelor OT 4년 2026)** - $39,600/년 / IELTS 7.0 (AHPRA 의료 표준) / Western Sydney Univ: $39,600/년 / PR MLTSSL (Occupational Therapist 252411 (MLTSSL))
- **Counselling/Psychology (Bachelor Psychology 3년 2026)** - $39,600/년 / IELTS 6.5 / Western Sydney Univ: $39,600/년 / PR MLTSSL (Psychologist 272311 (MLTSSL))
- **Social Work (Bachelor Social Work 4년 2026)** - $39,600/년 / IELTS 6.5 / Western Sydney Univ: $39,600/년 / PR MLTSSL (Social Worker 272511 (MLTSSL))

---

#### Western Sydney University - The College (WSU College)
*패스웨이*

**총 2개 학과**

**Diploma (1개)**

- **Diploma of Business / IT / Engineering / Nursing** - Foundation $26,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Western Sydney University (WSU 학사 2학년 직진)

**Foundation (1개)**

- **Foundation** - Foundation $26,000-$30,000 / Diploma $28,000-$32,000 / IELTS Foundation 5.5 / Diploma 5.5-6 / 고2/고3/검정고시 OK (→ Western Sydney University (WSU 학사 2학년 직진)

---

#### ⚪ 공통 PR (다중 TAFE)
*TAFE PR 전공*

**총 8개 학과**

**Cert III/IV / Diploma (8개)**

- **1 IT Cyber Security** - IELTS 5.5-6.0 / 1 IT Cyber Security (ANZSCO 262112 (ICT Security Specialist) / 261313 (Software Engineer) | | 연봉 | 추천 TAFE:)
- **2 Hospitality Management** - IELTS 5.5-6.0 / 2 Hospitality Management (ANZSCO 141111 (Cafe Manager) / 141311 (Hotel Manager) | | 연봉 | 추천 TAFE:)
- **3 Construction Management** - IELTS 5.5-6.0 / 3 Construction Management (ANZSCO 133111 (Construction Project Manager) | | 연봉 | 추천 TAFE:)
- **4 Accounting** - IELTS 5.5-6.0 / 4 Accounting (ANZSCO 221111 (Accountant General) / 221112 (Management) | | 연봉 | 추천 TAFE:)
- **5 Engineering Trades** - IELTS 5.5-6.0 / 5 Engineering Trades (ANZSCO 다양 (322111 Sheetmetal / 322113 Engineer Production) | | 연봉 | 추천 TAFE:)
- **6 Veterinary Nurse 동물간호** - IELTS 5.5-6.0 / 6 Veterinary Nurse 동물간호 (ANZSCO 361311 (Veterinary Nurse) | | 연봉 | 추천 TAFE:)
- **7 Marine Boat Building 해양/조선** - IELTS 5.5-6.0 / 7 Marine Boat Building 해양/조선 (ANZSCO 323411 (Boat Builder/Repairer) | | 연봉 | 추천 TAFE:)
- **8 Aviation 항공** - IELTS 5.5-6.0 / 8 Aviation 항공 (ANZSCO 231114 (Pilot) / 323311 (Aircraft Maintenance Engineer) | | 연봉 | 추천 TAFE:)

---

#### 🔵 남자 PR (다중 TAFE)
*TAFE PR 전공*

**총 8개 학과**

**Cert III/IV / Diploma (8개)**

- **1 Electrician 전기** - IELTS 5.5-6.0 / 1 Electrician 전기 (ANZSCO 341111 (Electrician General) | | 연봉 | 추천 TAFE:)
- **2 Plumber 배관** - IELTS 5.5-6.0 / 2 Plumber 배관 (ANZSCO 334111 (Plumber General) | | 연봉 | 추천 TAFE:)
- **3 Carpenter 목수** - IELTS 5.5-6.0 / 3 Carpenter 목수 (ANZSCO 331212 (Carpenter) | | 연봉 | 추천 TAFE:)
- **4 Welder 용접** - IELTS 5.5-6.0 / 4 Welder 용접 (ANZSCO 322311 (Metal Fabricator) / 322312 (Pressure Welder) | | 연봉 | 추천 TAFE:)
- **5 Diesel Mechanic 디젤 정비** - IELTS 5.5-6.0 / 5 Diesel Mechanic 디젤 정비 (ANZSCO 321212 (Diesel Motor Mechanic) | | 연봉 | 추천 TAFE:)
- **6 Automotive Mechanic 자동차** - IELTS 5.5-6.0 / 6 Automotive Mechanic 자동차 (ANZSCO 321211 (Motor Mechanic General) | | 연봉 | 추천 TAFE:)
- **7 Bricklayer 벽돌공** - IELTS 5.5-6.0 / 7 Bricklayer 벽돌공 (ANZSCO 331111 (Bricklayer) | | 연봉 | 추천 TAFE:)
- **8 Chef 요리사** - IELTS 5.5-6.0 / 8 Chef 요리사 (ANZSCO 351311 (Chef) | | 연봉 | 추천 TAFE:)

---

#### 🟣 여자 PR (다중 TAFE)
*TAFE PR 전공*

**총 8개 학과**

**Cert III/IV / Diploma (8개)**

- **1 Registered Nurse 등록간호사** - IELTS 5.5-6.0 / 1 Registered Nurse 등록간호사 (ANZSCO 254418 (Registered Nurse - Surgical) / 254499 (Other) | | 연봉 | 추천 TAFE:)
- **2 Early Childhood Educator 유아교육** - IELTS 5.5-6.0 / 2 Early Childhood Educator 유아교육 (ANZSCO 241111 (Early Childhood Teacher) / 421111 (Child Care Worker) | | 연봉 | 추천 TAFE:)
- **3 Aged Care 노인돌봄** - IELTS 5.5-6.0 / 3 Aged Care 노인돌봄 (ANZSCO 423111 (Aged or Disabled Carer) | | 연봉 | 추천 TAFE:)
- **4 Hairdresser 헤어디자이너** - IELTS 5.5-6.0 / 4 Hairdresser 헤어디자이너 (ANZSCO 391111 (Hairdresser) | | 연봉 | 추천 TAFE:)
- **5 Beauty Therapist 미용/스킨케어** - IELTS 5.5-6.0 / 5 Beauty Therapist 미용/스킨케어 (ANZSCO 451815 (Beauty Therapist) | | 연봉 | 추천 TAFE:)
- **6 Massage Therapist 마사지치료** - IELTS 5.5-6.0 / 6 Massage Therapist 마사지치료 (ANZSCO 411611 (Massage Therapist) | | 연봉 | 추천 TAFE:)
- **7 Patisserie 파티시에/제과제빵** - IELTS 5.5-6.0 / 7 Patisserie 파티시에/제과제빵 (ANZSCO 351112 (Pastrycook) / 351111 (Baker) | | 연봉 | 추천 TAFE:)
- **8 Florist 플로리스트** - IELTS 5.5-6.0 / 8 Florist 플로리스트 (ANZSCO 639911 (Florist) | | 연봉 | 추천 TAFE:)

---

## Part 7. 홈스테이 / 정착

호주 11개 도시 홈스테이 검증.

- **AHN Sydney**: Traditional (2식 평일 + 3식 주말) Private: $410/주 / Traditional (2식 평일 + 3식 주말) Shared: $380/주 / Complete (3식 7일) Private: $445/주 한국 학생 多 선택
- **AHN Melbourne**: Traditional Private: $410/주 / Traditional Shared: $380/주 / Complete (3식 7일) Private: $440/주 한국 학생 표준
- **AHN Perth Cat2**: Complete (3식 7일) Private: $410/주 한국 학생 표준 / Complete Shared: $380/주 / Traditional Private: $380/주
- **AHN Brisbane Cat2**: Complete (3식) Private: 약 $400-430/주 (Sydney/Melbou / Traditional Private: 약 $370-400/주
- **AHN Adelaide Cat2**: Complete (3식) Private: 약 $390-420/주 (Adelaide 학비) / Traditional Private: 약 $360-390/주
- **AHN Gold Coast Cat2**: Complete (3식) Private: 약 $400-430/주 / Traditional Private: 약 $370-400/주
- **AHN Hobart Cat3 DRA**: Complete (3식) Private: 약 $380-410/주 (Tasmania 학비) / Traditional Private: 약 $350-380/주
- **AHN Cairns Cat3 DRA**: Complete (3식) Private: 약 $380-410/주 / Traditional Private: 약 $350-380/주
- **AHN Darwin Cat3 DRA**: Complete (3식) Private: 약 $370-400/주 (Darwin 저렴) / Traditional Private: 약 $340-370/주
- **AHN Canberra Cat2**: Complete (3식) Private: 약 $410-440/주 / Traditional Private: 약 $380-410/주
- **AHN Hawthorn Melbourne**: homestay 18plus: $440/주 (Complete) / homestay under 18: $460/주 / airport reception: $210 (편도)
